package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.model.*;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.model.dto.PartyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.io.output.*;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.testsupport.AuthContextTestSupport;
import com.abacogroup.workflow.server.db.ntt.WorLogTransitionWithDetailsEntity;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.model.Transition;
import com.abacogroup.workflow.server.model.WorkflowNode;
import com.abacogroup.workflow.server.services.exceptions.ProcessNotFoundException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;
import com.fasterxml.jackson.core.JsonToken;
import io.dropwizard.jackson.Jackson;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.HandleCallback;
import org.jdbi.v3.core.HandleConsumer;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import jakarta.ws.rs.core.SecurityContext;
import java.time.*;
import java.util.*;

import static com.abacogroup.agri.dossiers.core.services.AnomaliesService.WAIVED_DOSSIER_ERROR_CODE;
import static com.abacogroup.agri.dossiers.core.services.AnomaliesService.WAIVED_DOSSIER_ERROR_MSG;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@Slf4j
@ExtendWith(MockitoExtension.class)
class DossiersServiceTest {
	public static final String STATUS_2 = "status2";
	private static final Long FORM_ID_1 = 33L;
	private static final String FORM_CODE = "Form Code";
	private static final String FORM_NAME = "Form Name";
	private static final Long FORM_GROUP_ID_1 = 45L;
	private static final Long MODULE_FORM_CONFIG_ID_1 = 65L;
	private static final Long MODULE_PRINT_CONFIG_ID_1 = 10L;
	private static final String MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1 = "print param name";
	private static final String MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1 = "123456";
	public static final String STATUS_1 = "status1";
	@Mock
	private Jdbi jdbi;
	@Mock
	private DossiersWorkflowService dossiersWorkflowService;
	@Mock
	private PartyService partyService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private ModuleDetailsCrudService moduleDetailsCrudService;
	@Mock
	private DossierDetailsCrudService dossierDetailsCrudService;
	@Mock
	private DossiersCrudService dossiersCrudService;
	@Mock
	private ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	@Mock
	private DossierCompileStatusCrudService dossierCompileStatusCrudService;
	@Mock
	private DossierProfilesCrudService dossierProfilesCrudService;
	@Mock
	private ModuleProfilesCrudService moduleProfilesCrudService;
	@Mock
	private AnomaliesService anomaliesService;
	@Mock
	private CheckPartyService checkPartyService;
	@Mock
	private CreateProcessQueue createProcessQueue;
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;
	@Mock
	private SectorsCrudService sectorsCrudService;
	@Mock
	private FormConfigService formConfigService;
	@Mock
	private DossierProtocolsCrudService dossierProtocolsCrudService;
	@Mock
	private AmendmentService amendmentService;
	@Mock
	private ProgressService progressService;
	@Mock
	private PrintService printService;
	@Mock
	private Handle handle;
	@Mock
	private SecurityContext sc;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	@InjectMocks
	private DossiersService dossiersService;

	private static final String TENANT_1 = "tenant_1";
	private static final String NEXT_KEY = "1";
	private static final Long PARTY_ID_1 = 24L;
	private static final AbsoluteDate ABSOLUTE_DATE_1 = new AbsoluteDate("20200919");
	private static final String MODULE_CODE = "module_code_1";
	private static final String MODULE_CODE_DESC = "module_code_1_desc";
	private static final Long SECTOR_ID_1 = 12L;
	private static final String SECTOR_CODE = "sector_code_1";
	private static final String SECTOR_CODE_DESC = "sector_code_1_desc";
	private static final Integer YEAR_1 = 2022;
	private static final String DOSSIER_CODE = "code";
	private static final Long DOSSIER_ID_1 = 30L;
	private static final String TAG_NAME = "tag_name";
	private static final Long AMEND_OF_ID = 5L;
	private static final Long AMENDED_BY_ID = 15L;
	private static final String SCOPE = "scope";
	private static final String WORKFLOW_DESCRIPTION = "workflow description";
	private static final String PRINT_CODE_1 = "print code - 1";
	private static final Long MODULE_ID_1 = 1L;
	private static final Integer TRANSITION_ID = 5;
	private static final String NODE_FROM = "node from";
	private static final String NODE_TO = "node to";
	private static final String NOTES = "notes";
	private static final Integer REFERRED_YEAR = 2022; // LocalDateTime.now().getYear();
	private static final Long PROCESS_ID_1 = 1L;
	private static final String USER_1 = "user_1";
	private static final LocalDateTime NOW = LocalDateTime.now();
	private static final String PROTOCOL = "Protocol";
	private static final String PROCESS_STATUS = "start";
	private static final String PROCESS_STATUS_DESCRIPTION = "Inizio Workflow";
	private static final User logged_user1 = new User(USER_1, TENANT_1);
	private static final LocalDateTime DEFAULT_NOT_DELETED_DATE = LocalDateTime.ofInstant(Instant.ofEpochSecond(253402300799L), ZoneOffset.UTC);
	private static final String PROCESS_STATUS_1 = "status_1";
	private static final String DOSSIER_CODE_1 = "30";
	private static final String WORKFLOW_CODE_1 = "wf-code-1";
	private static final Long DOSSIER_DETAILS_ID_1 = 36L;
	private static final String PROFILE_CODE_1 = "code1";
	private static final AbsoluteDate DT_VALIDITY_START = new AbsoluteDate(LocalDate.now());
	private static final AbsoluteDate DT_VALIDITY_END = new AbsoluteDate(LocalDate.MAX);
	private static final String CONTEXT_FUNCTION = "context function";
	private static final Integer WORKFLOW_NODE_ID = 1;
	private static final String ACTION = "action";
	private static final String NAME = "name";
	private static final NodeType NODE_TYPE = NodeType.start;
	private static final Long PK_ID_1 = 1L;
	private static final String CUAA_1 = "0123213";
	private static final String DOSSIER_COMPILE_STATUS_1 = "compile-status-1";
	private static final String DOSSIER_COMPILE_STATUS_IDENTIFIER_1 = "compile-status-identifier-1";
	private static final LocalDateTime PRINT_DATE = LocalDateTime.of(2022, Month.JULY, 12, 14, 46, 49);
	private static final String FILE_ID = "123";
	private static final Integer FL_AMEND = 0;

	private static final ModuleByPointInTimeDTO MODULE_BY_POINT_IN_TIME_DTO = ModuleByPointInTimeDTO.builder()
			.moduleCode(MODULE_CODE)
			.moduleShortDescription(MODULE_CODE_DESC)
			.sectorCode(SECTOR_CODE)
			.sectorShortDescription(SECTOR_CODE_DESC)
			.year(YEAR_1)
			.build();
	private final DossierProfileDTO dossierProfileDTO = DossierProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.dossierId(DOSSIER_ID_1)
			.profileCodeDescription(PROFILE_CODE_1)
			.pkid(PK_ID_1)
			.build();
	private final DossierWithDetailsDTO dossierWithDetailsDTO = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.dossierCode(DOSSIER_CODE)
			.dtClosed(null)
			.processStatus(PROCESS_STATUS)
			.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.profileList(List.of(dossierProfileDTO))
			.amendmentDossierId(AMEND_OF_ID)
			.amendedDossierId(AMENDED_BY_ID)
			.build();

	private final DossierWithDetailsDTO closedDossierWithDetailsDTO = DossierWithDetailsDTO.builder()
			.dossierId(DOSSIER_ID_1)
			.moduleId(MODULE_ID_1)
			.referredYear(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.processId(PROCESS_ID_1)
			.dossierCode(DOSSIER_CODE)
			.dtClosed(LocalDateTime.now())
			.processStatus(PROCESS_STATUS)
			.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
			.userIdInsert(USER_1)
			.userIdDelete(null)
			.dtInsert(NOW)
			.dtDelete(DEFAULT_NOT_DELETED_DATE)
			.profileList(List.of(dossierProfileDTO))
			.amendmentDossierId(AMEND_OF_ID)
			.amendedDossierId(AMENDED_BY_ID)
			.build();
	private final DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
			.pkid(PK_ID_1)
			.processStatus(PROCESS_STATUS)
			.dossierCode(DOSSIER_CODE)
			.dossierId(DOSSIER_ID_1)
			.amendOfId(AMEND_OF_ID)
			.build();
	private final DossierDetailsDTO dossierDetailsDTONotInTransition = DossierDetailsDTO.builder()
			.flInTransition(0)
			.build();

	private final DossierDetailsDTO dossierDetailsDTOInTransition = DossierDetailsDTO.builder()
			.flInTransition(1)
			.build();

	private final DosByPartyAndYearDTO dossierByPartyAndYearDTOMock = DosByPartyAndYearDTO.builder()
			.dossierCode(DOSSIER_CODE_1)
			.dtClosed(null)
			.moduleCode(MODULE_CODE)
			.moduleDescription(MODULE_CODE_DESC)
			.partyId(PARTY_ID_1)
			.sectorCode(SECTOR_CODE)
			.sectorDescription(SECTOR_CODE_DESC)
			.year(YEAR_1)
			.processStatus(PROCESS_STATUS_1)
			.build();

	private static final ModuleProfileDTO moduleProfileDTO = ModuleProfileDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.moduleId(MODULE_ID_1)
			.pkid(PK_ID_1)
			.build();

	private static final SectorDTO sectorDTO = SectorDTO.builder()
			.tenantId(TENANT_1)
			.sectorCode(SECTOR_CODE)
			.sectorId(SECTOR_ID_1)
			.build();

	private static final ModuleWithDetailDTO moduleWithDetailDTO = ModuleWithDetailDTO.builder()
			.moduleId(MODULE_ID_1)
			.moduleCode(MODULE_CODE)
			.sectorId(SECTOR_ID_1)
			.contextFunction("")
			.build();

	private static final SectorPublicDTO sectorPublicDTO = SectorPublicDTO.builder()
			.sectorId(SECTOR_ID_1)
			.sectorCode(SECTOR_CODE)
			.build();

	private static final ModuleProfilePublicDTO moduleProfilePublicDTO = ModuleProfilePublicDTO.builder()
			.profileCode(PROFILE_CODE_1)
			.build();

	private static final ModuleDetailsDTO moduleDetailsDto = ModuleDetailsDTO.builder()
			.dtValidityStart(DT_VALIDITY_START)
			.dtValidityEnd(DT_VALIDITY_END)
			.annuality(YEAR_1)
			.contextFunction(CONTEXT_FUNCTION)
			.build();
	private final DossierOutDTO dossierOutDTO = DossierOutDTO.builder()
			.dossier(dossierWithDetailsDTO)
			.dossierDetail(dossierDetailsDTO)
			.build();
	private final FormDetailsPublicDTO formDetailsPublicDTO = FormDetailsPublicDTO.builder()
			.formCode(FORM_CODE)
			.formConfigId(FORM_ID_1)
			.formName(FORM_NAME)
			.build();
	private final FormWithGroupHierarchyPublicDTO formWithGroupHierarchyPublicDTO = FormWithGroupHierarchyPublicDTO.builder()
			.formDetails(formDetailsPublicDTO)
			.build();
	private final ModuleDTO moduleDTO = ModuleDTO.builder()
			.flAmendModule(false)
			.moduleCode(MODULE_CODE)
			.moduleId(MODULE_ID_1)
			.sectorId(SECTOR_ID_1)
			.workflowCode(WORKFLOW_CODE_1)
			.build();
	private final PartyDTO partyDTO = PartyDTO.builder()
			.partyId(PARTY_ID_1)
			.cuaa(CUAA_1)
			.build();
	private final LastPrintDTO lastPrintDTO = LastPrintDTO.builder()
			.printDate(PRINT_DATE)
			.fileId(FILE_ID)
			.build();
	private final PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
			.printCode(PRINT_CODE_1)
			.printConfigId(MODULE_PRINT_CONFIG_ID_1)
			.printDescription(PRINT_CODE_1)
			.sortOrder(1)
			.params(Map.of(MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1, MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1))
			.lastPrint(lastPrintDTO)
			.build();

	private final Map<String, Object> metadataMock = new HashMap<>();
	private final WorkflowNode workflowNodeMock = WorkflowNode.builder()
			.id(WORKFLOW_NODE_ID)
			.action(ACTION)
			.name(NAME)
			.type(NODE_TYPE)
			.metadata(metadataMock)
			.build();

	private final DossierDTO dossierDTO = DossierDTO.builder()
			.moduleId(MODULE_ID_1)
			.dossierId(DOSSIER_ID_1)
			.referredYear(YEAR_1)
			.partyId(PARTY_ID_1)
			.build();

	private final ModuleWithParamsPublicDTO moduleWithParamsPublicDTO = ModuleWithParamsPublicDTO.builder()
			.moduleCode(MODULE_CODE)
			.build();

	private final ProgressDossierDTO progressDossierDTO = ProgressDossierDTO.builder()
			.notes(NOTES)
			.build();

	private final WorkflowNodePublic workflowNodePublic = WorkflowNodePublic.builder()
			.name(NAME)
			.build();
	private final DossierByPartyDTO dossierByPartyDTO = DossierByPartyDTO.builder()
			.year(REFERRED_YEAR)
			.partyId(PARTY_ID_1)
			.dossierCode(DOSSIER_CODE)
			.sectorCode(SECTOR_CODE)
			.dossierId(DOSSIER_ID_1)
			.processId(PROCESS_ID_1)
			.moduleCode(MODULE_CODE)
			.moduleDescription(MODULE_CODE_DESC)
			.build();
	private final DosByPartyAndYearDTO dosByPartyAndYearDTO = DosByPartyAndYearDTO.builder()
			.partyId(PARTY_ID_1)
			.year(REFERRED_YEAR)
			.dossierId(DOSSIER_ID_1)
			.dossierCode(DOSSIER_CODE)
			.moduleCode(MODULE_CODE)
			.moduleDescription(MODULE_CODE_DESC)
			.sectorCode(SECTOR_CODE)
			.sectorDescription(SECTOR_CODE_DESC)
			.processStatus(PROCESS_STATUS)
			.build();

	@BeforeEach
	protected void init() {
		dossiersService = new DossiersService(
				jdbi,
				dossiersWorkflowService,
				checkPartyService,
				partyService,
				moduleCrudService,
				moduleDetailsCrudService,
				dossiersCrudService,
				dossierDetailsCrudService,
				dossierProfilesCrudService,
				dossierCompileStatusCrudService,
				moduleFormConfigsCrudService,
				moduleProfilesCrudService,
				modulePrintConfigsCrudService,
				modulePrintConfigParamCrudService,
				createProcessQueue,
				progressService,
				dossierGeneratedPrintCrudService,
				sectorsCrudService,
				formConfigService,
				dossierProtocolsCrudService,
				amendmentService, printService,
				forceReadOnlyContextCheckerService);
		dossiersService.setAnomaliesService(anomaliesService);
	}

	@Test
	void test_getModulesByPointInTime_date_not_null() {
		when(moduleCrudService.find(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(MODULE_BY_POINT_IN_TIME_DTO), null));
		assertEquals(MODULE_BY_POINT_IN_TIME_DTO,
				dossiersService.getModulesByPointInTime(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null, sc).getRecords().stream().findFirst().orElse(null));
	}

	@Test
	void test_getModulesByPointInTime_date_null() {
		AbsoluteDate now = new AbsoluteDate(LocalDate.now());
		when(moduleCrudService.find(TENANT_1, now, FL_AMEND, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(MODULE_BY_POINT_IN_TIME_DTO), null));
		assertEquals(MODULE_BY_POINT_IN_TIME_DTO,
				dossiersService.getModulesByPointInTime(TENANT_1, null, FL_AMEND, null, sc).getRecords().stream().findFirst().orElse(null));
	}

	@Test
	void test_getModulesByPointInTime_not_found() {
		when(moduleCrudService.find(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(), null));

		assertThrows(NoModulesFoundAtDateRuntimeException.class, () -> dossiersService.getModulesByPointInTime(TENANT_1, ABSOLUTE_DATE_1, FL_AMEND, null, sc));
	}

	@Test
	void test_getModulesByPointInTime_list() {
		AbsoluteDate now = new AbsoluteDate(LocalDate.now());
		when(moduleCrudService.find(TENANT_1, now, FL_AMEND))
				.thenReturn(List.of(MODULE_BY_POINT_IN_TIME_DTO));
		assertEquals(List.of(MODULE_BY_POINT_IN_TIME_DTO), dossiersService.getModulesByPointInTime(TENANT_1, null, FL_AMEND, sc));

	}

	@Test
	void test_getModulesByPointInTime_ko() {
		AbsoluteDate now = new AbsoluteDate(LocalDate.now());
		when(moduleCrudService.find(TENANT_1, now, FL_AMEND))
				.thenReturn(List.of());
		assertThrows(NoModulesFoundAtDateRuntimeException.class, () ->
				dossiersService.getModulesByPointInTime(TENANT_1, null, FL_AMEND, sc));

	}

	@Test
	void test_getDossierWithDetailsById_ok() {
		DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.dtRequest(NOW)
				.dtResponse(NOW)
				.protocol(PROTOCOL)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId())).thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))).thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, AMEND_OF_ID))
					.thenReturn(dossierWithDetailsDTO);
			when(amendmentService.isDossierAmendable(TENANT_1, AMEND_OF_ID))
					.thenReturn(true);
			when(amendmentService.isAmendModule(TENANT_1, MODULE_ID_1))
					.thenReturn(true);
			when(dossierProtocolsCrudService.findAll(TENANT_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierProtocolsDTO));

			assertEquals(dossierWithDetailsDTO, dossiersService.getDossierWithDetailsById(TENANT_1, DOSSIER_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getDossierWithDetailsById_withoutAmendmentIds_ok() {
		DossierWithDetailsDTO dossierWithDetailsWithoutAmendmentIds = DossierWithDetailsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.moduleId(MODULE_ID_1)
				.referredYear(REFERRED_YEAR)
				.partyId(PARTY_ID_1)
				.processId(PROCESS_ID_1)
				.dossierCode(DOSSIER_CODE)
				.dtClosed(null)
				.processStatus(PROCESS_STATUS)
				.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
				.userIdInsert(USER_1)
				.userIdDelete(null)
				.dtInsert(NOW)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.profileList(List.of(dossierProfileDTO))
				.build();
		DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.dtRequest(NOW)
				.dtResponse(NOW)
				.protocol(PROTOCOL)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierWithDetailsWithoutAmendmentIds);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId())).thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))).thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(dossierProtocolsCrudService.findAll(TENANT_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierProtocolsDTO));

			assertEquals(dossierWithDetailsWithoutAmendmentIds, dossiersService.getDossierWithDetailsById(TENANT_1, DOSSIER_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getDossierWithDetailsById_DossierNotFoundRuntimeException_ok() {
		DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.pkid(PK_ID_1)
				.dtRequest(NOW)
				.dtResponse(NOW)
				.protocol(PROTOCOL)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId())).thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))).thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, AMEND_OF_ID))
					.thenReturn(dossierWithDetailsDTO);
			when(amendmentService.isDossierAmendable(TENANT_1, AMEND_OF_ID))
					.thenReturn(true);
			when(amendmentService.isAmendModule(TENANT_1, MODULE_ID_1))
					.thenReturn(true);
			when(dossierProtocolsCrudService.findAll(TENANT_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierProtocolsDTO));
			doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
					.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

			assertThrows(DossierNotFoundRuntimeException.class, () ->
					dossiersService.getDossierWithDetailsById(TENANT_1, DOSSIER_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getDossierWithDetailsById_ActionNotAuthorizedRuntimeException() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId())).thenReturn(moduleDetailsDto);

			when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(false);

			assertThrows(ActionNotAuthorizedRuntimeException.class,
					() -> dossiersService.getDossierWithDetailsById(TENANT_1, DOSSIER_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getDossierWithDetailsById_WorkflowGenericRuntimeException() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierWithDetailsDTO);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
					.thenReturn(moduleDetailsDto);
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenThrow(WorkflowNotFoundException.class);
			when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(true);

			assertThrows(WorkflowGenericRuntimeException.class,
					() -> dossiersService.getDossierWithDetailsById(TENANT_1, DOSSIER_ID_1, logged_user1, sc));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			fail(e);
		}
	}

	@Test
	void test_getPrintsByModuleIdAndProcessStatus_ok() {
		List<String> profileCodeList = List.of(PROFILE_CODE_1);

		Map<String, String> params = Map.of(MODULE_PRINT_CONFIG_1_PARAMETER_NAME_1, MODULE_PRINT_CONFIG_1_PARAMETER_VALUE_1);
		List<PrintDetailsOutDTO> expectedOutput = List.of(PrintDetailsOutDTO.builder()
				.printConfigId(MODULE_PRINT_CONFIG_ID_1)
				.printCode(PRINT_CODE_1)
						.printDescription(PRINT_CODE_1)
						.sortOrder(1)
				.params(params)
				.lastPrint(LastPrintDTO.builder()
						.fileId(FILE_ID)
						.printDate(PRINT_DATE)
						.build())
				.build());

		when(printService.getPrintsByModuleIdAndProcessStatus(TENANT_1, DOSSIER_ID_1, MODULE_ID_1, PROCESS_STATUS_1, List.of(PROFILE_CODE_1), sc))
				.thenReturn(List.of(printDetailsOutDTO));

		List<PrintDetailsOutDTO> result = dossiersService.getPrintsByModuleIdAndProcessStatus(TENANT_1, DOSSIER_ID_1, MODULE_ID_1, PROCESS_STATUS_1,
				profileCodeList, sc);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_getDossiersByPartyAndYear_ok() {
		when(dossiersCrudService.find(TENANT_1, sc, PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyAndYearDTOMock), null));

		DosByPartyAndYearDTO result = dossiersService.getDossiersByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc).getRecords().get(0);

		assertEquals(dossierByPartyAndYearDTOMock, result);
	}

	@Test
	void test_getDossiersByPartyYearAndModuleCode_ok() {
		when(dossiersCrudService.findWithModuleCode(TENANT_1, PARTY_ID_1, YEAR_1, MODULE_CODE))
				.thenReturn(List.of(dossierByPartyAndYearDTOMock));

		List<DosByPartyAndYearDTO> result = dossiersService.getDossiersByPartyYearAndModuleCode(TENANT_1, PARTY_ID_1, YEAR_1, MODULE_CODE,
				logged_user1);

		assertEquals(List.of(dossierByPartyAndYearDTOMock), result);
	}

	@Test
	void test_getDossiersByPartyAndYear_catchException_ok() {
		when(dossiersCrudService.find(TENANT_1, sc, PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyAndYearDTOMock), null));
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(ModuleDTO.builder().moduleCode(MODULE_CODE).moduleId(MODULE_ID_1).build()));
		when(dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))
				.thenThrow(ProcessNotFoundException.class);

		DosByPartyAndYearDTO expectedOutput = DosByPartyAndYearDTO.builder()
				.dossierCode(DOSSIER_CODE_1)
				.dtClosed(new AbsoluteDate(LocalDate.now()))
				.moduleCode(MODULE_CODE)
				.moduleDescription(MODULE_CODE_DESC)
				.partyId(PARTY_ID_1)
				.sectorCode(SECTOR_CODE)
				.sectorDescription(SECTOR_CODE_DESC)
				.year(YEAR_1)
				.processStatus(PROCESS_STATUS_1)
				.processStatusDescription("ERROR")
				.build();

		DosByPartyAndYearDTO result = dossiersService.getDossiersByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc).getRecords().get(0);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_getDossiersByPartyAndYear_not_found() {
		when(dossiersCrudService.find(TENANT_1, sc, PARTY_ID_1, YEAR_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(), null));

		assertThrows(NoDossiersFoundByPartyAndYearRuntimeException.class,
				() -> dossiersService.getDossiersByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, null, sc));
	}

	@Test
	void test_getDossiersByPartyAndYear_ActionNotAuthorizedRuntimeException() {
		doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
				.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

		InfiniteListResults<DosByPartyAndYearDTO> result = dossiersService.getDossiersByPartyAndYear(TENANT_1, PARTY_ID_1, YEAR_1, null, logged_user1, sc);

		assertEquals(List.of(), result.getRecords());
	}

	@Test
	void test_getDossiersSummaryByYear_no_party_id_ko() {
		assertThrows(NoMandatoryInputPartyIdRuntimeException.class, () -> dossiersService.getDossiersSummaryByYear(TENANT_1, null, null));
	}

	@Test
	void test_getDossiersSummaryByYear_no_data_found_ko() {

		when(dossiersCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of());

		assertThrows(NoDossierSummaryFoundRuntimeException.class, () -> dossiersService.getDossiersSummaryByYear(TENANT_1, PARTY_ID_1, null));
	}

	@Test
	void test_getDossiersSummaryByYear_same_year_ok() {
		DossierDTO dossier1 = DossierDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.dossierId(1L)
				.build();

		DossierDTO dossier2 = DossierDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.dossierId(2L)
				.build();

		when(dossiersCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(dossier1, dossier2));

		DossiersSummaryByYearOutDTO expectedResult = DossiersSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.dossiersSummaryByYear(List.of(DossiersSummaryByYearDTO.builder()
						.dossiersNumber(2)
						.year(2022)
						.build()))
				.build();

		DossiersSummaryByYearOutDTO result = dossiersService.getDossiersSummaryByYear(TENANT_1, PARTY_ID_1, null);

		assertEquals(expectedResult, result);
	}

	@Test
	void test_getDossiersSummaryByYear_ActionNotAuthorizedRuntimeException_ok() {
		doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
				.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

		DossiersSummaryByYearOutDTO expectedResult = DossiersSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.dossiersSummaryByYear(Collections.emptyList())
				.build();

		DossiersSummaryByYearOutDTO result = dossiersService.getDossiersSummaryByYear(TENANT_1, PARTY_ID_1, logged_user1);

		assertEquals(expectedResult, result);
	}

	@Test
	void test_getDossiersSummaryByYear_different_years_ok() {
		DossierDTO dossier1 = DossierDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2021)
				.dossierId(1L)
				.build();

		DossierDTO dossier2 = DossierDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(2022)
				.dossierId(2L)
				.build();

		when(dossiersCrudService.findAllByPartyId(TENANT_1, PARTY_ID_1)).thenReturn(List.of(dossier1, dossier2));

		DossiersSummaryByYearOutDTO expectedResult = DossiersSummaryByYearOutDTO.builder()
				.partyId(PARTY_ID_1)
				.dossiersSummaryByYear(List.of(DossiersSummaryByYearDTO.builder()
								.dossiersNumber(1)
								.year(2021)
								.build(),
						DossiersSummaryByYearDTO.builder()
								.dossiersNumber(1)
								.year(2022)
								.build()))
				.build();

		DossiersSummaryByYearOutDTO result = dossiersService.getDossiersSummaryByYear(TENANT_1, PARTY_ID_1, null);

		assertEquals(expectedResult, result);
	}

	@Test
	void test_createDossier_noModuleFound_ko() {
		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());

		CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		assertThrows(NoModulesFoundAtDateRuntimeException.class, () -> dossiersService.createDossierAsync(TENANT_1, logged_user1, createDossierInDTO));
	}

	@Test
	void test_createDossierAsync_noModuleFound_ko() {
		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.empty());

		CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		assertThrows(NoModulesFoundAtDateRuntimeException.class, () -> dossiersService.createDossierAsync(TENANT_1, logged_user1, createDossierInDTO));
	}

	@Test
	void test_createDossierAsync_emptyDossierAnomalies_ok() {
		ModuleDTO module1 = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.sectorId(SECTOR_ID_1)
				.build();

		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE)).thenReturn(Optional.of(module1));

		/*
		 * when(anomaliesService.checkForMultipleDossier(TENANT_1, MODULE_CODE, PARTY_ID_1, REFERRED_YEAR)).thenReturn(Collections.emptyList());
		 */

		CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		DossierDTO insertedDossierDTO = DossierDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.dtInsert(NOW)
				.moduleId(MODULE_ID_1)
				.processId(PROCESS_ID_1)
				.referredYear(YEAR_1)
				.userIdInsert(USER_1)
				.build();

		DossierDetailsDTO insertedDossierDetailsDTO = DossierDetailsDTO.builder()
				.dossierCode(DOSSIER_CODE_1)
				.dossierId(DOSSIER_ID_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.dtInsert(NOW)
				.pkid(DOSSIER_DETAILS_ID_1)
				.processStatus(PROCESS_STATUS)
				.userIdInsert(USER_1)
				.build();

		DossierOutDTO transactionOutput = DossierOutDTO.builder()
				.dossier(insertedDossierDTO)
				.dossierDetail(insertedDossierDetailsDTO)
				.build();

		CreateDossierOutDTO expectedResult = CreateDossierOutDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.dossierCode(transactionOutput.getDossierDetail().getDossierCode())
				.build();

		DossiersService dossiersServiceSpy = spy(dossiersService);

		Mockito.doReturn(transactionOutput).when(dossiersServiceSpy)
				.doInsertDossierAsync(TENANT_1, USER_1, createDossierInDTO, module1);
		when(moduleDetailsCrudService.findByModuleId(any(), any())).thenReturn(moduleDetailsDto);

		assertEquals(expectedResult, dossiersServiceSpy.createDossierAsync(TENANT_1, logged_user1, createDossierInDTO));
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void createAmendmentDossierAsync_ok() {
		try {
			ArgumentCaptor<HandleCallback> handleCallbackArgumentCaptor = ArgumentCaptor.forClass(HandleCallback.class);
			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.sectorId(SECTOR_ID_1)
					.build();
			DossierDetailsDTO dossierDetailsToUpdate = DossierDetailsDTO.builder()
					.pkid(PK_ID_1)
					.processStatus(PROCESS_STATUS)
					.dossierCode(DOSSIER_CODE)
					.dossierId(DOSSIER_ID_1)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(jdbi.inTransaction(any()))
					.thenCallRealMethod()
					.thenReturn(dossierOutDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsToUpdate);

			CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentDossierId(DOSSIER_ID_1)
					.build();

			CreateAmendmentDossierOutDTO expectedResult = CreateAmendmentDossierOutDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.dossierCode(DOSSIER_CODE)
					.amendmentDossierId(AMEND_OF_ID)
					.build();

			dossiersService.createAmendmentDossierAsync(TENANT_1, logged_user1, createDossierInDTO);

			verify(jdbi).inTransaction(handleCallbackArgumentCaptor.capture());
			CreateAmendmentDossierOutDTO result = (CreateAmendmentDossierOutDTO) handleCallbackArgumentCaptor.getValue().withHandle(handle);

			verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
			handleConsumerArgumentCaptor.getValue().useHandle(handle);

			dossierDetailsToUpdate.setAmendOfId(AMEND_OF_ID);
			verify(dossierDetailsCrudService, times(1)).update(PK_ID_1, dossierDetailsToUpdate, USER_1);

			assertEquals(expectedResult, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void createAmendmentDossierAsync_withAnomalies_ok() {
		try {
			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.sectorId(SECTOR_ID_1)
					.build();

			DossierAnomaly dossierAnomaly = DossierAnomaly.builder()
					.code(WAIVED_DOSSIER_ERROR_CODE)
					.message(WAIVED_DOSSIER_ERROR_MSG)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(anomaliesService.checkForDossierWaived(TENANT_1, DOSSIER_ID_1))
					.thenReturn(List.of(dossierAnomaly));

			CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentDossierId(DOSSIER_ID_1)
					.build();

			CreateAmendmentDossierOutDTO expectedResult = CreateAmendmentDossierOutDTO.builder()
					.anomalies(List.of(dossierAnomaly))
					.build();

			CreateAmendmentDossierOutDTO result = dossiersService.createAmendmentDossierAsync(TENANT_1, logged_user1, createDossierInDTO);

			assertEquals(expectedResult, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void createAmendmentDossierAsync_withoutAmendmentDossierId_ko() {
		try {
			CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.build();

			assertThrows(BadRequestRuntimeException.class, () ->
					dossiersService.createAmendmentDossierAsync(TENANT_1, logged_user1, createDossierInDTO));
		} catch (Exception e) {
			fail(e);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void createAmendmentDossierAsync_withoutDossierToUpdate_ko() {
		try {
			ArgumentCaptor<HandleCallback> handleCallbackArgumentCaptor = ArgumentCaptor.forClass(HandleCallback.class);
			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			ModuleDTO module1 = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorId(SECTOR_ID_1)
					.build();

			when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
					.thenReturn(Optional.of(module1));
			when(jdbi.inTransaction(any()))
					.thenCallRealMethod()
					.thenReturn(dossierOutDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			CreateDossierInDTO createDossierInDTO = CreateDossierInDTO.builder()
					.moduleCode(MODULE_CODE)
					.sectorCode(SECTOR_CODE)
					.partyId(PARTY_ID_1)
					.year(YEAR_1)
					.amendmentDossierId(DOSSIER_ID_1)
					.build();

			dossiersService.createAmendmentDossierAsync(TENANT_1, logged_user1, createDossierInDTO);

			assertThrows(DossierNotFoundRuntimeException.class, () -> {
				verify(jdbi).inTransaction(handleCallbackArgumentCaptor.capture());
				handleCallbackArgumentCaptor.getValue().withHandle(handle);

				verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
				handleConsumerArgumentCaptor.getValue().useHandle(handle);
			});
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void getDetailedDossierById_ok() {
		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
				.thenReturn(dossierWithDetailsDTO);
		when(dossierProfilesCrudService.findAll(TENANT_1, DOSSIER_ID_1, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(dossierProfileDTO));
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
				.thenReturn(ModuleDetailsDTO.builder().build());
		when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
				.thenReturn(PROCESS_STATUS_DESCRIPTION);
		when(amendmentService.getOriginalAmendedDossierId(dossierWithDetailsDTO, TENANT_1))
				.thenReturn(AMEND_OF_ID);
		when(formConfigService.getFormsByModuleIdAndProcessStatus(TENANT_1, MODULE_ID_1, PROCESS_STATUS, List.of(),
				List.of(PROFILE_CODE_1), sc, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(formWithGroupHierarchyPublicDTO));
		when(partyService.getPartyByPartyId(TENANT_1, PARTY_ID_1, logged_user1))
				.thenReturn(partyDTO);
		when(printService.getPrintsByModuleIdAndProcessStatus(TENANT_1, DOSSIER_ID_1, MODULE_ID_1, PROCESS_STATUS, List.of(PROFILE_CODE_1), sc))
				.thenReturn(List.of(printDetailsOutDTO));

		DossierWithDetailsDTO expectedOutput = DossierWithDetailsDTO.builder()
				.dossierCode(DOSSIER_CODE)
				.processStatus(PROCESS_STATUS)
				.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
				.dtClosed(null)
				.compileStatus(Collections.emptyList())
				.profileList(List.of(dossierProfileDTO))
				.moduleId(MODULE_ID_1)
				.processId(PROCESS_ID_1)
				.originalAmendedDossierId(AMEND_OF_ID)
				.referredYear(REFERRED_YEAR)
				.partyId(PARTY_ID_1)
				.dossierId(DOSSIER_ID_1)
				.forms(List.of(formWithGroupHierarchyPublicDTO))
				.prints(List.of(printDetailsOutDTO))
				.party(partyDTO)
				.userIdInsert(USER_1)
				.dtDelete(DEFAULT_NOT_DELETED_DATE)
				.build();

		DossierWithDetailsDTO result = dossiersService.getDetailedDossierById(TENANT_1, DOSSIER_ID_1, logged_user1, sc);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_createDossierAsync_notEmptyDossierAnomalies_ok() {
		ModuleDTO module1 = ModuleDTO.builder()
				.moduleCode(MODULE_CODE)
				.moduleId(MODULE_ID_1)
				.sectorId(SECTOR_ID_1)
				.build();

		List<DossierAnomaly> dossierAnomalies = List.of(DossierAnomaly.builder()
				.code(DOSSIER_CODE)
				.build());

		when(moduleCrudService.findByModuleCodeAndSectorCode(TENANT_1, MODULE_CODE, SECTOR_CODE))
				.thenReturn(Optional.of(module1));

		when(anomaliesService.checkForMultipleDossier(TENANT_1, module1, PARTY_ID_1, REFERRED_YEAR, null))
				.thenReturn(dossierAnomalies);

		CreateDossierInDTO createcreateDossierInDTOInDTO = CreateDossierInDTO.builder()
				.moduleCode(MODULE_CODE)
				.sectorCode(SECTOR_CODE)
				.partyId(PARTY_ID_1)
				.year(YEAR_1)
				.build();

		CreateDossierOutDTO expectedResult = CreateDossierOutDTO.builder()
				.anomalies(dossierAnomalies)
				.build();

		DossiersService dossiersServiceSpy = spy(dossiersService);
		when(moduleDetailsCrudService.findByModuleId(any(), any())).thenReturn(moduleDetailsDto);

		assertEquals(expectedResult, dossiersServiceSpy.createDossierAsync(TENANT_1, logged_user1, createcreateDossierInDTOInDTO));
	}

	@Test
	void test_getProfilesByModuleAndSector() {
		when(moduleProfilesCrudService.find(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(moduleProfileDTO), null));
		assertEquals(List.of(moduleProfilePublicDTO),
				dossiersService.getProfilesByModuleAndSector(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null).getRecords());
	}

	@Test
	void test_getModulesBySectorCode() {

		try {
			when(sectorsCrudService.findSectorByCode(TENANT_1, SECTOR_CODE))
					.thenReturn(sectorDTO);

			when(moduleCrudService.findAllModulesWithDetailBySectorId(TENANT_1, SECTOR_ID_1)).thenReturn(List.of(moduleWithDetailDTO));

			assertEquals(List.of(moduleWithDetailDTO),
					dossiersService.getModulesBySectorCode(TENANT_1, SECTOR_CODE, sc));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getModulesBySectorCode_ko() {
		try {
			when(sectorsCrudService.findSectorByCode(TENANT_1, SECTOR_CODE))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ObjectNotFoundRuntimeException.class, () ->
					dossiersService.getModulesBySectorCode(TENANT_1, SECTOR_CODE, sc));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getSectorsByTenant() {
		when(sectorsCrudService.findInfiniteAllSectors(TENANT_1, NEXT_KEY))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(sectorDTO), NEXT_KEY));
		assertEquals(List.of(sectorPublicDTO),
				dossiersService.getSectorsByTenant(TENANT_1, NEXT_KEY).getRecords());
	}

	@Test
	void test_getSectorsByTenant_exception() {
		when(sectorsCrudService.findInfiniteAllSectors(TENANT_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(Collections.emptyList(), null));

		assertThrows(NoSectorsFoundAtDateRuntimeException.class,
				() -> dossiersService.getSectorsByTenant(TENANT_1, null));
	}

	@Test
	void test_getStatusNodes() {
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(moduleDTO));
		when(dossiersWorkflowService.getWorkflowNodesByType(TENANT_1, WORKFLOW_CODE_1, NodeType.status)).thenReturn(List.of(workflowNodeMock));

		assertEquals(List.of(workflowNodePublic),
				dossiersService.getStatusNodes(TENANT_1, MODULE_CODE));
	}

	@Test
	void test_getStatusNodes_ko() {
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () ->
				dossiersService.getStatusNodes(TENANT_1, MODULE_CODE));
	}

	@Test
	void test_getProfilesByModuleAndSector_exception() {
		when(moduleProfilesCrudService.find(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null))
				.thenReturn(new InfiniteListResultsImpl<>(Collections.emptyList(), null));

		assertThrows(NoProfilesFoundAtDateRuntimeException.class,
				() -> dossiersService.getProfilesByModuleAndSector(TENANT_1, SECTOR_CODE, MODULE_CODE, ABSOLUTE_DATE_1, null));
	}

	@Test
	void test_findCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.applicationId(DOSSIER_ID_1)
				.compileStatusIdentifier(STATUS_1)
				.pkid(PK_ID_1)
				.build();

		InfiniteListResultsImpl<ApplicationCompileStatusDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(compileStatus));

		when(dossierCompileStatusCrudService.find(TENANT_1, DOSSIER_ID_1, null)).thenReturn(infiniteListResults);

		assertEquals(infiniteListResults, dossiersService.findCompileStatus(TENANT_1, DOSSIER_ID_1, null));
	}

	@Test
	void test_findCompileStatus_object_not_found_ko() {
		when(dossierCompileStatusCrudService.find(TENANT_1, DOSSIER_ID_1, null))
				.thenThrow(new ObjectNotFoundRuntimeException("not found"));

		assertThrows(ObjectNotFoundRuntimeException.class, () -> dossiersService.findCompileStatus(TENANT_1, DOSSIER_ID_1, null));
	}

	@Test
	void test_updateCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.applicationId(DOSSIER_ID_1)
				.compileStatusIdentifier(STATUS_1)
				.status(STATUS_2)
				.pkid(PK_ID_1)
				.build();

		ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
				.status(STATUS_2)
				.build();

		ApplicationCompileStatusDTO compileStatusUpdated = ApplicationCompileStatusDTO.builder()
				.applicationId(DOSSIER_ID_1)
				.compileStatusIdentifier(STATUS_2)
				.pkid(PK_ID_1)
				.build();

		DossierDTO dossier = DossierDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.build();

		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1)).thenReturn(dossier);
			when(dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, DOSSIER_ID_1, STATUS_1)).thenReturn(compileStatus);
			when(dossierCompileStatusCrudService.update(PK_ID_1, compileStatus, USER_1)).thenReturn(compileStatusUpdated);

			assertEquals(compileStatusUpdated, dossiersService.updateCompileStatus(TENANT_1, DOSSIER_ID_1, STATUS_1, compileStatusInput, USER_1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_updateCompileStatus_dossier_not_found_ko() throws ObjectNotFoundException {
		ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
				.status(STATUS_2)
				.build();

		when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1)).thenThrow(new ObjectNotFoundException("not found"));

		assertThrows(DossierNotFoundRuntimeException.class,
				() -> dossiersService.updateCompileStatus(TENANT_1, DOSSIER_ID_1, STATUS_2, compileStatusInput, USER_1));
	}

	@Test
	void test_updateCompileStatus_compile_status_not_found() {
		try {
			ApplicationCompileStatusPayloadDTO compileStatusInput = ApplicationCompileStatusPayloadDTO.builder()
					.status(STATUS_2)
					.build();
			DossierDTO dossier = DossierDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1)).thenReturn(dossier);
			when(dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, DOSSIER_ID_1, STATUS_1))
					.thenThrow(new ObjectNotFoundException("not found"));

			dossiersService.updateCompileStatus(TENANT_1, DOSSIER_ID_1, STATUS_1, compileStatusInput, USER_1);
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	//	@Test
	//	void test_getDossiersByModuleCode_ok() {
	//
	//		when(partyService.getPartiesByCodeOrDesc(TENANT_1 , -1L, CUAA_1, "", logged_user1)).thenReturn(List.of(partyDTO));
	//
	//		when(dossiersCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, YEAR_1, PROCESS_STATUS)).thenReturn(List.of(dosByPartyAndYearDTO));
	//
	//		InfiniteListResults<DosByPartyAndYearDTO> results = dossiersService.getDossiersByModuleCode(TENANT_1, MODULE_CODE, CUAA_1, YEAR_1, PROCESS_STATUS, NEXT_KEY, logged_user1);
	//
	//		assertEquals(List.of(dosByPartyAndYearDTO), results.getRecords());
	//	}

	//	@Test
	//	void test_getDossiersByCuaa_ok() {
	//
	//		when(partyService.getPartiesByCodeOrDesc(TENANT_1 , -1L, CUAA_1, "", logged_user1)).thenReturn(List.of(partyDTO));
	//
	//		when(dossiersCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, YEAR_1, PROCESS_STATUS)).thenReturn(List.of(dosByPartyAndYearDTO));
	//
	//		InfiniteListResults<DosByPartyAndYearDTO> results = dossiersService.getDossiersByCuaa(TENANT_1, CUAA_1, MODULE_CODE, YEAR_1, PROCESS_STATUS, NEXT_KEY, logged_user1);
	//
	//		assertEquals(List.of(dosByPartyAndYearDTO), results.getRecords());
	//	}

	@Test
	void test_getDossierProfiles_ok() {
		DossierProfileDTO dossierProfile = DossierProfileDTO.builder()
				.profileCode("profileCode1")
				.profileCodeDescription("profileDesc1")
				.build();

		ApplicationProfilePublicDTO dossierProfilePublic = ApplicationProfilePublicDTO.builder()
				.profileCode("profileCode1")
				.profileCodeDescription("profileDesc1")
				.build();
		InfiniteListResultsImpl<DossierProfileDTO> infiniteListAppProfile = new InfiniteListResultsImpl<>();
		infiniteListAppProfile.setRecords(List.of(dossierProfile));

		InfiniteListResultsImpl<ApplicationProfilePublicDTO> infiniteListResults = new InfiniteListResultsImpl<>();
		infiniteListResults.setRecords(List.of(dossierProfilePublic));

		when(dossierProfilesCrudService.find(TENANT_1, DOSSIER_ID_1, null)).thenReturn(infiniteListAppProfile);
		assertEquals(infiniteListResults.getRecords(), dossiersService.getDossierProfiles(TENANT_1, DOSSIER_ID_1, null, null).getRecords());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_doInsertDossierAsync_ok() {
		try {
			ArgumentCaptor<HandleCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleCallback.class);

			ModuleDTO module = ModuleDTO.builder()
					.moduleId(MODULE_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.build();

			CreateDossierInDTO dossierIn = CreateDossierInDTO.builder()
					.build();
			DossierDetailsDTO insertedDetails = DossierDetailsDTO.builder()
					.dossierCode(DOSSIER_CODE_1)
					.build();
			DossierDTO insertedDossier = DossierDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.moduleId(MODULE_ID_1)
					.partyId(PARTY_ID_1)
					.referredYear(YEAR_1)
					.build();
			ApplicationsWorkflowParams wfParams = ApplicationsWorkflowParams.builder()
					.applicationId(DOSSIER_ID_1)
					.applicationCode(DOSSIER_CODE_1)
					.tenant(TENANT_1)
					.username(USER_1)
					.locale(MDC.get(MDCPreFilter.LOCALE))
					.partyId(PARTY_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.referredYear(YEAR_1)
					.build();

			DossierOutDTO expectedOutput = DossierOutDTO.builder()
					.dossier(insertedDossier)
					.dossierDetail(insertedDetails)
					.build();

			when(jdbi.inTransaction(any()))
					.thenReturn(expectedOutput);

			dossiersService.doInsertDossierAsync(TENANT_1, USER_1, dossierIn, module);

			verify(jdbi).inTransaction(handleConsumerLambdaCaptor.capture());
			DossierOutDTO result = (DossierOutDTO) handleConsumerLambdaCaptor.getValue().withHandle(handle);

			verify(createProcessQueue).add(eq(wfParams), anyLong());

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Test
	void test_createVanillaDossierWithDetails_ok() throws Exception {
		ArgumentCaptor<HandleCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(HandleCallback.class);

		CreateDossierInDTO payload = CreateDossierInDTO.builder()
				.year(YEAR_1)
				.partyId(PARTY_ID_1)
				.build();

		DossierDTO dossierDTO = DossierDTO.builder()
				.partyId(PARTY_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.userIdInsert(USER_1)
				.build();

		DossierDTO dossierOutDTO = DossierDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.partyId(PARTY_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.userIdInsert(USER_1)
				.build();

		DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
				.dossierId(DOSSIER_ID_1)
				.dossierCode(DOSSIER_CODE_1)
				.flInTransition(ProcessTransitionEnum.NOT_IN_TRANSITION.getFl())
				.build();

		ModuleDTO module = ModuleDTO.builder()
				.moduleId(MODULE_ID_1)
				.build();

		when(dossiersCrudService.insert(dossierDTO, USER_1)).thenReturn(dossierOutDTO);

		dossiersService.createVanillaDossierWithDetails(USER_1, payload, module);

		verify(jdbi).inTransaction(handleConsumerLambdaCaptor.capture());
		handleConsumerLambdaCaptor.getValue().withHandle(handle);

		verify(dossiersCrudService, times(1)).insert(dossierDTO, USER_1);
		verify(dossierDetailsCrudService, times(1)).insert(dossierDetailsDTO, USER_1);
	}

	@Test
	void test_checkForMetadata_ok() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> expectedOutput = Map.of("first", "value", "second", "value");

		when(dossiersCrudService.findWithDetailsByDossierCode(TENANT_1, DOSSIER_CODE))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleCrudService.findById(dossierWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(dossiersWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				dossierWithDetailsDTO.getProcessStatus()))
				.thenReturn(expectedOutput);

		Map<String, Object> result = dossiersService.checkForMetadata(TENANT_1, DOSSIER_CODE);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_isDossierClosed_true_ok() {
		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
				.thenReturn(closedDossierWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, closedDossierWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION)).thenReturn(true);

		boolean result = dossiersService.isDossierClosed(TENANT_1, DOSSIER_ID_1, logged_user1, sc);

		assertTrue(result);
	}

	/*@Test
	void test_isDossierClosed_invalidMetadata_ko() {
		ModuleDTO moduleDTO = ModuleDTO.builder()
				.build();
		Map<String, Object> metadata = Map.of(WORKFLOW_CLOSED_KEY, "invalid value");

		when(dossiersCrudService.findWithDetailsByDossierCode(TENANT_1, DOSSIER_CODE_1))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION))
				.thenReturn(true);
		when(moduleCrudService.findById(dossierWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.of(moduleDTO));
		when(dossiersWorkflowService.getNodeMetadata(TENANT_1, moduleDTO.getWorkflowCode(),
				dossierWithDetailsDTO.getProcessStatus()))
				.thenReturn(metadata);

		assertThrows(IllegalStateException.class, () -> dossiersService.checkForMetadata(TENANT_1, DOSSIER_CODE_1));
	}*/

	@Test
	void test_isDossierClosed_false_ok() {
		WorLogTransitionWithDetailsEntity ntt = new WorLogTransitionWithDetailsEntity();
		ntt.setIs_failed(0);
		ntt.setFrom(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setTo(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setMessages(JsonToken.VALUE_NULL.asString());
		AuthContext authContext = new AuthContextTestSupport();
		List<DetailedTransitionLog> detailedTransitionLogList = List.of(new DetailedTransitionLog(ntt, authContext, Jackson.newObjectMapper()));

		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
				.thenReturn(moduleDetailsDto);
		when(sc.isUserInRole(CONTEXT_FUNCTION))
				.thenReturn(true);
		when(dossiersWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, logged_user1))
				.thenReturn(detailedTransitionLogList);

		boolean result = dossiersService.isDossierClosed(TENANT_1, DOSSIER_ID_1, logged_user1, sc);

		assertFalse(result);
	}

	@Test
	void test_findReadOnly_dossierNotClosed_ok() {
		ModuleFormConfigsDTO moduleFormConfig = ModuleFormConfigsDTO.builder()
				.compileStatusIdentifier(DOSSIER_COMPILE_STATUS_IDENTIFIER_1)
				.formId(FORM_ID_1)
				.formGroupId(FORM_GROUP_ID_1)
				.flReadOnly(1)
				.build();

		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierWithDetailsDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleFormConfigsCrudService.findById(TENANT_1, MODULE_FORM_CONFIG_ID_1))
					.thenReturn(moduleFormConfig);

			ReadOnlyDto result = dossiersService.findReadOnly(TENANT_1, DOSSIER_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findReadOnly_dossier_in_transition_ok() {
		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierWithDetailsDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTOInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);

			ReadOnlyDto result = dossiersService.findReadOnly(TENANT_1, DOSSIER_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_findReadOnly_dossierClosed_ok() {
		ReadOnlyDto expectedOutput = ReadOnlyDto.builder()
				.readOnly(true)
				.build();

		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierWithDetailsDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);

			ReadOnlyDto result = dossiersService.findReadOnly(TENANT_1, DOSSIER_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_deleteCompileStatus_ok() {
		ApplicationCompileStatusDTO compileStatus = ApplicationCompileStatusDTO.builder()
				.pkid(PK_ID_1)
				.status(DOSSIER_COMPILE_STATUS_1)
				.applicationId(DOSSIER_ID_1)
				.compileStatusIdentifier(DOSSIER_COMPILE_STATUS_IDENTIFIER_1)
				.build();

		try {
			when(dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, DOSSIER_ID_1,
					DOSSIER_COMPILE_STATUS_IDENTIFIER_1))
					.thenReturn(compileStatus);

			dossiersService.deleteCompileStatus(TENANT_1, DOSSIER_ID_1, DOSSIER_COMPILE_STATUS_IDENTIFIER_1, USER_1);

			verify(dossiersCrudService, times(1)).findById(TENANT_1, DOSSIER_ID_1);
			verify(dossierCompileStatusCrudService, times(1)).delete(PK_ID_1, USER_1);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_deleteCompileStatus_ObjectNotFoundException_ok() {
		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			dossiersService.deleteCompileStatus(TENANT_1, DOSSIER_ID_1, DOSSIER_COMPILE_STATUS_IDENTIFIER_1, USER_1);

			verify(dossierCompileStatusCrudService, times(0)).delete(anyLong(), anyString());
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_deleteCompileStatus_Exception_ok() {
		try {
			when(dossierCompileStatusCrudService.findByCompileStatusIdentifier(TENANT_1, DOSSIER_ID_1, DOSSIER_COMPILE_STATUS_IDENTIFIER_1))
					.thenThrow(ObjectNotFoundException.class);

			dossiersService.deleteCompileStatus(TENANT_1, DOSSIER_ID_1, DOSSIER_COMPILE_STATUS_IDENTIFIER_1, USER_1);

			verify(dossierCompileStatusCrudService, times(0)).delete(anyLong(), anyString());
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierHistoryByDossierId_ok() {
		DossierDTO dossierDTO = DossierDTO.builder()
				.processId(PROCESS_ID_1)
				.partyId(PARTY_ID_1)
				.dossierId(DOSSIER_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.build();

		WorLogTransitionWithDetailsEntity ntt = new WorLogTransitionWithDetailsEntity();
		ntt.setIs_failed(0);
		ntt.setFrom(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setTo(new WorLogTransitionWithDetailsEntity.Node());
		ntt.setMessages(JsonToken.VALUE_NULL.asString());
		AuthContext authContext = new AuthContextTestSupport();
		List<DetailedTransitionLog> expectedOutput = List.of(new DetailedTransitionLog(ntt, authContext, Jackson.newObjectMapper()));

		try {
			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossiersWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, logged_user1))
					.thenReturn(expectedOutput);

			List<DetailedTransitionLog> result = dossiersService.getDossierHistoryByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierHistoryByDossierId_returnEmptyList_ok() {
		DossierDTO dossierDTO = DossierDTO.builder()
				.processId(PROCESS_ID_1)
				.partyId(PARTY_ID_1)
				.dossierId(DOSSIER_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.build();

		try {
			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
					.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

			List<DetailedTransitionLog> result = dossiersService.getDossierHistoryByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getAvailableTransitionListByProcessId_ok() {
		DossierDTO dossierDTO = DossierDTO.builder()
				.processId(PROCESS_ID_1)
				.partyId(PARTY_ID_1)
				.dossierId(DOSSIER_ID_1)
				.referredYear(YEAR_1)
				.moduleId(MODULE_ID_1)
				.build();

		List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");
		List<Transition> expectedOutput = List.of(Transition.builder()
				.scope(SCOPE)
				.id(TRANSITION_ID)
				.notesRequired(false)
				.fromNode(NODE_FROM)
				.toNode(NODE_TO)
				.tags(tags)
				.build());

		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID_1, logged_user1, SCOPE))
					.thenReturn(expectedOutput);

			List<Transition> result = dossiersService.getAvailableTransitionListByProcessId(TENANT_1, DOSSIER_ID_1, logged_user1, SCOPE);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_checkForOngoingPrints_ok() {
		List<DossierGeneratedPrintDTO> dossierGeneratedPrintDTOs = List.of(DossierGeneratedPrintDTO.builder()
				.build());
		List<String> printCodes = List.of(PRINT_CODE_1);

		when(dossierGeneratedPrintCrudService.findOngoingPrintByCode(TENANT_1, DOSSIER_ID_1, PRINT_CODE_1))
				.thenReturn(dossierGeneratedPrintDTOs);

		List<DossierGeneratedPrintDTO> result = dossiersService.checkForOngoingPrints(TENANT_1, DOSSIER_ID_1, printCodes);

		assertEquals(dossierGeneratedPrintDTOs, result);
	}

	@Test
	void test_getDossierInTransition_withProcessId_ok() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.processId(PROCESS_ID_1)
					.build();
			DossierDetailsDTO dossierDetailsDTO = DossierDetailsDTO.builder()
					.dossierCode(DOSSIER_CODE_1)
					.dossierId(DOSSIER_ID_1)
					.dtDelete(DEFAULT_NOT_DELETED_DATE)
					.dtInsert(NOW)
					.pkid(DOSSIER_DETAILS_ID_1)
					.processStatus(PROCESS_STATUS)
					.userIdInsert(USER_1)
					.flInTransition(1)
					.build();

			WorLogTransitionWithDetailsEntity ntt = new WorLogTransitionWithDetailsEntity();
			ntt.setIs_failed(0);
			ntt.setFrom(new WorLogTransitionWithDetailsEntity.Node());
			ntt.setTo(new WorLogTransitionWithDetailsEntity.Node());
			ntt.setMessages(JsonToken.VALUE_NULL.asString());
			AuthContext authContext = new AuthContextTestSupport();
			List<DetailedTransitionLog> detailedTransitionLogs = List.of(new DetailedTransitionLog(ntt, authContext, Jackson.newObjectMapper()));

			DossierInTransitionDTO expectedOutput = DossierInTransitionDTO.builder()
					.inTransition(true)
					.lastTransitionLog(detailedTransitionLogs.get(0))
					.build();

			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(dossierDetailsCrudService.findDossierDetailByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTO);
			when(dossiersWorkflowService.getProcessTransitionHistory(TENANT_1, PROCESS_ID_1, logged_user1))
					.thenReturn(detailedTransitionLogs);

			DossierInTransitionDTO result = dossiersService.getDossierInTransition(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierInTransition_withoutProcessId_ok() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();

			DossierInTransitionDTO expectedOutput = DossierInTransitionDTO.builder()
					.inTransition(true)
					.build();

			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);

			DossierInTransitionDTO result = dossiersService.getDossierInTransition(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierInTransition_withoutProcessId_ko() {
		try {
			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> dossiersService.getDossierInTransition(TENANT_1, DOSSIER_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierPrintsByDossierId_ok() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();
			ModuleDTO moduleDTO = ModuleDTO.builder()
					.moduleCode(MODULE_CODE)
					.moduleId(MODULE_ID_1)
					.workflowCode(WORKFLOW_CODE_1)
					.build();
			List<DossierGeneratedPrintDTO> dossierGeneratedPrintDTOs = List.of(DossierGeneratedPrintDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.processStatus(PROCESS_STATUS_1)
					.username(USER_1)
					.pkid(PK_ID_1)
					.build());

			WorkflowNode workflowNode = WorkflowNode.builder()
					.description(WORKFLOW_DESCRIPTION)
					.build();

			List<DossierGeneratedPrintDTO> expectedOutput = List.of(DossierGeneratedPrintDTO.builder()
					.dossierId(DOSSIER_ID_1)
					.processStatus(WORKFLOW_DESCRIPTION)
					.username(USER_1)
					.pkid(PK_ID_1)
					.build());

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(moduleCrudService.findById(MODULE_ID_1))
					.thenReturn(Optional.of(moduleDTO));
			when(dossierGeneratedPrintCrudService.findAllGeneratedPrints(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierGeneratedPrintDTOs);
			when(dossiersWorkflowService.getWorkflowNode(TENANT_1, WORKFLOW_CODE_1, PROCESS_STATUS_1))
					.thenReturn(workflowNode);

			List<DossierGeneratedPrintDTO> result = dossiersService.getDossierPrintsByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getDossierPrintsByDossierId_returnEmptyList_ok() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
					.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

			List<DossierGeneratedPrintDTO> result = dossiersService.getDossierPrintsByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1);

			assertEquals(List.of(), result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getDossierPrintsByDossierId_DossierNotFoundRuntimeException() {
		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> dossiersService.getDossierPrintsByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getDossierPrintsByDossierId_ObjectNotFoundRuntimeException() {
		try {
			DossierDTO dossierDTO = DossierDTO.builder()
					.moduleId(MODULE_ID_1)
					.dossierId(DOSSIER_ID_1)
					.referredYear(YEAR_1)
					.partyId(PARTY_ID_1)
					.build();

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDTO);
			when(moduleCrudService.findById(MODULE_ID_1))
					.thenReturn(Optional.empty());

			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> dossiersService.getDossierPrintsByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void checkForMetadata_ok() {
		Map<String, Object> expectedOutput = Map.of("Key", "Value");

		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.of(moduleDTO));
		when(dossiersWorkflowService.getNodeMetadata(TENANT_1, WORKFLOW_CODE_1, PROCESS_STATUS))
				.thenReturn(expectedOutput);

		Map<String, Object> result = dossiersService.checkForMetadata(TENANT_1, MODULE_CODE, PROCESS_STATUS);

		assertEquals(expectedOutput, result);
	}

	@Test
	void test_checkForMetadata_ObjectNotFoundRuntimeException() {
		when(moduleCrudService.findByCode(TENANT_1, MODULE_CODE))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () -> dossiersService.checkForMetadata(TENANT_1, MODULE_CODE, PROCESS_STATUS_1));

	}

	@Test
	void test_getAvailableTransitionListByProcessId_ko() {
		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> dossiersService.getAvailableTransitionListByProcessId(TENANT_1, DOSSIER_ID_1, logged_user1, SCOPE));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getDossierHistoryByDossierId_ko() {
		try {
			when(dossiersCrudService.findByIdAlsoExpired(TENANT_1, DOSSIER_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(DossierNotFoundRuntimeException.class,
					() -> dossiersService.getDossierHistoryByDossierId(TENANT_1, DOSSIER_ID_1, logged_user1));
		} catch (Exception e) {
			fail(e);
		}
	}

	//	@Test
	//	void test_deleteCompileStatus_ko() {
	//		try {
	//			doThrow(ObjectNotFoundException.class)
	//					.when(dossiersCrudService).findById(TENANT_1, DOSSIER_ID_1);
	//
	//			assertThrows(DossierNotFoundRuntimeException.class,
	//					() -> dossiersService.deleteCompileStatus(TENANT_1, DOSSIER_ID_1, DOSSIER_COMPILE_STATUS_IDENTIFIER_1,
	//							USER_1));
	//		} catch (Exception e) {
	//			fail(e);
	//		}
	//	}

	@Test
	void test_findReadOnly_ko() {
		try {
			when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierWithDetailsDTO);
			when(dossierDetailsCrudService.findDossierDetailById(TENANT_1, DOSSIER_ID_1))
					.thenReturn(dossierDetailsDTONotInTransition);
			when(moduleDetailsCrudService.findByModuleId(TENANT_1, dossierWithDetailsDTO.getModuleId()))
					.thenReturn(ModuleDetailsDTO.builder().build());
			when((dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1)))
					.thenReturn(PROCESS_STATUS_DESCRIPTION);
			when(moduleFormConfigsCrudService.findById(TENANT_1, MODULE_FORM_CONFIG_ID_1))
					.thenThrow(ObjectNotFoundException.class);

			assertThrows(ObjectNotFoundRuntimeException.class,
					() -> dossiersService.findReadOnly(TENANT_1, DOSSIER_ID_1, MODULE_FORM_CONFIG_ID_1, logged_user1, sc));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_checkForMetadata_ko() {
		when(dossiersCrudService.findWithDetailsByDossierCode(TENANT_1, DOSSIER_CODE))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleCrudService.findById(dossierWithDetailsDTO.getModuleId()))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () -> dossiersService.checkForMetadata(TENANT_1, DOSSIER_CODE));
	}

	@Test
	void test_checkCanReadByAppId_ko() {
		when(dossiersCrudService.findWithDetailsByDossierId(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierWithDetailsDTO);

		dossiersService.checkCanReadByDosId(TENANT_1, DOSSIER_ID_1, logged_user1);

		verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);
	}

	@Test
	void test_progress_ok() {

		try {
			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierDTO);

			dossiersService.progress(TENANT_1, DOSSIER_ID_1, TAG_NAME, logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);

			verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);
			verify(progressService, times(1))
					.progress(TENANT_1, DOSSIER_ID_1, TAG_NAME, logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);
		} catch (Exception e) {
			fail(e);
		}

	}

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Test
	void test_progress2_ok() {

		try {

			ArgumentCaptor<HandleConsumer> handleConsumerArgumentCaptor = ArgumentCaptor.forClass(HandleConsumer.class);

			when(dossiersCrudService.findById(TENANT_1, DOSSIER_ID_1)).thenReturn(dossierDTO);

			dossiersService.progress(TENANT_1, DOSSIER_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);

			verify(checkPartyService, times(1)).checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

			verify(jdbi).useTransaction(handleConsumerArgumentCaptor.capture());
			handleConsumerArgumentCaptor.getValue().useHandle(handle);

			verify(progressService, times(1))
					.progress(TENANT_1, DOSSIER_ID_1, TRANSITION_ID, logged_user1, SCOPE, progressDossierDTO, ProgressTypeEnum.ASYNC);

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getModuleFormConfigsByModuleCode_ok() {

		when(formConfigService.findModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE)).thenReturn(moduleWithParamsPublicDTO);

		assertEquals(moduleWithParamsPublicDTO,
				dossiersService.getModuleFormConfigsByModuleCode(TENANT_1, MODULE_CODE));

	}

	@Test
	void getDossiersByParty_ok() {
		DossierByPartyDTO expectedOutput = DossierByPartyDTO.builder()
				.year(REFERRED_YEAR)
				.partyId(PARTY_ID_1)
				.dossierCode(DOSSIER_CODE)
				.sectorCode(SECTOR_CODE)
				.dossierId(DOSSIER_ID_1)
				.processId(PROCESS_ID_1)
				.moduleCode(MODULE_CODE)
				.moduleDescription(MODULE_CODE_DESC)
				.processStatusDescription(PROCESS_STATUS_DESCRIPTION)
				.flAmendable(Boolean.TRUE)
				.build();

		when(dossiersCrudService.find(TENANT_1, PARTY_ID_1, 0, List.of(), null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyDTO), null));
		when(dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))
				.thenReturn(PROCESS_STATUS_DESCRIPTION);
		when(dossiersCrudService.findWithDetailsByDossierCode(TENANT_1, DOSSIER_CODE))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleCrudService.findById(MODULE_ID_1))
				.thenReturn(Optional.of(moduleDTO));
		when(dossiersWorkflowService.getNodeMetadata(TENANT_1, WORKFLOW_CODE_1, PROCESS_STATUS))
				.thenReturn(Map.of("isAmendable", true));
		when(amendmentService.checkAmendmentStatus(TENANT_1, DOSSIER_ID_1, MODULE_CODE))
				.thenReturn(true);
		when(moduleCrudService.findByCode(any(), any())).thenReturn(Optional.of(moduleDTO));
		when(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(any(SecurityContext.class), any())).thenReturn(false);

		InfiniteListResults<DossierByPartyDTO> result = dossiersService.getDossiersByParty(TENANT_1, PARTY_ID_1,
				0, List.of(), null, logged_user1, sc);

		assertEquals(List.of(expectedOutput), result.getRecords());
	}

	@Test
	void getDossiersByParty_returnEmptyList_ok() {
		doThrow(ActionNotAuthorizedRuntimeException.class).when(checkPartyService)
				.checkCanReadParty(TENANT_1, PARTY_ID_1, logged_user1);

		InfiniteListResults<DossierByPartyDTO> result = dossiersService.getDossiersByParty(TENANT_1, PARTY_ID_1,
				0, List.of(), null, logged_user1, sc);

		assertEquals(List.of(), result.getRecords());
	}

	@Test
	void getDossiersByParty_exception_ok() {
		when(dossiersCrudService.find(TENANT_1, PARTY_ID_1, 0, List.of(), null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dossierByPartyDTO), null));
		when(dossiersWorkflowService.getProcessStatusDescription(TENANT_1, PROCESS_ID_1, logged_user1))
				.thenReturn(PROCESS_STATUS_DESCRIPTION);
		when(dossiersCrudService.findWithDetailsByDossierCode(TENANT_1, DOSSIER_CODE))
				.thenReturn(dossierWithDetailsDTO);
		when(moduleCrudService.findByCode(any(), any())).thenReturn(Optional.of(moduleDTO));
		when(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(any(SecurityContext.class), any())).thenReturn(false);

		InfiniteListResults<DossierByPartyDTO> result = dossiersService.getDossiersByParty(TENANT_1, PARTY_ID_1,
				0, List.of(), null, logged_user1, sc);

		assertEquals("ERROR", result.getRecords().get(0).getProcessStatusDescription());
		assertNotNull(result.getRecords().get(0).getDtClosed());
	}

	@Test
	void getDossiersByModuleCode_ok() {
		when(partyService.getPartiesByCodeOrDesc(TENANT_1, -1L, PARTY_ID_1.toString(), "", logged_user1))
				.thenReturn(List.of(partyDTO));
		when(dossiersCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, REFERRED_YEAR, PROCESS_STATUS, List.of(DOSSIER_ID_1), null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dosByPartyAndYearDTO), null));

		InfiniteListResults<DosByPartyAndYearDTO> result = dossiersService.getDossiersByModuleCode(TENANT_1, MODULE_CODE,
				PARTY_ID_1.toString(), REFERRED_YEAR, PROCESS_STATUS, List.of(DOSSIER_ID_1), null, logged_user1);

		assertEquals(List.of(dosByPartyAndYearDTO), result.getRecords());
	}

	@Test
	void getDossiersByPartyCode_ok() {
		when(partyService.getPartiesByCodeOrDesc(TENANT_1, -1L, PARTY_ID_1.toString(), "", logged_user1))
				.thenReturn(List.of(partyDTO));
		when(dossiersCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, PARTY_ID_1, REFERRED_YEAR, PROCESS_STATUS, null, null))
				.thenReturn(new InfiniteListResultsImpl<>(List.of(dosByPartyAndYearDTO), null));

		InfiniteListResults<DosByPartyAndYearDTO> result = dossiersService.getDossiersByPartyCode(TENANT_1, PARTY_ID_1.toString(),
				MODULE_CODE, REFERRED_YEAR, PROCESS_STATUS, null, logged_user1);

		assertEquals(List.of(dosByPartyAndYearDTO), result.getRecords());
	}

	@Test
	void getDossiersByModuleCode_emptyPartyIds_ok() {
		when(dossiersCrudService.findInfiniteResults(TENANT_1, MODULE_CODE, null, REFERRED_YEAR, PROCESS_STATUS, List.of(DOSSIER_ID_1), null))
				.thenReturn(new InfiniteListResultsImpl<>());

		InfiniteListResults<DosByPartyAndYearDTO> result = dossiersService.getDossiersByModuleCode(TENANT_1, MODULE_CODE,
				null, REFERRED_YEAR, PROCESS_STATUS, List.of(DOSSIER_ID_1), null, logged_user1);

		assertEquals(List.of(), result.getRecords());
	}

	@Test
	void getModules_ok() {
		when(moduleCrudService.findAllModulesWithDetail(TENANT_1))
				.thenReturn(List.of(moduleWithDetailDTO));

		List<ModuleWithDetailDTO> result = dossiersService.getModules(TENANT_1, sc);

		assertEquals(List.of(moduleWithDetailDTO), result);
	}


}
