package com.abacogroup.agri.dossiers.core.model;

import com.abacogroup.agri.dossiers.core.mappers.DossierMapper;
import com.abacogroup.agri.dossiers.db.dao.IGenericHistoricizationFieldsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;

import java.util.Optional;

public class TestImplAbstractHistoricizationFieldsCrudServiceWithCustomKey extends TestImplAbstractHistoricizationFieldsCrudService<Long> {
    public TestImplAbstractHistoricizationFieldsCrudServiceWithCustomKey(IGenericHistoricizationFieldsDAO<DossierNTT, Long, Long> dao, DossierMapper mapper) {
        super(dao, mapper);
    }

    @Override
    protected boolean hasPrimaryKey() {
        return false;
    }

    @Override
    protected Optional<DossierNTT> findRsByCustomKey(Long customKey) {
        return dao.findById(customKey).stream().findFirst();
    }
}
