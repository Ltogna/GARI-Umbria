package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.agri.dossiers.core.exceptions.CreateOrUpdateWorkflowRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ProgressWorkflowRuntimeException;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.sdk.auth.AuthContext;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.*;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.exceptions.ProcessNotFoundException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowGenericException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;
import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * The type Dossiers workflow service test.
 *
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class DossiersWorkflowServiceTest {

	private static final String TENANT = "tenant";
	private static final String TENANT_TO_COPY = "tenant to copy";
	private static final String DEST_TENANT = "destination tenant";

	private static final Long DOSSIER_ID = 1L;

	private static File tempFile = null;

	private static final Long PROCESS_ID = 1L;

	private static final Integer WORKFLOW_NODE_ID = 1;

	private static final String WORKFLOW_CODE_1 = "workflow_code - 1";
	private static final String WORKFLOW_CODE_2 = "workflow_code - 2";
	private static final String WORKFLOW_CODE_3 = "workflow_code - 3";

	private static final String ACTION = "action";

	private static final String NAME = "name";

	private static final String CURRENT_NODE = "current_node";
	private static final String NODE_FROM = "node from";
	private static final String NODE_TO = "node to";

	private static final NodeType NODE_TYPE = NodeType.start;

	private static final String NODE_DESCRIPTION = "node_description";

	private static final String NOTES = "notes";

	private static final Integer TRANSITION_ID = 5;

	private static final String SCOPE = "scope";

	private final Map<String, Object> metadataMock = new HashMap<>();

	private final WorkflowNode workflowNodeMock = WorkflowNode.builder()
			.id(WORKFLOW_NODE_ID)
			.action(ACTION)
			.name(NAME)
			.type(NODE_TYPE)
			.metadata(metadataMock)
			.build();

	private final ProcessState processStateMock = ProcessState.builder()
			.processId(PROCESS_ID)
			.workflowCode(WORKFLOW_CODE_1)
			.currentNodeDescription(NODE_DESCRIPTION)
			.build();

	private final User userMock = new User("user", TENANT);

	@Mock
	private WorkflowService workflowServiceMock;

	@Mock
	private ProcessService processServiceMock;

	@Mock
	private AuthContextFactory authContextFactoryMock;

	@Mock
	private FileFactory fileFactoryMock;
	@Mock
	private ProcessData processData;

	@Mock
	private DossierProfilesCrudService dossierProfilesCrudServiceMock;

	@InjectMocks
	private DossiersWorkflowService dossiersWorkflowService;

	@BeforeEach
	void init() throws IOException {
		dossiersWorkflowService = new DossiersWorkflowService(
				workflowServiceMock,
				processServiceMock,
				authContextFactoryMock,
				fileFactoryMock,
				dossierProfilesCrudServiceMock
		);

		metadataMock.put("first", "value");
		metadataMock.put("second", "value");

		tempFile = Files.createTempFile("tempFile", ".txt").toFile();
	}

	@AfterAll
	static void atFinally() {
		tempFile.delete();
	}

	@Test
	void test_addOrUpdateWorkflowFromInputStream() {
		byte[] array = new byte[10];
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(array);

		try {
			when(fileFactoryMock.createFile(byteArrayInputStream)).thenReturn(tempFile);

			dossiersWorkflowService.addOrUpdateWorkflowFromInputStream(TENANT, byteArrayInputStream);

		} catch (Exception e) {
			fail(e);
		} finally {
			IOUtils.closeQuietly(byteArrayInputStream);
		}
	}

	@Test
	void test_addOrUpdateWorkflowFromFile() {
		try {
			dossiersWorkflowService.addOrUpdateWorkflowFromFile(TENANT, tempFile);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getNodeMetadata() {
		try {
			when(workflowServiceMock.getWorkflowNode(TENANT, WORKFLOW_CODE_1, NAME, MDC.get(MDCPreFilter.LOCALE))).thenReturn(workflowNodeMock);

			Map<String, Object> result = dossiersWorkflowService.getNodeMetadata(TENANT, WORKFLOW_CODE_1, NAME);

			assertEquals(workflowNodeMock.getMetadata().get("firstValue"), result.get("firstValue"));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getProcessStatusDescription() {
		try {
			when(processServiceMock
					.getProcessState(PROCESS_ID, authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE))))
					.thenReturn(processStateMock);

			String result = dossiersWorkflowService.getProcessStatusDescription(TENANT, PROCESS_ID, userMock);

			assertEquals(processStateMock.getCurrentNodeDescription(), result);
		} catch (AuthenticationException e) {
			fail(e);
		}
	}

	@Test
	void test_getProcessTransitionHistory() {
		DetailedTransitionLog detailedTransitionLogMock = mock(DetailedTransitionLog.class);

		try {
			when(processServiceMock
					.getTransitionsHistory(PROCESS_ID,
							authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)),
							true)).thenReturn(List.of(detailedTransitionLogMock));

			List<DetailedTransitionLog> result = dossiersWorkflowService.getProcessTransitionHistory(TENANT, PROCESS_ID, userMock);

			assertEquals(detailedTransitionLogMock.getTransitionId(), result.get(0).getTransitionId());
		} catch (AuthenticationException e) {
			fail(e);
		}
	}

	@Test
	void test_executeProcessTransition() {
		AuthContext authContextMock = mock(AuthContext.class);
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());

		ProcessTransitionResult expectedOutput = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();

		try {
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE))).thenReturn(authContextMock);
			when(processServiceMock.executeProcessTransition(any()))
					.thenReturn(expectedOutput);

			ProcessTransitionResult result =
					dossiersWorkflowService
							.executeProcessTransition(TENANT, DOSSIER_ID, PROCESS_ID, TRANSITION_ID, userMock.getName(), MDC.get(MDCPreFilter.LOCALE),
									SCOPE, NOTES);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_executeProcessTransitionWithFatherProcessData() {
		AuthContext authContextMock = mock(AuthContext.class);
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());

		ProcessTransitionResult expectedOutput = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();

		try {
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE))).thenReturn(authContextMock);
			when(processServiceMock.executeProcessTransition(any(), eq(processData)))
					.thenReturn(expectedOutput);

			ProcessTransitionResult result =
					dossiersWorkflowService
							.executeProcessTransitionWithFatherProcessData(TENANT, DOSSIER_ID, PROCESS_ID, TRANSITION_ID, userMock.getName(), MDC.get(MDCPreFilter.LOCALE),
									SCOPE, NOTES, processData);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_executeProcessTransitionWithFatherProcessData_IOException() {
		AuthContext authContextMock = mock(AuthContext.class);
		try {
			when(processServiceMock.executeProcessTransition(any(), eq(processData)))
					.thenThrow(IOException.class);
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService
							.executeProcessTransitionWithFatherProcessData(TENANT, DOSSIER_ID, PROCESS_ID, TRANSITION_ID, userMock.getName(), MDC.get(MDCPreFilter.LOCALE),
					SCOPE, NOTES, processData));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_createProcess() {
		AuthContext authContextMock = mock(AuthContext.class);
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());
		ProcessTransitionResult.TransitionLog transitionLogMock = mock(ProcessTransitionResult.TransitionLog.class);
		List<WorkflowMessage> messages = List.of(new WorkflowMessage());

		ProcessTransitionResult expectedOutput = ProcessTransitionResult.builder()
				.processId(PROCESS_ID)
				.currentNode(CURRENT_NODE)
				.globalVars(globalVars)
				.lastTransitionLog(transitionLogMock)
				.messages(messages)
				.build();

		try {
			when(processServiceMock.createProcess(any()))
					.thenReturn(expectedOutput);
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			ProcessTransitionResult result =
					dossiersWorkflowService
							.createProcess(TENANT, DOSSIER_ID, userMock.getName(), WORKFLOW_CODE_1, MDC.get(MDCPreFilter.LOCALE), globalVars);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getUserAvailableTransitions() {
		AuthContext authContextMock = mock(AuthContext.class);
		List<String> tags = List.of("Tag - 1", "Tag - 2", "Tag - 3", "Tag - 4");

		List<Transition> expectedOutput = List.of(Transition.builder()
				.scope(SCOPE)
				.id(TRANSITION_ID)
				.notesRequired(false)
				.fromNode(NODE_FROM)
				.toNode(NODE_TO)
				.tags(tags)
				.build());

		try {
			when(processServiceMock.getUserAvailableTransitions(PROCESS_ID, authContextMock, SCOPE))
					.thenReturn(expectedOutput);
			when(authContextFactoryMock.createAuthContext(userMock, Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it")))
					.thenReturn(authContextMock);

			List<Transition> result = dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID, userMock, SCOPE);

			assertEquals(expectedOutput, result);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getWorkflowFilesByTenantAndInsertThem() {
		List<String> workflowCodes = List.of(WORKFLOW_CODE_1, WORKFLOW_CODE_2, WORKFLOW_CODE_3);

		try {
			when(workflowServiceMock.getWorkflowCodes(TENANT_TO_COPY))
					.thenReturn(workflowCodes);

			dossiersWorkflowService.getWorkflowFilesByTenantAndInsertThem(TENANT_TO_COPY, DEST_TENANT);

			verify(workflowServiceMock, times(1)).getWorkflowCodes(TENANT_TO_COPY);
			verify(workflowServiceMock, times(3)).getWorkflowPackage(eq(TENANT_TO_COPY), any(), any());
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_getWorkflowFilesByTenantAndInsertThem_IOException() {
		List<String> workflowCodes = List.of(WORKFLOW_CODE_1, WORKFLOW_CODE_2, WORKFLOW_CODE_3);

		try {
			when(workflowServiceMock.getWorkflowCodes(TENANT_TO_COPY))
					.thenReturn(workflowCodes);

			doThrow(IOException.class).when(workflowServiceMock).getWorkflowPackage(eq(TENANT_TO_COPY), any(), any());

			assertThrows(WorkflowGenericException.class, () ->
					dossiersWorkflowService.getWorkflowFilesByTenantAndInsertThem(TENANT_TO_COPY, DEST_TENANT));

			verify(workflowServiceMock, times(1)).getWorkflowCodes(TENANT_TO_COPY);
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_addOrUpdateWorkflowFromInputStream_exception() {
		byte[] array = new byte[10];
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(array);

		try {
			when(fileFactoryMock.createFile(byteArrayInputStream))
					.thenThrow(IOException.class);

			assertThrows(CreateOrUpdateWorkflowRuntimeException.class, () ->
					dossiersWorkflowService.addOrUpdateWorkflowFromInputStream(TENANT, byteArrayInputStream));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_addOrUpdateWorkflowFromFile_exception() {
		try {
			when(workflowServiceMock.addOrUpdateWorkflow(TENANT, tempFile))
					.thenThrow(IOException.class);

			assertThrows(CreateOrUpdateWorkflowRuntimeException.class, () ->
					dossiersWorkflowService.addOrUpdateWorkflowFromFile(TENANT, tempFile));
		} catch (Exception e) {
			fail(e);
		}
	}

	@Test
	void test_createProcess_IOException() {
		AuthContext authContextMock = mock(AuthContext.class);
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());

		try {
			when(processServiceMock.createProcess(any()))
					.thenThrow(IOException.class);
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService
							.createProcess(TENANT, DOSSIER_ID, userMock.getName(), WORKFLOW_CODE_1, MDC.get(MDCPreFilter.LOCALE), globalVars));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_createProcess_AuthenticationException() {
		Map<String, Object> globalVars = Map.of(ApplicationsWorkflowParams.KEY, new ApplicationsWorkflowParams());

		try {
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenThrow(AuthenticationException.class);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService
							.createProcess(TENANT, DOSSIER_ID, userMock.getName(), WORKFLOW_CODE_1, MDC.get(MDCPreFilter.LOCALE), globalVars));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_executeProcessTransition_IOException() {
		AuthContext authContextMock = mock(AuthContext.class);
		try {
			when(processServiceMock.executeProcessTransition(any()))
					.thenThrow(IOException.class);
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService
							.executeProcessTransition(TENANT, DOSSIER_ID, PROCESS_ID, TRANSITION_ID, userMock.getName(), MDC.get(MDCPreFilter.LOCALE),
									SCOPE, NOTES));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_executeProcessTransition_AuthenticationException() {
		try {
			when(authContextFactoryMock.createAuthContext(TENANT, userMock.getName(), MDC.get(MDCPreFilter.LOCALE)))
					.thenThrow(AuthenticationException.class);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService
							.executeProcessTransition(TENANT, DOSSIER_ID, PROCESS_ID, TRANSITION_ID, userMock.getName(), MDC.get(MDCPreFilter.LOCALE),
									SCOPE, NOTES));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getUserAvailableTransitions_IOException() {
		AuthContext authContextMock = mock(AuthContext.class);

		try {
			when(processServiceMock.getUserAvailableTransitions(PROCESS_ID, authContextMock, SCOPE))
					.thenThrow(IOException.class);
			when(authContextFactoryMock.createAuthContext(userMock, Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it")))
					.thenReturn(authContextMock);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID, userMock, SCOPE));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getUserAvailableTransitions_WorkflowNotFoundException() {
		AuthContext authContextMock = mock(AuthContext.class);

		try {
			when(processServiceMock.getUserAvailableTransitions(PROCESS_ID, authContextMock, SCOPE))
					.thenThrow(WorkflowNotFoundException.class);
			when(authContextFactoryMock.createAuthContext(userMock, Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it")))
					.thenReturn(authContextMock);

			assertThrows(ObjectNotFoundRuntimeException.class, () ->
					dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID, userMock, SCOPE));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getUserAvailableTransitions_AuthenticationException() {
		try {
			when(authContextFactoryMock.createAuthContext(userMock, Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it")))
					.thenThrow(AuthenticationException.class);

			assertThrows(ProgressWorkflowRuntimeException.class, () ->
					dossiersWorkflowService.getUserAvailableTransitions(PROCESS_ID, userMock, SCOPE));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getProcessTransitionHistory_WorkflowNotFoundException() {
		AuthContext authContextMock = mock(AuthContext.class);

		try {
			when(processServiceMock.getTransitionsHistory(PROCESS_ID, authContextMock, true))
					.thenThrow(WorkflowNotFoundException.class);
			when(authContextFactoryMock.createAuthContext(userMock, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			assertThrows(ObjectNotFoundRuntimeException.class, () ->
					dossiersWorkflowService.getProcessTransitionHistory(TENANT, PROCESS_ID, userMock));

		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getProcessTransitionHistory_AuthenticationException() {
		try {
			when(authContextFactoryMock.createAuthContext(userMock, MDC.get(MDCPreFilter.LOCALE)))
					.thenThrow(AuthenticationException.class);

			assertThrows(ObjectNotFoundRuntimeException.class, () ->
					dossiersWorkflowService.getProcessTransitionHistory(TENANT, PROCESS_ID, userMock));
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getProcessStatusDescription_ProcessNotFoundException() {
		AuthContext authContextMock = mock(AuthContext.class);

		try {
			when(processServiceMock.getProcessState(PROCESS_ID, authContextMock))
					.thenThrow(ProcessNotFoundException.class);
			when(authContextFactoryMock.createAuthContext(userMock, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			String result = dossiersWorkflowService.getProcessStatusDescription(TENANT, PROCESS_ID, userMock);

			assertNull(result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getProcessStatusDescription_WorkflowNotFoundException() {
		AuthContext authContextMock = mock(AuthContext.class);

		try {
			when(processServiceMock.getProcessState(PROCESS_ID, authContextMock))
					.thenThrow(WorkflowNotFoundException.class);
			when(authContextFactoryMock.createAuthContext(userMock, MDC.get(MDCPreFilter.LOCALE)))
					.thenReturn(authContextMock);

			String result = dossiersWorkflowService.getProcessStatusDescription(TENANT, PROCESS_ID, userMock);

			assertNull(result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void test_getProcessStatusDescription_AuthenticationException() {
		try {
			when(authContextFactoryMock.createAuthContext(userMock, MDC.get(MDCPreFilter.LOCALE)))
					.thenThrow(AuthenticationException.class);

			String result = dossiersWorkflowService.getProcessStatusDescription(TENANT, PROCESS_ID, userMock);

			assertNull(result);
		} catch (Exception e) {
			fail(e);
		}

	}

	@Test
	void getWorkflowNode_ok() {
		when(workflowServiceMock.getWorkflowNode(TENANT, WORKFLOW_CODE_1, NODE_FROM, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(workflowNodeMock);

		WorkflowNode result = dossiersWorkflowService.getWorkflowNode(TENANT, WORKFLOW_CODE_1, NODE_FROM);

		assertEquals(workflowNodeMock, result);
	}

	@Test
	void getWorkflowNodesByType_ok() {
		when(workflowServiceMock.getWorkflowNodesByType(TENANT, WORKFLOW_CODE_1, NODE_TYPE, MDC.get(MDCPreFilter.LOCALE)))
				.thenReturn(List.of(workflowNodeMock));

		List<WorkflowNode> result = dossiersWorkflowService.getWorkflowNodesByType(TENANT, WORKFLOW_CODE_1, NODE_TYPE);

		assertEquals(List.of(workflowNodeMock), result);
	}
}
