package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class LogicallyDeleteDossierImplTest {
    @Mock
    private DossiersCrudService dossiersCrudService;

    @InjectMocks
    private LogicallyDeleteDossierImpl logicallyDeleteDossier;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);

    @Test
    void logicallyDeleteApplication_ok() {
        logicallyDeleteDossier.logicallyDeleteApplication(TENANT, DOSSIER_ID, USER);

        verify(dossiersCrudService, times(1)).delete(DOSSIER_ID, USERNAME);
    }
}