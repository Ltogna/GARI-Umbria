package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierEnvMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierEnvDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierEnvNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * The type Dossier env crud service test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class DossierEnvCrudServiceTest {

    private static final String TENANT_ID = "*";
    private static final String KEY = "key";
    private static final String VALUE = "value";
    private static final Integer FL_CLIENT = 1;

    private final DossierEnvDTO dossierEnvDTOMock = DossierEnvDTO.builder()
            .tenant(TENANT_ID)
            .key(KEY)
            .value(VALUE)
            .flClient(FL_CLIENT)
            .build();

    private final DossierEnvNTT dossierEnvNTTMock = DossierEnvNTT.builder()
            .tenant_id(TENANT_ID)
            .key_(KEY)
            .value(VALUE)
            .fl_client(FL_CLIENT)
            .build();

    private final DossierEnvKey dossierEnvKeyMock = DossierEnvKey.builder()
            .tenant_id(TENANT_ID)
            .key_(KEY)
            .fl_client(FL_CLIENT)
            .build();

    @Mock
    private DossierEnvMapper dossierEnvMapper;
    @Mock
    private DossierEnvDAO dossierEnvDAO;
    @InjectMocks
    private DossierEnvCrudService dossierEnvCrudService;

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_insert() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dossierEnvDAO.findByKey(dossierEnvKeyMock)).thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.dtoToEntity(dossierEnvDTOMock))
                    .thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.entityToDto(dossierEnvNTTMock))
                    .thenReturn(dossierEnvDTOMock);

            dossierEnvCrudService.insert(dossierEnvDTOMock);

            verify(dossierEnvDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            DossierEnvDTO actual = (DossierEnvDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierEnvDAO);

            assertEquals(dossierEnvDTOMock, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_update() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dossierEnvDAO.findByKey(dossierEnvKeyMock))
                    .thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.dtoToEntity(dossierEnvDTOMock))
                    .thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.entityToDto(dossierEnvNTTMock))
                    .thenReturn(dossierEnvDTOMock);

            dossierEnvCrudService.update(dossierEnvKeyMock, dossierEnvDTOMock);

            verify(dossierEnvDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            handleConsumerLambdaCaptor.getValue().inTransaction(dossierEnvDAO);

            verify(dossierEnvDAO, times(1)).inTransaction(handleConsumerLambdaCaptor.capture());

            DossierEnvDTO actual = (DossierEnvDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierEnvDAO);

            assertEquals(dossierEnvDTOMock, actual);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void test_delete() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);
            dossierEnvCrudService.delete(dossierEnvKeyMock);

            verify(dossierEnvDAO).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(dossierEnvDAO);
            verify(dossierEnvDAO).deleteById(dossierEnvKeyMock);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void test_findByEnv() {
        try {
            when(dossierEnvDAO.findByKey(dossierEnvKeyMock))
                    .thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.entityToDto(dossierEnvNTTMock))
                    .thenReturn(dossierEnvDTOMock);

            DossierEnvDTO result = dossierEnvCrudService.findEnvironmentByKey(dossierEnvKeyMock);

            assertEquals(dossierEnvDTOMock, result);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            fail(e.getMessage(), e);
        }
    }

    @Test
    void findByKeyWithoutFlClient_ok() {
        try {
            when(dossierEnvDAO.findByKeyWithoutFlClient(dossierEnvKeyMock))
                    .thenReturn(dossierEnvNTTMock);
            when(dossierEnvMapper.entityToDto(dossierEnvNTTMock))
                    .thenReturn(dossierEnvDTOMock);

            DossierEnvDTO result = dossierEnvCrudService.findByKeyWithoutFlClient(dossierEnvKeyMock);

            assertEquals(dossierEnvDTOMock, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findByKeyWithoutFlClient_ko() {
        try {
            when(dossierEnvDAO.findByKeyWithoutFlClient(dossierEnvKeyMock))
                    .thenReturn(null);

            assertThrows(ObjectNotFoundException.class, () ->
                    dossierEnvCrudService.findByKeyWithoutFlClient(dossierEnvKeyMock));
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void deleteByCustomKey_ok() {
        dossierEnvCrudService.deleteByCustomKey(dossierEnvKeyMock);

        verify(dossierEnvDAO, times(1)).deleteById(dossierEnvKeyMock);
    }

    @Test
    void setCustomSearchKey_ok() {
        DossierEnvNTT rs = DossierEnvNTT.builder()
                        .build();
        dossierEnvCrudService.setCustomSearchKey(rs, dossierEnvKeyMock);

        assertEquals(dossierEnvKeyMock.getTenant_id(), rs.getTenant_id());
        assertEquals(dossierEnvKeyMock.getKey_(), rs.getKey_());
        assertEquals(dossierEnvKeyMock.getFl_client(), rs.getFl_client());
    }

    @Test
    void findAllByTenant_ok() {
        when(dossierEnvDAO.findAll(TENANT_ID))
                .thenReturn(List.of(dossierEnvNTTMock));
        when(dossierEnvMapper.entityToDto(dossierEnvNTTMock))
                .thenReturn(dossierEnvDTOMock);

        List<DossierEnvDTO> result = dossierEnvCrudService.findAllByTenant(TENANT_ID);

        assertEquals(List.of(dossierEnvDTOMock), result);
    }
}