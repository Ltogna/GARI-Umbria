package com.abacogroup.agri.dossiers.core.caller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;
import java.util.Objects;

import static com.abacogroup.agri.dossiers.core.caller.GetPartiesInput.RESOURCE;
import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class GetPartiesInputTest {

    private GetPartiesInput getPartiesInput;

    private static final String URL = "URL";
    private static final String TENANT = "TENANT";
    private static final String SEARCH_CODE = "Search Code";
    private static final String SEARCH_DESCRIPTION = "Search Description";
    private static final Long PARTY_ID = 123456879L;
    private static final String AUTH_TOKEN = "Auth Token";


    @BeforeEach
    void init() {
        getPartiesInput = new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, URL, SEARCH_CODE, SEARCH_DESCRIPTION);
    }

    @Test
    void getPathVariablesMap_ok() {
        Map<String, Object> expectedOutput = Map.of("TENANT", TENANT);

        Map<String, Object> result = getPartiesInput.getPathVariablesMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void provideAuthToken_ok() {
        String result = getPartiesInput.provideAuthToken();

        assertEquals(AUTH_TOKEN, result);
    }

    @Test
    void getQueryParamsMap_ok() {
        Map<String, Object> expectedOutput = Map.of("search_code", SEARCH_CODE,
                "search_description", SEARCH_DESCRIPTION);

        Map<String, Object> result = getPartiesInput.getQueryParamsMap();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getUrl_ok() {
        String expectedOutput = URL + RESOURCE;

        String result = getPartiesInput.getUrl();

        assertEquals(expectedOutput, result);
    }

    @Test
    void getUrl_withResource_ok() {
        String legacyUrlWithResource = URL + RESOURCE;

        getPartiesInput = new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, legacyUrlWithResource, SEARCH_CODE, SEARCH_DESCRIPTION);

        String result = getPartiesInput.getUrl();

        assertEquals(legacyUrlWithResource, result);
    }

    @Test
    void getHttpMethod_ok() {
        String result = getPartiesInput.getHttpMethod();

        assertEquals(GET_METHOD, result);
    }

    @Test
    void equals_true_ok() {
        GetPartiesInput newInstance =
                new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, URL, SEARCH_CODE, SEARCH_DESCRIPTION);

        boolean result = getPartiesInput.equals(newInstance);

        assertTrue(result);
    }

    @Test
    void equals_differentTenant_false_ok() {
        GetPartiesInput newInstance = new GetPartiesInput("Different Tenant", PARTY_ID, AUTH_TOKEN,
                URL, SEARCH_CODE, SEARCH_DESCRIPTION);

        boolean result = getPartiesInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_differentParty_false_ok() {
        GetPartiesInput newInstance =
                new GetPartiesInput(TENANT, 0L, AUTH_TOKEN, URL, SEARCH_CODE, SEARCH_DESCRIPTION);

        boolean result = getPartiesInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_differentSearchCode_false_ok() {
        GetPartiesInput newInstance = new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, URL,
                "Different Search Code", SEARCH_DESCRIPTION);

        boolean result = getPartiesInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_differentSearchDescription_false_ok() {
        GetPartiesInput newInstance = new GetPartiesInput(TENANT, PARTY_ID, AUTH_TOKEN, URL,
                SEARCH_CODE, "Different Search Description");

        boolean result = getPartiesInput.equals(newInstance);

        assertFalse(result);
    }

    @Test
    void equals_sameObject_true_ok() {
        boolean result = getPartiesInput.equals(getPartiesInput);

        assertTrue(result);
    }

    @Test
    void equals_differentInstance_false_ok() {
        CheckCanReadPartyInput checkCanReadPartyInput = CheckCanReadPartyInput.builder()
                .url(URL)
                .tenant(TENANT)
                .partyId(PARTY_ID)
                .authToken(AUTH_TOKEN)
                .build();

        boolean result = getPartiesInput.equals(checkCanReadPartyInput);

        assertFalse(result);
    }

    @Test
    void hashCode_ok() {
        Integer expectedOutput = Objects.hash(SEARCH_CODE, SEARCH_DESCRIPTION);

        Integer result = getPartiesInput.hashCode();

        assertEquals(expectedOutput, result);
    }
}
