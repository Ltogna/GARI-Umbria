package com.abacogroup.agri.dossiers.bundles.processor.amendable;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.File;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

@Slf4j
@ExtendWith(MockitoExtension.class)
class BundleAmendableModulesProcessorTest {

	protected static final String TEMPLATE_TENANT_ID = "*";
	protected static final String DOMAIN_NAME = "amendable-modules";

	protected static final String SECTOR_CODE = "module_code";
	private static final String DESCRIPTION = "description";
	private static final String AMENDABLE_MODULE_CODE = "AMENDABLE_MODULE_CODE";
	private static final String MODULE_CODE = "MODULE_CODE";
	private static final String LANG = "lang";

	private static final Path PATH = new File("test.json").toPath();

	private final I18nPair moduleI18nMock = I18nPair.builder()
			.description(DESCRIPTION)
			.lang(LANG)
			.build();

	private final BundleAmendableModuleInDTO bundleAmendableModuleInDTO = BundleAmendableModuleInDTO.builder()
			.amendableModuleCode(AMENDABLE_MODULE_CODE)
			.moduleCode(MODULE_CODE)
			.build();

	private final BundleAmendableModulesMessage bundleModulesMessageMock = BundleAmendableModulesMessage.builder()
			.amendableModules(List.of(bundleAmendableModuleInDTO))
			.build();

	private final ConfigDataMessage configDataMessage = new ConfigDataMessage();
	@Mock
	private AmendableModulesBundleWorker amendableModulesBundleWorker;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	private Jdbi jdbi;
	@InjectMocks
	private BundleAmendableModulesProcessor bundleAmendableModulesProcessor;

	@BeforeEach
	void init() {
		configDataMessage.setTenantId(TEMPLATE_TENANT_ID);
		bundleAmendableModulesProcessor = new BundleAmendableModulesProcessor(objectMapper, amendableModulesBundleWorker, jdbi);
	}

	@Test
	void test_getDomainName() {
		assertEquals(DOMAIN_NAME, bundleAmendableModulesProcessor.getDomainName());
	}

	@Test
	void test_getTypeReference() {
		assertEquals(new TypeReference<BundleAmendableModulesMessage>() {
		}.getType(), bundleAmendableModulesProcessor.getTypeReference().getType());
	}

	@Test
	void onMessageInTransaction() {
		try {
			configDataMessage.setConfigFiles(List.of(PATH));
			bundleAmendableModulesProcessor.onMessageInTransaction(configDataMessage);
			verify(objectMapper).readValue(eq(PATH.toFile()), any(TypeReference.class));
		} catch (Exception e) {
			fail(e.getMessage(), e);
		}
	}

	@Test
	void test_doInsertOrUpdate() {
		bundleAmendableModulesProcessor.doInsertOrUpdate(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		verify(amendableModulesBundleWorker).insertBundleModules(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
	}

	// TODO when delete method is implemented
	@Test
	void test_delete() {
		bundleAmendableModulesProcessor.delete(TEMPLATE_TENANT_ID, bundleModulesMessageMock);
		assert true;
	}
}
