package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.mappers.DossierProtocolsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierProtocolsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierProtocolsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProtocolsNTT;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierProtocolsCrudServiceTest {
    @Mock
    DossierProtocolsDAO dossierProtocolsDAO;
    @Mock
    DossierProtocolsMapper dossierProtocolsMapper;

    @InjectMocks
    DossierProtocolsCrudService dossierProtocolsCrudService;

    private static final String TENANT = "ADMIN";
    private static final String USERNAME = "Username";
    private static final Long DOSSIER_ID = 5L;
    private static final Long PKID = 1L;
    private static final String PROTOCOL = "Protocol";
    private static final LocalDateTime REQUEST_DATE = LocalDateTime.now();
    private static final LocalDateTime RESPONSE_DATE = LocalDateTime.of(2030, 9, 27, 10, 5, 26);

    private final DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
            .pkid(PKID)
            .dossierId(DOSSIER_ID)
            .protocol(PROTOCOL)
            .dtRequest(REQUEST_DATE)
            .dtResponse(RESPONSE_DATE)
            .build();
    private final DossierProtocolsNTT dossierProtocolsNTT = DossierProtocolsNTT.builder()
            .pkid(PKID)
            .dossier_id(DOSSIER_ID)
            .protocol(PROTOCOL)
            .dt_request(REQUEST_DATE)
            .dt_response(RESPONSE_DATE)
            .build();

    @Test
    void findById_ok() {
        try {
            when(dossierProtocolsDAO.findById(PKID))
                    .thenReturn(List.of(dossierProtocolsNTT));
            when(dossierProtocolsMapper.entityToDto(dossierProtocolsNTT))
                    .thenReturn(dossierProtocolsDTO);

            DossierProtocolsDTO result = dossierProtocolsCrudService.findById(PKID);

            assertEquals(dossierProtocolsDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void findAll_ok() {
        when(dossierProtocolsDAO.find(TENANT, DOSSIER_ID))
                .thenReturn(List.of(dossierProtocolsNTT));
        when(dossierProtocolsMapper.entityToDto(dossierProtocolsNTT))
                .thenReturn(dossierProtocolsDTO);

        List<DossierProtocolsDTO> result = dossierProtocolsCrudService.findAll(TENANT, DOSSIER_ID);

        assertEquals(List.of(dossierProtocolsDTO), result);
    }

    @Test
    void logicallyDeleteByDossierId_ok() {
        dossierProtocolsCrudService.logicallyDeleteByDossierId(PKID, USERNAME);

        verify(dossierProtocolsDAO, times(1)).logicallyDeleteById(eq(PKID), eq(USERNAME), any());
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ok() {
        DossierProtocolsDTO in = DossierProtocolsDTO.builder()
                .dossierId(DOSSIER_ID)
                .protocol(PROTOCOL)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dossierProtocolsDAO.nextSequenceVal())
                    .thenReturn(PKID);
            when(dossierProtocolsMapper.dtoToEntity(in))
                    .thenReturn(dossierProtocolsNTT);
            when(dossierProtocolsDAO.findById(PKID))
                    .thenReturn(List.of(dossierProtocolsNTT));
            when(dossierProtocolsMapper.entityToDto(dossierProtocolsNTT))
                    .thenReturn(dossierProtocolsDTO);

            dossierProtocolsCrudService.insert(in, USERNAME);

            verify(dossierProtocolsDAO).inTransaction(handleConsumerLambdaCaptor.capture());

            DossierProtocolsDTO result = (DossierProtocolsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierProtocolsDAO);

            assertEquals(dossierProtocolsDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void update_ok() {
        DossierProtocolsDTO in = DossierProtocolsDTO.builder()
                .dossierId(DOSSIER_ID)
                .protocol(PROTOCOL)
                .build();

        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);
            when(dossierProtocolsDAO.getCurrentTimestamp())
                    .thenReturn(LocalDateTime.now());
            when(dossierProtocolsDAO.inTransaction(handleConsumerLambdaCaptor.capture()))
                    .thenReturn(dossierProtocolsDTO);

            dossierProtocolsCrudService.update(PKID, in, USERNAME);

            verify(dossierProtocolsDAO).inTransaction(handleConsumerLambdaCaptor.capture());
            DossierProtocolsDTO result = (DossierProtocolsDTO) handleConsumerLambdaCaptor.getValue().inTransaction(dossierProtocolsDAO);

            assertEquals(dossierProtocolsDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void retrieveCustomKeyByResultSet_ok() {
        assertNull(dossierProtocolsCrudService.retrieveCustomKeyByResultSet(dossierProtocolsNTT));
    }

    @Test
    void findRsByCustomKey_ok() {
        Optional<DossierProtocolsNTT> result = dossierProtocolsCrudService.findRsByCustomKey(null);

        assertEquals(Optional.empty(), result);
    }
}