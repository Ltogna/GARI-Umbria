package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierProtocolsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierGeneratedPrintCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProtocolsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProtocol;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatcher;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DossierProtocolUtilsImplTest {
    @Mock
    DossiersCrudService dossiersCrudService;
    @Mock
    DossierProtocolsCrudService dossierProtocolsCrudService;
    @Mock
    DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;

    @InjectMocks
    DossierProtocolUtilsImpl dossierProtocolUtils;

    private static final String TENANT = "ADMIN";
    private static final Long DOSSIER_ID = 5L;
    private static final String USERNAME = "Username";
    private static final User USER = new User(USERNAME, TENANT);
    private static final Long PROCESS_ID = 10L;
    private static final Integer REFERRED_YEAR = 2023;
    private static final Long MODULE_ID = 15L;
    private static final Long PARTY_ID = 123456L;
    private static final String MODULE_DESCRIPTION = "Module Description";
    private static final String SECTOR_DESCRIPTION = "Sector Description";
    private static final String PROCESS_STATUS = "Process Status";
    private static final String PRINT_CODE = "Print Code";
    private static final String PRINT_DESCRIPTION = "Print Description";
    private static final String PRINT_STATUS = "Print Status";
    private static final String PRINT_JOB_UUID = "Print Job UUID";
    private static final String FILE_ID = "File ID";
    private static final Long PKID = 1L;
    private static final LocalDateTime NOW = LocalDateTime.now();
    private static final String PROTOCOL = "Protocol";

    private final DossierWithDetailsDTO dossierWithDetails = DossierWithDetailsDTO.builder()
            .dossierId(DOSSIER_ID)
            .processId(PROCESS_ID)
            .referredYear(REFERRED_YEAR)
            .moduleId(MODULE_ID)
            .moduleDescription(MODULE_DESCRIPTION)
            .sectorDescription(SECTOR_DESCRIPTION)
            .partyId(PARTY_ID)
            .processStatus(PROCESS_STATUS)
            .build();
    private final DossierGeneratedPrintDTO dossierGeneratedPrintDTO = DossierGeneratedPrintDTO.builder()
            .printCode(PRINT_CODE)
            .dossierId(DOSSIER_ID)
            .printDescription(PRINT_DESCRIPTION)
            .fileId(FILE_ID)
            .pkid(PKID)
            .printStatus(PRINT_STATUS)
            .printJobUuid(PRINT_JOB_UUID)
            .printDate(NOW)
            .username(USERNAME)
            .processStatus(PROCESS_STATUS)
            .build();

    @Test
    void retrieveSectorDescription_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(dossierWithDetails);

        String result =
                dossierProtocolUtils.retrieveSectorDescription(TENANT, DOSSIER_ID, USER, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(SECTOR_DESCRIPTION, result);
    }

    @Test
    void retrieveModuleDescription_ok() {
        when(dossiersCrudService.findWithDetailsByDossierId(TENANT, DOSSIER_ID, MDC.get(MDCPreFilter.LOCALE)))
                .thenReturn(dossierWithDetails);

        String result =
                dossierProtocolUtils.retrieveModuleDescription(TENANT, DOSSIER_ID, USER, MDC.get(MDCPreFilter.LOCALE));

        assertEquals(MODULE_DESCRIPTION, result);
    }

    @Test
    void insertProtocolRequest_ok() {
        dossierProtocolUtils.insertProtocolRequest(TENANT, DOSSIER_ID, USER);

        verify(dossierProtocolsCrudService, times(1))
                .insert(any(DossierProtocolsDTO.class), eq(USERNAME));
    }

    @Test
    void retrievePrintId_ok() {
        when(dossierGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, DOSSIER_ID))
                .thenReturn(List.of(dossierGeneratedPrintDTO));

        String result = dossierProtocolUtils.retrievePrintId(TENANT, DOSSIER_ID, PRINT_CODE, USER);

        assertEquals(FILE_ID, result);
    }

    @Test
    void retrievePrintId_ko() {
        when(dossierGeneratedPrintCrudService.findAllGeneratedPrints(TENANT, DOSSIER_ID))
                .thenReturn(List.of());

        assertThrows(RuntimeException.class, () ->
                dossierProtocolUtils.retrievePrintId(TENANT, DOSSIER_ID, PRINT_CODE, USER));
    }

    @Test
    void insertProtocolCodeAndDate_ok() {
        DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
                .pkid(PKID)
                .dossierId(DOSSIER_ID)
                .dtRequest(NOW)
                .build();

        DossierProtocolsDTO in = DossierProtocolsDTO.builder()
                .pkid(PKID)
                .dossierId(DOSSIER_ID)
                .dtRequest(NOW)
                .protocol(PROTOCOL)
                .dtResponse(NOW)
                .build();

        when(dossierProtocolsCrudService.findAll(TENANT, DOSSIER_ID))
                .thenReturn(List.of(dossierProtocolsDTO));

        dossierProtocolUtils.insertProtocolCodeAndDate(TENANT, DOSSIER_ID, PROTOCOL, NOW, USER);

        verify(dossierProtocolsCrudService, times(1)).update(PKID, in, USERNAME);
    }

    @Test
    void insertProtocolCodeAndDate_withoutDate_ok() {
        DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
                .pkid(PKID)
                .dossierId(DOSSIER_ID)
                .dtRequest(NOW)
                .build();

        when(dossierProtocolsCrudService.findAll(TENANT, DOSSIER_ID))
                .thenReturn(List.of(dossierProtocolsDTO));

        ArgumentMatcher<DossierProtocolsDTO> inMatcher = argument -> PKID.equals(argument.getPkid()) &&
                DOSSIER_ID.equals(argument.getDossierId()) &&
                NOW.equals(argument.getDtRequest()) &&
                PROTOCOL.equals(argument.getProtocol()) &&
                Optional.ofNullable(argument.getDtResponse()).isPresent();

        dossierProtocolUtils.insertProtocolCodeAndDate(TENANT, DOSSIER_ID, PROTOCOL, null, USER);

        verify(dossierProtocolsCrudService, times(1)).update(eq(PKID), argThat(inMatcher), eq(USERNAME));
    }

    @Test
    void retrieveProtocol_ok() {
        DossierProtocolsDTO dossierProtocolsDTO = DossierProtocolsDTO.builder()
                .pkid(PKID)
                .dossierId(DOSSIER_ID)
                .protocol(PROTOCOL)
                .dtRequest(NOW)
                .dtResponse(NOW)
                .build();

        ApplicationProtocol expectedOutput = ApplicationProtocol.builder()
                .applicationId(DOSSIER_ID)
                .protocol(PROTOCOL)
                .dtRequest(NOW)
                .dtResponse(NOW)
                .build();

        when(dossierProtocolsCrudService.findAll(TENANT, DOSSIER_ID))
                .thenReturn(List.of(dossierProtocolsDTO));

        Optional<ApplicationProtocol> result = dossierProtocolUtils.retrieveProtocol(TENANT, DOSSIER_ID);

        assertEquals(Optional.of(expectedOutput), result);
    }
}