package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.mappers.DossierMapper;
import com.abacogroup.agri.dossiers.core.model.MockGenericHistoricizationFieldsDAO;
import com.abacogroup.agri.dossiers.core.model.TestImplAbstractHistoricizationFieldsCrudService;
import com.abacogroup.agri.dossiers.core.model.TestImplAbstractHistoricizationFieldsCrudServiceWithCustomKey;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;
import com.abacogroup.jdbi.paging.PagedResults;
import com.abacogroup.jdbi.paging.impl.PagedResultsImpl;
import org.jdbi.v3.core.statement.StatementContext;
import org.jdbi.v3.core.statement.StatementException;
import org.jdbi.v3.sqlobject.transaction.TransactionalCallback;
import org.jdbi.v3.sqlobject.transaction.TransactionalConsumer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.function.Supplier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AbstractHistoricizationFieldsCrudServiceTest {

    @Mock
    private DossierDAO dao;
    @Mock
    private MockGenericHistoricizationFieldsDAO daoWithCustomKey;
    @Mock
    private DossierMapper mapper;

    private AbstractHistoricizationFieldsCrudService<DossierNTT, Long, DossierDTO, DossierMapper, Void> abstractHistoricizationFieldsCrudService;
    private AbstractHistoricizationFieldsCrudService<DossierNTT, Long, DossierDTO, DossierMapper, Long> abstractHistoricizationFieldsCrudServiceWithCustomKey;

    private static final Long DOSSIER_ID = 5L;
    private static final Long MODULE_ID = 10L;
    private static final Long PROCESS_ID = 20L;
    private static final Long PARTY_ID = 123456789L;
    private static final Integer REFERRED_YEAR = 2023;
    private static final String USERNAME = "Username";
    private static final LocalDateTime NOW = LocalDateTime.now();
    private static final Supplier<StatementException> STATEMENT_EXCEPTION_SUPPLIER = () -> new StatementException("Statement Exception Supplier") {
        @Override
        public StatementContext getStatementContext() {
            return super.getStatementContext();
        }
    };

    private final DossierNTT dossierNTT = DossierNTT.builder()
            .id(DOSSIER_ID)
            .module_id(MODULE_ID)
            .party_id(PARTY_ID)
            .process_id(PROCESS_ID)
            .referred_year(REFERRED_YEAR)
            .build();
    private final DossierDTO dossierDTO = DossierDTO.builder()
            .dossierId(DOSSIER_ID)
            .moduleId(MODULE_ID)
            .partyId(PARTY_ID)
            .processId(PROCESS_ID)
            .referredYear(REFERRED_YEAR)
            .build();

    @BeforeEach
    void init() {
        abstractHistoricizationFieldsCrudService = new TestImplAbstractHistoricizationFieldsCrudService<>(dao, mapper);
        abstractHistoricizationFieldsCrudServiceWithCustomKey = new TestImplAbstractHistoricizationFieldsCrudServiceWithCustomKey(daoWithCustomKey, mapper);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_StatementException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dao.nextSequenceVal())
                    .thenReturn(DOSSIER_ID);
            when(mapper.dtoToEntity(dossierDTO))
                    .thenReturn(dossierNTT);
            doThrow(STATEMENT_EXCEPTION_SUPPLIER.get()).when(dao)
                    .insert(dossierNTT, USERNAME, NOW);

            assertThrows(InsertExceptionRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.insert(dossierDTO, USERNAME, null, NOW);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_ObjectNotFoundException_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dao.nextSequenceVal())
                    .thenReturn(DOSSIER_ID);
            when(mapper.dtoToEntity(dossierDTO))
                    .thenReturn(dossierNTT);
            when(dao.findById(DOSSIER_ID))
                    .thenReturn(List.of());

            assertThrows(ObjectNotFoundRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.insert(dossierDTO, USERNAME, null, NOW);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_Exception_ko() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(dao.nextSequenceVal())
                    .thenReturn(DOSSIER_ID);
            when(mapper.dtoToEntity(dossierDTO))
                    .thenReturn(dossierNTT);
            doThrow(RuntimeException.class).when(dao)
                    .insert(dossierNTT);

            assertThrows(AgriDossiersRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.insert(dossierDTO, USERNAME, null, NOW);

                verify(dao).inTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().inTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_StatementException_ko() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            doThrow(STATEMENT_EXCEPTION_SUPPLIER.get()).when(dao)
                    .logicallyDeleteById(DOSSIER_ID, USERNAME, NOW);

            assertThrows(StatementExceptionRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.delete(DOSSIER_ID, USERNAME, null, NOW);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_ObjectNotFoundRuntimeException_ko() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            doThrow(ObjectNotFoundRuntimeException.class).when(dao)
                    .logicallyDeleteById(DOSSIER_ID, USERNAME, NOW);

            assertThrows(ObjectNotFoundRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.delete(DOSSIER_ID, USERNAME, null, NOW);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_Exception_ko() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            doThrow(RuntimeException.class).when(dao)
                    .logicallyDeleteById(DOSSIER_ID, USERNAME, NOW);

            assertThrows(AgriDossiersRuntimeException.class, () -> {
                abstractHistoricizationFieldsCrudService.delete(DOSSIER_ID, USERNAME, null, NOW);

                verify(dao).useTransaction(handleConsumerLambdaCaptor.capture());
                handleConsumerLambdaCaptor.getValue().useTransaction(dao);
            });
        } catch (Exception e) {
            fail(e);
        }
    }

    @Test
    void returnPagedResults_ok() {
        int totalCount = 2;
        int offset = 10;

        PagedResults<DossierNTT> dossierNTTPagedResults = new PagedResultsImpl<>(totalCount, offset, List.of(dossierNTT));

        when(mapper.entityToDto(dossierNTT))
                .thenReturn(dossierDTO);

        PagedResults<DossierDTO> result = abstractHistoricizationFieldsCrudService.returnPagedResults(dossierNTTPagedResults);

        assertEquals(List.of(dossierDTO), result.getRecords());
        assertEquals(dossierNTTPagedResults.getCount(), result.getTotalcount());
        assertEquals(offset, result.getOffset());
    }

    @Test
    void findOutDtoByCustom_ok() {
        try {
            when(daoWithCustomKey.findById(DOSSIER_ID))
                    .thenReturn(List.of(dossierNTT));
            when(mapper.entityToDto(dossierNTT))
                    .thenReturn(dossierDTO);

            DossierDTO result = abstractHistoricizationFieldsCrudServiceWithCustomKey.findOutDtoByCustom(DOSSIER_ID);

            assertEquals(dossierDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void insert_customKey_ok() {
        try {
            ArgumentCaptor<TransactionalCallback> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalCallback.class);

            when(daoWithCustomKey.nextSequenceVal())
                    .thenReturn(DOSSIER_ID);
            when(mapper.dtoToEntity(dossierDTO))
                    .thenReturn(dossierNTT);
            when(daoWithCustomKey.findById(DOSSIER_ID))
                    .thenReturn(List.of(dossierNTT));
            when(mapper.entityToDto(dossierNTT))
                    .thenReturn(dossierDTO);

            abstractHistoricizationFieldsCrudServiceWithCustomKey.insert(dossierDTO, USERNAME, DOSSIER_ID, NOW);

            verify(daoWithCustomKey).inTransaction(handleConsumerLambdaCaptor.capture());
            DossierDTO result = (DossierDTO) handleConsumerLambdaCaptor.getValue().inTransaction(daoWithCustomKey);

            assertEquals(dossierDTO, result);
        } catch (Exception e) {
            fail(e);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Test
    void delete_withoutPrimaryKey_ok() {
        try {
            ArgumentCaptor<TransactionalConsumer> handleConsumerLambdaCaptor = ArgumentCaptor.forClass(TransactionalConsumer.class);

            abstractHistoricizationFieldsCrudServiceWithCustomKey.delete(DOSSIER_ID, USERNAME, DOSSIER_ID, NOW);

            verify(daoWithCustomKey).useTransaction(handleConsumerLambdaCaptor.capture());
            handleConsumerLambdaCaptor.getValue().useTransaction(daoWithCustomKey);

            verify(daoWithCustomKey, times(1)).logicallyDeleteByCustomKey(DOSSIER_ID, USERNAME, NOW);
        } catch (Exception e) {
            fail(e);
        }
    }
}