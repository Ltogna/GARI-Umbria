package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.mockito.Mockito.when;

/**
 * The type Dossier profiles manager test.
 *
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class DossierProfilesManagerTest {

	private static final String TENANT = "tenant";

	private static final Long DOSSIER_ID = 1L;

	private static final String PROFILE_CODE = "profile_code";

	private static final String PROFILE_CODE_1 = "profile_code_1";

	private static final String PROFILE_CODE_2 = "profile_code_2";

	private final DossierProfileDTO dossierProfileDTOMock = DossierProfileDTO.builder()
			.dossierId(DOSSIER_ID)
			.profileCode(PROFILE_CODE)
			.build();

	@Mock
	private DossierProfilesCrudService dossierProfilesCrudService;

	@InjectMocks
	private DossierProfilesManager dossierProfilesManager;

	@BeforeEach
	void init() {
		dossierProfilesManager = new DossierProfilesManager(TENANT, DOSSIER_ID, dossierProfilesCrudService);
	}

	@Test
	void test_getProfiles() {
		when(dossierProfilesCrudService.find(TENANT, DOSSIER_ID)).thenReturn(List.of(dossierProfileDTOMock));

		List<String> result = dossierProfilesManager.getAllProfiles(TENANT, DOSSIER_ID);

		Assertions.assertEquals(dossierProfileDTOMock.getProfileCode(), result.get(0));
	}

	@Test
	void test_haveAllOf() {
		try {
			Assertions.assertFalse(dossierProfilesManager.haveAllOf(PROFILE_CODE_1, PROFILE_CODE_2));
		} catch (Exception e) {
			Assertions.fail();
		}
	}

	@Test
	void test_haveAnyOf() {
		try {
			dossierProfilesManager.haveAnyOf(PROFILE_CODE_1, PROFILE_CODE_2);
		} catch (Exception e) {
			Assertions.fail();
		}
	}

}
