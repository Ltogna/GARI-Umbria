package com.abacogroup.agri.dossiers.core.services.print;

import com.abacogroup.agri.dossiers.core.caller.CreatePrintJobCaller;
import com.abacogroup.agri.dossiers.core.caller.CreatePrintJobInput;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.CreatePrintJobOutDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.LastPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.dossiers.core.services.CheckPartyService;
import com.abacogroup.agri.dossiers.core.services.FileStoreService;
import com.abacogroup.agri.dossiers.core.services.ForceReadOnlyContextCheckerService;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import jakarta.ws.rs.core.SecurityContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;

import jakarta.ws.rs.core.Response;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PrintServiceTest {
	@Mock
	private DossiersCrudService dossiersCrudService;
	@Mock
	private CheckPartyService checkPartyService;
	@Mock
	private ModuleCrudService moduleCrudService;
	@Mock
	private DossiersWorkflowService dossiersWorkflowService;
	@Mock
	private ModulePrintConfigsCrudService modulePrintConfigsCrudServiceMock;
	@Mock
	private ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	@Mock
	private DossierGeneratedPrintCrudService dossierGeneratedPrintCrudServiceMock;
	@Mock
	private CreatePrintJobCaller createPrintJobCallerMock;
	@Mock
	private FileStoreService fileStoreServiceMock;
	@Mock
	private ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	@InjectMocks
	PrintService printService;

	private static final String PRINT_DESTINATION = "dossiers-prints-destination";
	private static final String TENANT = "ADMIN";
	private static final Long DOSSIER_ID = 46L;
	private static final Long PARTY_ID = 123L;
	private static final String FILE_ID = "123456";
	private static final String PRINT_BUCKET_NAME = "dossiers-prints-bucket";
	private static final String PRINT_ENGINE_URL = "http://print-engine:8080/print-engine";
	private static final String PRINT_CODE = "print code";
	private static final String DIFFERENT_PRINT_CODE = "different print code";
	private static final String PRINT_DESCRIPTION = "print description";
	private static final Long PRINT_CONFIG_ID = 27L;
	private static final String PROCESS_STATUS = "process status";
	private static final String USERNAME = "Username";
	private static final String AUTH_TOKEN = "Auth Token";
	private static final User USER = new User(USERNAME, AUTH_TOKEN, TENANT, USERNAME);
	private static final Long PKID = 1L;
	private static final LocalDateTime PRINT_DATE = LocalDateTime.of(2022, Month.JULY, 12, 14, 46, 49);
	private static final String UUID = "123456";
	private static final Long MODULE_ID = 10L;
	private static final String PROFILE_CODE = "Profile Code";
	private static final String PARAM_NAME = "Param Name";
	private static final String PARAM_VALUE = "Param Value";

	private final DossierGeneratedPrintDTO dossierGeneratedPrintDTO = DossierGeneratedPrintDTO.builder()
			.dossierId(DOSSIER_ID)
			.processStatus(PROCESS_STATUS)
			.username(USERNAME)
			.pkid(PKID)
			.printDate(PRINT_DATE)
			.fileId(FILE_ID)
			.build();
	private final CreatePrintJobOutDTO createPrintJobOutDTO = CreatePrintJobOutDTO.builder()
			.uuid(UUID)
			.build();
	private final ModulePrintConfigsDTO modulePrintConfigsDTO = ModulePrintConfigsDTO.builder()
			.moduleId(MODULE_ID)
			.printCode(PRINT_CODE)
			.id(PRINT_CONFIG_ID)
			.printDescription(PRINT_DESCRIPTION)
			.processStatus(PROCESS_STATUS)
			.build();
	private final ModulePrintConfigParamDTO modulePrintConfigParamDTO = ModulePrintConfigParamDTO.builder()
			.modulePrintConfigId(PRINT_CONFIG_ID)
			.parameterName(PARAM_NAME)
			.parameterValue(PARAM_VALUE)
			.build();

	@BeforeEach
	void init() {
		printService = new PrintService(dossiersCrudService, checkPartyService, moduleCrudService, dossiersWorkflowService, modulePrintConfigsCrudServiceMock,
				modulePrintConfigParamCrudService,
				dossierGeneratedPrintCrudServiceMock,
				createPrintJobCallerMock,
				fileStoreServiceMock,
				PRINT_BUCKET_NAME,
				PRINT_ENGINE_URL,
				forceReadOnlyContextCheckerService);
	}

	@Test
	void startPrintJob_ok() {
		CreatePrintJobInput input = CreatePrintJobInput.builder()
				.url(PRINT_ENGINE_URL)
				.bucketName(PRINT_BUCKET_NAME)
				.destination(PRINT_DESTINATION)
				.printCode(PRINT_CODE)
				.tenant(TENANT)
				.token("JWT " + AUTH_TOKEN)
				.locale(MDC.get(MDCPreFilter.LOCALE))
				.params(Map.of("dossierId", DOSSIER_ID,
						"partyId", PARTY_ID))
				.build();
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		when(createPrintJobCallerMock.makeCall(input))
				.thenReturn(createPrintJobOutDTO);
		when(dossierGeneratedPrintCrudServiceMock.insert(DossierGeneratedPrintDTO.builder()
				.dossierId(DOSSIER_ID)
				.printCode(PRINT_CODE)
				.printDate(any())
				.processStatus(PROCESS_STATUS)
				.printJobUuid(UUID)
				.username(USERNAME)
				.build()))
				.thenReturn(dossierGeneratedPrintDTO);

		DossierGeneratedPrintDTO result =
				printService.startPrintJob(TENANT, DOSSIER_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER);

		assertEquals(dossierGeneratedPrintDTO, result);
	}

	@Test
	void getPrintFromFileStore_ok() {
		Response expectedOutput = Response.ok().build();

		when(dossierGeneratedPrintCrudServiceMock.findPrintByDossierIdAndFileId(TENANT, DOSSIER_ID, FILE_ID))
				.thenReturn(Optional.of(dossierGeneratedPrintDTO));
		when(fileStoreServiceMock.getFileForDownload(eq(TENANT), eq(FILE_ID), eq(PRINT_BUCKET_NAME), eq(USER), any()))
				.thenReturn(expectedOutput);

		Response result = printService.getPrintFromFileStore(TENANT, DOSSIER_ID, FILE_ID, USER);

		assertEquals(expectedOutput, result);
	}

	@Test
	void getPrintFromFileStore_ko() {
		when(dossierGeneratedPrintCrudServiceMock.findPrintByDossierIdAndFileId(TENANT, DOSSIER_ID, FILE_ID))
				.thenReturn(Optional.empty());

		assertThrows(ObjectNotFoundRuntimeException.class, () ->
				printService.getPrintFromFileStore(TENANT, DOSSIER_ID, FILE_ID, USER));
	}

	@Test
	void startPrintJob_modulesPrint_noneMatch_ko() {
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(DIFFERENT_PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		assertThrows(RuntimeException.class, () ->
				printService.startPrintJob(TENANT, DOSSIER_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER));
	}

	@Test
	void startPrintJob_catchRuntimeException_ko() {
		CreatePrintJobInput input = CreatePrintJobInput.builder()
				.url(PRINT_ENGINE_URL)
				.bucketName(PRINT_BUCKET_NAME)
				.destination(PRINT_DESTINATION)
				.printCode(PRINT_CODE)
				.tenant(TENANT)
				.token(MDC.get(MDCPreFilter.USED_JWT))
				.locale(MDC.get(MDCPreFilter.LOCALE))
				.params(Map.of("businessId", "40952", //TODO remove mock
						"cropPlanId", "402",
						"pointInTime", "20221022"))
				.build();
		PrintDetailsOutDTO printDetailsOutDTO = PrintDetailsOutDTO.builder()
				.printCode(PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.lastPrint(LastPrintDTO.builder()
						.printDate(PRINT_DATE)
						.fileId(FILE_ID)
						.build())
				.build();

		List<PrintDetailsOutDTO> modulesPrint = List.of(printDetailsOutDTO);

		when(createPrintJobCallerMock.makeCall(input))
				.thenThrow(RuntimeException.class);

		assertThrows(RuntimeException.class, () ->
				printService.startPrintJob(TENANT, DOSSIER_ID, PARTY_ID, PROCESS_STATUS, modulesPrint, PRINT_CODE, USER));

	}

	@Test
	void getPrintsByModuleIdAndProcessStatus_ok() {
		SecurityContext sc = mock(SecurityContext.class);

		LastPrintDTO lastPrintDTO = LastPrintDTO.builder()
				.printDate(PRINT_DATE)
				.fileId(FILE_ID)
				.build();

		PrintDetailsOutDTO expectedOutput = PrintDetailsOutDTO.builder()
				.printCode(PRINT_CODE)
				.printConfigId(PRINT_CONFIG_ID)
				.printDescription(PRINT_DESCRIPTION)
				.params(Map.of(PARAM_NAME, PARAM_VALUE))
				.lastPrint(lastPrintDTO)
				.build();

		when(modulePrintConfigsCrudServiceMock.find(TENANT, MODULE_ID, PROCESS_STATUS, List.of(PROFILE_CODE)))
				.thenReturn(List.of(modulePrintConfigsDTO));
		when(modulePrintConfigParamCrudService.find(TENANT, PRINT_CONFIG_ID))
				.thenReturn(List.of(modulePrintConfigParamDTO));
		when(dossierGeneratedPrintCrudServiceMock.findLastGeneratedPrintByCode(TENANT, DOSSIER_ID, PRINT_CODE))
				.thenReturn(Optional.ofNullable(dossierGeneratedPrintDTO));

		List<PrintDetailsOutDTO> result = printService.getPrintsByModuleIdAndProcessStatus(TENANT, DOSSIER_ID, MODULE_ID,
				PROCESS_STATUS, List.of(PROFILE_CODE), sc);

		assertEquals(List.of(expectedOutput), result);
	}
}
