package com.abacogroup.agri.dossiers.utils;

import com.abacogroup.jdbi.orderby.OrderBy;
import com.abacogroup.jdbi.orderby.OrderByBuilder;
import com.abacogroup.jdbi.orderby.SortDirection;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SortUtilityTest {
    private static final String PARAM_ASC = "Param";
    private static final String PARAM_DESC = "Param,DESC";

    @Test
    void createOrderBy_asc_ok() {
        OrderBy expectedOutput = OrderByBuilder.field(PARAM_ASC).direction(SortDirection.ASC);

        OrderBy result = SortUtility.createOrderBy(List.of(PARAM_ASC));

        assertEquals(expectedOutput.toSqlFragment(), result.toSqlFragment());
    }

    @Test
    void createOrderBy_desc_ok() {
        OrderBy expectedOutput = OrderByBuilder.field(PARAM_ASC).direction(SortDirection.DESC);

        OrderBy result = SortUtility.createOrderBy(List.of(PARAM_DESC));

        assertEquals(expectedOutput.toSqlFragment(), result.toSqlFragment());
    }

    @Test
    void createOrderBy_nullParam_ok() {
        OrderBy expectedOutput = OrderByBuilder.from();

        OrderBy result = SortUtility.createOrderBy(null);

        assertEquals(expectedOutput.toSqlFragment(), result.toSqlFragment());
    }

    @Test
    void createOrderBy_emptyParams_ok() {
        OrderBy expectedOutput = OrderByBuilder.from();

        OrderBy result = SortUtility.createOrderBy(List.of());

        assertEquals(expectedOutput.toSqlFragment(), result.toSqlFragment());
    }
}