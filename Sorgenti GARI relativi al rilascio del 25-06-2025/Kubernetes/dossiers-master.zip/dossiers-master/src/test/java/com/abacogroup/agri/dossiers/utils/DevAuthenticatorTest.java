package com.abacogroup.agri.dossiers.utils;

import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.basic.BasicCredentials;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

/**
 * The type Dev authenticator test.
 * @author Carlo Sindico
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
class DevAuthenticatorTest {
    private DevAuthenticator devAuthenticator;
    private DevAuthenticator defaultDevAuthenticator;

    private static final String USERNAME = "username";
    private static final String TENANT = "tenant";

    @BeforeEach
    void init() {
        devAuthenticator = new DevAuthenticator(USERNAME, TENANT);
        defaultDevAuthenticator = new DevAuthenticator();
    }

    @Test
    void test_authenticate() {
        User expectedOutput = new User(USERNAME, TENANT, "", USERNAME);

        try {
            BasicCredentials basicCredentials = mock(BasicCredentials.class);
            Optional<User> result = devAuthenticator.authenticate(basicCredentials);

            assertEquals(Optional.of(expectedOutput), result);
        } catch (Exception e) {
            Assertions.fail();
        }
    }

    @Test
    void test_authenticate_default() {
        User expectedOutput = new User("ADMIN", "master", "", "ADMIN");

        try {
            BasicCredentials basicCredentials = mock(BasicCredentials.class);
            Optional<User> result = defaultDevAuthenticator.authenticate(basicCredentials);

            assertEquals(Optional.of(expectedOutput), result);
        } catch (Exception e) {
            Assertions.fail();
        }
    }

}
