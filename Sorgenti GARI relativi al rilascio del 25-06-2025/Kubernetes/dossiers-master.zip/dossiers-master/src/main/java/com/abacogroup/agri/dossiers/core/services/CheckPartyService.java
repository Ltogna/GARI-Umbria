package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.caller.CheckCanReadPartyCaller;
import com.abacogroup.agri.dossiers.core.caller.CheckCanReadPartyInput;
import com.abacogroup.agri.dossiers.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadConfig;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadDTO;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadKey;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;
import org.slf4j.MDC;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.abacogroup.applicationworkflowsdk.model.Constants.AUTHORIZATION_PREFIX;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckPartyService {

	private final CheckCanReadPartyCaller checkCanReadPartyCaller;
	private final DossierEnvCrudService dossierEnvCrudService;
	private final LoadingCache<CheckCanReadKey, CheckCanReadDTO> checkCache;

	private final CheckCanReadConfig checkCanReadConfig;
	private final CheckCanReadConfig checkCanReadAllPartiesConfig;

	public CheckPartyService(CheckCanReadPartyCaller checkCanReadPartyCaller,
			DossierEnvCrudService dossierEnvCrudService,
			CheckCanReadConfig checkCanReadConfig, CheckCanReadConfig checkCanReadAllPartiesConfig) {
		this.checkCanReadPartyCaller = checkCanReadPartyCaller;
		this.dossierEnvCrudService = dossierEnvCrudService;
		this.checkCanReadConfig = checkCanReadConfig;
		this.checkCanReadAllPartiesConfig = checkCanReadAllPartiesConfig;
		this.checkCache = Caffeine.newBuilder()
				.maximumSize(100L)
				.expireAfterAccess(10, TimeUnit.MINUTES)
				.build(key -> this.makeCall(key.getTenant(), key.getPartyId()));
	}

	private CheckCanReadDTO makeCall(String tenant, Long partyId) throws ObjectNotFoundException {
		DossierEnvDTO conf = DossierEnvDTO.builder()
				.value(this.checkCanReadConfig.getOverriddenUrl())
				.build();
		if (Boolean.FALSE.equals(this.checkCanReadConfig.getOverride())) {
			conf = dossierEnvCrudService.findEnvironmentByKey(DossierEnvKey.builder()
					.key_(this.checkCanReadConfig.getKey())
					.tenant_id(tenant)
					.fl_client(0)
					.build());
		}
		var input = CheckCanReadPartyInput.builder()
				.authToken(MDC.get(MDCPreFilter.USED_JWT))
				.partyId(partyId)
				.url(conf.getValue())
				.tenant(tenant)
				.build();
		return this.checkCanReadPartyCaller.makeCall(input);
	}

	public void checkCanReadParty(String tenant, Long partyId, User user) {
		if (Boolean.TRUE.equals(this.checkCanReadConfig.getActive())) {
			var result = this.checkCache.get(CheckCanReadKey.builder()
					.partyId(partyId)
					.tenant(tenant)
					.username(user.getName())
					.build());
			if (!Boolean.TRUE.equals(Optional.ofNullable(result).map(CheckCanReadDTO::getCanRead).orElse(false))) {
				throw new ActionNotAuthorizedRuntimeException("");
			}
		}
	}

	private CheckCanReadDTO verifyCanReadAllParties(String tenant, User user) throws ObjectNotFoundException {
		DossierEnvDTO conf = DossierEnvDTO.builder()
				.value(this.checkCanReadAllPartiesConfig.getOverriddenUrl())
				.build();
		if (Boolean.FALSE.equals(this.checkCanReadAllPartiesConfig.getOverride())) {
			conf = dossierEnvCrudService.findEnvironmentByKey(DossierEnvKey.builder()
					.key_(this.checkCanReadAllPartiesConfig.getKey())
					.tenant_id(tenant)
					.fl_client(0)
					.build());
		}
		var input = CheckCanReadPartyInput.builder()
				.authToken(AUTHORIZATION_PREFIX + user.getAuthToken())
				.url(conf.getValue())
				.partyId(-1L) //needed for Map.of
				.tenant(tenant)
				.build();
		return this.checkCanReadPartyCaller.makeCall(input);
	}

	public void canReadAllParties(String tenant, User user) throws ObjectNotFoundException {
		if (Boolean.TRUE.equals(this.checkCanReadAllPartiesConfig.getActive())) {
			var result = verifyCanReadAllParties(tenant, user);
			if (!Boolean.TRUE.equals(Optional.ofNullable(result).map(CheckCanReadDTO::getCanRead).orElse(false))) {
				throw new ActionNotAuthorizedRuntimeException("");
			}
		}
	}
}
