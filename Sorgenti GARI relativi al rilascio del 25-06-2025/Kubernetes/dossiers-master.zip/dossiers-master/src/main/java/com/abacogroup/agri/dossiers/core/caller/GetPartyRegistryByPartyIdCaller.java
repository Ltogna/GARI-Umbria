package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.agri.dossiers.core.model.dto.PartyRegistryDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Gennaro Tamburrelli
 */
public class GetPartyRegistryByPartyIdCaller extends AbacoDtoCaller<GetPartyRegistryByPartyIdInput, PartyRegistryDTO> {

	public GetPartyRegistryByPartyIdCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
