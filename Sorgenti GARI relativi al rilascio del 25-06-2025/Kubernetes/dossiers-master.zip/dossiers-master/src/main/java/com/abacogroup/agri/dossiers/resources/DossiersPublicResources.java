package com.abacogroup.agri.dossiers.resources;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.abacogroup.agri.dossiers.core.model.dto.publics.*;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import org.slf4j.MDC;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierDetailsPublicMapper;
import com.abacogroup.agri.dossiers.core.model.ProgressTypeEnum;
import com.abacogroup.agri.dossiers.core.model.WorkflowNodePublic;
import com.abacogroup.agri.dossiers.core.model.dto.CreateAnomalyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.services.DossiersService;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl.AnomalyHandlerImpl;
import com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl.DossierProfilesService;
import com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl.SetClosureDateServiceImpl;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusPayloadDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ReadOnlyDto;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@Timed
@Path("/{tenant}/public/v1/")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@PermitAll
@RolesAllowed("DOSSIERS|USER")
public class DossiersPublicResources {

	public static final String PROFILES_TAG = "Dossiers Profiles Public Resources";
	public static final String FORM_CONFIGS_TAG = "Form Configs Public Resources";
	public static final String COMPILE_STATUSES_TAG = "Compile Statuses Public Resources";
	public static final String ANOMALIES_TAG = "Anomalies Public Resources";
	public static final String WORKFLOWS_TAG = "Workflows Public Resources";
	public static final String DOSSIERS_TAG = "Dossiers Public Resources";
	public static final String MODULES_PRIVATE_RESOURCES = "Modules Private Resources";
	public static final String DOSSIERS_RESOURCES_SCOPE = "DOSSIERS_RESOURCES_SCOPE";

	private final DossiersService dossiersService;
	private final DossierProfilesService dossierProfilesService;
	private final FormConfigService formConfigService;
	private final AnomalyHandlerImpl anomalyHandler;
	private final SetClosureDateServiceImpl setClosureDateService;
	private final PrintService printService;

	public DossiersPublicResources(DossiersService dossiersService,
								   DossierProfilesService dossierProfilesService, FormConfigService formConfigService,
								   AnomalyHandlerImpl anomalyHandler,
								   SetClosureDateServiceImpl setClosureDateService,
			PrintService printService) {
		this.dossiersService = dossiersService;
		this.dossierProfilesService = dossierProfilesService;
		this.formConfigService = formConfigService;
		this.anomalyHandler = anomalyHandler;
		this.setClosureDateService = setClosureDateService;
		this.printService = printService;
	}

	@GET
	@Path("/dossiers/{dossier_id}/profiles")
	@Operation(description = "Returns the list of dossier's profiles, given the dossier's id", tags = { PROFILES_TAG })
	@ApiResponse(description = "The list of dossier's profiles")
	public InfiniteListResults<ApplicationProfilePublicDTO> getDossierProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		return dossiersService.getDossierProfiles(tenant, dossierId, nextKey, user);
	}

	@PUT
	@Path("/dossiers/{dossier_id}/profiles")
	@Operation(description = "Bulk updates the list of dossier's profiles, given the dossier's id", tags = { PROFILES_TAG })
	@ApiResponse(description = "The list of dossier's profiles")
	@ApiResponse(responseCode = "400", description = "At least one of the profile code list is not valid - ErrCode: PROFILE_CODE_NOT_EXISTS")
	public Response purDossierProfiles(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			List<String> profileCodeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		dossierProfilesService.putDossierProfiles(tenant, dossierId, profileCodeList, user);
		return Response.ok().build();
	}

	@DELETE
	@Path("/dossiers/{dossier_id}/profiles/{profileCode}")
	@Operation(description = "Delete the profile code, given the dossier's id", tags = { PROFILES_TAG })
	public Response deleteProfileByDossierId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The profile code") @PathParam("profileCode") String profileCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		dossierProfilesService.deleteApplicationProfile(tenant, dossierId, profileCode, user);
		return Response.ok().build();
	}

	@GET
	@Path("/dossiers/{dossier_id}/module/profiles")
	@Operation(description = "Returns the list of dossier's module profiles, given the dossier's id", tags = { PROFILES_TAG })
	@ApiResponse(description = "The list of module's profiles")
	public List<ModuleProfileDTO> getModuleProfilesByDossierId(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		var dossier = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);
		return dossierProfilesService.getModuleProfileByModuleId(tenant, dossier.getModuleId());
	}

	@GET
	@Path("/dossiers/{dossier_id}/form-configs/{config_id}/read-only")
	@Operation(description = "Returns the readonly status of form config, given the dossier id and the form config id", tags = {
			FORM_CONFIGS_TAG })
	@ApiResponse(description = "The readonly status. Returns true if form is in read only or dossier is closed")
	public ReadOnlyDto getFormConfigReadOnly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The form code") @PathParam("config_id") Long configId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		return dossiersService.findReadOnly(tenant, dossierId, configId, user, sc);
	}

	@GET
	@Path("/dossiers/{dossier_id}/form-configs")
	@Operation(description = "Returns the the form configs", tags = {
			FORM_CONFIGS_TAG })
	@ApiResponse(description = "The form config list")
	public List<FormWithGroupHierarchyPublicDTO> getFormConfigList(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		return formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						res.getProcessStatus(),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc,
						MDC.get(MDCPreFilter.LOCALE));
	}

	@GET
	@Path("/dossiers/{dossier_id}/compile-statuses")
	@Operation(description = "Returns the list of dossier compile statuses, given the dossier's id", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of dossier's compile statuses")
	public InfiniteListResults<ApplicationCompileStatusDTO> getDossierCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		return dossiersService.findCompileStatus(tenant, dossierId, nextKey);
	}

	@PUT
	@Path("/dossiers/{dossier_id}/compile-statuses/{compileStatusIdentifier}")
	@Operation(description = "Updates the dossier compile status, given the dossier's id and compile status id. If compileStatusIdentifier does not exist, "
			+
			"it will be created", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of dossier's compile statuses")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: COMPILE_STATUS_NOT_FOUND_ERROR")
	public ApplicationCompileStatusDTO updateDossierCompileStatusById(@PathParam("tenant") String tenant,
																	  @PathParam("dossier_id") Long dossierId,
																	  @PathParam("compileStatusIdentifier") String compileStatusIdentifier,
																	  @RequestBody ApplicationCompileStatusPayloadDTO dosCompileStatusDTO,
																	  @Parameter(hidden = true) @Auth User user) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		return dossiersService.updateCompileStatus(tenant, dossierId, compileStatusIdentifier, dosCompileStatusDTO, user.getName());
	}

	@DELETE
	@Path("/dossiers/{dossier_id}/compile-statuses/{compileStatusIdentifier}")
	@Operation(description = "Updates the dossier compile status, given the dossier's id and compile status id. If compileStatusIdentifier does not exist, "
			+
			"it will be created", tags = { COMPILE_STATUSES_TAG })
	@ApiResponse(description = "The list of dossier's compile statuses")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: COMPILE_STATUS_NOT_FOUND_ERROR")
	public Response deleteDossierCompileStatusById(@PathParam("tenant") String tenant,
												   @PathParam("dossier_id") Long dossierId,
												   @PathParam("compileStatusIdentifier") String compileStatusIdentifier,
												   @Parameter(hidden = true) @Auth User user) throws ObjectNotFoundException {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		dossiersService.deleteCompileStatus(tenant, dossierId, compileStatusIdentifier, user.getName());
		return Response.ok().build();
	}

	@PATCH
	@Path("/dossiers/{dossier_id}/progress/transitions/{transition_id}")
	@Operation(description = "Updates the process status of the dossier", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Dossier - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response progressDossier(ProgressDossierDTO payload,
									@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
									@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
									@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
									@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
									@Parameter(hidden = true) @Auth User user,
									@Context SecurityContext sc) throws Exception {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		dossiersService.progress(tenant, dossierId, transitionId, user, Optional.ofNullable(scope).orElse(DOSSIERS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@PATCH
	@Path("/dossiers/{dossier_id}/progress/tags/{tag_name}")
	@Operation(description = "Updates the process status of the dossier", tags = { WORKFLOWS_TAG })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Dossier - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response progressDossier(ProgressDossierDTO payload,
									@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
									@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
									@Parameter(description = "Tag name") @PathParam("tag_name") String tagName,
									@Parameter(description = "The wanted scope") @QueryParam("scope") String scope,
									@Parameter(hidden = true) @Auth User user,
									@Context SecurityContext sc) throws ObjectNotFoundException {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		dossiersService.progress(tenant, dossierId, tagName, user, Optional.ofNullable(scope).orElse(DOSSIERS_RESOURCES_SCOPE), payload,
				ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@GET
	@Path("/dossiers/{dossier_id}/anomalies")
	@Operation(description = "Returns the list of dossier's anomalies", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The list of dossier's compile statuses")
	public List<AnomalyDTO> getDossierCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		return anomalyHandler.getAnomaliesForApp(tenant, dossierId);
	}

	@POST
	@Path("/dossiers/{dossier_id}/anomalies")
	@Operation(description = "Create an anomaly", tags = { ANOMALIES_TAG })
	@ApiResponse(responseCode = "204", description = "Anomaly was created")
	public Response createAnomaly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@RequestBody CreateAnomalyDTO payload,
			@Parameter(hidden = true) @Auth User user) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		anomalyHandler.insertAnomaly(tenant, dossierId, payload.getCode(), user.getName());
		return Response.noContent().build();
	}

	@DELETE
	@Path("/dossiers/{dossier_id}/anomalies/{anomaly_code}")
	@Operation(description = "Create an anomaly", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The anomaly was deleted")
	public Response createAnomaly(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The anomaly code") @PathParam("anomaly_code") String anomalyCode,
			@Parameter(hidden = true) @Auth User user) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		anomalyHandler.deleteAnomaly(tenant, dossierId, anomalyCode, user.getName());
		return Response.noContent().build();
	}

	@GET
	@Path("/dossiers/{dossier_id}/details")
	@Operation(description = "Returns the detail of the dossier", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The detail of the dossier")
	@ApiResponse(responseCode = "404", description = "No dossier found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public ApplicationDetailsPublicDTO getDossierDetail(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
														@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
														@Parameter(hidden = true) @Auth User user,
														@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);
		return DossierDetailsPublicMapper.INSTANCE.entityToDto(res);
	}

	@POST
	@Path("/dossiers/{dossier_id}/closure-date")
	@Operation(description = "Set the closure date, if is the first the first time", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The detail of the dossier")
	@ApiResponse(responseCode = "404", description = "No dossier found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public Response setClosureDate(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanReadByDosId(tenant, dossierId, user);
		setClosureDateService.conditionallySetClosureDate(tenant, dossierId, user.getName());
		return Response.ok().build();
	}

	@GET
	@Path("/dossiers/parties/{partyId}/years/{year}/modules/{moduleCode}")
	@Operation(description = "Returns the list of dossiers, given the party id and the year", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for party or year - ErrCode: NO_DOSSIERS_FOUND_BY_PARTY_AND_YEAR")
	public List<DosByPartyAndYearDTO> getDossierByPartyAndYear(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "The specific year") @PathParam("year") Integer year,
			@PathParam("moduleCode") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		dossiersService.checkCanRead(tenant, partyId, user);
		return dossiersService.getDossiersByPartyYearAndModuleCode(tenant, partyId, year, moduleCode, user);
	}

	@GET
	@Path("/dossiers/parties/{partyId}")
	@Operation(description = "Returns the list of dossiers, given the party id, the optional flag 'closed' and the optional type list", tags = { DOSSIERS_TAG })
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for party - ErrCode: NO_DOSSIERS_FOUND_BY_PARTY")
	public InfiniteListResults<DossierByPartyDTO> getDossiersByParty(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "Filter by closed status", in = ParameterIn.QUERY) @QueryParam("includeClosed") Boolean includeClosed,
			@Parameter(description = "Filter by type list", in = ParameterIn.QUERY) @QueryParam("typeList") List<String> typeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersByParty(tenant, partyId, (includeClosed != null && includeClosed) ? 1 : 0, typeList, nextKey, user, sc);
	}

	@GET
	@Path("/sectors/{sector_code}/modules")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No sectors found for this sector code - ErrCode: OBJECT_NOT_FOUND_ERROR")
	public List<ModuleWithDetailDTO> getModulesByPointInTime(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The sector code to be used in search") @PathParam("sector_code") String sectorCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getModulesBySectorCode(tenant, sectorCode, sc);
	}

	@GET
	@Path("/sectors")
	@Operation(description = "Returns the list of sectors, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of sectors")
	@ApiResponse(responseCode = "404", description = "No profiles with sector and module code, at date - " +
			"ErrCode: NO_PROFILES_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE")
	public InfiniteListResults<SectorPublicDTO> getSectorsByTenant(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getSectorsByTenant(tenant, nextKey);
	}

	@GET
	@Path("/modules/{module_code}/statuses")
	@Operation(description = "Returns the list of module's statuses")
	@ApiResponse(description = "The list of module's statuses")
	@ApiResponse(responseCode = "404", description = "No Module was found")
	public List<WorkflowNodePublic> getModuleStatuses(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "The next key") @QueryParam("next_key") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getStatusNodes(tenant, moduleCode);
	}

	@GET
	@Path("/dossiers/modules/{module_code}")
	@Operation(description = "Returns the list of dossiers, given the module code", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for module code - ErrCode: NO_DOSSIERS_FOUND_BY_MODULE_CODE")
	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "The optional party code") @QueryParam("party_code") String partyCode,
			@Parameter(description = "The optional year") @QueryParam("year") Integer year,
			@Parameter(description = "The optional process status") @QueryParam("process_status") String processStatus,
			@Parameter(description = "The optional dossier ids") @QueryParam("dossier_id") List<Long> dossierIdList,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersByModuleCode(tenant, moduleCode, partyCode, year, processStatus, dossierIdList, nextKey, user);
	}

	@GET
	@Path("/dossiers/partyCode/{partyCode}")
	@Operation(description = "Returns the list of dossiers, given the code", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for code - ErrCode: NO_DOSSIERS_FOUND_BY_CODE")
	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party code") @PathParam("partyCode") String partyCode,
			@Parameter(description = "The optional module code") @QueryParam("module_code") String moduleCode,
			@Parameter(description = "The optional year") @QueryParam("year") Integer year,
			@Parameter(description = "The optional process status") @QueryParam("process_status") String processStatus,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersByPartyCode(tenant, partyCode, moduleCode, year, processStatus, nextKey, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}")
	@Operation(description = "Returns the detail of the dossier", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The detail of the dossier")
	@ApiResponse(responseCode = "404", description = "No dossier found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public DossierWithDetailsDTO getDetailedDossier(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
													@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
													@Parameter(hidden = true) @Auth User user,
													@Context SecurityContext sc) {
		return dossiersService.getDetailedDossierById(tenant, dossierId, user, sc);
	}

	@GET
	@Path("/modules/{module_code}")
	@Operation(description = "Returns the configurations related to the module code", tags = {DOSSIERS_TAG})
	@ApiResponse(description = "The module configurations")
	@ApiResponse(responseCode = "404", description = "Module not found by code - ErrCode: OBJECT_NOT_FOUND_ERROR")
	public ModuleWithParamsPublicDTO getDossiersByModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific module code") @PathParam("module_code") String moduleCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getModuleFormConfigsByModuleCode(tenant, moduleCode);
	}

	@GET
	@Path("/dossiers/{dossier_id}/history")
	@Operation(description = "Returns the dossier's history, given the dossier id", tags = { DOSSIERS_TAG })
	@ApiResponse(description = "The dossier's history")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<DetailedTransitionLog> getHistoryByDossierCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossierHistoryByDossierId(tenant, dossierId, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}/print-history")
	@Operation(description = "Returns the dossier's prints, given the dossier id", tags = { DOSSIERS_TAG })
	@ApiResponse(description = "The dossier's generated prints")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<DossierGeneratedPrintDTO> getPrintsByDossierCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossierPrintsByDossierId(tenant, dossierId, user);
	}

	@POST
	@Path("/dossiers/{dossier_id}/prints/{print_code}")
	@Operation(description = "Start the creation print job", tags = { DOSSIERS_TAG })
	@ApiResponse(description = "The dossier's generated prints")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public DossierGeneratedPrintDTO createPrintJob(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The print code to print") @PathParam("print_code") String printCode,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = dossiersService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						dossierId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return printService
				.startPrintJob(tenant, dossierId, res.getPartyId(), res.getProcessStatus(), modulesPrint, printCode, user);
	}
}
