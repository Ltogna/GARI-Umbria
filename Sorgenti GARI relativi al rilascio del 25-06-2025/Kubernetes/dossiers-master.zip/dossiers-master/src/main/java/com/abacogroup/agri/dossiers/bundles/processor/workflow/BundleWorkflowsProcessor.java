package com.abacogroup.agri.dossiers.bundles.processor.workflow;

import com.abacogroup.agri.dossiers.bundles.processor.AbstractBundleDossiersProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.io.File;
import java.nio.file.Path;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class BundleWorkflowsProcessor extends AbstractBundleDossiersProcessor<File> {

	protected final WorkflowsBundleWorker workflowsBundleWorker;

	public BundleWorkflowsProcessor(WorkflowsBundleWorker workflowsBundleWorker, Jdbi jdbi) {
		super(null, jdbi);
		this.workflowsBundleWorker = workflowsBundleWorker;
	}

	@Override
	public String getDomainName() {
		return "workflows";
	}

	@Override
	public TypeReference<File> getTypeReference() {
		return null;
	}

	@Override
	public void processFile(String tenantId, File file) {
		log.info("BundleWorkflowsProcessor: proccessing file with tenant {}", tenantId);
		if (file.getAbsolutePath().endsWith(".delete.jar") || file.getAbsolutePath().endsWith(".delete.zip")) {
			delete(tenantId, file);
		} else {
			doInsertOrUpdate(tenantId, file);
		}
		log.info("BundleWorkflowsProcessor: proccessing file with tenant {} END", tenantId);
	}

	@Override
	public void onMessageInTransaction(ConfigDataMessage message) {
		log.info("BundleWorkflowsProcessor: reveiced message with tenant {}", message.getTenantId());
		message.getConfigFiles().stream()
				.map(Path::toFile)
				.filter(file -> file.getAbsolutePath().endsWith(".jar") || file.getAbsolutePath().endsWith(".zip"))
				.forEach(file -> processFile(message.getTenantId(), file));
	}

	@Override
	protected void delete(String tenantId, File message) {
		// TODO implement this
	}

	@Override
	protected void doInsertOrUpdate(String tenantId, File workFlowFile) {
		workflowsBundleWorker.insertBundleWorkflow(tenantId, workFlowFile);
	}

}
