package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.ModuleFormConfigsDTO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleFormConfigsMapper extends EntityMapper<ModuleFormConfigsDTO, ModuleFormConfigsNTT> {

	ModuleFormConfigsMapper INSTANCE = Mappers.getMapper(ModuleFormConfigsMapper.class);

	@InheritInverseConfiguration()
	ModuleFormConfigsDTO entityToDto(ModuleFormConfigsNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "formId", target = "form_id")
	@Mapping(source = "formGroupId", target = "form_group_id")
	@Mapping(source = "sortOrder", target = "sort_order")
	@Mapping(source = "flReadOnly", target = "fl_readonly")
	@Mapping(source = "compileStatusIdentifier", target = "compile_status_identifier")
	@Mapping(source = "contextFunction", target = "context_function")
	@Mapping(source = "forceReadOnlyContextFunction", target = "force_read_only_context_function")
	ModuleFormConfigsNTT dtoToEntity(ModuleFormConfigsDTO dto);

}
