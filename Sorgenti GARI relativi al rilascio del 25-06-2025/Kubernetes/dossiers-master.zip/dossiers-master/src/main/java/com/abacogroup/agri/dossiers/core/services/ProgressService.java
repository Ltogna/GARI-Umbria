package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.model.*;
import com.abacogroup.agri.dossiers.core.model.dto.publics.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.UpdateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.sdk.beans.WorkflowMessage;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.Transition;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.MDC;

import java.util.*;

import static java.util.stream.Collectors.groupingBy;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ProgressService {

	private final Jdbi jdbi;
	private final DossiersWorkflowService dossiersWorkflowService;
	private final DossiersCrudService dossiersCrudService;
	private final DossierDetailsCrudService dossierDetailsCrudService;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	private final UpdateProcessQueue updateProcessQueue;

	public ProgressService(Jdbi jdbi,
                           DossiersWorkflowService dossiersWorkflowService,
                           DossiersCrudService dossiersCrudService,
                           DossierDetailsCrudService dossierDetailsCrudService, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService,
                           UpdateProcessQueue updateProcessQueue) {
		this.jdbi = jdbi;
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.dossiersCrudService = dossiersCrudService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
		this.updateProcessQueue = updateProcessQueue;
	}

	public void progress(String tenant, Long dossierId, String tagName, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType) {
		this.progress(tenant, dossierId, tagName, user, scope, progressDossierDTO, progressType, null);

	}

	public void progress(String tenant, Long dossierId, String tagName, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType, ProcessData fatherProcessData) {
		DossierDTO dossier = getDossier(tenant, dossierId);
		Optional<Integer> optTransitionId = dossiersWorkflowService.getUserAvailableTransitions(dossier.getProcessId(), user, scope)
				.stream()
				.filter(x -> x.getTags().contains(tagName))
				.findFirst()
				.map(Transition::getId);
		optTransitionId.ifPresentOrElse(transitionId -> {
					try {
						progress(tenant, dossierId, transitionId, user, scope, progressDossierDTO, progressType, fatherProcessData);
					} catch (Exception e) {
						throw new RuntimeException(e.getMessage(), e);
					}
				},
				() -> {
					throw new NoTransitionFoundRuntimeException();
				});
	}

	private DossierDTO getDossier(String tenant, Long dossierId) {
		DossierDTO dossier;
		try {
			dossier = dossiersCrudService.findById(tenant, dossierId);
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("dossier not found");
		}
		return dossier;
	}

	public void progress(String tenant, Long dossierId, Integer transitionId, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType) throws Exception {
		progress(tenant, dossierId, transitionId, user, scope, progressDossierDTO, progressType, null);
	}

	public void progress(String tenant, Long dossierId, Integer transitionId, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType, ProcessData fatherProcessData) throws Exception {
		jdbi.useTransaction(handle -> {
			try {
				// get dossier
				var dossier = dossiersCrudService.findById(tenant, dossierId);
				var dossierDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);

				forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, dossier.getModuleId());
				// get transition
				Transition wantendTransition = findTransitionByProcessIdAndTransitionId(tenant, user, dossier.getProcessId(), scope, transitionId);
				// update dossier detail
				dossierDetailsCrudService.updateProcessStatusAndFlTransition(tenant, dossierId, dossierDetails.getProcessStatus(), user.getName(),
						ProcessTransitionEnum.IN_TRANSITION);
				QueueWorkflowParams queueWorkflowParams = QueueWorkflowParams.builder()
						.processId(dossier.getProcessId())
						.dossierId(dossierId)
						.tenant(tenant)
						.transitionId(wantendTransition.getId())
						.username(user.getName())
						.locale(Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it"))
						.scope(scope)
						.notes(progressDossierDTO.getNotes())
						.build();
				switch (progressType) {
				case ASYNC:
					// execute progress process asynchronously
					updateProcessQueue.add(queueWorkflowParams, System.currentTimeMillis());
					break;
				case SYNC:
					// execute progress process synchronously
					updateProcessQueue.executeTransition(queueWorkflowParams, fatherProcessData);
					break;
				default:
					throw new RuntimeException("sync type not valid");
				}

			} catch (ObjectNotFoundException e) {
				throw new DossierNotFoundRuntimeException(e.getMessage());
			}
		});
	}

	private Transition findTransitionByProcessIdAndTransitionId(String tenant, User user, Long processId, String scope, Integer transitionId) {
		log.info("Searching transition by processId: {}", processId);
		return dossiersWorkflowService.getUserAvailableTransitions(processId, user, scope)
				.stream()
				.filter(t -> t.getId().equals(transitionId))
				.findFirst()
				.orElseThrow(NoTransitionFoundRuntimeException::new);
	}

	public boolean lastTransitionHasError(String tenant, Long dossierId, User user) {
		var app = getDossier(tenant, dossierId);
		return dossiersWorkflowService.getProcessTransitionHistory(tenant, app.getProcessId(), user)
				.stream()
				.max(Comparator.comparing(DetailedTransitionLog::getEndDate))
				.map(x -> x.getMessages().stream().anyMatch(y -> y.getType().equals(WorkflowMessage.Type.ERROR)))
				.orElse(false);
	}
}
