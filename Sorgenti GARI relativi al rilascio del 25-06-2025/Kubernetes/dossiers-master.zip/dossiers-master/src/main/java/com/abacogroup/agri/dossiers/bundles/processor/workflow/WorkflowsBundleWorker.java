package com.abacogroup.agri.dossiers.bundles.processor.workflow;

import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import lombok.extern.slf4j.Slf4j;

import java.io.File;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class WorkflowsBundleWorker {

	private final DossiersWorkflowService dossiersWorkflowService;

	public WorkflowsBundleWorker(DossiersWorkflowService dossiersWorkflowService) {
		this.dossiersWorkflowService = dossiersWorkflowService;
	}

	public DossiersWorkflowService exposeDossierWorkflowService() {
		return this.dossiersWorkflowService;
	}

	public void insertBundleWorkflow(String tenantId, File workFlowFile) {
		log.info("WorkflowsBundleWorker: processing file with tenant {}", tenantId);
		dossiersWorkflowService.addOrUpdateWorkflowFromFile(tenantId, workFlowFile);
		log.info("WorkflowsBundleWorker: processing file with tenant {} END", tenantId);
	}
}
