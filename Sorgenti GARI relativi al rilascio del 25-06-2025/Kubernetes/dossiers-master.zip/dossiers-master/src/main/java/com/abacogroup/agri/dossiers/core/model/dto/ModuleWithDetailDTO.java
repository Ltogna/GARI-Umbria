package com.abacogroup.agri.dossiers.core.model.dto;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleWithDetailDTO extends ModuleDTO {
	private Integer annuality;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
	private AbsoluteDate dtValidityStart;
	private AbsoluteDate dtValidityEnd;
	private String sectorCode;
	private String sectorDescription;
	private String moduleDescription;
}
