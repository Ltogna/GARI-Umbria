package com.abacogroup.agri.dossiers.core.services.workflow;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.abacogroup.workflow.server.model.*;
import org.slf4j.MDC;

import com.abacogroup.agri.dossiers.core.exceptions.CreateOrUpdateWorkflowRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ProgressWorkflowRuntimeException;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.abacogroup.workflow.server.services.exceptions.ProcessNotFoundException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowGenericException;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;

import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossiersWorkflowService {

	private final WorkflowService workflowService;
	private final ProcessService processService;
	private final AuthContextFactory authContextFactory;
	private final FileFactory fileFactory;
	private final DossierProfilesCrudService dossierProfilesCrudService;

	public DossiersWorkflowService(WorkflowService workflowService, ProcessService processService, AuthContextFactory authContextFactory,
								   FileFactory fileFactory, DossierProfilesCrudService dossierProfilesCrudService) {
		this.workflowService = workflowService;
		this.processService = processService;
		this.authContextFactory = authContextFactory;
		this.fileFactory = fileFactory;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
	}

	public void addOrUpdateWorkflowFromInputStream(String tenant, InputStream inputStream) {
		try (inputStream) {
			File tempFile = this.fileFactory.createFile(inputStream);
			this.addOrUpdateWorkflowFromFile(tenant, tempFile);
		} catch (IOException e) {
			throw new CreateOrUpdateWorkflowRuntimeException(e.getMessage());
		}
	}

	public void addOrUpdateWorkflowFromFile(String tenant, File file) {
		try {
			workflowService.addOrUpdateWorkflow(tenant, file);
		} catch (IOException e) {
			throw new CreateOrUpdateWorkflowRuntimeException(e.getMessage());
		}
	}

	public ProcessTransitionResult createProcess(String tenant, Long dossierId, String username, String workflowCode, String locale,
			Map<String, Object> globalVars) {
		try {
			return this.processService.createProcess(CreateProcessParams.builder()
					.tenantId(tenant)
					.workflowCode(workflowCode)
					.authContext(this.authContextFactory.createAuthContext(tenant, username, locale))
					.globalVars(globalVars)
					.returnGlobalVars(true)
					.profilesManager(new DossierProfilesManager(tenant, dossierId, dossierProfilesCrudService))
					.build());
		} catch (IOException | AuthenticationException e) {
			throw new ProgressWorkflowRuntimeException(e.getMessage());
		}
	}

	public List<Transition> getUserAvailableTransitions(Long processId, User user, String scope) {
		try {
			return processService
					.getUserAvailableTransitions(processId,
							this.authContextFactory.createAuthContext(user, Optional.ofNullable(MDC.get(MDCPreFilter.LOCALE)).orElse("it")),
							scope);
		} catch (IOException | AuthenticationException e) {
			throw new ProgressWorkflowRuntimeException(e.getMessage());
		} catch (WorkflowNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	public ProcessTransitionResult executeProcessTransition(String tenant, Long dossierId, Long processId, Integer transitionId, String username,
			String locale, String scope, String notes) {
		try {
			log.info("Invoking executeProcessTransition with params processId: {} transitionId: {} scope: {}", processId, transitionId, scope);
			return processService.executeProcessTransition(ExecuteTransitionParams.builder()
					.processId(processId)
					.authContext(this.authContextFactory.createAuthContext(tenant, username, locale))
					.notes(notes)
					.transitionId(transitionId)
					.scope(scope)
					.profilesManager(new DossierProfilesManager(tenant, dossierId, dossierProfilesCrudService))
					.build());
		} catch (Exception e) {
			throw new ProgressWorkflowRuntimeException(e.getMessage());
		}
	}

	public ProcessTransitionResult executeProcessTransitionWithFatherProcessData(String tenant, Long dossierId, Long processId, Integer transitionId,
			String username,
			String locale, String scope, String notes, ProcessData fatherProcessData) {
		try {
			log.info("Invoking executeProcessTransition with params processId: {} transitionId: {} scope: {}", processId, transitionId, scope);
			return processService.executeProcessTransition(ExecuteTransitionParams.builder()
							.processId(processId)
							.authContext(this.authContextFactory.createAuthContext(tenant, username, locale))
							.notes(notes)
							.transitionId(transitionId)
							.scope(scope)
							.profilesManager(new DossierProfilesManager(tenant, dossierId, dossierProfilesCrudService))
							.build(),
					fatherProcessData);
		} catch (Exception e) {
			throw new ProgressWorkflowRuntimeException(e.getMessage());
		}
	}

	public List<DetailedTransitionLog> getProcessTransitionHistory(String tenant, Long processId, User user) {
		try {
			log.info("Invoking getProcessTransitionHistory with params processId: {}", processId);
			return processService
					.getTransitionsHistory(processId,
							this.authContextFactory.createAuthContext(user, MDC.get(MDCPreFilter.LOCALE)),
							true);
		} catch (WorkflowNotFoundException | AuthenticationException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	public void getWorkflowFilesByTenantAndInsertThem(String tenantToCopy, String destTenant) {
		workflowService.getWorkflowCodes(tenantToCopy)
				.stream()
				.forEachOrdered(wfCode -> {
					try {
						ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
						workflowService.getWorkflowPackage(tenantToCopy, wfCode, outputStream);
						this.addOrUpdateWorkflowFromInputStream(destTenant, new ByteArrayInputStream(outputStream.toByteArray()));
					} catch (IOException e) {
						throw new WorkflowGenericException(e);
					}
				});
	}

	public ProcessState getProcessStatusDetail(String tenant, Long processId, User user) throws AuthenticationException {
		return processService.getProcessState(processId, this.authContextFactory.createAuthContext(user, MDC.get(MDCPreFilter.LOCALE)));
	}

	public String getProcessStatusDescription(String tenant, Long processId, User user) {
		try {
			return this.getProcessStatusDetail(tenant, processId, user).getCurrentNodeDescription();
		} catch (ProcessNotFoundException | WorkflowNotFoundException | AuthenticationException e) {
			return null;
		}
	}

	public WorkflowNode getWorkflowNode(String tenantId, String workflowCode, String nodeName) {
		return workflowService.getWorkflowNode(tenantId, workflowCode, nodeName, MDC.get(MDCPreFilter.LOCALE));
	}

	public List<WorkflowNode> getWorkflowNodesByType(String tenantId, String workflowCode, NodeType nodeType) {
		return workflowService.getWorkflowNodesByType(tenantId, workflowCode, nodeType, MDC.get(MDCPreFilter.LOCALE));
	}

	public Map<String, Object> getNodeMetadata(String tenantId, String workflowCode, String nodeName) {
		return this.getWorkflowNode(tenantId, workflowCode, nodeName).getMetadata();
	}

}
