package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierDetailsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DossierDetailsMapper extends EntityMapper<DossierDetailsDTO, DossierDetailsNTT> {

	DossierDetailsMapper INSTANCE = Mappers.getMapper(DossierDetailsMapper.class);

	@InheritInverseConfiguration()
	DossierDetailsDTO entityToDto(DossierDetailsNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "dossierCode", target = "dossier_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "amendedById", target = "amended_by_id")
	@Mapping(source = "amendOfId", target = "amend_of_id")
	@Mapping(source = "dtPresentation", target = "dt_presentation")
	@Mapping(source = "dtClosed", target = "dt_closed")
	@Mapping(source = "flInTransition", target = "fl_in_transition")
	DossierDetailsNTT dtoToEntity(DossierDetailsDTO dto);

}
