package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 * @author Mauro Pozzana
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigsDTO {
	private Long id;
	private Long moduleId;
	private String processStatus;
	private Long formId;
	private Long formGroupId;
	private Integer sortOrder;
	private Integer flReadOnly;
	private String compileStatusIdentifier;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
}
