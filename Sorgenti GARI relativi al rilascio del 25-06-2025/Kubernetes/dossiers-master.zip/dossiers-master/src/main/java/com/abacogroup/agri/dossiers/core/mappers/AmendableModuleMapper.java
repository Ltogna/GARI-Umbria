package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.db.ntt.AmendableModuleNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface AmendableModuleMapper extends EntityMapper<AmendableModuleDTO, AmendableModuleNTT> {

	AmendableModuleMapper INSTANCE = Mappers.getMapper(AmendableModuleMapper.class);

	@InheritInverseConfiguration()
	AmendableModuleDTO entityToDto(AmendableModuleNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "amendableModuleId", target = "amendable_module_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
    AmendableModuleNTT dtoToEntity(AmendableModuleDTO dto);

}
