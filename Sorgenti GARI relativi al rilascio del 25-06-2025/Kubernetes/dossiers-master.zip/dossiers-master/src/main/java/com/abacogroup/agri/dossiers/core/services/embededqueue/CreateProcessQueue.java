package com.abacogroup.agri.dossiers.core.services.embededqueue;

import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.RESCHEDULE;

/**
 * @author Gennaro Tamburrelli
 */
public class CreateProcessQueue extends WorkQueue<ApplicationsWorkflowParams> {

	private DossiersWorkflowService dossiersWorkflowService;

	public CreateProcessQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
							  DossiersWorkflowService dossiersWorkflowService, int numThreads, long timeoutMs) {
		super("app-create-process", repo, numThreads, timeoutMs);
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(doTheJob);
		this.setErrorListener(handleError);
		this.start();
	}

	@Override
	protected Class<ApplicationsWorkflowParams> getJobClass() {
		return ApplicationsWorkflowParams.class;
	}

	private final ThrowingConsumer<ApplicationsWorkflowParams> doTheJob = appParams ->
			dossiersWorkflowService
					.createProcess(appParams.getTenant(), appParams.getApplicationId(),
							appParams.getUsername(), appParams.getWorkflowCode(),
							appParams.getLocale(), Map.of(ApplicationsWorkflowParams.KEY, appParams));

	private final QueueErrorListener<ApplicationsWorkflowParams> handleError = (appParams, exp) -> {
		return RESCHEDULE;
	};

}
