package com.abacogroup.agri.dossiers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCatalogWIthModuleCodeNTT {

	private String anomaly_code;
	private String severity;
	private String module_code;

}
