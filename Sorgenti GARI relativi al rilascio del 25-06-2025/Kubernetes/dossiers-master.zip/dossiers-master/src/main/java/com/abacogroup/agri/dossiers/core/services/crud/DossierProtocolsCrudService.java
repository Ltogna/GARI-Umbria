package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierProtocolsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierProtocolsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierProtocolsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProtocolsNTT;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class DossierProtocolsCrudService extends AbstractHistoricizationFieldsCrudService<DossierProtocolsNTT, Long, DossierProtocolsDTO, DossierProtocolsMapper, Void> {

	public DossierProtocolsCrudService(DossierProtocolsDAO dao, DossierProtocolsMapper mapper) {
		super(dao, mapper);
	}


	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(DossierProtocolsNTT rs) {
		return null;
	}

	@Override
	protected DossierProtocolsNTT adjustR(DossierProtocolsNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<DossierProtocolsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public DossierProtocolsDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by with params key: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	/**
	 * get all protocols by dossier id
	 *
	 * @param tenant        current tenant
	 * @param dossierId the dossier's id
	 * @return the protocols list
	 */
	public List<DossierProtocolsDTO> findAll(String tenant, Long dossierId) {
		log.info("Invoking findAll with params tenant: {} dossierId: {}", tenant, dossierId);
		return returnMappedList(((DossierProtocolsDAO) this.dao).find(tenant, dossierId));
	}

	public DossierProtocolsDTO insert(DossierProtocolsDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public DossierProtocolsDTO update(Long key, DossierProtocolsDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void logicallyDeleteByDossierId(Long id, String username) {
		(this.dao).logicallyDeleteById(id, username, LocalDateTime.now());
	}
}
