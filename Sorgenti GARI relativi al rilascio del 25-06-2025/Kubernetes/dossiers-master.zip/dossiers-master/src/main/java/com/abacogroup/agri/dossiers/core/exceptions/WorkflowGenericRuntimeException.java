package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class WorkflowGenericRuntimeException extends AbstractException {

	private static final WorkflowGenericRuntimeException.ErrorBody BODY = new WorkflowGenericRuntimeException.ErrorBody();

	public WorkflowGenericRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	@Schema(name = "WorkflowGenericRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "WORKFLOW_GENERIC_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
