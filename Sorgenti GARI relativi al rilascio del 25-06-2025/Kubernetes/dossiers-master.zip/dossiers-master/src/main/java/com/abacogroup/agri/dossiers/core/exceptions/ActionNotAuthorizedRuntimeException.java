package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ActionNotAuthorizedRuntimeException extends AbstractException {

	public ActionNotAuthorizedRuntimeException(String message) {
		super(Response.Status.FORBIDDEN, BODY, message);
	}

	private static final ActionNotAuthorizedRuntimeException.ErrorBody BODY = new ActionNotAuthorizedRuntimeException.ErrorBody();

	@Schema(name = "ActionNotAuthorizedRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "ACTION_NOT_AUTHORIZED";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}

}
