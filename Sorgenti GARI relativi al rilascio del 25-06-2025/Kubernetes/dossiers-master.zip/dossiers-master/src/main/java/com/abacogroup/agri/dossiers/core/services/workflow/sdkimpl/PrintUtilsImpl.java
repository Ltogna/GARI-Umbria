package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.applicationworkflowsdk.model.GeneratedPrintDTO;
import com.abacogroup.applicationworkflowsdk.service.PrintUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.AuthenticationException;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PrintUtilsImpl implements PrintUtils {

	private final DossiersCrudService dossiersCrudService;
	private final DossierProfilesCrudService dossierProfilesCrudService;
	private final PrintService printService;
	private final Sso2Client sso2Client;

	public PrintUtilsImpl(DossiersCrudService dossiersCrudService,
			DossierProfilesCrudService dossierProfilesCrudService, PrintService printService, Sso2Client sso2Client) {
		this.dossiersCrudService = dossiersCrudService;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
		this.printService = printService;
		this.sso2Client = sso2Client;
	}

	@Override
	public void startPrint(String tenant, Long dossierId, String printCode, String locale, User user, boolean forceProcessStatus,
			String processStatus) throws AuthenticationException {
		var app = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
		app.setProfileList(dossierProfilesCrudService.findAll(tenant, app.getDossierId(), locale));

		List<String> requiredProfileCodes = app.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = printService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						dossierId,
						app.getModuleId(),
						forceProcessStatus ? processStatus : app.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sso2Client.createSecurityContextFromUserName(tenant, user.getName()));
		if (modulesPrint.isEmpty()) {
			log.info("print not found");
		} else {
			printService
					.startPrintJob(tenant, dossierId, app.getPartyId(), app.getProcessStatus(), modulesPrint, printCode, user, locale);
		}

	}

	@Override
	public void startSystemPrint(String s, Long aLong, String s1, String s2, String s3, User user){
		// TODO
	}

	@Override public List<GeneratedPrintDTO> retrievePrintHistory(String tenant, Long applicationId, User user) {
		return printService.getDossierPrintsByDossierId(tenant, applicationId, user)
				.stream()
				.map(x -> GeneratedPrintDTO.builder()
						.pkid(x.getPkid())
						.applicationId(x.getDossierId())
						.processStatus(x.getProcessStatus())
						.printCode(x.getPrintCode())
						.printDescription(x.getPrintDescription())
						.printDate(x.getPrintDate())
						.fileId(x.getFileId())
						.username(x.getUsername())
						.printJobUuid(x.getPrintJobUuid())
						.processStatus(x.getPrintStatus())
						.build())
				.collect(Collectors.toList());
	}
}
