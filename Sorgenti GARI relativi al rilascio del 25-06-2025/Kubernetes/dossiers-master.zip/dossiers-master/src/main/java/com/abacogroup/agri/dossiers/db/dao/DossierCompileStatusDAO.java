package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierCompileStatusNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface DossierCompileStatusDAO extends IGenericHistoricizationFieldsDAO<DossierCompileStatusNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_dossiers_compile_status_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_dossiers_compile_status (pkid, dossier_id, compile_status_identifier, status, " +
			"dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :dossier_id, :compile_status_identifier, :status, " +
			":current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean DossierCompileStatusNTT rs, @Bind("user_id") String userId,
				@Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"dossier_id, " +
			"compile_status_identifier, " +
			"status " +
			"FROM doss_dossiers_compile_status " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	List<DossierCompileStatusNTT> findById(@Bind("id") Long id);

	@SqlUpdate("UPDATE doss_dossiers_compile_status SET " +
			"compile_status_identifier=:compile_status_identifier, " +
			"status=:status " +
			"where pkid=:pkid")
	void update(@BindBean DossierCompileStatusNTT rs);

	@Override
	@SqlUpdate("UPDATE doss_dossiers_compile_status SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.dossier_id, " +
			"acs.compile_status_identifier, " +
			"acs.status, " +
			"FROM doss_dossiers_compile_status acs " +
			"LEFT JOIN doss_dossiers a ON acs.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON a.id = ad.dossier_id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and ad.dossier_code = :dossier_code " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")

	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	ResultIterator<DossierCompileStatusNTT> findByDossierCode(@Bind("tenant") String tenant, @Bind("dossier_code") String dossierCode,
															  @Bind("lang") String lang);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.dossier_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM doss_dossiers_compile_status acs " +
			"LEFT JOIN doss_dossiers a ON acs.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON a.id = ad.dossier_id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and a.id = :dossier_id " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	ResultIterator<DossierCompileStatusNTT> findByDossierId(@Bind("tenant") String tenant, @Bind("dossier_id") Long dossierId,
															@Bind("lang") String lang);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.dossier_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM doss_dossiers_compile_status acs " +
			"LEFT JOIN doss_dossiers a ON acs.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m on a.module_id = m.id " +
			"LEFT JOIN doss_sectors s on m.sector_id = s.id " +
			"WHERE a.id = :dossier_id " +
			"and s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	List<DossierCompileStatusNTT> findByDossierId(@Bind("tenant") String tenant, @Bind("dossier_id") Long dossierId);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.dossier_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM doss_dossiers_compile_status acs " +
			"LEFT JOIN doss_dossiers a ON acs.dossier_id = a.id " +
			"LEFT JOIN doss_modules m on a.module_id = m.id " +
			"LEFT JOIN doss_sectors s on m.sector_id = s.id " +
			"WHERE acs.pkid = :pkid " +
			"and s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	List<DossierCompileStatusNTT> findByTenantAndId(@Bind("tenant") String tenant, @Bind("pkid") Long pkid);

	@SqlQuery("SELECT acs.pkid, " +
			"acs.dossier_id, " +
			"acs.compile_status_identifier, " +
			"acs.status " +
			"FROM doss_dossiers_compile_status acs " +
			"LEFT JOIN doss_dossiers a ON acs.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON a.id = ad.dossier_id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON s.id = m.sector_id " +
			"WHERE s.tenant_id = :tenant " +
			"and acs.compile_status_identifier = :app_compile_status_identifier " +
			"and a.id = :dossier_id " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between acs.dt_insert and acs.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete ")
	@RegisterBeanMapper(DossierCompileStatusNTT.class)
	List<DossierCompileStatusNTT> findByDossierIdAndCompileStatus(@Bind("tenant") String tenant, @Bind("dossier_id") Long dossierId,
																  @Bind("app_compile_status_identifier") String compileStatusIdentifier);
}
