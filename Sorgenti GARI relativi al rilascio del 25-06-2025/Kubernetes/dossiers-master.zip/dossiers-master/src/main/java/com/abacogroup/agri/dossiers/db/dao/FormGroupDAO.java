package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.FormGroupNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface FormGroupDAO extends IGenericDAO<FormGroupNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(doss_form_groups_id_seq)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO doss_form_groups " +
			"(ID, TENANT_ID, FORM_GROUP_CODE, PARENT_FORM_GROUP_ID) " +
			"VALUES(:id, :tenant_id, :form_group_code,:parent_form_group_id)")
	void insert(@BindBean FormGroupNTT formGroup);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id, " +
			"§i18n(:tenantId, 'doss_form_groups', 'form_group_code', form_group_code, :lang)§ as form_group_desc " +
			"FROM doss_form_groups  " +
			"WHERE id=:id AND tenant_id=:tenantId")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findById(@Bind("tenantId") String tenantId, @Bind("id") Long formGroupId, @Bind("lang") String lang);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id " +
			"FROM doss_form_groups  " +
			"WHERE id=:id")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findById(@Bind("id") Long formGroupId);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id, " +
			"§i18n(:tenantId, 'doss_form_groups', 'form_group_code', form_group_code, :lang)§ as form_group_desc " +
			"FROM doss_form_groups  " +
			"WHERE form_group_code=:form_group_code AND tenant_id=:tenantId")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findByCode(@Bind("tenantId") String tenantId, @Bind("form_group_code") String formGroupCode, @Bind("lang") String lang);

	@SqlUpdate("UPDATE doss_form_groups SET " +
			"parent_form_group_id=:parent_form_group_id " +
			"where form_group_code=:form_group_code and tenant_id=:tenant_id and id=:id")
	void update(@BindBean FormGroupNTT sector);

	@SqlUpdate("DELETE FROM doss_form_groups " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long formGroupId);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id, " +
			"§i18n(:tenantId, 'doss_form_groups', 'form_group_code', form_group_code, :lang)§ as form_group_desc " +
			"FROM doss_form_groups  " +
			"WHERE tenant_id=:tenantId")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findAllFormGroups(@Bind("tenantId") String tenant, @Bind("lang") String lang);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id, " +
			"§i18n(:tenantId, 'doss_form_groups', 'form_group_code', form_group_code, :lang)§ as form_group_desc " +
			"FROM doss_form_groups  " +
			"WHERE tenant_id=:tenantId " +
			"and parent_form_group_id is null")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findAllFormGroupsWithNoParentByTenant(@Bind("tenantId") String tenant, @Bind("lang") String lang);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id, " +
			"§i18n(:tenantId, 'doss_form_groups', 'form_group_code', form_group_code, :lang)§ as form_group_desc " +
			"FROM doss_form_groups  " +
			"WHERE tenant_id=:tenantId " +
			"and parent_form_group_id is null " +
			"and id in (<formGroupIdList>)")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findAllFormGroupsWithNoParent(@Bind("tenantId") String tenant, @BindList("formGroupIdList") List<Long> formGroupIdList,
			@Bind("lang") String lang);

	@SqlQuery("SELECT id, " +
			"tenant_id, " +
			"form_group_code, " +
			"parent_form_group_id " +
			"FROM doss_form_groups  " +
			"WHERE tenant_id=:tenantId " +
			"and parent_form_group_id=:parent_form_group_id")
	@RegisterBeanMapper(FormGroupNTT.class)
	List<FormGroupNTT> findFormCatalogsByParentId(@Bind("tenantId") String tenant, @Bind("parent_form_group_id") Long parentFormGroupId);

}
