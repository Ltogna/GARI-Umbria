package com.abacogroup.agri.dossiers.core.services.workflow;

import java.security.Principal;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientRequestFilter;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.SecurityContext;

import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.dropwizard.auth.sso2.UserFunction;
import com.abacogroup.workflow.sdk.auth.AuthContext;

import io.dropwizard.auth.AuthenticationException;

/**
 * @author Gennaro Tamburrelli
 */
public class AuthContextFactory {

	private final Sso2Client sso2Client;

	public AuthContextFactory(Sso2Client sso2Client) {
		this.sso2Client = sso2Client;
	}

	public AuthContext createAuthContext(User user, String locale) throws AuthenticationException {
		return new AuthContext() {
			@Override
			public String getUserId() {
				return user.getUserId();
			}

			@Override
			public Principal getPrincipal() {
				return user;
			}

			@Override
			public String getLocaleCode() {
				return locale;
			}

			@Override
			public boolean isFunctionEnabled(String context, String function) {
				return sso2Client.isFunctionEnabled(user, new UserFunction(context, function));
			}

			@Override
			public WebTarget getAuthenticatedWebTarget(Client client, String url) {
				return client.target(url).register(
						(ClientRequestFilter) requestContext -> requestContext.getHeaders().add("Authorization", "JWT " + user.getAuthToken()));
			}
		};
	}

	public AuthContext createAuthContext(String tenant, String username, String locale) throws AuthenticationException {
		SecurityContext sc = sso2Client.createSecurityContextFromUserName(tenant, username);
		User user = (User) sc.getUserPrincipal();
		return createAuthContext(user, locale);
	}

}
