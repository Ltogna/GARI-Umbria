package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.db.ntt.DossierCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DossierCompileStatusMapper extends EntityMapper<ApplicationCompileStatusDTO, DossierCompileStatusNTT> {

	DossierCompileStatusMapper INSTANCE = Mappers.getMapper(DossierCompileStatusMapper.class);

	@InheritInverseConfiguration()
	ApplicationCompileStatusDTO entityToDto(DossierCompileStatusNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "applicationId", target = "dossier_id")
	@Mapping(source = "compileStatusIdentifier", target = "compile_status_identifier")
	@Mapping(source = "status", target = "status")
    DossierCompileStatusNTT dtoToEntity(ApplicationCompileStatusDTO dto);

}
