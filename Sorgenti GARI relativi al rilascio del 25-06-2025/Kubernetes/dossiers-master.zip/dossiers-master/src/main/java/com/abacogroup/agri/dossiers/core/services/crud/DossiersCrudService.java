package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierMapper;
import com.abacogroup.agri.dossiers.core.mappers.DossierWithDetailMapper;
import com.abacogroup.agri.dossiers.core.mappers.DossiersByPartyAndYearMapper;
import com.abacogroup.agri.dossiers.core.mappers.DossiersByPartyMapper;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DosByPartyAndYearDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierByPartyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierByPartyAndYearNTT;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.result.ResultIterator;
import org.slf4j.MDC;

import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossiersCrudService extends AbstractHistoricizationFieldsCrudService<DossierNTT, Long, DossierDTO, DossierMapper, Void> {

	public DossiersCrudService(DossierDAO dao, DossierMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(DossierNTT rs) {
		return null;
	}

	@Override protected DossierNTT adjustR(DossierNTT rs) {
		return rs;
	}

	@Override
	protected Optional<DossierNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public Optional<DossierDTO> findById(Long moduleId) {
		return returnOptionalRecord(dao.findById(moduleId));
	}

	public DossierDTO findByCode(String tenant, String dossierCode) throws ObjectNotFoundException {
		return ((DossierDAO) this.dao).findByCode(tenant, dossierCode).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public DossierDTO findById(String tenant, Long dossierId) throws ObjectNotFoundException {
		return ((DossierDAO) this.dao).findById(tenant, dossierId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public DossierDTO findByIdAlsoExpired(String tenant, Long dossierId) throws ObjectNotFoundException {
		return ((DossierDAO) this.dao).findByIdAlsoExpired(tenant, dossierId).stream()
				.findFirst()
				.map(mapper::entityToDto)
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public DossierDTO insert(DossierDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public DossierDTO update(Long key, DossierDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void updateProcessId(Long id, Long processId) {
		((DossierDAO) this.dao).updateProcessId(id, processId);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public DossierWithDetailsDTO findWithDetailsByDossierCode(String tenantId, String dossierCode) {
		return this.findWithDetailsByDossierCode(tenantId, dossierCode, MDC.get(MDCPreFilter.LOCALE));
	}

	public DossierWithDetailsDTO findWithDetailsByDossierCode(String tenantId, String dossierCode, String locale) {
		return ((DossierDAO) this.dao).findWithDetailByCode(tenantId, dossierCode, locale)
				.stream()
				.map(DossierWithDetailMapper.INSTANCE::entityToDto)
				.findFirst()
				.orElseThrow(() -> new DossierNotFoundRuntimeException(
						MessageFormat.format("Dossier not found by tenant: {0} code: {1}", tenantId, dossierCode)));
	}

	public DossierWithDetailsDTO findWithDetailsByDossierId(String tenantId, Long dossierId) {
		return this.findWithDetailsByDossierId(tenantId, dossierId, MDC.get(MDCPreFilter.LOCALE));
	}

	public DossierWithDetailsDTO findWithDetailsByDossierId(String tenantId, Long dossierId, String locale) {
		return ((DossierDAO) this.dao).findWithDetailById(tenantId, dossierId, locale)
				.stream()
				.map(DossierWithDetailMapper.INSTANCE::entityToDto)
				.findFirst()
				.orElseThrow(() -> new DossierNotFoundRuntimeException(
						MessageFormat.format("Dossier not found by tenant: {0} id: {1}", tenantId, dossierId)));
	}

	public List<DossierDTO> findAllByPartyId(String tenant, Long partyId) {
		log.info("Invoking find with params tenant: {} partyId: {}", tenant, partyId);
		return ((DossierDAO) dao).findAllByPartyId(tenant, partyId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());

	}

	/**
	 * Find by party id
	 *
	 * @param tenant  current tenant
	 * @param partyId the party id
	 * @param nextKey for pagination
	 * @return the partial list of result
	 */
	public InfiniteListResults<DossierByPartyDTO> find(String tenant, Long partyId, Integer includeClosed, List<String> typeList, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierDAO) this.dao).find(tenant, partyId, includeClosed, typeList, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE),
				DossiersByPartyMapper.INSTANCE::entityToDto
		);
	}

	/**
	 * Find by party id, year
	 *
	 * @param tenant  current tenant
	 * @param partyId the party id
	 * @param year    the specified year
	 * @param nextKey for pagination
	 * @return the partial list of result
	 */
	public InfiniteListResults<DosByPartyAndYearDTO> find(String tenant, Long partyId, Integer year, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierDAO) this.dao).find(tenant, partyId, year, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE),
				DossiersByPartyAndYearMapper.INSTANCE::entityToDto
		);
	}

	public InfiniteListResults<DosByPartyAndYearDTO> find(String tenant, SecurityContext sc, Long partyId, Integer year, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierDAO) this.dao).find(tenant, partyId, year, MDC.get(MDCPreFilter.LOCALE)),
						(x) -> x.getContext_function() == null || Optional.ofNullable(sc).map(y -> y.isUserInRole(x.getContext_function())).orElse(false),
						nextKey,
						DEFAULT_PAGE_SIZE),
				DossiersByPartyAndYearMapper.INSTANCE::entityToDto);
	}

	/**
	 * Find by party id, year, module code
	 *
	 * @param tenant     current tenant
	 * @param partyId    the party id
	 * @param year       the specified year
	 * @param moduleCode the specified module code
	 * @return the list of result
	 */
	public List<DosByPartyAndYearDTO> findWithModuleCode(String tenant, Long partyId, Integer year, String moduleCode) {
		return ((DossierDAO) this.dao).find(tenant, partyId, year, moduleCode, MDC.get(MDCPreFilter.LOCALE))
				.stream()
				.map(DossiersByPartyAndYearMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public InfiniteListResults<DosByPartyAndYearDTO> findInfiniteResults(String tenant, String moduleCode, Long partyId,
																		 Integer year, String processStatus, List<Long> dossierIdList, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(conditionallyLaunchFindInfinite(tenant, moduleCode, partyId, year, processStatus, dossierIdList),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				DossiersByPartyAndYearMapper.INSTANCE::entityToDto);
	}

	private Supplier<ResultIterator<DossierByPartyAndYearNTT>> conditionallyLaunchFindInfinite(String tenant, String moduleCode, Long partyId, Integer year,
																							   String processStatus, List<Long> dossierIdList) {
		if (dossierIdList == null || dossierIdList.isEmpty()) {
			return () -> ((DossierDAO) this.dao)
					.findInfinite(tenant, partyId, year, moduleCode, processStatus, MDC.get(MDCPreFilter.LOCALE));
		} else {
			return () -> ((DossierDAO) this.dao)
					.findInfinite(tenant, partyId, year, moduleCode, processStatus, dossierIdList, MDC.get(MDCPreFilter.LOCALE));
		}

	}

	public List<DossierDTO> findAllByModuleId(String tenant, Long moduleId) {
		log.info("Invoking findAllByModuleId with params tenant: {} partyId: {}", tenant, moduleId);
		return ((DossierDAO) dao).findAllByModuleId(tenant, moduleId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public List<DossierWithDetailsDTO> findAllByModuleIdAndPartyIdAndReferredYear(String tenant, Long moduleId, Long partyId, Integer referredYear) {
		log.info("Invoking findAllByModuleIdAndPartyId with params tenant: {} moduleId: {} partyId: {}", tenant, moduleId, partyId);
		return ((DossierDAO) dao).findAllByModuleIdAndPartyIdAndReferredYear(tenant, moduleId, partyId, referredYear).stream()
				.map(DossierWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public static final boolean FIND_EXPIRED = true;
	public static final boolean FIND_NOT_EXPIRED = false;

	public void getDossierAndUpdateProcessId(String tenant, Long dossierId, Long processId, boolean findExpired) throws ObjectNotFoundException {
		//get dossier
		DossierDTO dossier;
		if (findExpired == FIND_NOT_EXPIRED) {
			dossier = this.findById(tenant, dossierId);
		} else {
			dossier = this.findByIdAlsoExpired(tenant, dossierId);
		}

		//update dossier
		this.updateProcessId(dossier.getDossierId(), processId);
	}
}
