package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.ProgressTypeEnum;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ProgressDossierDTO;
import com.abacogroup.agri.dossiers.core.services.ProgressService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.model.exception.AmendException;
import com.abacogroup.applicationworkflowsdk.service.AmendApplication;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierAmendImpl implements AmendApplication {

	private final ProgressService progressService;
	private final DossierDetailsCrudService dossierDetailsCrudService;

	public DossierAmendImpl(ProgressService progressService,
							DossierDetailsCrudService dossierDetailsCrudService) {
		this.progressService = progressService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
	}

	@Override
	public void amendApplication(String tenant, Long dossierId, User user, String tagName, String scope, ProcessData currentProcessData)
			throws AmendException {
		try {
			progressService.progress(tenant, dossierId, tagName, user, scope, new ProgressDossierDTO(), ProgressTypeEnum.SYNC,
					currentProcessData);
			if (progressService.lastTransitionHasError(tenant, dossierId, user)) {
				throw new AmendException("last transition log has error");
			}
		} catch (Exception e) {
			throw new AmendException(e.getMessage(), e);
		}

	}

	@Override
	public void cancelAmendedById(String tenant, Long originalDossierId, User user) {
		try {
			dossierDetailsCrudService.cancelAmendedBy(tenant, originalDossierId, user.getUserId());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}
}
