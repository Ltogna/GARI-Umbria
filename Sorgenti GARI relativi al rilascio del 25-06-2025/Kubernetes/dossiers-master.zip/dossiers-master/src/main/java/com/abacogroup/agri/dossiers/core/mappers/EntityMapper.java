package com.abacogroup.agri.dossiers.core.mappers;

/**
 * @author Mauro Pozzana
 * @param <D> the DTO entity model
 * @param <N> the resultset entity model
 */
public interface EntityMapper<D, N> {
    D entityToDto(N entity);
    N dtoToEntity(D dto);

}
