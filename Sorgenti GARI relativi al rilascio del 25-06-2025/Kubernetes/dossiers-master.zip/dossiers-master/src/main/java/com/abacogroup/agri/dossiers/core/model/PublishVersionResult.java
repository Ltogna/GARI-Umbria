package com.abacogroup.agri.dossiers.core.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PublishVersionResult
{
    @NotNull
    private Boolean published;
}
