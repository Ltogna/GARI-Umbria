package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierDetailsMapper;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierDetailsDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierDetailsNTT;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class DossierDetailsCrudService
		extends AbstractHistoricizationFieldsCrudService<DossierDetailsNTT, Long, DossierDetailsDTO, DossierDetailsMapper, Void> {

	public DossierDetailsCrudService(DossierDetailsDAO dao, DossierDetailsMapper mapper) {
		super(dao, mapper);
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(DossierDetailsNTT rs) {
		return null;
	}

	@Override protected DossierDetailsNTT adjustR(DossierDetailsNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<DossierDetailsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public DossierDetailsDTO insert(DossierDetailsDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public DossierDetailsDTO update(Long key, DossierDetailsDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public DossierDetailsDTO findDossierDetailByCode(String tenant, String dossierDetailCode) throws ObjectNotFoundException {
		log.info("Invoking findDossierDetailByCode with params tenant: {} dossierDetailCode: {}", tenant, dossierDetailCode);
		return returnOptionalRecord(((DossierDetailsDAO) this.dao).findByCode(tenant, dossierDetailCode))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public DossierDetailsDTO findDossierDetailById(String tenant, Long dossierId) throws ObjectNotFoundException {
		log.info("Invoking findDossierDetailById with params tenant: {} dossierId: {}", tenant, dossierId);
		var res = returnOptionalRecord(((DossierDetailsDAO) this.dao).findByDossierId(tenant, dossierId))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
		res.setDtInsert(this.findFirstCreationDate(tenant, dossierId));
		return res;
	}

	public DossierDetailsDTO findDossierDetailByIdAlsoExpired(String tenant, Long dossierId) throws ObjectNotFoundException {
		log.info("Invoking findDossierDetailByIdAlsoExpired with params tenant: {} dossierId: {}", tenant, dossierId);
		var res = returnOptionalRecord(((DossierDetailsDAO) this.dao).findByDossierIdAlsoExpired(tenant, dossierId))
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
		res.setDtInsert(this.findFirstCreationDate(tenant, dossierId));
		return res;
	}

	public LocalDateTime findFirstCreationDate(String tenant, Long dossierId) {
		return ((DossierDetailsDAO) this.dao).findFirstDtInsert(tenant, dossierId);
	}

	public void updateProcessStatusAndFlTransition(String tenant, Long dossierId, String processStatus, String username,
			ProcessTransitionEnum inTransitionFl) throws ObjectNotFoundException {
		//get dossier details
		var dosDetails = this.findDossierDetailByIdAlsoExpired(tenant, dossierId);
		//update dossier details
		dosDetails.setProcessStatus(processStatus);
		dosDetails.setFlInTransition(inTransitionFl.getFl());
		this.update(dosDetails.getPkid(), dosDetails, username);
	}

	public void updateFlTransition(String tenant, Long dossierId, String username,
			ProcessTransitionEnum inTransitionFl) throws ObjectNotFoundException {
		//get dossier details
		var dosDetails = this.findDossierDetailById(tenant, dossierId);
		//update dossier details
		dosDetails.setFlInTransition(inTransitionFl.getFl());
		dosDetails.setProcessStatus(dosDetails.getProcessStatus());
		this.update(dosDetails.getPkid(), dosDetails, username);
	}

	public void cancelAmendedBy(String tenant, Long dossierId, String username) throws ObjectNotFoundException {
		var appDetails = this.findDossierDetailById(tenant, dossierId);
		appDetails.setAmendedById(null);
		this.update(appDetails.getPkid(), appDetails, username);
	}
}
