package com.abacogroup.agri.dossiers.core.model.dto.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ProgressDossierDTO {
	@Schema(description = "Notes for the dossier progress event")
	private String notes;
}
