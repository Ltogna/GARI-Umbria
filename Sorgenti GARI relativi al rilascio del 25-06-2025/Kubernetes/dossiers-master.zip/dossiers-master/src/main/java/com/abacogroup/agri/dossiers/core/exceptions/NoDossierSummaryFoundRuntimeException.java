package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoDossierSummaryFoundRuntimeException extends AbstractException {

	private static final NoDossierSummaryFoundRuntimeException.ErrorBody BODY = new NoDossierSummaryFoundRuntimeException.ErrorBody();

	public NoDossierSummaryFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoDossierSummaryFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No summary found");
	}

	@Schema(name = "NoDossierSummaryFoundRuntimeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_DOSSIER_SUMMARY_FOUND";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
