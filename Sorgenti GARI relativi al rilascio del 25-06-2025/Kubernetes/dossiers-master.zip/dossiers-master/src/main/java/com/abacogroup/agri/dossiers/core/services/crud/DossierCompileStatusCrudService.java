package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierCompileStatusMapper;
import com.abacogroup.agri.dossiers.db.dao.DossierCompileStatusDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierCompileStatusNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Mauro Pozzana
 */
@Slf4j
public class DossierCompileStatusCrudService
		extends AbstractHistoricizationFieldsCrudService<DossierCompileStatusNTT, Long, ApplicationCompileStatusDTO, DossierCompileStatusMapper, Void> {

	public static final String TO_BE_COMPILED = "TO_BE_COMPILED";

	public DossierCompileStatusCrudService(DossierCompileStatusDAO dao, DossierCompileStatusMapper mapper) {
		super(dao, mapper);
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Void retrieveCustomKeyByResultSet(DossierCompileStatusNTT rs) {
		return null;
	}

	@Override
	protected DossierCompileStatusNTT adjustR(DossierCompileStatusNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<DossierCompileStatusNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public ApplicationCompileStatusDTO insert(ApplicationCompileStatusDTO in, String userId) {
		log.info("Invoking insert with params in: {} userid: {}", in, userId);
		return this.insert(in, userId, null);
	}

	public ApplicationCompileStatusDTO update(Long key, ApplicationCompileStatusDTO in, String userId) {
		log.info("Invoking update with params key: {} in: {} userId: {}", key, in, userId);
		return this.update(key, in, userId, null);
	}

	public void delete(Long key, String userId) {
		log.info("Invoking delete with params key: {} userId: {}", key, userId);
		this.delete(key, userId, null);
	}

	public ApplicationCompileStatusDTO findById(Long key) throws ObjectNotFoundException {
		return findOutDtoByPrimaryKey(key);
	}

	/**
	 * find all compile status by dossier id
	 *
	 * @param tenant currrent tenant
	 * @param dosId  the dossier id
	 * @return all compile status
	 */
	public List<ApplicationCompileStatusDTO> find(String tenant, Long dosId) {
		return returnMappedList(((DossierCompileStatusDAO) this.dao).findByDossierId(tenant, dosId));
	}

	/**
	 * find partial compile status by dossier code
	 *
	 * @param tenant          current tenant
	 * @param dossierCode the dossier code
	 * @param nextKey         the next key for pagination
	 * @return partial compile status
	 */
	public InfiniteListResults<ApplicationCompileStatusDTO> find(String tenant, String dossierCode, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierCompileStatusDAO) this.dao).findByDossierCode(tenant, dossierCode, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE));
	}

	/**
	 * find partial compile status by dossier id
	 *
	 * @param tenant        current tenant
	 * @param dossierId the dossier id
	 * @param nextKey       the next key for pagination
	 * @return partial compile status
	 */
	public InfiniteListResults<ApplicationCompileStatusDTO> find(String tenant, Long dossierId, String nextKey) {
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierCompileStatusDAO) this.dao).findByDossierId(tenant, dossierId, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE));
	}

	public ApplicationCompileStatusDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		return findOutDtoByPrimaryKey(id);
	}

	/**
	 * find App compile status by tenant, dossier id, compile status identifier
	 *
	 * @param tenant                  current tenant
	 * @param dossierId           the dossier id
	 * @param compileStatusIdentifier the compile status identifier to filter with
	 * @return the app compile status
	 */
	public ApplicationCompileStatusDTO findByCompileStatusIdentifier(String tenant, Long dossierId, String compileStatusIdentifier)
			throws ObjectNotFoundException {
		return ((DossierCompileStatusDAO) this.dao)
				.findByDossierIdAndCompileStatus(tenant, dossierId, compileStatusIdentifier)
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	protected ApplicationCompileStatusDTO findByTenantAndPrimaryKey(String tenant, Long key) throws ObjectNotFoundException {
		return ((DossierCompileStatusDAO) this.dao).findByTenantAndId(tenant, key)
				.stream()
				.filter(this::isNotLogicallyDeleted)
				.map(mapper::entityToDto)
				.findFirst()
				.orElseThrow(AbstractCrudService.OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}
}
