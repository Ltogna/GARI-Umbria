package com.abacogroup.agri.dossiers.utils;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.basic.BasicCredentials;

import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestContext;

import java.io.IOException;
import java.security.Principal;

/**
 * @author Gennaro Tamburrelli
 */
@Priority(1000)
public class DevFilter<P extends Principal> extends AuthFilter<BasicCredentials, P> {

	private DevFilter() {
	}

	public void filter(ContainerRequestContext requestContext) throws IOException {
		this.authenticate(requestContext, new BasicCredentials("a", "p"), "BASIC");
	}

	public static class Builder<P extends Principal> extends AuthFilterBuilder<BasicCredentials, P, DevFilter<P>> {
		public Builder() {
			/*
			 * Not used
			 */
		}

		protected DevFilter<P> newInstance() {
			return new DevFilter<>();
		}
	}

}
