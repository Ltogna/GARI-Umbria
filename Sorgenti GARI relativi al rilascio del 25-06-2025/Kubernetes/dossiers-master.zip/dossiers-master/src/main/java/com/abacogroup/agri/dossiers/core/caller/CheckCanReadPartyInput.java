package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

import static com.abacogroup.applicationworkflowsdk.model.Constants.TENANT;
import static com.abacogroup.jaxrsutils.GenericCallerService.GET_METHOD;
import static com.abacogroup.jaxrsutils.GenericCallerService.PARTY_ID;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CheckCanReadPartyInput implements ICallerInput {

	private String url;
	private String tenant;
	private Long partyId;
	private String authToken;

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of(TENANT, this.tenant, PARTY_ID, this.partyId);
	}

	@Override
	public String getHttpMethod() {
		return GET_METHOD;
	}

	@Override
	public String provideAuthToken() {
		return this.authToken;
	}
}
