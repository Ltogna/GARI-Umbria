package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierCompileStatusCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.abacogroup.applicationworkflowsdk.service.GetFormConfigs;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class GetFormConfigsImpl implements GetFormConfigs {

	private final DossiersCrudService dossiersCrudService;
	private final DossierProfilesCrudService dossierProfilesCrudService;
	private final DossierCompileStatusCrudService dossierCompileStatusCrudService;
	private final FormConfigService formConfigService;
	private final Sso2Client sso2Client;
	public GetFormConfigsImpl(DossiersCrudService dossiersCrudService,
			DossierProfilesCrudService dossierProfilesCrudService,
			DossierCompileStatusCrudService dossierCompileStatusCrudService,
			FormConfigService formConfigService, Sso2Client sso2Client) {
		this.dossiersCrudService = dossiersCrudService;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
		this.dossierCompileStatusCrudService = dossierCompileStatusCrudService;
		this.formConfigService = formConfigService;
		this.sso2Client = sso2Client;
	}

	@Override
	public List<FormWithGroupHierarchyPublicDTO> getForms(String tenant, Long dossierId, User user, String locale) throws Exception  {
		return this.getFormsByProcessStatus(tenant, dossierId, null, user, locale);
	}

	@Override
	public List<FormWithGroupHierarchyPublicDTO> getFormsByProcessStatus(String tenant, Long dossierId, String processStatus, User user, String locale)
			throws Exception {
		var res = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
		res.setCompileStatus(dossierCompileStatusCrudService.find(tenant, res.getDossierId()));
		var profileList = dossierProfilesCrudService.findAll(tenant, res.getDossierId(), locale);
		List<String> requiredProfileCodes = profileList
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
		return formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						Optional.ofNullable(processStatus).orElse(res.getProcessStatus()),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sso2Client.createSecurityContextFromUserId(tenant, user.getUserId()),
						locale);
	}
}
