package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleMapper extends EntityMapper<ModuleDTO, ModuleNTT> {

	ModuleMapper INSTANCE = Mappers.getMapper(ModuleMapper.class);

	@InheritInverseConfiguration()
	ModuleDTO entityToDto(ModuleNTT entity);

	@Mapping(source = "moduleId", target = "id")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "sectorId", target = "sector_id")
	@Mapping(source = "workflowCode", target = "workflow_code")
	@Mapping(source = "flAmendModule", target = "fl_amend_module")
	ModuleNTT dtoToEntity(ModuleDTO dto);

	default boolean map(Integer value) {
		return value != null && (value == 1);
	}
	default int map(Boolean value) {
		return value == null ? 0 : (value ? 1 : 0);
	}

}
