package com.abacogroup.agri.dossiers.core.services.embededqueue.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class QueueWorkflowParams {
	private Long processId;
	private Long dossierId;
	private Integer transitionId;
	private String tenant;
	private String username;
	private String locale;
	private String scope;
	private String notes;
}
