package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DossierMapper extends EntityMapper<DossierDTO, DossierNTT> {

	DossierMapper INSTANCE = Mappers.getMapper(DossierMapper.class);

	@InheritInverseConfiguration()
	DossierDTO entityToDto(DossierNTT entity);

	@Mapping(source = "dossierId", target = "id")
	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "referredYear", target = "referred_year")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
	DossierNTT dtoToEntity(DossierDTO dto);

}
