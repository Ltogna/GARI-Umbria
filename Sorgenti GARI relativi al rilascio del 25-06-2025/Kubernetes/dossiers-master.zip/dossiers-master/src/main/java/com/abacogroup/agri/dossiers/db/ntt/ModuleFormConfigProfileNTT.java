package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigProfileNTT implements IIdRs<Void> {

	private Long module_form_config_id;
	private String required_profile_code;

	@Override public Optional<Void> getKey() {
		return Optional.empty();
	}

	@Override public void setKey(Void id) {
		// not in use
	}

}
