package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Samuele Sbarbaro
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AmendableModuleDTO {
	private Long pkid;
	private Long moduleId;
	private Long amendableModuleId;
	private String userIdInsert;
	private String userIdDelete;
	private LocalDateTime dtInsert;
	private LocalDateTime dtDelete;
}
