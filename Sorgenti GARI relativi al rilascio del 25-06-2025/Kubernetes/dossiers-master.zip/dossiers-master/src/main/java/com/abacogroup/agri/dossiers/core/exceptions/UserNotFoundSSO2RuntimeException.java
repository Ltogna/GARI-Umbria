package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class UserNotFoundSSO2RuntimeException extends AbstractException {

	private static final UserNotFoundSSO2RuntimeException.ErrorBody BODY = new UserNotFoundSSO2RuntimeException.ErrorBody();

	public UserNotFoundSSO2RuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public UserNotFoundSSO2RuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "User does not exist in sso2");
	}

	@Schema(name = "UserNotFoundSSO2RuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "USER_NOT_FOUND_SSO2";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
