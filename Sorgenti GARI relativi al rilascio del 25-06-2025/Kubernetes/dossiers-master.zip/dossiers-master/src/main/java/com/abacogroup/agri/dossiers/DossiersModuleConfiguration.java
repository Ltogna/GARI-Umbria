package com.abacogroup.agri.dossiers;

import com.abacogroup.agri.dossiers.bundles.model.BundleConfig;
import com.abacogroup.agri.dossiers.core.model.CheckCanReadConfig;
import com.abacogroup.agri.dossiers.core.model.OverridePartyHostConfig;
import com.abacogroup.agri.dossiers.core.model.QueueProcessorConfig;
import com.abacogroup.agri.dossiers.core.model.RabbitMqConfig;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import io.dropwizard.db.DataSourceFactory;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class DossiersModuleConfiguration extends Configuration {
	@Valid
	@NotNull
	private DataSourceFactory database;

	private boolean secureAuth;

	private String dbType;

	private String sso2Url;

	private String sso2TokenSecretAuth;

	private String dossiersUrl;

	private String dossierFormsUrl;

	private String printEngineUrl;

	private String fileStoreUrl;

	private OverridePartyHostConfig overridePartyHostConfig;

	private String printsBucket;

	private String userRole;

	private Boolean devUser;
	private RabbitMqConfig rabbitmqConfig;

	private String bundleServiceId;

	private Boolean activateBundleConfig;
	private BundleConfig bundleConfig;

	private QueueProcessorConfig queueProcessorConfig;

	private String environmentId;

	private CheckCanReadConfig checkCanReadConfig;
	private CheckCanReadConfig checkCanReadAllPartiesConfig;
	private boolean devMode;

	@JsonProperty("database")
	public DataSourceFactory getDatabase() {
		return database;
	}

	@Valid
	@NotNull
	private JerseyClientConfiguration jerseyClient = new JerseyClientConfiguration();

	@JsonProperty("jerseyClient")
	public JerseyClientConfiguration getJerseyClientConfiguration() {
		return jerseyClient;
	}

	@JsonProperty("jerseyClient")
	public void setJerseyClientConfiguration(JerseyClientConfiguration jerseyClient) {
		this.jerseyClient = jerseyClient;
	}

	@JsonProperty("database")
	public void setDatabase(DataSourceFactory database) {
		this.database = database;
	}
}
