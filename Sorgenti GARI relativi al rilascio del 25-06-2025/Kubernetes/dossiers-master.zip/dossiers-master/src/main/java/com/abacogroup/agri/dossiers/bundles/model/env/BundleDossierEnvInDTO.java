package com.abacogroup.agri.dossiers.bundles.model.env;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Bundle dossier env in dto.
 * @author Carlo Sindico
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleDossierEnvInDTO {

    private String key;
    private String value;
    private Integer flClient;

}
