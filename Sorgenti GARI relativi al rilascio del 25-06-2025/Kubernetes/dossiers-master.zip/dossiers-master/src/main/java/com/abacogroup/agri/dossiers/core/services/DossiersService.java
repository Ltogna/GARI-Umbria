package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.mappers.*;
import com.abacogroup.agri.dossiers.core.model.*;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.model.dto.PartyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.applicationworkflowsdk.model.io.output.*;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.NodeType;
import com.abacogroup.workflow.server.model.Transition;
import com.abacogroup.workflow.server.model.WorkflowNode;
import com.abacogroup.workflow.server.services.exceptions.WorkflowNotFoundException;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.jdbi.v3.core.Jdbi;
import org.slf4j.MDC;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.abacogroup.applicationworkflowsdk.model.Constants.WORKFLOW_CLOSED_KEY;
import static java.util.stream.Collectors.groupingBy;

/**
 * @author Gennaro Tamburrelli
 * @author Mauro Pozzana
 * @author Alexandru Paraschiv
 */
@Slf4j
public class DossiersService {
	private final Jdbi jdbi;
	private final DossiersWorkflowService dossiersWorkflowService;
	private final PartyService partyService;
	private final CheckPartyService checkPartyService;

	private final ModuleCrudService moduleCrudService;
	private final ModuleDetailsCrudService moduleDetailsCrudService;
	private final DossiersCrudService dossiersCrudService;
	private final DossierDetailsCrudService dossierDetailsCrudService;
	private final DossierProfilesCrudService dossierProfilesCrudService;
	private final DossierCompileStatusCrudService dossierCompileStatusCrudService;
	private final ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final CreateProcessQueue createProcessQueue;
	private final ProgressService progressService;
	private final DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;
	private final DossierProtocolsCrudService dossierProtocolsCrudService;
	private AnomaliesService anomaliesService;
	private final SectorsCrudService sectorsCrudService;
	private final FormConfigService formConfigService;
	private final AmendmentService amendmentService;
	private final PrintService printService;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	public DossiersService(Jdbi jdbi,
                           DossiersWorkflowService dossiersWorkflowService,
                           CheckPartyService checkPartyService,
                           PartyService partyService,
                           ModuleCrudService moduleCrudService,
                           ModuleDetailsCrudService moduleDetailsCrudService,
                           DossiersCrudService dossiersCrudService,
                           DossierDetailsCrudService dossierDetailsCrudService,
                           DossierProfilesCrudService dossierProfilesCrudService,
                           DossierCompileStatusCrudService dossierCompileStatusCrudService,
                           ModuleFormConfigsCrudService moduleFormConfigsCrudService,
                           ModuleProfilesCrudService moduleProfilesCrudService,
                           ModulePrintConfigsCrudService modulePrintConfigsCrudService,
                           ModulePrintConfigParamCrudService modulePrintConfigParamCrudService,
                           CreateProcessQueue createProcessQueue,
                           ProgressService progressService,
                           DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService,
                           SectorsCrudService sectorsCrudService,
                           FormConfigService formConfigService,
                           DossierProtocolsCrudService dossierProtocolsCrudService,
                           AmendmentService amendmentService,
                           PrintService printService, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService) {
		this.jdbi = jdbi;
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.partyService = partyService;
		this.checkPartyService = checkPartyService;
		this.moduleCrudService = moduleCrudService;
		this.moduleDetailsCrudService = moduleDetailsCrudService;
		this.dossiersCrudService = dossiersCrudService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
		this.dossierCompileStatusCrudService = dossierCompileStatusCrudService;
		this.moduleFormConfigsCrudService = moduleFormConfigsCrudService;
		this.moduleProfilesCrudService = moduleProfilesCrudService;
		this.modulePrintConfigsCrudService = modulePrintConfigsCrudService;
		this.modulePrintConfigParamCrudService = modulePrintConfigParamCrudService;
		this.createProcessQueue = createProcessQueue;
		this.progressService = progressService;
		this.dossierGeneratedPrintCrudService = dossierGeneratedPrintCrudService;
		this.dossierProtocolsCrudService = dossierProtocolsCrudService;
		this.sectorsCrudService = sectorsCrudService;
		this.formConfigService = formConfigService;
		this.amendmentService = amendmentService;
		this.printService = printService;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
        this.anomaliesService = new AnomaliesService(this, moduleCrudService, dossiersCrudService, dossierDetailsCrudService);
	}

	public void setAnomaliesService(AnomaliesService anomaliesService) {
		this.anomaliesService = anomaliesService;
	}

	public InfiniteListResults<ModuleByPointInTimeDTO> getModulesByPointInTime(String tenant, AbsoluteDate pointInTime, Integer flAmend, String nextKey,
																			   SecurityContext sc) {
		AbsoluteDate dateToUse = getDefaultAbsoluteDate(pointInTime);
		var res = moduleCrudService.find(tenant, dateToUse, flAmend, nextKey);
		if (nextKey == null && res.getRecords().isEmpty()) {
			throw new NoModulesFoundAtDateRuntimeException(MessageFormat.format("no modules found at date {0}", dateToUse));
		} else {
			return new InfiniteListResultsImpl<>(
					res.getRecords().stream()
							.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
							.filter(x -> verifyForceReadOnlyContextFunction(sc, x.getForceReadOnlyContextFunction()))
							.collect(Collectors.toList()),
					res.getNextKey());
		}
	}

	public List<ModuleByPointInTimeDTO> getModulesByPointInTime(String tenant, AbsoluteDate pointInTime, Integer flAmend, SecurityContext sc) {
		AbsoluteDate dateToUse = getDefaultAbsoluteDate(pointInTime);
		var res = moduleCrudService.find(tenant, dateToUse, flAmend);
		if (res.isEmpty()) {
			throw new NoModulesFoundAtDateRuntimeException(MessageFormat.format("no modules found at date {0}", dateToUse));
		} else {
			return res.stream()
					.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
					.filter(x -> verifyForceReadOnlyContextFunction(sc, x.getForceReadOnlyContextFunction()))
					.collect(Collectors.toList());
		}
	}

	public List<ModuleWithDetailDTO> getModulesBySectorCode(String tenant, String sectorCode, SecurityContext sc) {
		try {
			SectorDTO sector = sectorsCrudService.findSectorByCode(tenant, sectorCode);
			return moduleCrudService.findAllModulesWithDetailBySectorId(tenant, sector.getSectorId()).stream()
					.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
					.filter(x -> verifyForceReadOnlyContextFunction(sc, x.getForceReadOnlyContextFunction()))
					.collect(Collectors.toList());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(MessageFormat.format("No sectors found for this sector code {0}", sectorCode));
		}
	}

	public InfiniteListResults<ModuleProfilePublicDTO> getProfilesByModuleAndSector(String tenant, String sectorCode, String moduleCode,
			AbsoluteDate pointInTime, String nextKey) {
		AbsoluteDate dateToUse = getDefaultAbsoluteDate(pointInTime);
		var res = moduleProfilesCrudService.find(tenant, sectorCode, moduleCode, dateToUse, nextKey);
		if (nextKey == null && res.getRecords().isEmpty()) {
			throw new NoProfilesFoundAtDateRuntimeException(MessageFormat.format("no modules found at date {0}", dateToUse));
		} else {
			return new InfiniteListResultsImpl<>(res.getRecords().stream().map(ModuleProfilePublicMapper.INSTANCE::dtoToPublic).collect(Collectors.toList()),
					res.getNextKey());
		}
	}

	public InfiniteListResults<SectorPublicDTO> getSectorsByTenant(String tenant, String nextKey) {
		InfiniteListResults<SectorDTO> sectors = sectorsCrudService.findInfiniteAllSectors(tenant, nextKey);
		if (nextKey == null && sectors.getRecords().isEmpty()) {
			throw new NoSectorsFoundAtDateRuntimeException(MessageFormat.format("No sectors found for tenant {0}", tenant));
		}

		return new InfiniteListResultsImpl<>(sectors.getRecords().stream().map(SectorPublicMapper.INSTANCE::dtoToPublic).collect(Collectors.toList()),
				nextKey);
	}

	public List<WorkflowNodePublic> getStatusNodes(String tenant, String moduleCode) {
		ModuleDTO moduleDTO = moduleCrudService.findByCode(tenant, moduleCode)
				.orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", moduleCode)));

		List<WorkflowNode> workflowNodes = dossiersWorkflowService.getWorkflowNodesByType(tenant, moduleDTO.getWorkflowCode(), NodeType.status);

		return workflowNodes.stream()
				.sorted(Comparator.comparing(WorkflowNode::getId))
				.map(WorkflowNodePublicMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	private AbsoluteDate getDefaultAbsoluteDate(AbsoluteDate pointInTime) {
		return Optional.ofNullable(pointInTime).orElseGet(() -> new AbsoluteDate(LocalDate.now()));
	}

	public DossiersSummaryByYearOutDTO getDossiersSummaryByYear(String tenant, Long partyId, User user) {
		if (Optional.ofNullable(partyId).isEmpty()) {
			throw new NoMandatoryInputPartyIdRuntimeException("Party id is mandatory");
		}

		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			return DossiersSummaryByYearOutDTO.builder()
					.partyId(partyId)
					.dossiersSummaryByYear(Collections.emptyList())
					.build();
		}

		List<DossierDTO> dossiers = dossiersCrudService.findAllByPartyId(tenant, partyId);

		Map<Integer, List<DossierDTO>> dossiersByYear = dossiers.stream()
				.sorted(Comparator.comparing(DossierDTO::getReferredYear))
				.collect(groupingBy(DossierDTO::getReferredYear));

		DossiersSummaryByYearOutDTO results = DossiersSummaryByYearOutDTO.builder()
				.partyId(partyId)
				.build();

		dossiersByYear.keySet().stream()
				.forEach(year -> results.getDossiersSummaryByYear().add(
						DossiersSummaryByYearDTO.builder()
								.year(year)
								.dossiersNumber(dossiersByYear.get(year).size())
								.build()));

		if (results.getDossiersSummaryByYear().isEmpty()) {
			throw new NoDossierSummaryFoundRuntimeException(
					MessageFormat.format("No dossier summary found for tenant: {0} partyId: {1}", tenant, partyId));
		}

		return results;
	}

	public CreateDossierOutDTO createDossierAsync(String tenant, User user, CreateDossierInDTO payload) {
		ModuleDTO module = getModule(tenant, payload);
		ModuleDetailsDTO moduleDetails = moduleDetailsCrudService.findByModuleId(tenant, module.getModuleId());

		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, moduleDetails.getModuleId());
		List<DossierAnomaly> dossierAnomalies = checkForAnomalies(tenant, payload, module);

		if (!dossierAnomalies.isEmpty()) {
			return CreateDossierOutDTO.builder()
					.anomalies(dossierAnomalies)
					.build();
		}
		DossierOutDTO newDossier = doInsertDossierAsync(tenant, user.getName(), payload, module);

		return CreateDossierOutDTO.builder()
				.dossierId(newDossier.getDossier().getDossierId())
				.dossierCode(newDossier.getDossierDetail().getDossierCode())
				.build();
	}

	public CreateAmendmentDossierOutDTO createAmendmentDossierAsync(String tenant, User user, CreateDossierInDTO payload) {
		if (Optional.ofNullable(payload.getAmendmentDossierId()).isEmpty()) {
			throw new BadRequestRuntimeException("No amendment dossier id found");
		}

		ModuleDTO module = getModule(tenant, payload);

		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByModuleId(user, module.getModuleId());

		List<DossierAnomaly> dossierAnomalies = checkForAnomalies(tenant, payload, module);
		dossierAnomalies.addAll(anomaliesService.checkForAmendmentModule(module));
		dossierAnomalies.addAll(anomaliesService.checkForDossierNotAmended(tenant, payload.getAmendmentDossierId()));
		dossierAnomalies.addAll(anomaliesService.checkForDossierWaived(tenant, payload.getAmendmentDossierId()));

		if (!dossierAnomalies.isEmpty()) {
			return CreateAmendmentDossierOutDTO.builder()
					.anomalies(dossierAnomalies)
					.build();
		}

		return jdbi.inTransaction(handle -> {
			DossierOutDTO newDossier = doInsertDossierAsync(tenant, user.getName(), payload, module);

			updateAmendedByDossierId(tenant, payload.getAmendmentDossierId(), newDossier.getDossier().getDossierId(), user.getName());

			return CreateAmendmentDossierOutDTO.builder()
					.dossierId(newDossier.getDossier().getDossierId())
					.dossierCode(newDossier.getDossierDetail().getDossierCode())
					.amendmentDossierId(newDossier.getDossierDetail().getAmendOfId())
					.build();
		});
	}

	private void updateAmendedByDossierId(String tenant, Long dossierId, Long amendedById, String username) {
		jdbi.useTransaction(handle -> {
			try {
				DossierDetailsDTO dossierDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);

				dossierDetails.setAmendedById(amendedById);

				dossierDetailsCrudService.update(dossierDetails.getPkid(), dossierDetails, username);
			} catch (ObjectNotFoundException e) {
				throw new DossierNotFoundRuntimeException(MessageFormat.format("Dossier with id {0} not found", dossierId));
			}
		});
	}

	private ModuleDTO getModule(String tenant, CreateDossierInDTO payload) {
		Optional<ModuleDTO> optModule = moduleCrudService.findByModuleCodeAndSectorCode(tenant, payload.getModuleCode(), payload.getSectorCode());

		if (optModule.isEmpty()) {
			throw new NoModulesFoundAtDateRuntimeException("Module not found");
		}

		return optModule.get();
	}

	private List<DossierAnomaly> checkForAnomalies(String tenant, CreateDossierInDTO payload, ModuleDTO module) {
		ModuleDetailsDTO moduleDetailsDTO = moduleDetailsCrudService.findByModuleId(tenant, module.getModuleId());
		List<DossierAnomaly> dossierAnomalies = anomaliesService.checkForModuleDateValidity(moduleDetailsDTO);

		dossierAnomalies.addAll(anomaliesService.checkForMultipleDossier(tenant, module, payload.getPartyId(),
				payload.getYear(), null));
		return dossierAnomalies;
	}

	public DossierOutDTO doInsertDossierAsync(String tenant, String username, CreateDossierInDTO payload, ModuleDTO module) {
		return jdbi.inTransaction(handle -> {
			var dossier = createVanillaDossierWithDetails(username, payload, module);
			// creo il processo
			log.info("Creating process with tenant: {} workflowCode: {}", tenant, module.getWorkflowCode());
			String workflowCode = module.getWorkflowCode();
			// execute create process asynchronously
			createProcessQueue.add(ApplicationsWorkflowParams.builder()
					.applicationId(dossier.getDossier().getDossierId())
					.applicationCode(dossier.getDossierDetail().getDossierCode())
					.amendedApplicationId(dossier.getDossierDetail().getAmendOfId())
					.tenant(tenant)
					.username(username)
					.locale(MDC.get(MDCPreFilter.LOCALE))
					.partyId(dossier.getDossier().getPartyId())
					.workflowCode(workflowCode)
					.referredYear(dossier.getDossier().getReferredYear())
					.build(), System.currentTimeMillis());
			return dossier;
		});
	}

	/**
	 * Create dossier's record without process id and status
	 *
	 * @param username user name
	 * @param payload  the dossier's detail
	 * @param module   the module's detail
	 * @return the created record
	 */
	public DossierOutDTO createVanillaDossierWithDetails(String username, CreateDossierInDTO payload, ModuleDTO module) {
		return jdbi.inTransaction(x -> {

			DossierDTO in = DossierDTO.builder()
					.partyId(payload.getPartyId())
					.referredYear(payload.getYear())
					.moduleId(module.getModuleId())
					.userIdInsert(username)
					.build();

			// restituisco il dossier creato
			log.info("Inserting dossier");
			DossierDTO insertedDossier = dossiersCrudService.insert(in, username);
			log.info("Dossier inserted");
			DossierDetailsDTO detailsIn = DossierDetailsDTO.builder()
					.dossierId(insertedDossier.getDossierId())
					.dossierCode(generateDossierCode(insertedDossier.getDossierId()))
					.flInTransition(ProcessTransitionEnum.NOT_IN_TRANSITION.getFl())
					.amendOfId(payload.getAmendmentDossierId())
					.build();
			log.info("Inserting dossier details");
			DossierDetailsDTO insertedDetails = dossierDetailsCrudService.insert(detailsIn, username);
			log.info("Dossier details Inserted");

			return DossierOutDTO.builder()
					.dossier(insertedDossier)
					.dossierDetail(insertedDetails)
					.build();
		});
	}

	public String generateDossierCode(Long dossierId) {
		return Optional.ofNullable(dossierId).map(Objects::toString).orElse(null);
	}

	public DossierWithDetailsDTO getDetailedDossierById(String tenant, Long dossierId, User user, SecurityContext sc) {
		DossierWithDetailsDTO res = getDossierWithDetailsById(tenant, dossierId, user, sc);

		res.setOriginalAmendedDossierId(amendmentService.getOriginalAmendedDossierId(res, tenant));

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		res.setForms(formConfigService.getFormsByModuleIdAndProcessStatus(tenant,
				res.getModuleId(),
				res.getProcessStatus(),
				res.getCompileStatus(),
				requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
				sc,
				MDC.get(MDCPreFilter.LOCALE)));

		res.setPrints(getPrintsByModuleIdAndProcessStatus(tenant,
				dossierId,
				res.getModuleId(),
				res.getProcessStatus(),
				requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
				sc));

		res.setParty(partyService.getPartyByPartyId(tenant, res.getPartyId(), user));
		return res;
	}

	public DossierWithDetailsDTO getDossierWithDetailsById(String tenant, Long dossierId, User user, SecurityContext sc) {
		var res = Optional.of(dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId))
				.filter(app -> {
					var moduleDetails = moduleDetailsCrudService.findByModuleId(tenant, app.getModuleId());
					if (moduleDetails.getContextFunction() == null) {
						return true;
					}
					var userCanSeeModule = sc.isUserInRole(moduleDetails.getContextFunction());
					if (userCanSeeModule) {
						return true;
					} else {
						throw new ActionNotAuthorizedRuntimeException("user cannot see dossiers of this module");
					}
				})
				.map(app -> {
					try {
						app.setProcessStatusDescription(dossiersWorkflowService.getProcessStatusDescription(tenant, app.getProcessId(), user));
					} catch (WorkflowNotFoundException e) {
						throw new WorkflowGenericRuntimeException(e.getMessage());
					}
					return app;
				})
				.map(app -> {
					app.setDtInsert(dossierDetailsCrudService.findFirstCreationDate(tenant, dossierId));
					app.setProfileList(dossierProfilesCrudService.findAll(tenant, app.getDossierId(), MDC.get(MDCPreFilter.LOCALE)));
					app.setCompileStatus(dossierCompileStatusCrudService.find(tenant, app.getDossierId()));

					Optional<DetailedTransitionLog> lastMovement = extractLastMovement(tenant, user, app);

					if(lastMovement.isPresent()) {
						app.setLastMovement(lastMovement.get().getDescription());
						app.setDtLastMovement(Optional.ofNullable(lastMovement.get().getEndDate()).map(Timestamp::toLocalDateTime).orElse(null));
						app.setLastMovementUserIdExecutor(lastMovement.get().getUserId());
					}

					dossierProtocolsCrudService.findAll(tenant, dossierId)
							.stream()
							.findFirst()
							.ifPresent(protocol -> {
								app.setDtProtocolRequest(protocol.getDtRequest());
								app.setDtProtocolResponse(protocol.getDtResponse());
								app.setProtocolCode(protocol.getProtocol());
							});
					app.setAmendmentDossierId(
							getDossierAmendment(tenant, app, DossierWithDetailsDTO::getAmendmentDossierId, this::isAmendmentDossierIdViewable));
					app.setAmendedDossierId(
							getDossierAmendment(tenant, app, DossierWithDetailsDTO::getAmendedDossierId, this::isAmendedDossierIdViewable));
					return app;
				})
				.orElse(DossierWithDetailsDTO.builder().build());
		conditionallyThrowDossierNotFound(tenant, user, res.getPartyId());
		return res;
	}

	private Long getDossierAmendment(String tenant, DossierWithDetailsDTO dossierWithDetails, Function<DossierWithDetailsDTO, Long> idGetter,
			BiPredicate<String, DossierWithDetailsDTO> checkerFunction) {
		if (!checkerFunction.test(tenant, dossierWithDetails)) {
			return null;
		}

		return idGetter.apply(dossierWithDetails);
	}

	private String extractInformationFromLastMovement(String tenant, User user, DossierWithDetailsDTO app, Function<DetailedTransitionLog, String> getter) {
		return dossiersWorkflowService.getProcessTransitionHistory(tenant, app.getProcessId(), user)
				.stream()
				.min(Comparator.comparing(DetailedTransitionLog::getEndDate).reversed())
				.map(getter)
				.orElse(null);
	}

	private Optional<DetailedTransitionLog> extractLastMovement(String tenant, User user, DossierWithDetailsDTO app) {
		return dossiersWorkflowService.getProcessTransitionHistory(tenant, app.getProcessId(), user)
				.stream()
				.min(Comparator.comparing(DetailedTransitionLog::getEndDate).reversed());
	}

	private Boolean isAmendmentDossierIdViewable(String tenant, DossierWithDetailsDTO dossierWithDetails) {
		if (Optional.ofNullable(dossierWithDetails.getAmendmentDossierId()).isEmpty()) {
			return false;
		}

		DossierWithDetailsDTO amendmentDossierWithDetails =
				dossiersCrudService.findWithDetailsByDossierId(tenant, dossierWithDetails.getAmendmentDossierId());

		return Boolean.TRUE.equals(amendmentService.isDossierAmendable(tenant, dossierWithDetails.getAmendmentDossierId()) &&
				amendmentService.isAmendModule(tenant, amendmentDossierWithDetails.getModuleId()));
	}

	private Boolean isAmendedDossierIdViewable(String tenant, DossierWithDetailsDTO dossierWithDetails) {
		if (Optional.ofNullable(dossierWithDetails.getAmendedDossierId()).isEmpty()) {
			return false;
		}

		return Boolean.TRUE.equals(amendmentService.isAmendModule(tenant, dossierWithDetails.getModuleId()));
	}

	private Boolean isAmendableDossier(final String tenant, final Long dossierId, final String dossierCode, final String moduleCode) {
		Optional<Boolean> isAmendable = Optional.ofNullable((Boolean) checkForMetadata(tenant, dossierCode).get("isAmendable"));
		return isAmendable.isPresent() && isAmendable.get() && amendmentService.checkAmendmentStatus(tenant, dossierId, moduleCode);
	}

	public List<PrintDetailsOutDTO> getPrintsByModuleIdAndProcessStatus(String tenant, Long dossierId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {
		if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(sc, moduleId)) {
			return Collections.emptyList();
		} else {
			return this.printService.getPrintsByModuleIdAndProcessStatus(tenant, dossierId, moduleId, processStatus, profileCodeList, sc);
		}
	}

	public InfiniteListResults<DossierByPartyDTO> getDossiersByParty(String tenant, Long partyId, Integer includeClosed, List<String> typeList, String nextKey, User user,
																	 SecurityContext securityContext) {
		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			return new InfiniteListResultsImpl<>();
		}
		var res = dossiersCrudService.find(tenant, partyId, includeClosed, typeList, nextKey);
		res.getRecords().stream()
				.forEachOrdered(dossier -> {
					try {
						dossier.setProcessStatusDescription(
								dossiersWorkflowService.getProcessStatusDescription(tenant, dossier.getProcessId(), user));
						// Evaluate amendable status for dossier
						if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(securityContext,
								moduleCrudService.findByCode(tenant, dossier.getModuleCode())
										.map(ModuleDTO::getModuleId)
										.orElseThrow())) {
							dossier.setFlAmendable(false);
						} else {
							dossier.setFlAmendable(isAmendableDossier(tenant, dossier.getDossierId(), dossier.getDossierCode(),
									dossier.getModuleCode()));
						}
					} catch (Exception e) {
						dossier.setProcessStatusDescription("ERROR");
						dossier.setDtClosed(new AbsoluteDate(LocalDate.now()));
					}
				});
		return res;
	}

	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByPartyAndYear(String tenant, Long partyId, Integer year, String nextKey,
			User user, SecurityContext securityContext) {
		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			return new InfiniteListResultsImpl<>();
		}
		var res = dossiersCrudService.find(tenant, securityContext, partyId, year, nextKey);
		if (nextKey == null && res.getRecords().isEmpty()) {
			throw new NoDossiersFoundByPartyAndYearRuntimeException(
					MessageFormat.format("no dossiers found for partyId {0} and year {1}", partyId, year));
		} else {
			res.getRecords().stream()
					.forEachOrdered(dossier -> {
						try {
							dossier.setProcessStatusDescription(
									dossiersWorkflowService.getProcessStatusDescription(tenant, dossier.getProcessId(), user));
							// Evaluate amendable status for dossier
							if(forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(securityContext,
									moduleCrudService.findByCode(tenant, dossier.getModuleCode())
											.map(ModuleDTO::getModuleId)
											.orElseThrow())) {
								dossier.setFlAmendable(false);
							} else {
								dossier.setFlAmendable(isAmendableDossier(tenant, dossier.getDossierId(), dossier.getDossierCode(),
										dossier.getModuleCode()));
							}
						} catch (Exception e) {
							dossier.setProcessStatusDescription("ERROR");
							dossier.setDtClosed(new AbsoluteDate(LocalDate.now()));
						}
					});
			return res;
		}
	}

	public List<DosByPartyAndYearDTO> getDossiersByPartyYearAndModuleCode(String tenant, Long partyId, Integer year, String moduleCode,
			User user) {
		return dossiersCrudService.findWithModuleCode(tenant, partyId, year, moduleCode)
				.stream()
				.map(x -> {
					x.setProcessStatusDescription(dossiersWorkflowService.getProcessStatusDescription(tenant, x.getProcessId(), user));
					return x;
				})
				.collect(Collectors.toList());
	}

	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByModuleCode(String tenant, String moduleCode, String partyCode, Integer year,
			String processStatus, List<Long> dossierIdList, String nextKey, User user) {
		List<Long> partyIds = getPartyIdsByCode(tenant, partyCode, user);

		Long partyId = partyIds.stream().findFirst().orElse(null);

		var partialResult = dossiersCrudService.findInfiniteResults(tenant, moduleCode, partyId, year, processStatus, dossierIdList, nextKey);

		var partialList = partialResult.getRecords();
		var nextNextKey = partialResult.getNextKey();

		return new InfiniteListResultsImpl<>(partialList, nextNextKey);
	}

	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByPartyCode(String tenant, String code, String moduleCode, Integer year,
			String processStatus, String nextKey, User user) {
		List<Long> partyIds = getPartyIdsByCode(tenant, code, user);

		Long partyId = partyIds.stream().findFirst().orElseThrow(PartyNotFoundRuntimeException::new);

		return dossiersCrudService.findInfiniteResults(tenant, moduleCode, partyId, year, processStatus, null, nextKey);
	}

	private List<Long> getPartyIdsByCode(String tenant, String code, User user) {
		if (Optional.ofNullable(code).isEmpty()) {
			return Collections.emptyList();
		}

		return partyService.getPartiesByCodeOrDesc(tenant, -1L /*partyId not required for calling endpoint*/, code, "", user).stream()
				.map(PartyDTO::getPartyId)
				.collect(Collectors.toList());
	}

	public InfiniteListResults<ApplicationProfilePublicDTO> getDossierProfiles(String tenant, Long dossierId, String nextKey, User user) {
		var res = dossierProfilesCrudService.find(tenant, dossierId, nextKey);
		return new InfiniteListResultsImpl<>(res.getRecords()
				.stream()
				.map(DossierProfilePublicMapper.INSTANCE::dtoToPublic)
				.collect(Collectors.toList()),
				res.getNextKey());
	}

	public Map<String, Object> checkForMetadata(String tenant, String dossierCode) {
		return checkForMetadata(tenant, dossiersCrudService.findWithDetailsByDossierCode(tenant, dossierCode));
	}

	public Map<String, Object> checkForMetadata(String tenant, DossierWithDetailsDTO dossier) {
		var module = moduleCrudService.findById(dossier.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
		return dossiersWorkflowService.getNodeMetadata(tenant, module.getWorkflowCode(), dossier.getProcessStatus());
	}

	public Map<String, Object> checkForMetadata(String tenant, String moduleCode, String processStatus) {
		var module = moduleCrudService.findByCode(tenant, moduleCode).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
		return dossiersWorkflowService.getNodeMetadata(tenant, module.getWorkflowCode(), processStatus);
	}

	public boolean isDossierClosed(String tenant, Long dossierId, User user, SecurityContext sc) {
		var dossier = getDossierWithDetailsById(tenant, dossierId, user, sc);
		return dossier.getDtClosed() != null;
	}

	public ReadOnlyDto findReadOnly(String tenant, Long dossierId, Long formConfigId, User user, SecurityContext sc) {
		try {
			boolean readOnlyValue;
			boolean isDossierClosed = this.isDossierClosed(tenant, dossierId, user, sc);
			boolean isDossierInTransition = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId).getFlInTransition() == 1;
			if (isDossierClosed || isDossierInTransition) { // if dossier is closed or in transition: return true for read only status
				readOnlyValue = true;
			} else { // else, if dossier is open, return the value of form
				readOnlyValue = Optional.ofNullable(moduleFormConfigsCrudService.findById(tenant, formConfigId))
						.map(x -> {
							if (x.getForceReadOnlyContextFunction() != null && sc.isUserInRole(x.getForceReadOnlyContextFunction())) {
								x.setFlReadOnly(1); // forcing read only
							}
							return x;
						})
						.map(ModuleFormConfigsDTO::getFlReadOnly)
						.map(x -> x == 1)
						.orElse(true);
			}
			return ReadOnlyDto.builder()
					.readOnly(readOnlyValue)
					.build();
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException("form config not found");
		}
	}

	public InfiniteListResults<ApplicationCompileStatusDTO> findCompileStatus(String tenant, Long dossierId, String nextKey) {
		return dossierCompileStatusCrudService.find(tenant, dossierId, nextKey);
	}

	public ApplicationCompileStatusDTO updateCompileStatus(String tenant, Long dossierId, String compileStatusIdentifier,
			ApplicationCompileStatusPayloadDTO appCompileStatusInput, String username) {
		try {
			dossiersCrudService.findById(tenant, dossierId);
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("Dossier not found");
		}

		ApplicationCompileStatusDTO currentDosCompileStatus;
		try {
			currentDosCompileStatus = dossierCompileStatusCrudService.findByCompileStatusIdentifier(tenant, dossierId, compileStatusIdentifier);
			currentDosCompileStatus.setStatus(appCompileStatusInput.getStatus());
			return dossierCompileStatusCrudService.update(currentDosCompileStatus.getPkid(), currentDosCompileStatus, username);
		} catch (ObjectNotFoundException e) {
			log.info("compile status not found, inserting it");
			ApplicationCompileStatusDTO toInsert = ApplicationCompileStatusDTO.builder()
					.applicationId(dossierId)
					.compileStatusIdentifier(compileStatusIdentifier)
					.status(appCompileStatusInput.getStatus())
					.build();
			return dossierCompileStatusCrudService.insert(toInsert, username);
		}
	}

	public void deleteCompileStatus(String tenant, Long dossierId, String compileStatusIdentifier, String username) throws ObjectNotFoundException {
		try {
			dossiersCrudService.findById(tenant, dossierId);
		} catch (ObjectNotFoundException e) {
			log.error("Dossier not found");
			return;
		}
		try {
			ApplicationCompileStatusDTO currentAppCompileStatus = dossierCompileStatusCrudService
					.findByCompileStatusIdentifier(tenant, dossierId, compileStatusIdentifier);
			dossierCompileStatusCrudService.delete(currentAppCompileStatus.getPkid(), username);
		} catch (Exception e) {
			log.error("error trying to delete compile status");
		}

	}

	public List<DetailedTransitionLog> getDossierHistoryByDossierId(String tenant, Long dossierId, User user) {
		try {
			var dossier = dossiersCrudService.findByIdAlsoExpired(tenant, dossierId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, dossier.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			return dossiersWorkflowService.getProcessTransitionHistory(tenant, dossier.getProcessId(), user);
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(e.getMessage());
		}
	}

	public List<DossierGeneratedPrintDTO> getDossierPrintsByDossierId(String tenant, Long dossierId, User user) {
		try {
			var dossier = dossiersCrudService.findById(tenant, dossierId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, dossier.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			var module = moduleCrudService.findById(dossier.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
			var printList = dossierGeneratedPrintCrudService.findAllGeneratedPrints(tenant, dossierId);
			printList.stream()
					.forEach(x -> x.setProcessStatus(
							dossiersWorkflowService.getWorkflowNode(tenant, module.getWorkflowCode(), x.getProcessStatus()).getDescription()));
			return printList;
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("dossier not found");
		}
	}

	public List<Transition> getAvailableTransitionListByProcessId(String tenant, Long dossierId, User user, String scope) {
		try {
			var dossier = dossiersCrudService.findById(tenant, dossierId);
			conditionallyThrowDossierNotFound(tenant, user, dossier.getPartyId());
			if (forceReadOnlyContextCheckerService.moduleHasReadOnlyAndUserHasIt(user, dossier.getModuleId())) {
				return Collections.emptyList();
			}
			return dossiersWorkflowService.getUserAvailableTransitions(dossier.getProcessId(), user, scope);
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(e.getMessage());
		}
	}

	public DossierInTransitionDTO getDossierInTransition(String tenant, Long dossierId, User user) {
		try {
			var dossier = dossiersCrudService.findByIdAlsoExpired(tenant, dossierId);
			conditionallyThrowDossierNotFound(tenant, user, dossier.getPartyId());
			if (dossier.getProcessId() != null) {
				var dossierDetails = dossierDetailsCrudService.findDossierDetailByIdAlsoExpired(tenant, dossierId);
				var historyLog = this.getDossierHistoryByDossierId(tenant, dossierId, user);
				return DossierInTransitionDTO.builder()
						.inTransition(dossierDetails.getFlInTransition() == 1)
						.lastTransitionLog(historyLog.stream().max(Comparator.comparing(DetailedTransitionLog::getStartDate)).orElse(null))
						.build();
			} else {
				return DossierInTransitionDTO.builder()
						.inTransition(true)
						.build();
			}
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(e.getMessage());
		}
	}

	private void conditionallyThrowDossierNotFound(String tenant, User user, Long partyId) {
		try {
			this.checkPartyService.checkCanReadParty(tenant, partyId, user);
		} catch (ActionNotAuthorizedRuntimeException e) {
			throw new DossierNotFoundRuntimeException("not found");
		}
	}

	public void checkCanReadByDosId(String tenant, Long dossierId, User user) {
		var dossier = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
		this.checkCanRead(tenant, dossier.getPartyId(), user);
	}

	public void checkCanRead(String tenant, Long partyId, User user) {
		this.checkPartyService.checkCanReadParty(tenant, partyId, user);
	}

	public List<ModuleWithDetailDTO> getModules(String tenant, SecurityContext sc) {
		List<ModuleWithDetailDTO> allModules = this.moduleCrudService.findAllModulesWithDetail(tenant);
		return allModules.stream()
				.filter(x -> verifyContextFunction(sc, x.getContextFunction()))
				.collect(Collectors.toList());
	}

	private Transition findTransitionByProcessIdAndTransitionId(String tenant, User user, Long processId, String scope, Integer transitionId) {
		log.info("Searching transition by processId: {}", processId);
		return dossiersWorkflowService.getUserAvailableTransitions(processId, user, scope)
				.stream()
				.filter(t -> t.getId().equals(transitionId))
				.findFirst()
				.orElseThrow(NoTransitionFoundRuntimeException::new);
	}

	public void progress(String tenant, Long dossierId, String tagName, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType) throws ObjectNotFoundException {
		var dossier = dossiersCrudService.findById(tenant, dossierId);
		conditionallyThrowDossierNotFound(tenant, user, dossier.getPartyId());
		progressService.progress(tenant, dossierId, tagName, user, scope, progressDossierDTO, progressType);
	}

	public void progress(String tenant, Long dossierId, Integer transitionId, User user, String scope, ProgressDossierDTO progressDossierDTO,
			ProgressTypeEnum progressType) throws Exception {
		var dossier = dossiersCrudService.findById(tenant, dossierId);
		conditionallyThrowDossierNotFound(tenant, user, dossier.getPartyId());
		jdbi.useTransaction(handle -> {
			progressService.progress(tenant, dossierId, transitionId, user, scope, progressDossierDTO, progressType);
		});
	}

	public List<DossierGeneratedPrintDTO> checkForOngoingPrints(String tenant, Long dossierId, List<String> printCodeList) {
		return printCodeList.stream()
				.map(printCode -> this.dossierGeneratedPrintCrudService.findOngoingPrintByCode(tenant, dossierId, printCode))
				.flatMap(Collection::stream)
				.collect(Collectors.toList());
	}

	public ModuleWithParamsPublicDTO getModuleFormConfigsByModuleCode(String tenant, String moduleCode) {
		return formConfigService.findModuleFormConfigsByModuleCode(tenant, moduleCode);
	}

	private boolean verifyContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isAllBlank(contextFunction) || Optional.ofNullable(sc)
				.map(xsc -> xsc.isUserInRole(contextFunction))
				.orElse(true);
	}

	private boolean verifyForceReadOnlyContextFunction(SecurityContext sc, String contextFunction) {
		return StringUtils.isAllBlank(contextFunction) ||
				Optional.ofNullable(sc)
						.map(xsc -> !xsc.isUserInRole(contextFunction)) // if user has read only context function then it returns false
						.orElse(true);
	}
}
