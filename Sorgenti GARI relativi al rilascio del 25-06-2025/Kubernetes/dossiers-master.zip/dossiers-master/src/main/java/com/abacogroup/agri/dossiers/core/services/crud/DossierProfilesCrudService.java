package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierProfileMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.DossierProfileDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProfileNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierProfilesCrudService
		extends AbstractHistoricizationFieldsCrudService<DossierProfileNTT, Long, DossierProfileDTO, DossierProfileMapper, Void> {

	public static final String I18N_DOSSIER_PROFILES_TABLE = "doss_dossiers_profiles";
	private final I18NService i18NService;

	public DossierProfilesCrudService(DossierProfileDAO dao, DossierProfileMapper mapper,
									  I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(DossierProfileNTT rs) {
		return null;
	}

	@Override protected DossierProfileNTT adjustR(DossierProfileNTT rs) throws Exception {
		return rs;
	}

	@Override protected Optional<DossierProfileNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public DossierProfileDTO insert(DossierProfileDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public DossierProfileDTO update(Long key, DossierProfileDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public void insertModuleI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_DOSSIER_PROFILES_TABLE, DOSSIER_PROFILES_I18N.DESCRIPTION.code, lang, code, description);
	}

	public DossierProfileDTO findById(Long id) throws ObjectNotFoundException {
		log.info("Invoking find by  with params key: {}", id);
		return this.findOutDtoByPrimaryKey(id);
	}

	public void bulkLogicallyDeleteByDossierCode(String tenant, String dossierCode, String username) {
		log.info("Invoking bulk delete with params tenant: {} dossierCode: {} username: {}", tenant, dossierCode, username);
		((DossierProfileDAO) this.dao).bulkLogicallyDeleteByDossierCode(tenant, dossierCode, username);
	}

	public void bulkLogicallyDeleteByDossierId(String tenant, Long dossierId, String username) {
		log.info("Invoking bulk delete with params tenant: {} dossierId: {} username: {}", tenant, dossierId, username);
		((DossierProfileDAO) this.dao).bulkLogicallyDeleteByDossierId(tenant, dossierId, username);
	}

	public enum DOSSIER_PROFILES_I18N {
		DESCRIPTION("description");

		private final String code;

		DOSSIER_PROFILES_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

	/**
	 * get all profiles by dossier code
	 *
	 * @param tenant          current tenant
	 * @param dossierCode the dossier's code
	 * @return the profiles list
	 */
	public List<DossierProfileDTO> find(String tenant, String dossierCode) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} dossierCode: {}", tenant, dossierCode);
		return returnMappedList(((DossierProfileDAO) this.dao).find(tenant, dossierCode, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<DossierProfileDTO> findByUnique(String tenant, Long dossierId, String profileCode) {
		return returnOptionalRecord(((DossierProfileDAO) this.dao).findByUnique(tenant, dossierId, profileCode));
	}

	/**
	 * get all profiles by dossier id
	 *
	 * @param tenant        current tenant
	 * @param dossierId the dossier's id
	 * @return the profiles list
	 */
	public List<DossierProfileDTO> find(String tenant, Long dossierId) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} dossierId: {}", tenant, dossierId);
		return returnMappedList(((DossierProfileDAO) this.dao).find(tenant, dossierId));
	}

	/**
	 * get all profiles by dossier id
	 *
	 * @param tenant        current tenant
	 * @param dossierId the dossier's id
	 * @param locale        the locale
	 * @return the profiles list
	 */
	public List<DossierProfileDTO> findAll(String tenant, Long dossierId, String locale) {
		log.info("Invoking findCategoryByTenantAndCode with params tenant: {} dossierId: {}", tenant, dossierId);
		return returnMappedList(((DossierProfileDAO) this.dao).find(tenant, dossierId, locale));
	}

	/**
	 * get profiles by dossier code
	 *
	 * @param tenant          current tenant
	 * @param dossierCode the dossier's code
	 * @param nextKey         the nextKey
	 * @return the profiles list
	 */
	public InfiniteListResults<DossierProfileDTO> find(String tenant, String dossierCode, String nextKey) {
		log.info("Invoking find with params tenant: {} dossierCode: {}", tenant, dossierCode);
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierProfileDAO) this.dao).findInfinite(tenant, dossierCode, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				mapper::entityToDto);
	}

	/**
	 * get profiles by dossier id
	 *
	 * @param tenant        current tenant
	 * @param dossierId the dossier's id
	 * @param nextKey       the nextKey
	 * @return the profiles list
	 */
	public InfiniteListResults<DossierProfileDTO> find(String tenant, Long dossierId, String nextKey) {
		log.info("Invoking find with params tenant: {} dossierId: {}", tenant, dossierId);
		return returnInfiniteResults(
				this.dao.infinite(() -> ((DossierProfileDAO) this.dao).findInfinite(tenant, dossierId, MDC.get(MDCPreFilter.LOCALE)),
						nextKey,
						DEFAULT_PAGE_SIZE
				),
				mapper::entityToDto);
	}
}
