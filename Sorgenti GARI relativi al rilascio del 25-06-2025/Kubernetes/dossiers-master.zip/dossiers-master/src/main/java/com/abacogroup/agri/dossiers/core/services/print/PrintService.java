package com.abacogroup.agri.dossiers.core.services.print;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.abacogroup.agri.dossiers.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.services.CheckPartyService;
import com.abacogroup.agri.dossiers.core.services.ForceReadOnlyContextCheckerService;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.mappers.PrintDetailsOutMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.LastPrintDTO;

import com.abacogroup.agri.dossiers.core.caller.CreatePrintJobCaller;
import com.abacogroup.agri.dossiers.core.caller.CreatePrintJobInput;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.PrintDetailsOutDTO;
import com.abacogroup.agri.dossiers.core.services.FileStoreService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.client.auth.Sso2Authenticator;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class PrintService {

	private final DossiersCrudService dossiersCrudService;
	private final CheckPartyService checkPartyService;
	private final ModuleCrudService moduleCrudService;
	private final DossiersWorkflowService dossiersWorkflowService;
	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;
	private final CreatePrintJobCaller createPrintJobCaller;
	private final FileStoreService fileStoreService;
	private final String printBucketName;
	private final String printEngineUrl;
	private final ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService;

	public static final String PRINT_DESTINATION = "dossiers-prints-destination";

	public PrintService(DossiersCrudService dossiersCrudService,
                        CheckPartyService checkPartyService, ModuleCrudService moduleCrudService,
                        DossiersWorkflowService dossiersWorkflowService,
                        ModulePrintConfigsCrudService modulePrintConfigsCrudService,
                        ModulePrintConfigParamCrudService modulePrintConfigParamCrudService,
                        DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService,
                        CreatePrintJobCaller createPrintJobCaller,
                        FileStoreService fileStoreService,
                        String printBucketName,
                        String printEngineUrl, ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService) {
		this.dossiersCrudService = dossiersCrudService;
		this.checkPartyService = checkPartyService;
		this.moduleCrudService = moduleCrudService;
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.modulePrintConfigsCrudService = modulePrintConfigsCrudService;
		this.modulePrintConfigParamCrudService = modulePrintConfigParamCrudService;
		this.dossierGeneratedPrintCrudService = dossierGeneratedPrintCrudService;
		this.createPrintJobCaller = createPrintJobCaller;
		this.fileStoreService = fileStoreService;
		this.printBucketName = printBucketName;
		this.printEngineUrl = printEngineUrl;
        this.forceReadOnlyContextCheckerService = forceReadOnlyContextCheckerService;
    }

	public DossierGeneratedPrintDTO startPrintJob(String tenant, Long dossierId, Long partyId, String processStatus,
			List<PrintDetailsOutDTO> modulesPrint, String printCode, User user) {
		return this.startPrintJob(tenant, dossierId, partyId, processStatus, modulesPrint, printCode, user, MDC.get(MDCPreFilter.LOCALE));
	}

	public DossierGeneratedPrintDTO startPrintJob(String tenant, Long dossierId, Long partyId, String processStatus,
			List<PrintDetailsOutDTO> modulesPrint,
			String printCode, User user, String locale) {
		forceReadOnlyContextCheckerService.checkForReadOnlyContextFunctionByApplicationId(user, dossierId);
		if (modulesPrint.stream().noneMatch(x -> x.getPrintCode().equals(printCode))) {
			throw new RuntimeException("print code not valid");
		}
		try {
			var uuid = createPrintJobCaller.makeCall(CreatePrintJobInput.builder()
					.url(this.printEngineUrl)
					.bucketName(this.printBucketName)
					.destination(PRINT_DESTINATION)
					.printCode(printCode)
					.tenant(tenant)
					.token("JWT " + user.getAuthToken())
					.locale(locale)
					.params(Map.of("dossierId", dossierId,"partyId", partyId))
					.build());
			return dossierGeneratedPrintCrudService.insert(DossierGeneratedPrintDTO.builder()
					.dossierId(dossierId)
					.printCode(printCode)
					.printDate(LocalDateTime.now())
					.processStatus(processStatus)
					.printJobUuid(uuid.getUuid())
					.username(user.getName())
					.build());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw e;
		}

	}

	public Response getPrintFromFileStore(String tenant, Long dossierId, String fileId, User user) {
		if (dossierGeneratedPrintCrudService.findPrintByDossierIdAndFileId(tenant, dossierId, fileId).isPresent()) {
			return this.fileStoreService.getFileForDownload(tenant, fileId, this.printBucketName, user, new Sso2Authenticator(user));
		} else {
			throw new ObjectNotFoundRuntimeException("print not found");
		}
	}

	public List<PrintDetailsOutDTO> getPrintsByModuleIdAndProcessStatus(String tenant, Long dossierId, Long moduleId, String processStatus,
			List<String> profileCodeList, SecurityContext sc) {

		return modulePrintConfigsCrudService
				.find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || sc.isUserInRole(x.getContextFunction()))
				.map(PrintDetailsOutMapper.INSTANCE::toPublicDTO)
				.map(x -> {
					x.setParams(modulePrintConfigParamCrudService.find(tenant, x.getPrintConfigId())
							.stream()
							.collect(Collectors
									.toMap(ModulePrintConfigParamDTO::getParameterName,
											ModulePrintConfigParamDTO::getParameterValue)));
					var lastPrint = dossierGeneratedPrintCrudService.findLastGeneratedPrintByCode(tenant, dossierId, x.getPrintCode());
					lastPrint.ifPresent(y -> x.setLastPrint(LastPrintDTO.builder()
							.printDate(y.getPrintDate())
							.fileId(y.getFileId())
							.build()));

					return x;
				})
				.collect(Collectors.toList());
	}

	public List<DossierGeneratedPrintDTO> getDossierPrintsByDossierId(String tenant, Long applicationId, User user) {
		try {
			var application = dossiersCrudService.findById(tenant, applicationId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			var module = moduleCrudService.findById(application.getModuleId()).orElseThrow(() -> new ObjectNotFoundRuntimeException("module not found"));
			var printList = dossierGeneratedPrintCrudService.findAllGeneratedPrints(tenant, applicationId);
			printList.stream()
					.forEach(x -> x.setProcessStatus(
							dossiersWorkflowService.getWorkflowNode(tenant, module.getWorkflowCode(), x.getProcessStatus()).getDescription()));
			return printList;
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("application not found");
		}
	}

}
