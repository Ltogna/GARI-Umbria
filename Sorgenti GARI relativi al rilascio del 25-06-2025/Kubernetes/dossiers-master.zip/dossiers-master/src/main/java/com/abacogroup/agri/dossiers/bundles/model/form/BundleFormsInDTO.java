package com.abacogroup.agri.dossiers.bundles.model.form;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleFormsInDTO {
	private List<BundleFormCatalogInDTO> formCatalogs;
	private List<BundleFormGroupInDTO> formGroups;
	private List<BundleModuleFormConfigsInDTO> moduleFormConfigs;
}
