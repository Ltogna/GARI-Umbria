package com.abacogroup.agri.dossiers.bundles.processor.module;

import com.abacogroup.agri.dossiers.bundles.BundleConstants;
import com.abacogroup.agri.dossiers.bundles.model.form.*;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModulesBundleWorker {

	protected final ModuleCrudService moduleCrudService;
	private final SectorsCrudService sectorsCrudService;
	private final ModuleDetailsCrudService moduleDetailsCrudService;

	private final FormCatalogsCrudService formCatalogsCrudService;
	private final FormGroupsCrudService formGroupsCrudService;
	private final ModuleFormConfigsCrudService moduleFormConfigsCrudService;
	private final ModuleFormConfigParamCrudService moduleFormConfigParamCrudService;
	private final ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService;

	private final ModulePrintConfigsCrudService modulePrintConfigsCrudService;
	private final ModulePrintConfigParamCrudService modulePrintConfigParamCrudService;
	private final ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService;

	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final FormConfigService formConfigService;

	public ModulesBundleWorker(ModuleCrudService moduleCrudService,
			ModuleDetailsCrudService moduleDetailsCrudService,
			SectorsCrudService sectorsCrudService, FormCatalogsCrudService formCatalogsCrudService,
			FormGroupsCrudService formGroupsCrudService, ModuleFormConfigsCrudService moduleFormConfigsCrudService,
			ModuleFormConfigParamCrudService moduleFormConfigParamCrudService,
			ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService,
			ModulePrintConfigsCrudService modulePrintConfigsCrudService,
			ModulePrintConfigParamCrudService modulePrintConfigParamCrudService,
			ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService,
			ModuleProfilesCrudService moduleProfilesCrudService, FormConfigService formConfigService) {
		this.moduleCrudService = moduleCrudService;
		this.moduleDetailsCrudService = moduleDetailsCrudService;
		this.sectorsCrudService = sectorsCrudService;
		this.formCatalogsCrudService = formCatalogsCrudService;
		this.formGroupsCrudService = formGroupsCrudService;
		this.moduleFormConfigsCrudService = moduleFormConfigsCrudService;
		this.moduleFormConfigParamCrudService = moduleFormConfigParamCrudService;
		this.moduleFormConfigProfilesCrudService = moduleFormConfigProfilesCrudService;
		this.modulePrintConfigsCrudService = modulePrintConfigsCrudService;
		this.modulePrintConfigParamCrudService = modulePrintConfigParamCrudService;
		this.modulePrintConfigProfilesCrudService = modulePrintConfigProfilesCrudService;
		this.moduleProfilesCrudService = moduleProfilesCrudService;
		this.formConfigService = formConfigService;
	}

	public SectorsCrudService exposeSectorsCrudService() {
		return this.sectorsCrudService;
	}

	public ModuleCrudService exposeModuleCrudService() {
		return this.moduleCrudService;
	}

	public FormCatalogsCrudService exposeFormCatalogsCrudService() {
		return this.formCatalogsCrudService;
	}

	public FormGroupsCrudService exposeFormGroupsCrudService() {
		return this.formGroupsCrudService;
	}

	public ModuleFormConfigsCrudService exposeModuleFormConfigsCrudService() {
		return this.moduleFormConfigsCrudService;
	}

	public ModuleFormConfigParamCrudService exposeModuleFormConfigParamCrudService() {
		return this.moduleFormConfigParamCrudService;
	}

	public ModuleFormConfigProfilesCrudService exposeModuleFormConfigProfilesCrudService() {
		return this.moduleFormConfigProfilesCrudService;
	}

	public ModuleProfilesCrudService exposeModuleProfilesCrudService() {
		return this.moduleProfilesCrudService;
	}

	public ModulePrintConfigsCrudService exposeModulePrintConfigsCrudService() {
		return this.modulePrintConfigsCrudService;
	}

	public ModulePrintConfigParamCrudService exposeModulePrintConfigParamCrudService() {
		return this.modulePrintConfigParamCrudService;
	}

	public ModulePrintConfigProfilesCrudService exposeModulePrintConfigProfilesCrudService() {
		return this.modulePrintConfigProfilesCrudService;
	}

	public void insertBundleModules(String tenantId, BundleModulesMessage message) {
		log.info("ModulesBundleWorker: processing file with tenant {}", tenantId);
		message.getModules()
				.stream()
				.forEachOrdered(module -> {
					this.insertOrUpdateModule(tenantId, module);
				});
	}

	private void insertOrUpdateModule(String tenantId, BundleModuleInDTO bundleModuleInDTO) {
		log.info("ModulesBundleWorker: inserting module with tenant {} and code {}", tenantId, bundleModuleInDTO.getModuleCode());
		ModuleDTO module = this.insertModule(tenantId, bundleModuleInDTO);
		this.upsertModuleDetail(tenantId, bundleModuleInDTO, module.getModuleId());
		this.upsertModuleProfile(tenantId, bundleModuleInDTO, module.getModuleId());
		this.deleteOldConfigAndPrints(tenantId, module.getModuleId());
		this.upsertForms(tenantId, bundleModuleInDTO.getForms(), module.getModuleId());
		this.upsertPrints(tenantId, bundleModuleInDTO.getModulePrints(), module.getModuleId());
	}

	private void deleteOldConfigAndPrints(String tenantId, Long moduleId) {
		try {
			log.info("deleting old config params");
			modulePrintConfigsCrudService.findAllModulePrintConfigs(tenantId, moduleId)
					.forEach(x -> {
						modulePrintConfigParamCrudService.deleteByModulePrintConfigId(x.getId());
						modulePrintConfigProfilesCrudService.deleteByModulePrintConfigId(x.getId());
						modulePrintConfigsCrudService.delete(x.getId());
					});
			moduleFormConfigsCrudService.findAllModuleFormConfigs(tenantId, moduleId)
					.forEach(x -> {
						moduleFormConfigParamCrudService.deleteByModuleFormConfigId(x.getId());
						moduleFormConfigProfilesCrudService.deleteByModuleFormConfigId(x.getId());
						moduleFormConfigsCrudService.delete(x.getId());
					});
		} catch (Exception e) {
			log.error("error deleting ");
		}
	}

	private void upsertPrints(String tenantId, List<BundleModulePrintInDTO> modulePrintConfigs, Long moduleId) {
		log.info("Invoking upsertModulePrintConfigs with params tenantId: {} modulePrintConfigs: {} createModuleId: {}", tenantId,
				modulePrintConfigs, moduleId);
		Optional.ofNullable(modulePrintConfigs)
				.ifPresent(mfc -> mfc
						.stream()
						.forEachOrdered(modulePrintConfig -> {
							if (modulePrintConfig.getProcessStatus() != null && (modulePrintConfig.getProcessStatusList() != null && !modulePrintConfig
									.getProcessStatusList().isEmpty())) {
								throw new IllegalStateException("invalid input: cannot be present at same time process status and process status list!");
							}
							List<String> processStatusToUse = new ArrayList<>();
							if (modulePrintConfig.getProcessStatus() != null) {
								processStatusToUse.add(modulePrintConfig.getProcessStatus());
							} else {
								processStatusToUse.addAll(modulePrintConfig.getProcessStatusList());
							}
							for (String currentProcessStatus : processStatusToUse) {
								ModulePrintConfigsDTO placeHolder;
								var bundleEntity = ModulePrintConfigsDTO.builder()
										.moduleId(moduleId)
										.printCode(modulePrintConfig.getPrintCode())
										.processStatus(currentProcessStatus)
										.sortOrder(modulePrintConfig.getSortOrder())
										.contextFunction(modulePrintConfig.getContextFunction())
										.build();
								var existentPrintsConfig = modulePrintConfigsCrudService.find(tenantId, moduleId,
										modulePrintConfig.getPrintCode(), currentProcessStatus)
										.orElse(null);

								boolean checkForProfiles = formConfigService.checkForModulePrintConfigProfiles(tenantId, existentPrintsConfig, modulePrintConfig.getRequiredProfiles());

								if (Optional.ofNullable(existentPrintsConfig).isPresent() && checkForProfiles) {
									placeHolder = modulePrintConfigsCrudService.update(existentPrintsConfig.getId(), bundleEntity);
								} else {
									//Creating new instance for ModuleFormConfigs
									placeHolder = modulePrintConfigsCrudService.insert(bundleEntity);
								}
								this.insertOrUpdateModulePrintConfigParams(modulePrintConfig.getParams(), placeHolder.getId());
								this.insertOrUpdatePrintConfigProfiles(modulePrintConfig.getRequiredProfiles(), placeHolder.getId());
								Optional.ofNullable(modulePrintConfig.getI18n())
										.ifPresent(i18n -> i18n
												.stream()
												.forEachOrdered(val -> {
													modulePrintConfigsCrudService
															.deletePrintCodeI18N(tenantId, modulePrintConfig.getPrintCode(), val.getLang());
													modulePrintConfigsCrudService.insertPrintCodeI18N(tenantId,
															modulePrintConfig.getPrintCode(),
															val.getLang(),
															val.getDescription());
												}));
							}
						}));
	}

	private void upsertForms(String tenantId, BundleFormsInDTO forms, Long moduleId) {
		log.info("upsertForms: insertForms with tenant: {} forms: {} createdModuleId: {}", tenantId, forms, moduleId);
		// FORM-CATALOGS
		this.upsertFormCatalogs(tenantId, forms.getFormCatalogs());
		// FORM-GROUPS
		this.upsertRecursiveFormGroups(tenantId, forms.getFormGroups(), null);
		// MODULE-FORM-CONFIG and PROFILES related
		this.upsertModuleFormConfigs(tenantId, forms.getModuleFormConfigs(), moduleId);
	}

	private ModuleDTO insertModule(String tenantId, BundleModuleInDTO module) {
		log.info("Invoking insertOrUpdateModuleWithDetail with params tenantId: {} module: {}", tenantId, module);
		try {
			Optional<ModuleDTO> existingModule = moduleCrudService.findByModuleCodeAndSectorCode(tenantId, module.getModuleCode(), module.getSectorCode());
			log.info("insertModule: existingModule: {}", existingModule);

			log.info("ModulesBundleWorker: inserting i18n with tenant {} and code {}", tenantId, module.getSectorCode());
			module.getI18n()
					.stream()
					.forEachOrdered(val ->
					{
						existingModule.ifPresent(moduleDTO -> moduleCrudService.deleteModuleI18N(tenantId, module.getModuleCode(), val.getLang()));
						moduleCrudService.insertModuleI18N(tenantId,
								module.getModuleCode(),
								val.getLang(),
								val.getDescription());
					});

			if (existingModule.isEmpty()) {
				return moduleCrudService.insert(ModuleDTO.builder()
						.moduleCode(module.getModuleCode())
						.workflowCode(module.getWorkflowCode())
						.sectorId(sectorsCrudService.findSectorByCode(tenantId, module.getSectorCode()).getSectorId())
                        .flAmendModule(Optional.ofNullable(module.getFlAmendModule()).orElse(false))
                        .build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			} else {
				var mod = existingModule.get();
				moduleCrudService.updateWorkflwoCode(mod.getModuleId(), mod.getWorkflowCode());
				return mod;
			}

		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(e.getMessage());
		}
	}

	private void upsertModuleDetail(String tenantId, BundleModuleInDTO module, Long moduleId) {

		ModuleDetailsDTO existingModuleDetail = moduleDetailsCrudService.findByModuleId(tenantId, moduleId);
		if (Optional.ofNullable(existingModuleDetail).isPresent()) {
			moduleDetailsCrudService.update(existingModuleDetail.getPkid(),
					ModuleDetailsDTO.builder()
							.moduleId(moduleId)
							.annuality(module.getAnnuality())
							.contextFunction(module.getContextFunction())
							.forceReadOnlyContextFunction(module.getForceReadOnlyContextFunction())
							.dtValidityStart(module.getDtValidityStart())
							.dtValidityEnd(module.getDtValidityEnd())
							.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
		} else {
			moduleDetailsCrudService.insert(ModuleDetailsDTO.builder()
					.moduleId(moduleId)
					.annuality(module.getAnnuality())
					.contextFunction(module.getContextFunction())
					.forceReadOnlyContextFunction(module.getForceReadOnlyContextFunction())
					.dtValidityStart(module.getDtValidityStart())
					.dtValidityEnd(module.getDtValidityEnd())
					.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
		}

	}

	private void upsertModuleProfile(String tenantId, BundleModuleInDTO module, Long moduleId) {
		Optional.ofNullable(module.getModuleProfiles()).ifPresent(rpc -> rpc.forEach(profile -> {
			ModuleProfileDTO existingModuleProfile = moduleProfilesCrudService.find(tenantId, moduleId, profile.getPrfCode());

			if (Optional.ofNullable(existingModuleProfile).isEmpty()) {
				moduleProfilesCrudService.insert(ModuleProfileDTO.builder()
						.moduleId(moduleId)
						.profileCode(profile.getPrfCode())
						.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			} else {
				moduleProfilesCrudService.update(existingModuleProfile.getPkid(), ModuleProfileDTO.builder()
						.moduleId(moduleId)
						.profileCode(profile.getPrfCode())
						.build(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
			}

			profile.getI18n()
					.stream()
					.forEachOrdered(val -> {
						Optional.ofNullable(existingModuleProfile).ifPresent(f -> {
							moduleProfilesCrudService.deleteModuleProfileI18N(tenantId, f.getProfileCode(), val.getLang());
						});
						if (!moduleProfilesCrudService.verifyI18NIsPresent(tenantId, profile.getPrfCode(), val.getLang(), val.getDescription())) {
							moduleProfilesCrudService.insertModuleProfileI18N(tenantId,
									profile.getPrfCode(),
									val.getLang(),
									val.getDescription());
						} else {
							log.warn("translation was already present");
						}

					});
		}));
	}

	private void upsertFormCatalogs(String tenantId, List<BundleFormCatalogInDTO> formCatalogs) {
		log.info("Invoking upsertFormCatalogs with params tenantId: {} formCatalogs: {}", tenantId, formCatalogs);
		Optional.ofNullable(formCatalogs)
				.ifPresent(fc -> fc.stream().forEachOrdered(formCatalog -> {
					FormCatalogDTO existingFormCatalog = formCatalogsCrudService.findByCodeNullable(tenantId, formCatalog.getFormCode());
					if (Optional.ofNullable(existingFormCatalog).isPresent()) {
						formCatalogsCrudService.update(existingFormCatalog.getId(), FormCatalogDTO
								.builder()
								.formCode(formCatalog.getFormCode())
								.softwareUrl(formCatalog.getSoftwareUrl())
								.routerUrl(formCatalog.getRouterUrl())
								.tenantId(tenantId)
								.build());
					} else {
						formCatalogsCrudService.insert(FormCatalogDTO.builder()
								.tenantId(tenantId)
								.formCode(formCatalog.getFormCode())
								.softwareUrl(formCatalog.getSoftwareUrl())
								.routerUrl(formCatalog.getRouterUrl())
								.build());
					}

					Optional.ofNullable(formCatalog.getI18n())
							.ifPresent(i18n -> i18n
									.stream()
									.forEachOrdered(val -> {
										Optional.ofNullable(existingFormCatalog).ifPresent(
												formCatalogI18n -> formCatalogsCrudService.deleteFormCatalogI18N(tenantId, formCatalog.getFormCode(),
														val.getLang()));
										formCatalogsCrudService.insertFormCatalogI18N(tenantId,
												formCatalog.getFormCode(),
												val.getLang(),
												val.getDescription());
									}));
				}));
	}

	/*
	 * Creating recursively new instances for FormGroups following a tree-like hierarchy:
	 * Basic case: the node does not have any childs (formGroupChilds)
	 * Inductive case: calling insertRecursiveFormGroups with the current tenantId,
	 * 					node's formGroupChilds and the newly created form group's id as parentId
	 */
	private void upsertRecursiveFormGroups(String tenantId, List<BundleFormGroupInDTO> formGroups, Long parentGroupId) {
		log.info("ModulesBundleWorker: upsertRecursiveFormGroups with tenant {} and formGroups {} parentGroupId: {}", tenantId, formGroups,
				parentGroupId);
		if (Optional.ofNullable(formGroups).isPresent()) {
			formGroups
					.stream()
					.forEachOrdered(formGroup -> {
						Long newParentGroupId;
						FormGroupDTO existingFormGroup = formGroupsCrudService.findFormGroupByCodeNullable(tenantId, formGroup.getFormGroupCode());
						if (Optional.ofNullable(existingFormGroup).isPresent()) {
							formGroupsCrudService.update(existingFormGroup.getId(), FormGroupDTO.builder()
									.tenantId(tenantId)
									.formGroupCode(existingFormGroup.getFormGroupCode())
									.parentFormGroupId(parentGroupId)
									.build());
							newParentGroupId = existingFormGroup.getId();
						} else {
							FormGroupDTO createdFormGroup = formGroupsCrudService.insert(FormGroupDTO.builder()
									.tenantId(tenantId)
									.formGroupCode(formGroup.getFormGroupCode())
									.parentFormGroupId(parentGroupId)
									.build());
							newParentGroupId = createdFormGroup.getId();

						}
						formGroup.getI18n()
								.stream()
								.forEachOrdered(val -> {
									Optional.ofNullable(existingFormGroup).ifPresent(f -> {
										formGroupsCrudService.deleteFormGroupI18N(tenantId, f.getFormGroupCode(), val.getLang());
									});
									formGroupsCrudService.insertFormGroupI18N(tenantId,
											formGroup.getFormGroupCode(),
											val.getLang(),
											val.getDescription());
								});
						this.upsertRecursiveFormGroups(tenantId, formGroup.getFormGroupChildren(), newParentGroupId);
					});
		}
	}

	private void upsertModuleFormConfigs(String tenantId, List<BundleModuleFormConfigsInDTO> moduleFormConfigs, Long moduleId) {
		log.info("Invoking upsertModuleFormConfigs with params tenantId: {} moduleFormConfigs: {} createModuleId: {}", tenantId,
				moduleFormConfigs, moduleId);
		Optional.ofNullable(moduleFormConfigs)
				.ifPresent(mfc -> mfc
						.stream().forEachOrdered(moduleFormConfig -> {
							try {
								if (moduleFormConfig.getProcessStatus() != null && (moduleFormConfig.getProcessStatusList() != null && !moduleFormConfig
										.getProcessStatusList().isEmpty())) {
									throw new IllegalStateException("invalid input: cannot be present at same time process status and process status list!");
								}
								List<String> processStatusToUse = new ArrayList<>();
								if (moduleFormConfig.getProcessStatus() != null) {
									processStatusToUse.add(moduleFormConfig.getProcessStatus());
								} else {
									processStatusToUse.addAll(moduleFormConfig.getProcessStatusList());
								}
								insertOrUpdateModuleFormConfigs(tenantId, moduleId, moduleFormConfig, processStatusToUse);

							} catch (ObjectNotFoundException e) {
								throw new ObjectNotFoundRuntimeException(e.getMessage());
							}
						}));
	}

	private void insertOrUpdateModuleFormConfigs(String tenantId, Long moduleId, BundleModuleFormConfigsInDTO moduleFormConfig, List<String> processStatusToUse)
			throws ObjectNotFoundException {
		List<String> contextFunctionList = new ArrayList<>();
		if(moduleFormConfig.getContextFunctionList() != null && !moduleFormConfig.getContextFunctionList().isEmpty()) {
			log.info("context function list is not empty: will loop nxm by process status and context function");
			contextFunctionList.addAll(moduleFormConfig.getContextFunctionList());
			if(moduleFormConfig.getContextFunction() != null) {
				throw new IllegalStateException("both context function and context function list are present!");
			}
		}
		for (String currentProcessStatus : processStatusToUse) {
			if(!contextFunctionList.isEmpty()) {
				for (String currentContextFunction: moduleFormConfig.getContextFunctionList()) {
					moduleFormConfig.setContextFunction(currentContextFunction);
					upsertSingleModuleFormConfig(tenantId, moduleId, moduleFormConfig, currentProcessStatus);
				}
			} else {
				upsertSingleModuleFormConfig(tenantId, moduleId, moduleFormConfig, currentProcessStatus);
			}
		}
	}

	private void upsertSingleModuleFormConfig(String tenantId, Long moduleId, BundleModuleFormConfigsInDTO moduleFormConfig, String currentProcessStatus) throws ObjectNotFoundException {
		var formId = formCatalogsCrudService.findByCode(tenantId, moduleFormConfig.getFormCode()).getId();
		var formGroupId = formGroupsCrudService.findFormGroupByCode(tenantId, moduleFormConfig.getFormGroupCode()).getId();
		var bundleEntity = ModuleFormConfigsDTO.builder()
				.formId(formId)
				.formGroupId(formGroupId)
				.moduleId(moduleId)
				.processStatus(currentProcessStatus)
				.sortOrder(moduleFormConfig.getSortOrder())
				.flReadOnly(moduleFormConfig.getFlReadOnly())
				.compileStatusIdentifier(moduleFormConfig.getCompileStatusIdentifier())
				.contextFunction(moduleFormConfig.getContextFunction())
				.forceReadOnlyContextFunction(moduleFormConfig.getForceReadOnlyContextFunction())
				.build();

		ModuleFormConfigsDTO placeHolderToUse = moduleFormConfigsCrudService.insert(bundleEntity);

		//Creating new instances for ModuleFormConfigsParams
		this.insertOrUpdateModuleFormConfigParams(moduleFormConfig.getParams(), placeHolderToUse.getId());
		//Creating new instances for ModuleConfigProfiles
		this.insertOrUpdateModuleConfigProfiles(moduleFormConfig.getRequiredProfiles(), placeHolderToUse.getId());
	}

	private void insertOrUpdateModulePrintConfigParams(Map<String, String> params, Long modulePrintConfigId) {
		log.info("Invoking insertOrUpdateModulePrintConfigParams with params: {} modulePrintConfigId: {}", params, modulePrintConfigId);

		modulePrintConfigParamCrudService.deleteByModulePrintConfigId(modulePrintConfigId);
		Optional.ofNullable(params)
				.ifPresent(map -> map.forEach((key, value) -> modulePrintConfigParamCrudService.insert(ModulePrintConfigParamDTO.builder()
						.modulePrintConfigId(modulePrintConfigId)
						.parameterName(key)
						.parameterValue(value)
						.build())));
	}

	private void insertOrUpdateModuleFormConfigParams(Map<String, String> params, Long createdModuleFormConfigId) {
		log.info("Invoking insertOrUpdateModuleFormConfigParams with params: {} createdModuleFormConfigId: {}", params, createdModuleFormConfigId);

		moduleFormConfigParamCrudService.deleteByModuleFormConfigId(createdModuleFormConfigId);
		Optional.ofNullable(params)
				.ifPresent(map -> map.forEach((key, value) -> moduleFormConfigParamCrudService.insert(ModuleFormConfigParamDTO.builder()
						.moduleFormConfigId(createdModuleFormConfigId)
						.parameterName(key)
						.parameterValue(value)
						.build())));
	}

	private void insertOrUpdatePrintConfigProfiles(List<String> requiredProfiles, Long modulePrintConfigId) {
		log.info("Invoking insertOrUpdatePrintConfigProfiles with params requiredProfiles: {} modulePrintConfigId: {}", requiredProfiles,
				modulePrintConfigId);
		Optional.ofNullable(requiredProfiles).ifPresent(rpc -> rpc.forEach(profileCode -> {
			modulePrintConfigProfilesCrudService.deleteByModulePrintConfigId(modulePrintConfigId);
			//Creating new instances for ModuleFormConfigsProfiles
			modulePrintConfigProfilesCrudService.insert(ModulePrintConfigProfileDTO.builder()
					.modulePrintConfigId(modulePrintConfigId)
					.requiredProfileCode(profileCode)
					.build());

		}));
	}

	private void insertOrUpdateModuleConfigProfiles(List<String> requiredProfiles, Long createdModuleFormConfigId) {
		log.info("Invoking insertOrUpdateModuleConfigProfiles with params requiredProfiles: {} createdModuleFormConfigId: {}", requiredProfiles,
				createdModuleFormConfigId);
		Optional.ofNullable(requiredProfiles).ifPresent(rpc -> rpc.forEach(profileCode -> {
			moduleFormConfigProfilesCrudService.deleteByModuleFormConfigId(createdModuleFormConfigId);
			//Creating new instances for ModuleFormConfigsProfiles
			moduleFormConfigProfilesCrudService.insert(ModuleFormConfigProfileDTO.builder()
					.moduleFormConfigId(createdModuleFormConfigId)
					.requiredProfileCode(profileCode)
					.build());

		}));
	}

	public void deleteBundleModules(String tenantId, BundleModulesMessage message) {
		log.info("ModulesBundleWorker: processing file with tenant {}", tenantId);
		message.getModules()
				.stream()
				.forEachOrdered(module -> {
					this.deleteModuleAndRelationships(tenantId, module);
				});
	}

	private void deleteModuleAndRelationships(String tenantId, BundleModuleInDTO module) {
		moduleCrudService.findByModuleCodeAndSectorCode(tenantId, module.getModuleCode(), module.getSectorCode())
				.ifPresent(moduleDTO -> {
					moduleCrudService.delete(moduleDTO.getModuleId(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleDetailsCrudService.deleteByModuleId(moduleDTO.getModuleId(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleProfilesCrudService.deleteByModuleId(moduleDTO.getModuleId(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
					moduleFormConfigProfilesCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
					moduleFormConfigParamCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
					moduleFormConfigsCrudService.bulkDeleteByModuleId(moduleDTO.getModuleId());
				});
	}

}
