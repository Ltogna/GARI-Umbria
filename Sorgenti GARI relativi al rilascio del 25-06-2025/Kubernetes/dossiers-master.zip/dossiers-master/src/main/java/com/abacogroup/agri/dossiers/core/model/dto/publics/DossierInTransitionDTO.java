package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierInTransitionDTO {
	private Boolean inTransition;
	private DetailedTransitionLog lastTransitionLog;
}
