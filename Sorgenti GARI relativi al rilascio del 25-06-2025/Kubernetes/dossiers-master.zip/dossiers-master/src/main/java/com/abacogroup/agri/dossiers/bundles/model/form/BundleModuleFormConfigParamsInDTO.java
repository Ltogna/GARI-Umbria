package com.abacogroup.agri.dossiers.bundles.model.form;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModuleFormConfigParamsInDTO {
	private String parameterName;
	private String parameterValue;
}
