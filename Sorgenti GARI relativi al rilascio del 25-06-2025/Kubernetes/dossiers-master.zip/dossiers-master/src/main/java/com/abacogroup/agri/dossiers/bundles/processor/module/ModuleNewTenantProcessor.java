package com.abacogroup.agri.dossiers.bundles.processor.module;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.form.*;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.module.BundleModulesMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.*;
import java.util.stream.Collectors;

import static com.abacogroup.agri.dossiers.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleNewTenantProcessor implements TenantMessageProcessor {

	protected final Jdbi jdbi;
	protected final ModulesBundleWorker modulesBundleWorker;

	public ModuleNewTenantProcessor(Jdbi jdbi, ModulesBundleWorker modulesBundleWorker) {
		this.jdbi = jdbi;
		this.modulesBundleWorker = modulesBundleWorker;
	}

	@Override
	public void onMessage(TenantMessage message) {
		jdbi.useTransaction(handle -> {
			log.info("ModuleNewTenantProcessor got new tenant {}", message.getTenantId());
			this.checkAndInsertModules(message.getTenantId());
			log.info("ModuleNewTenantProcessor end working with new tenant {}", message.getTenantId());
		});
	}

	private void checkAndInsertModules(String tenantId) {
		log.info("ModuleNewTenantProcessor check and insert new tenant {}", tenantId);
		ModuleCrudService moduleCrudService = modulesBundleWorker.exposeModuleCrudService();
		SectorsCrudService sectorCrudService = modulesBundleWorker.exposeSectorsCrudService();
		FormCatalogsCrudService formCatalogsCrudService = modulesBundleWorker.exposeFormCatalogsCrudService();
		FormGroupsCrudService formGroupsCrudService = modulesBundleWorker.exposeFormGroupsCrudService();
		ModuleFormConfigsCrudService moduleFormConfigsCrudService = modulesBundleWorker.exposeModuleFormConfigsCrudService();
		ModulePrintConfigsCrudService modulePrintConfigsCrudService = modulesBundleWorker.exposeModulePrintConfigsCrudService();

		List<ModuleWithDetailDTO> asteriskModules = moduleCrudService.findAllModulesWithDetail(TENANT_TEMPLATE_CODE);

		modulesBundleWorker.insertBundleModules(tenantId,
				BundleModulesMessage.builder()
						.modules(asteriskModules
								.stream()
								.map(module -> {
									List<ModuleFormConfigsDTO> asteriskModuleFormConfigs = moduleFormConfigsCrudService
											.findAllModuleFormConfigs(TENANT_TEMPLATE_CODE, module.getModuleId());
									List<FormCatalogDTO> asteriskFormCatalogs = formCatalogsCrudService.findAllFormCatalogs(TENANT_TEMPLATE_CODE,
											asteriskModuleFormConfigs
													.stream()
													.map(ModuleFormConfigsDTO::getFormId)
													.collect(Collectors.toList()));
									List<FormGroupDTO> asteriskFormGroups = formGroupsCrudService.findAllFormGroupsWithNoParent(TENANT_TEMPLATE_CODE,
											asteriskModuleFormConfigs
													.stream()
													.map(ModuleFormConfigsDTO::getFormGroupId)
													.collect(Collectors.toList()));

									List<ModulePrintConfigsDTO> asteriskModulePrintConfigs = modulePrintConfigsCrudService
											.findAllModulePrintConfigs(TENANT_TEMPLATE_CODE, module.getModuleId());
									try {
										//setting module
										return BundleModuleInDTO.builder()
												.moduleCode(module.getModuleCode())
												.workflowCode(module.getWorkflowCode())
												.annuality(module.getAnnuality())
												.contextFunction(module.getContextFunction())
												.sectorCode(sectorCrudService.findById(TENANT_TEMPLATE_CODE, module.getSectorId()).getSectorCode())
												.dtValidityStart(module.getDtValidityStart())
												.dtValidityEnd(module.getDtValidityEnd())
												.i18n(mapModuleI18NList(TENANT_TEMPLATE_CODE, module.getModuleCode()))
												.flAmendModule(module.getFlAmendModule())
												//setting forms
												.forms(BundleFormsInDTO.builder()
														//setting form catalogs
														.formCatalogs(asteriskFormCatalogs
																.stream()
																.map(formCatalogDTO -> BundleFormCatalogInDTO.builder()
																		.formCode(formCatalogDTO.getFormCode())
																		.softwareUrl(formCatalogDTO.getSoftwareUrl())
																		.routerUrl(formCatalogDTO.getRouterUrl())
																		.i18n(mapFormCatalogI18NList(TENANT_TEMPLATE_CODE, formCatalogDTO.getFormCode()))
																		.build()).collect(Collectors.toList()))
														//setting form groups
														.formGroups(asteriskFormGroups
																.stream()
																.map(formGroup -> BundleFormGroupInDTO.builder()
																		.formGroupCode(formGroup.getFormGroupCode())
																		.formGroupChildren(mapFormGroupChilds(TENANT_TEMPLATE_CODE, formGroup.getId()))
																		.i18n(mapFormGroupI18NList(TENANT_TEMPLATE_CODE, formGroup.getFormGroupCode()))
																		.build()).collect(Collectors.toList()))
														//setting module form configs
														.moduleFormConfigs(asteriskModuleFormConfigs
																.stream()
																.map(moduleFormConfigs -> {
																	try {
																		return BundleModuleFormConfigsInDTO.builder()
																				.moduleCode(module.getModuleCode())
																				.formCode(formCatalogsCrudService
																						.findById(TENANT_TEMPLATE_CODE, moduleFormConfigs.getFormId())
																						.getFormCode())
																				.formGroupCode(formGroupsCrudService
																						.findById(TENANT_TEMPLATE_CODE, moduleFormConfigs.getFormGroupId())
																						.getFormGroupCode())
																				.processStatus(moduleFormConfigs.getProcessStatus())
																				.contextFunction(moduleFormConfigs.getContextFunction())
																				.forceReadOnlyContextFunction(moduleFormConfigs.getForceReadOnlyContextFunction())
																				.sortOrder(moduleFormConfigs.getSortOrder())
																				.params(this.mapBundleModuleFormConfigsParams(TENANT_TEMPLATE_CODE,
																						moduleFormConfigs.getId()))
																				//setting profile codes
																				.requiredProfiles(
																						this.mapModuleFormConfigProfiles(TENANT_TEMPLATE_CODE,
																								moduleFormConfigs.getId()))
																				.flReadOnly(moduleFormConfigs.getFlReadOnly())
																				.compileStatusIdentifier(moduleFormConfigs.getCompileStatusIdentifier())
																				.build();
																	} catch (ObjectNotFoundException e) {
																		throw new ObjectNotFoundRuntimeException(e.getMessage());
																	}
																}).collect(Collectors.toList()))
														.build())
												.moduleProfiles(
														this.mapModuleProfiles(TENANT_TEMPLATE_CODE, module.getModuleId()))
												.modulePrints(asteriskModulePrintConfigs.stream()
														.map(printConfig -> {
															return BundleModulePrintInDTO.builder()
																	.printCode(printConfig.getPrintCode())
																	.processStatus(printConfig.getProcessStatus())
																	.sortOrder(printConfig.getSortOrder())
																	.contextFunction(printConfig.getContextFunction())
																	.params(mapBundleModulePrintConfigsParams(TENANT_TEMPLATE_CODE, printConfig.getId()))
																	.requiredProfiles(mapModulePrintConfigProfiles(TENANT_TEMPLATE_CODE, printConfig.getId()))
																	.i18n(mapPrintConfigI18NList(TENANT_TEMPLATE_CODE, printConfig.getPrintCode()))
																	.build();
														})
														.collect(Collectors.toList()))
												.build();
									} catch (ObjectNotFoundException e) {
										throw new ObjectNotFoundRuntimeException(e.getMessage());
									}
								})
								.collect(Collectors.toList()))
						.build());
	}

	private List<BundleModuleProfileInDTO> mapModuleProfiles(String tenantId, Long moduleId) {
		ModuleProfilesCrudService moduleProfilesCrudService = modulesBundleWorker.exposeModuleProfilesCrudService();
		return moduleProfilesCrudService.find(tenantId, moduleId)
				.stream()
				.map(ModuleProfileDTO::getProfileCode)
				.map(requiredProfileCode -> BundleModuleProfileInDTO.builder()
						.prfCode(requiredProfileCode)
						.i18n(this.mapModuleProfileI18NList(tenantId, requiredProfileCode))
						.build()).collect(Collectors.toList());
	}

	private List<String> mapModulePrintConfigProfiles(String tenantId, Long modulePrintConfigId) {
		ModulePrintConfigProfilesCrudService moduleFormConfigProfilesCrudService = modulesBundleWorker.exposeModulePrintConfigProfilesCrudService();
		return moduleFormConfigProfilesCrudService.find(tenantId, modulePrintConfigId)
				.stream()
				.map(ModulePrintConfigProfileDTO::getRequiredProfileCode)
				.collect(Collectors.toList());
	}

	private List<String> mapModuleFormConfigProfiles(String tenantId, Long moduleFormConfigId) {
		ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService = modulesBundleWorker.exposeModuleFormConfigProfilesCrudService();
		return moduleFormConfigProfilesCrudService.find(tenantId, moduleFormConfigId)
				.stream()
				.map(ModuleFormConfigProfileDTO::getRequiredProfileCode)
				.collect(Collectors.toList());
	}

	private List<I18nPair> mapModuleI18NList(String tenantId, String sectorCode) {
		var mapLang = modulesBundleWorker.exposeModuleCrudService()
				.getAllModuleI18NByTenantAndCode(tenantId, sectorCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModuleCrudService.MODULE_I18N.MODULE_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapFormCatalogI18NList(String tenantId, String formCode) {
		var mapLang = modulesBundleWorker.exposeFormCatalogsCrudService()
				.getAllFormCatalogI18NByTenantAndCode(tenantId, formCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapFormGroupI18NList(String tenantId, String formCode) {
		var mapLang = modulesBundleWorker.exposeFormGroupsCrudService()
				.getAllFormGroupI18NByTenantAndCode(tenantId, formCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, FormGroupsCrudService.FORM_GROUPS_I18N.FORM_GROUP_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapPrintConfigI18NList(String tenantId, String printCode) {
		var mapLang = modulesBundleWorker.exposeModulePrintConfigsCrudService()
				.getAllPrintCodeI18NByTenantAndCode(tenantId, printCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModulePrintConfigsCrudService.PRINT_CODE_I18N.PROFILE_CODE.getCode()))
				.build()));

		return records;
	}

	private List<I18nPair> mapModuleProfileI18NList(String tenantId, String requiredProfileCode) {
		var mapLang = modulesBundleWorker.exposeModuleProfilesCrudService()
				.getAllModuleProfileI18NByTenantAndCode(tenantId, requiredProfileCode)
				.stream()
				.collect(Collectors.groupingBy(RsI18N::getLang));
		List<I18nPair> records = new ArrayList<>();
		mapLang.forEach((lang, item) -> records.add(I18nPair.builder()
				.lang(lang)
				.description(extractI18NText(item, ModuleProfilesCrudService.DOSSIER_PROFILES_I18N.PROFILE_CODE.getCode()))
				.build()));

		return records;
	}

	private String extractI18NText(List<RsI18N> items, String field) {
		return items
				.stream()
				.filter(x -> field.equals(x.getField_name()))
				.findFirst()
				.map(RsI18N::getI18n_text)
				.orElse(null);
	}

	private Map<String, String> mapBundleModuleFormConfigsParams(String tenantId, Long moduleFormConfigsId) {
		ModuleFormConfigParamCrudService moduleFormConfigParamCrudService = modulesBundleWorker.exposeModuleFormConfigParamCrudService();

		List<ModuleFormConfigParamDTO> moduleFormConfigParams = moduleFormConfigParamCrudService.find(tenantId, moduleFormConfigsId);
		Map<String, String> params = new HashMap<>();
		moduleFormConfigParams.forEach(moduleFormConfigParam -> {
			params.put(moduleFormConfigParam.getParameterName(), moduleFormConfigParam.getParameterValue());
		});
		return params;
	}

	private Map<String, String> mapBundleModulePrintConfigsParams(String tenantId, Long modulePrintConfigsId) {
		ModulePrintConfigParamCrudService modulePrintConfigParamCrudService = modulesBundleWorker.exposeModulePrintConfigParamCrudService();

		List<ModulePrintConfigParamDTO> modulePrintConfigParams = modulePrintConfigParamCrudService.find(tenantId, modulePrintConfigsId);
		Map<String, String> params = new HashMap<>();
		modulePrintConfigParams.forEach(moduleFormConfigParam -> {
			params.put(moduleFormConfigParam.getParameterName(), moduleFormConfigParam.getParameterValue());
		});
		return params;
	}

	private List<BundleFormGroupInDTO> mapFormGroupChilds(String tenantId, Long parentGroupId) {
		if (Optional.ofNullable(parentGroupId).isEmpty()) {
			return Collections.emptyList();
		}
		FormGroupsCrudService formGroupsCrudService = modulesBundleWorker.exposeFormGroupsCrudService();
		return formGroupsCrudService.findFormGroupsByParentId(tenantId, parentGroupId) // children
				.stream()
				.map(child -> {
					try {
						return BundleFormGroupInDTO.builder()
								.formGroupCode(child.getFormGroupCode())
								.i18n(mapFormGroupI18NList(tenantId, child.getFormGroupCode()))
								.formGroupChildren(
										this.mapFormGroupChilds(tenantId,
												formGroupsCrudService.findFormGroupByCode(tenantId, child.getFormGroupCode()).getId()))
								.build();
					} catch (ObjectNotFoundException e) {
						throw new ObjectNotFoundRuntimeException(e.getMessage());
					}
				}).collect(Collectors.toList());
	}
}
