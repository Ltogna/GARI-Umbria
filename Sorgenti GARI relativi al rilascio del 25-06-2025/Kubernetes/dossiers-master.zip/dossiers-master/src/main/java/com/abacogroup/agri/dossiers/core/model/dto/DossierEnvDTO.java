package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * The type Dossier env dto.
 * @author Carlo Sindico
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierEnvDTO {

    private String tenant;
    private String key;
    private String value;
    private Integer flClient;

}
