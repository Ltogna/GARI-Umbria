package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.PartyDTO;
import com.abacogroup.agri.dossiers.core.model.dto.PartyRegistryDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface PartyRegistryMapper extends EntityMapper<PartyDTO, PartyRegistryDTO> {

	PartyRegistryMapper INSTANCE = Mappers.getMapper(PartyRegistryMapper.class);

	@Mapping(source = "id", target = "partyId")
	@Mapping(expression = "java(getCode(dto))", target = "cuaa")
	@Mapping(expression = "java(getDescription(dto))", target = "description")
	PartyDTO callerOutToDTO(PartyRegistryDTO dto);

	default String getDescription(PartyRegistryDTO pt) {
		return pt.getLastName() + " " + pt.getFirstName();
	}

	default String getCode(PartyRegistryDTO pt) {
		return pt.getCode() != null ? pt.getCode() : pt.getTaxCode();
	}
}
