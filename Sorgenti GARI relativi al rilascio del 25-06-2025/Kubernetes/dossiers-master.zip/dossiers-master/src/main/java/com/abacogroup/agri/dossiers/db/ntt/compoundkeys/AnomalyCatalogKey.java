package com.abacogroup.agri.dossiers.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class AnomalyCatalogKey {
	private String anomaly_code;
	private Long module_id;

}
