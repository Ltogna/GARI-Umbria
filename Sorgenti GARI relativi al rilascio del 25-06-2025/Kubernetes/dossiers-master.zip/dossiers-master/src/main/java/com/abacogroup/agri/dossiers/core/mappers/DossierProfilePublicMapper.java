package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DossierProfilePublicMapper {

	DossierProfilePublicMapper INSTANCE = Mappers.getMapper(DossierProfilePublicMapper.class);

	@InheritInverseConfiguration()
	DossierProfileDTO publicToDto(ApplicationProfilePublicDTO entity);

	@Mapping(source = "profileCode", target = "profileCode")
	@Mapping(source = "profileCodeDescription", target = "profileCodeDescription")
	ApplicationProfilePublicDTO dtoToPublic(DossierProfileDTO dto);

}
