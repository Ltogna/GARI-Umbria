package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.FormCatalogMapper;
import com.abacogroup.agri.dossiers.core.model.dto.FormCatalogDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.FormCatalogDAO;
import com.abacogroup.agri.dossiers.db.ntt.FormCatalogNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class FormCatalogsCrudService extends AbstractCrudService<FormCatalogNTT, Long, FormCatalogDTO, FormCatalogMapper, Long> {

	public static final String I18N_FORM_CATALOG_TABLE = "doss_form_catalog";

	private I18NService i18NService;

	public FormCatalogsCrudService(FormCatalogDAO dao, FormCatalogMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	public List<FormCatalogDTO> findAllFormCatalogsByTenant(String tenantId) {
		return returnMappedList(((FormCatalogDAO) this.dao).findAllFormCatalogsByTenant(tenantId, MDC.get(MDCPreFilter.LOCALE)));
	}

	public List<FormCatalogDTO> findAllFormCatalogs(String tenantId, List<Long> formIdList) {
		return returnMappedList(((FormCatalogDAO) this.dao).findAllFormCatalogs(tenantId, formIdList, MDC.get(MDCPreFilter.LOCALE)));
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<FormCatalogNTT> findRsByCustomKey(Long customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(FormCatalogNTT rs, Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public FormCatalogDTO insert(FormCatalogDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public FormCatalogDTO update(Long key, FormCatalogDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public FormCatalogDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return this.findById(tenant, id, MDC.get(MDCPreFilter.LOCALE));
	}

	public FormCatalogDTO findById(String tenant, Long id, String locale) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((FormCatalogDAO) this.dao).findById(tenant, id, locale))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public FormCatalogDTO findByCode(String tenant, String code) throws ObjectNotFoundException {
		log.info("Invoking findByCode with params tenant: {} code: {}", tenant, code);
		return returnOptionalRecord(((FormCatalogDAO) this.dao).findByCode(tenant, code))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public FormCatalogDTO findByCodeNullable(String tenant, String code) {
		log.info("Invoking findByCode with params tenant: {} code: {}", tenant, code);
		return returnOptionalRecord(((FormCatalogDAO) this.dao).findByCode(tenant, code))
				.orElse(null);
	}

	public List<RsI18N> getAllFormCatalogI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_FORM_CATALOG_TABLE, code);
	}

	public void insertFormCatalogI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_FORM_CATALOG_TABLE, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.code, lang, code, description);
	}

	public void deleteFormCatalogI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_FORM_CATALOG_TABLE, FormCatalogsCrudService.FORM_CATALOG_I18N.FORM_CODE.code, code, lang);
	}

	public enum FORM_CATALOG_I18N {
		FORM_CODE("form_code");

		private final String code;

		FORM_CATALOG_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

}
