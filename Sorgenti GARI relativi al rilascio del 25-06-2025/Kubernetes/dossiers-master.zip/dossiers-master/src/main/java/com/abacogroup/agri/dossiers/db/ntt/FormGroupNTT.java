package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormGroupNTT implements IIdRs<Long> {

	private Long id;
	private String tenant_id;
	private String form_group_code;
	private String form_group_desc;
	private Long parent_form_group_id;

	@Override public void setKey(Long id) {
		this.id = id;
	}

	@Override public Optional<Long> getKey() {
		return Optional.of(this.id);
	}
}
