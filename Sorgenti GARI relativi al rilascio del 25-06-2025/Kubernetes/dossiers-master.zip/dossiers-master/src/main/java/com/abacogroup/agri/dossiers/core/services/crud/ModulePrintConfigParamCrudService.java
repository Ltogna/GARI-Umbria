package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModulePrintConfigParamMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigParamDTO;
import com.abacogroup.agri.dossiers.db.dao.ModulePrintConfigParamDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModulePrintConfigParamNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.PrintConfigParamKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModulePrintConfigParamCrudService
		extends AbstractCrudService<ModulePrintConfigParamNTT, Void, ModulePrintConfigParamDTO, ModulePrintConfigParamMapper, PrintConfigParamKey> {

	public ModulePrintConfigParamCrudService(ModulePrintConfigParamDAO dao, ModulePrintConfigParamMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(PrintConfigParamKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModulePrintConfigParamNTT> findRsByCustomKey(PrintConfigParamKey customKey) {
		return ((ModulePrintConfigParamDAO) this.dao).findById(customKey.getModule_print_config_id(), customKey.getParameter_name())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(PrintConfigParamKey customKey) {
		((ModulePrintConfigParamDAO) this.dao).deleteById(customKey.getModule_print_config_id(), customKey.getParameter_name());
	}

	@Override
	protected void setCustomSearchKey(ModulePrintConfigParamNTT rs, PrintConfigParamKey customKey) {
		rs.setModule_print_config_id(customKey.getModule_print_config_id());
		rs.setParameter_name(customKey.getParameter_name());
	}

	public ModulePrintConfigParamDTO insert(ModulePrintConfigParamDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, PrintConfigParamKey.builder()
				.module_print_config_id(in.getModulePrintConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public ModulePrintConfigParamDTO update(ModulePrintConfigParamDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, PrintConfigParamKey.builder()
				.module_print_config_id(in.getModulePrintConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public void delete(PrintConfigParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModulePrintConfigId(Long moduleFormConfigId) {
		((ModulePrintConfigParamDAO) this.dao).deleteByModulePrintConfigId(moduleFormConfigId);
	}

	public ModulePrintConfigParamDTO findById(String tenant, PrintConfigParamKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModulePrintConfigParamDAO) this.dao).findById(tenant, id.getModule_print_config_id(), id.getParameter_name()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModulePrintConfigParamDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModulePrintConfigParamDAO) this.dao).find(tenant, formConfig));
	}

}
