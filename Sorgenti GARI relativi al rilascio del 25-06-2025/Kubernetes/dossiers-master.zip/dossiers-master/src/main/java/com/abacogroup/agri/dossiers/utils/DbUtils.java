package com.abacogroup.agri.dossiers.utils;

public class DbUtils {

	private DbUtils() {
	}

	public static Boolean mainDbIsPostgres;
}
