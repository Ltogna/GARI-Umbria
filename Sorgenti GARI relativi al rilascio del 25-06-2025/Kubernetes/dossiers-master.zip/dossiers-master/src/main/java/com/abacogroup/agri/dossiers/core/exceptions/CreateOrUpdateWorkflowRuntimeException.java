package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class CreateOrUpdateWorkflowRuntimeException extends AbstractException {

	private static final CreateOrUpdateWorkflowRuntimeException.ErrorBody BODY = new CreateOrUpdateWorkflowRuntimeException.ErrorBody();

	public CreateOrUpdateWorkflowRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public CreateOrUpdateWorkflowRuntimeException() {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, "generic error");
	}

	@Schema(name = "CreateOrUpdateWorkflowRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "ADD_OR_UPDATE_WORKFLOW_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
