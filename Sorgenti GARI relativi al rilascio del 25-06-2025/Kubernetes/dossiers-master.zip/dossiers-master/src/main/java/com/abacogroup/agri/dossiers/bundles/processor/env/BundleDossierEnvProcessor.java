package com.abacogroup.agri.dossiers.bundles.processor.env;

import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvMessage;
import com.abacogroup.agri.dossiers.bundles.processor.AbstractBundleDossiersProcessor;
import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.nio.file.Path;

/**
 * The type Bundle dossier env processor.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class BundleDossierEnvProcessor extends AbstractBundleDossiersProcessor<BundleDossierEnvMessage> {

    private final DossierEnvBundleWorker dossierEnvBundleWorker;

    public BundleDossierEnvProcessor(ObjectMapper objectMapper, DossierEnvBundleWorker dossierEnvBundleWorker, Jdbi jdbi) {
        super(objectMapper, jdbi);
        this.dossierEnvBundleWorker = dossierEnvBundleWorker;
    }

    @Override
    protected TypeReference<BundleDossierEnvMessage> getTypeReference() {
        return new TypeReference<>() {};
    }

    @Override
    protected void onMessageInTransaction(ConfigDataMessage message) {
        log.info("onMessageInTransaction: proccessing file with tenant {}", message.getTenantId());
        message.getConfigFiles().stream()
                .map(Path::toFile)
                .filter(file -> file.getAbsolutePath().endsWith(".json"))
                .forEach(file -> processFile(message.getTenantId(), file));
    }

    @Override
    protected void delete(String tenantId, BundleDossierEnvMessage message) {
        dossierEnvBundleWorker.deleteDossierEnvironments(tenantId, message);
    }

    @Override
    protected void doInsertOrUpdate(String tenantId, BundleDossierEnvMessage message) {
        dossierEnvBundleWorker.upsertDossierEnvironments(tenantId, message);
    }

    @Override
    public String getDomainName() {
        return "dossiers-env";
    }

}
