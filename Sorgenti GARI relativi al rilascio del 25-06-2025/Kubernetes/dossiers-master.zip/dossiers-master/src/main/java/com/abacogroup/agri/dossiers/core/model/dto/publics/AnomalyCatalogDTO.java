package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCatalogDTO {
	@Schema(description = "the anomaly's code")
	private String anomalyCode;
	@Schema(description = "the anomaly's description")
	private String anomalyDesc;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long moduleId;
	@Schema(description = "the anomaly's severity")
	private String severity;

}
