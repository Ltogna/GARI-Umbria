package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.AnomalyCatalogKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyCatalogNTT implements IIdRs<AnomalyCatalogKey> {

	private String anomaly_code;
	private String anomaly_desc;
	private String severity;
	private Long module_id;

	@Override public void setKey(AnomalyCatalogKey id) {
		this.anomaly_code = id.getAnomaly_code();
		this.module_id = id.getModule_id();
	}

	@Override public Optional<AnomalyCatalogKey> getKey() {
		return Optional.ofNullable(AnomalyCatalogKey.builder()
				.anomaly_code(this.anomaly_code)
				.module_id(this.module_id)
				.build());
	}
}
