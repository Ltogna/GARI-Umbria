package com.abacogroup.agri.dossiers.bundles.model.form;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModulePrintInDTO {
	private String printCode;
	private String processStatus;
	private List<String> processStatusList;
	private Integer sortOrder;
	private String contextFunction;
	private List<I18nPair> i18n;
	private Map<String, String> params;
	private List<String> requiredProfiles;

}
