package com.abacogroup.agri.dossiers.core.services.crud;

import java.util.List;
import java.util.Optional;

import com.abacogroup.agri.dossiers.core.mappers.DossierGeneratedPrintMapper;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierGeneratedPrintDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierGeneratedPrintCrudService
		extends AbstractCrudService<DossierGeneratedPrintNTT, Long, DossierGeneratedPrintDTO, DossierGeneratedPrintMapper, Void> {

	public DossierGeneratedPrintCrudService(DossierGeneratedPrintDAO dao, DossierGeneratedPrintMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected Long retrievePrimaryKey(Void customKey) {
		return this.dao.nextSequenceVal();
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<DossierGeneratedPrintNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(DossierGeneratedPrintNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public DossierGeneratedPrintDTO insert(DossierGeneratedPrintDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public DossierGeneratedPrintDTO update(Long key, DossierGeneratedPrintDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public List<DossierGeneratedPrintDTO> findAllGeneratedPrints(String tenantId, Long dossierId) {
		return returnMappedList(getDao().findCompletedPrintsByDossierId(tenantId, dossierId, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<DossierGeneratedPrintDTO> findPrintByDossierIdAndFileId(String tenantId, Long dossierId, String fileId) {
		return returnOptionalRecord(getDao().findByDossierIdAndFileId(tenantId, dossierId, MDC.get(MDCPreFilter.LOCALE), fileId));
	}

	public static final Integer ON_GOING_PRINT = 1;
	public static final Integer DEFINITIVE_PRINT = 0;

	public Optional<DossierGeneratedPrintDTO> findLastGeneratedPrintByCode(String tenantId, Long dossierId, String printCode) {
		return returnOptionalRecord(getDao().findLastGeneratedPrintByCode(tenantId, dossierId, printCode, MDC.get(MDCPreFilter.LOCALE), DEFINITIVE_PRINT));
	}

	public List<DossierGeneratedPrintDTO> findOngoingPrintByCode(String tenantId, Long dossierId, String printCode) {
		return returnMappedList(getDao().findLastGeneratedPrintByCode(tenantId, dossierId, printCode, MDC.get(MDCPreFilter.LOCALE), ON_GOING_PRINT));
	}

	public DossierGeneratedPrintDTO findByUuid(String uuid) {
		return this.mapper.entityToDto(getDao().findByUuid(uuid));
	}

	private DossierGeneratedPrintDAO getDao() {
		return (DossierGeneratedPrintDAO) this.dao;
	}

}
