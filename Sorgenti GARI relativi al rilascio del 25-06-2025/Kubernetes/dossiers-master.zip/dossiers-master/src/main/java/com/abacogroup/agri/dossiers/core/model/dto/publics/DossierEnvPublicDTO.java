package com.abacogroup.agri.dossiers.core.model.dto.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The type Dossier env public dto.
 * @author Carlo Sindico
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierEnvPublicDTO {

    @Schema(description = "the environment key")
    private String key;
    @Schema(description = "the environment value")
    private String value;

}
