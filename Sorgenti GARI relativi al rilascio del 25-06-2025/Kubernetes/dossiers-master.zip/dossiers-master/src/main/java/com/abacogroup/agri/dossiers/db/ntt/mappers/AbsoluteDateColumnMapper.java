package com.abacogroup.agri.dossiers.db.ntt.mappers;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import org.jdbi.v3.core.mapper.ColumnMapper;
import org.jdbi.v3.core.statement.StatementContext;

import java.sql.ResultSet;
import java.sql.SQLException;

public class AbsoluteDateColumnMapper implements ColumnMapper<AbsoluteDate>
{
	@Override
	public AbsoluteDate map(ResultSet r, int columnNumber, StatementContext ctx) throws SQLException
	{
		return new AbsoluteDate(r.getString(columnNumber));
	}
}
