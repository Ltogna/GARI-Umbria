package com.abacogroup.agri.dossiers.db.ntt.dossiers;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RsI18N {
	private String tenant_id;
	private String table_name;
	private String field_name;
	private String i18n_value;
	private String lang;
	private String i18n_text;
}
