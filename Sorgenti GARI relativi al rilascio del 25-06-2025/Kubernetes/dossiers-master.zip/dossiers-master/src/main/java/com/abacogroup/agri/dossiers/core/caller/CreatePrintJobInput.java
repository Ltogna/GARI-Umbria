package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.callerv2.ICallerInput;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

import static com.abacogroup.jaxrsutils.GenericCallerService.POST_METHOD;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreatePrintJobInput implements ICallerInput {

	private String url;
	private String tenant;
	private String bucketName;
	private String destination;
	private String printCode;
	private String token;
	private String locale;
	private Map<String, Object> params = new HashMap<>();

	@Override public Object providePayload() {
		return Map.of("_params", this.params);
	}

	@Override
	public Map<String, Object> getPathVariablesMap() {
		return Map.of("TENANT_ID", this.tenant,
				"PRINT_TYPE_NAME", this.printCode);
	}

	@Override
	public Map<String, Object> getQueryParamsMap() {
		return Map.of("bucket", this.bucketName,
				"dest", this.destination);
	}

	@Override
	public String provideAuthToken() {
		return this.token;
	}

	@Override
	public String getUrl() {
		return this.url + "/{TENANT_ID}/public/v1/{PRINT_TYPE_NAME}";
	}

	@Override
	public String getHttpMethod() {
		return POST_METHOD;
	}

	@Override public String locale() {
		return this.locale;
	}
}
