package com.abacogroup.agri.dossiers.bundles.model.form;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModuleFormConfigsInDTO {
	private String moduleCode;
	private String formCode;
	private String formGroupCode;
	private String processStatus;
	private List<String> processStatusList;
	private Integer sortOrder;
	private Integer flReadOnly;
	private String compileStatusIdentifier;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
	private List<String> contextFunctionList;
	private Map<String, String> params;
	private List<String> requiredProfiles;
}
