package com.abacogroup.agri.dossiers.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleFormConfigsPublicDTO {
	private Long formConfigId;
	private String processStatus;
	private String formCode;
	private String formGroupCode;
	private Integer sortOrder;
	private Integer flReadOnly;
	private String compileStatusIdentifier;
	private String contextFunction;
	private Map<String, String> params;
}
