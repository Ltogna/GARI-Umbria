package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.applicationworkflowsdk.service.WorkflowUtils;
import com.abacogroup.workflow.server.services.WorkflowService;

import java.util.Map;

/**
 * @author Gennaro Tamburrelli
 */
public class DossiersWorkflowUtils implements WorkflowUtils {

	private final WorkflowService workflowService;

	public DossiersWorkflowUtils(WorkflowService workflowService) {
		this.workflowService = workflowService;
	}

	@Override
	public Map<String, Object> getNodeMetadata(String tenantId, String workflowCode, String nodeName, String locale) {
		var node = workflowService.getWorkflowNode(tenantId, workflowCode, nodeName, locale);
		return node.getMetadata();
	}
}
