package com.abacogroup.agri.dossiers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleWithDetailNTT extends ModuleNTT {
	private Integer annuality;
	private String context_function;
	private String force_read_only_context_function;
	private String dt_validity_start;
	private String dt_validity_end;
	private String sector_code;
	private String sector_description;
	private String module_description;
}
