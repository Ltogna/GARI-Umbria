package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.*;
import com.abacogroup.agri.dossiers.core.mappers.EntityMapper;
import com.abacogroup.agri.dossiers.db.dao.IGenericDAO;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import com.abacogroup.agri.dossiers.utils.GenericUtility;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.PagedResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import com.abacogroup.jdbi.paging.impl.PagedResultsImpl;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.statement.StatementException;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public abstract class AbstractCrudService<R extends IIdRs<K>, K, D, M extends EntityMapper<D, R>, C> {

	public static final Supplier<ObjectNotFoundException> OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER = () -> new ObjectNotFoundException("not found");
	protected final IGenericDAO<R, K> dao;
	protected final M mapper;

	protected AbstractCrudService(IGenericDAO<R, K> dao, M mapper) {
		this.dao = dao;
		this.mapper = mapper;
	}

	protected K retrievePrimaryKey(C customKey) {
		// default implementation is retrieve id from sequence
		return this.dao.nextSequenceVal();
	}

	protected abstract boolean hasPrimaryKey();

	protected D insert(D dtoIn, C customKey) {
		return dao.inTransaction(handle -> {
			try {
				K key = this.retrievePrimaryKey(customKey);
				R rs = mapper.dtoToEntity(dtoIn);
				rs.setKey(key);
				dao.insert(rs);
				if (hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					return findOutDtoByPrimaryKey(key);
				} else {
					return findOutDtoByCustom(customKey);
				}
			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new InsertExceptionRuntimeException("error during insert");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriDossiersRuntimeException(e.getMessage());
			}
		});
	}

	protected D findOutDtoByPrimaryKey(K key) throws ObjectNotFoundException {
		return this.findRsByPrimaryKey(key)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	protected D findOutDtoByCustom(C customKey) throws ObjectNotFoundException {
		return this.findRsByCustomKey(customKey)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	private Optional<R> findRsByPrimaryKey(K key) {
		return dao.findById(key)
				.stream()
				.findFirst();
	}

	protected abstract Optional<R> findRsByCustomKey(C customKey);

	public void delete(K key, C customKey) {
		dao.useTransaction(handle -> {
			try {
				if (hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					dao.deleteById(key);
				} else {
					this.deleteByCustomKey(Optional.ofNullable(customKey).orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER));
				}
			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new StatementExceptionRuntimeException("error during delete");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriDossiersRuntimeException(e.getMessage());
			}
		});
	}

	protected abstract void deleteByCustomKey(C customKey);

	protected abstract void setCustomSearchKey(R rs, C customKey);

	protected D update(K key, D newRecord, C customKey) {
		return dao.inTransaction(handle -> {
			try {
				R rs = mapper.dtoToEntity(newRecord);
				if (this.hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					rs.setKey(key);
				} else {
					this.setCustomSearchKey(rs, Optional.ofNullable(customKey).orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER));
				}
				dao.update(rs);
				if (this.hasPrimaryKey() && Optional.ofNullable(customKey).isEmpty()) {
					return this.findOutDtoByPrimaryKey(key);
				} else {
					return this.findOutDtoByCustom(Optional.ofNullable(customKey).orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER));
				}
			} catch (StatementException e) {
				log.error(e.getMessage(), e);
				throw new StatementExceptionRuntimeException("error during update");
			} catch (ObjectNotFoundException e) {
				throw new ObjectNotFoundRuntimeException();
			} catch (Exception e) {
				throw new AgriDossiersRuntimeException(e.getMessage());
			}
		});
	}

	protected PagedResults<D> returnPagedResults(PagedResults<R> pagedResult) {
		return new PagedResultsImpl<>(pagedResult.getTotalcount(),
				pagedResult.getOffset(),
				pagedResult.getRecords()
						.stream()
						.map(mapper::entityToDto)
						.collect(Collectors.toList()));
	}

	protected InfiniteListResults<D> returnInfiniteResults(InfiniteListResults<R> infiniteListResults) {
		return GenericUtility.returnInfiniteResults(infiniteListResults, mapper::entityToDto);
	}

	protected List<D> returnMappedList(List<R> recordList) {
		return GenericUtility.returnMappedList(recordList, mapper::entityToDto);
	}

	protected Optional<D> returnOptionalRecord(List<R> recordList) {
		return GenericUtility.returnOptionalFromList(recordList, mapper::entityToDto);
	}

	protected <Y, A> InfiniteListResults<A> returnInfiniteResults(InfiniteListResults<Y> infiniteListResults, Function<Y, A> customMapper) {
		return new InfiniteListResultsImpl<>(
				infiniteListResults.getRecords()
						.stream()
						.map(customMapper)
						.collect(Collectors.toList()),
				infiniteListResults.getNextKey());
	}

}
