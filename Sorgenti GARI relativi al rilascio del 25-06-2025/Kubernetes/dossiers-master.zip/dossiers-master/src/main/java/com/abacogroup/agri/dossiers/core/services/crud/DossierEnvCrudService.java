package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.DossierEnvMapper;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.db.dao.DossierEnvDAO;
import com.abacogroup.agri.dossiers.db.ntt.DossierEnvNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Dossier env crud service.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class DossierEnvCrudService
		extends AbstractCrudService<DossierEnvNTT, DossierEnvKey, DossierEnvDTO, DossierEnvMapper, DossierEnvKey> {

	public DossierEnvCrudService(DossierEnvDAO dao, DossierEnvMapper mapper) {
		super(dao, mapper);
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected DossierEnvDTO findOutDtoByPrimaryKey(DossierEnvKey key) throws ObjectNotFoundException {
		return Optional.ofNullable(((DossierEnvDAO) this.dao).findByKey(key))
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	@Override
	protected DossierEnvKey retrievePrimaryKey(DossierEnvKey customKey) {
		return customKey;
	}

	@Override
	protected Optional<DossierEnvNTT> findRsByCustomKey(DossierEnvKey customKey) {
		return Optional.ofNullable(((DossierEnvDAO) this.dao).findByKey(customKey));
	}

	@Override
	protected void deleteByCustomKey(DossierEnvKey key) {
		this.dao.deleteById(key);
	}

	@Override
	protected void setCustomSearchKey(DossierEnvNTT rs, DossierEnvKey key) {
		rs.setKey(key);
	}

	public DossierEnvDTO insert(DossierEnvDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, DossierEnvKey.builder()
				.tenant_id(in.getTenant())
				.fl_client(in.getFlClient())
				.key_(in.getKey())
				.build()
		);
	}

	public DossierEnvDTO update(DossierEnvKey key, DossierEnvDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(key, in, null);
	}

	public void delete(DossierEnvKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public DossierEnvDTO findEnvironmentByKey(DossierEnvKey key) throws ObjectNotFoundException {
		log.info("Invoking findByKey with params tenant: {} key: {}", key.getTenant_id(), key.getKey_());
		DossierEnvNTT dossierEnvNTT = ((DossierEnvDAO) this.dao).findByKey(key);

		return Optional.ofNullable(dossierEnvNTT)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public DossierEnvDTO findByKeyWithoutFlClient(DossierEnvKey key) throws ObjectNotFoundException {
		log.info("Invoking findByKey with params tenant: {} key: {}", key.getTenant_id(), key.getKey_());
		DossierEnvNTT dossierEnvNTT = ((DossierEnvDAO) this.dao).findByKeyWithoutFlClient(key);

		return Optional.ofNullable(dossierEnvNTT)
				.map(mapper::entityToDto)
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<DossierEnvDTO> findAllByTenant(final String tenant) {
		log.info("Invoking findAllByBy with params tenant: {}", tenant);
		return ((DossierEnvDAO) this.dao).findAll(tenant).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

}
