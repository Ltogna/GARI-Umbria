package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoTransitionFoundRuntimeException extends AbstractException {

	private static final NoTransitionFoundRuntimeException.ErrorBody BODY = new NoTransitionFoundRuntimeException.ErrorBody();

	public NoTransitionFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoTransitionFoundRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "Object not found");
	}

	@Schema(name = "NoTransitionFoundRuntimeErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "TRANSITION_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
