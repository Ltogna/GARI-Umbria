package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ModuleByPointInTimeDTO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleNTT;
import com.abacogroup.agri.dossiers.db.ntt.ModuleWithDetailNTT;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateArgumentFactory;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateColumnMapper;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateColumnMapper.class)
public interface ModuleDAO extends IGenericHistoricizationFieldsDAO<ModuleNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_modules_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO DOSS_MODULES " +
			"(id, module_code, sector_id, workflow_code, user_id_insert, user_id_delete, dt_insert, dt_delete, fl_amend_module) " +
			"VALUES(:id, :module_code, :sector_id, :workflow_code, :user_id, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :fl_amend_module)")
	void insert(@BindBean ModuleNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE DOSS_MODULES " +
			"SET workflow_code =:workflow_code " +
			"WHERE id =:id ")
	void updateWorkflowCode(@Bind("id") Long id, @Bind("workflow_code") String workflowCode);

	@SqlQuery("select m.id," +
			"  m.module_code," +
			"  m.sector_id," +
			"  m.workflow_code," +
			"  m.dt_insert," +
			"  m.dt_delete," +
			"  m.user_id_insert," +
			"  m.user_id_delete," +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m " +
			" where m.id = :id")
	@RegisterBeanMapper(ModuleNTT.class)
	List<ModuleNTT> findById(@Bind("id") Long id);

	@SqlQuery("select m.id," +
			"  m.module_code," +
			"  m.sector_id," +
			"  m.workflow_code," +
			"  m.dt_insert," +
			"  m.dt_delete," +
			"  m.user_id_insert," +
			"  m.user_id_delete," +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m " +
			" left join doss_sectors s on m.sector_id = s.id" +
			" where m.module_code = :moduleCode and s.tenant_id = :tenant " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ModuleNTT.class)
	List<ModuleNTT> findByCode(@Bind("tenant") String tenant, @Bind("moduleCode") String moduleCode);

	@SqlQuery("select m.id," +
			"  m.module_code," +
			"  m.sector_id," +
			"  m.workflow_code," +
			"  m.dt_insert," +
			"  m.dt_delete," +
			"  m.user_id_insert," +
			"  m.user_id_delete," +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m " +
			" left join doss_sectors s on m.sector_id = s.id and s.tenant_id = :tenant" +
			" where m.module_code = :moduleCode and s.sector_code = :sectorCode" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ModuleNTT.class)
	List<ModuleNTT> findByModuleCodeAndSectorCode(@Bind("tenant") String tenant, @Bind("moduleCode") String moduleCode, @Bind("sectorCode") String sectorCode);

	@SqlQuery("select m.id," +
			"  m.module_code," +
			"  m.sector_id," +
			"  m.workflow_code," +
			"  m.dt_insert," +
			"  m.dt_delete," +
			"  m.user_id_insert," +
			"  m.user_id_delete, " +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m RIGHT JOIN DOSS_SECTORS s on s.id = m.sector_id" +
			" where s.tenant_id = :tenant_id" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and s.id = :sector_id")
	@RegisterBeanMapper(ModuleNTT.class)
	List<ModuleNTT> findAllModulesBySectorId(@Bind("tenant_id") String tenantId, @Bind("sector_id") Long sectorId);

	@Override
	@SqlUpdate("UPDATE DOSS_MODULES SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE id = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	//CLONED QUERY IN List<ModuleByPointInTimeDTO> findByDateAndAmendFl
	@SqlQuery("select amd.annuality as year, " +
			"am.module_code as moduleCode, " +
			"am.fl_amend_module as flAmendModule, " +
			"amd.context_function as contextFunction," +
			"amd.force_read_only_context_function as forceReadOnlyContextFunction," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as moduleShortDescription," +
			"s.sector_code as sectorCode," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sectorShortDescription " +
			"from doss_sectors s join doss_modules am on s.id = am.sector_id " +
			"left join doss_module_details amd on am.id = amd.module_id " +
			"where s.tenant_id = :tenant_id " +
			"and am.fl_amend_module = :fl_amend " +
			"and :point_in_time between amd.dt_validity_start and amd.dt_validity_end " +
			"and §current_timestamp§ between amd.dt_insert and amd.dt_delete " +
			"and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModuleByPointInTimeDTO.class)
	ResultIterator<ModuleByPointInTimeDTO> find(@Bind("tenant_id") String tenantId, @Bind("point_in_time") AbsoluteDate pointInTime,
												@Bind("fl_amend") Integer flAmend,
												@Bind("lang") String lang);

	//CLONED QUERY IN ResultIterator<ModuleByPointInTimeDTO> find
	@SqlQuery("select amd.annuality as year, " +
			"am.module_code as moduleCode, " +
			"am.fl_amend_module as flAmendModule, " +
			"amd.context_function as contextFunction," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as moduleShortDescription," +
			"s.sector_code as sectorCode," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sectorShortDescription " +
			"from doss_sectors s join doss_modules am on s.id = am.sector_id " +
			"left join doss_module_details amd on am.id = amd.module_id " +
			"where s.tenant_id = :tenant_id " +
			"and am.fl_amend_module = :fl_amend " +
			"and :point_in_time between amd.dt_validity_start and amd.dt_validity_end " +
			"and §current_timestamp§ between amd.dt_insert and amd.dt_delete " +
			"and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModuleByPointInTimeDTO.class)
	List<ModuleByPointInTimeDTO> findByDateAndAmendFl(@Bind("tenant_id") String tenantId, @Bind("point_in_time") AbsoluteDate pointInTime,
												@Bind("fl_amend") Integer flAmend,
												@Bind("lang") String lang);
	@SqlQuery("select m.id, " +
			"  m.module_code, " +
			"  m.sector_id, " +
			"  m.workflow_code, " +
			"  md.dt_validity_start, " +
			"  md.dt_validity_end, " +
			"  md.context_function, " +
			"  md.force_read_only_context_function, " +
			"  md.annuality, " +
			"  m.dt_insert, " +
			"  m.dt_delete, " +
			"  m.user_id_insert, " +
			"  m.user_id_delete, " +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m RIGHT JOIN DOSS_SECTORS s on s.id = m.sector_id" +
			" LEFT JOIN DOSS_MODULE_DETAILS md on md.module_id = m.id " +
			" where s.tenant_id = :tenantId " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between md.dt_insert and md.dt_delete ")
	@RegisterBeanMapper(ModuleWithDetailNTT.class)
	List<ModuleWithDetailNTT> findAllModulesWithDetail(@Bind("tenantId") String tenant);

	@SqlQuery("select m.id, " +
			"  m.module_code, " +
			"  m.sector_id, " +
			"  m.workflow_code, " +
			"  md.dt_validity_start, " +
			"  md.dt_validity_end, " +
			"  md.context_function, " +
			"  md.force_read_only_context_function, " +
			"  md.annuality, " +
			"  m.dt_insert, " +
			"  m.dt_delete, " +
			"  m.user_id_insert, " +
			"  m.user_id_delete, " +
			"  m.fl_amend_module, " +
			"  §i18n(:tenantId, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  §i18n(:tenantId, 'doss_modules', 'module_code', m.module_code, :lang)§ as module_description," +
			" s.sector_code " +
			" from DOSS_MODULES m RIGHT JOIN DOSS_SECTORS s on s.id = m.sector_id" +
			" LEFT JOIN DOSS_MODULE_DETAILS md on md.module_id = m.id " +
			" LEFT JOIN DOSS_AMENDABLE_MODULES am on am.module_id = md.module_id " +
			" where s.tenant_id = :tenantId " +
			" and m.id = :moduleId " +
			" and (:fl_amend_module IS NULL OR m.fl_amend_module = :fl_amend_module) " +
			" and :dt_validity between md.dt_validity_start and md.dt_validity_end " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between md.dt_insert and md.dt_delete ")
	@RegisterBeanMapper(ModuleWithDetailNTT.class)
	List<ModuleWithDetailNTT> findValidModulesWithDetailByModuleId(@Bind("tenantId") String tenant, @Bind("moduleId") Long moduleId,
																   @Bind("dt_validity") AbsoluteDate dtValidity,
																   @Bind("fl_amend_module") Integer flAmendModule, @Bind("lang") String lang);

	@SqlQuery("select m.id, " +
			"  m.module_code, " +
			"  m.sector_id, " +
			"  m.workflow_code, " +
			"  md.dt_validity_start, " +
			"  md.dt_validity_end, " +
			"  md.context_function, " +
			"  md.force_read_only_context_function, " +
			"  md.annuality, " +
			"  m.dt_insert, " +
			"  m.dt_delete, " +
			"  m.user_id_insert, " +
			"  m.user_id_delete, " +
			"  m.fl_amend_module," +
			"  §i18n(:tenantId, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  §i18n(:tenantId, 'doss_modules', 'module_code', m.module_code, :lang)§ as module_description," +
			" s.sector_code " +
			" from DOSS_MODULES m RIGHT JOIN DOSS_SECTORS s on s.id = m.sector_id" +
			" LEFT JOIN DOSS_MODULE_DETAILS md on md.module_id = m.id " +
			" where s.tenant_id = :tenantId " +
			" and m.id IN (<moduleIds>) " +
			" and (:fl_amend_module IS NULL OR m.fl_amend_module = :fl_amend_module) " +
			" and :dt_validity between md.dt_validity_start and md.dt_validity_end " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between md.dt_insert and md.dt_delete ")
	@RegisterBeanMapper(ModuleWithDetailNTT.class)
	List<ModuleWithDetailNTT> findModulesWithDetailByModuleIds(@Bind("tenantId") String tenant, @BindList("moduleIds") List<Long> moduleIds,
															   @Bind("dt_validity") AbsoluteDate dtValidity,
															   @Bind("fl_amend_module") Integer flAmendModule, @Bind("lang") String lang);

	@SqlQuery("select m.id, " +
			"  m.module_code, " +
			"  m.sector_id, " +
			"  m.workflow_code, " +
			"  md.dt_validity_start, " +
			"  md.dt_validity_end, " +
			"  md.context_function, " +
			"  md.force_read_only_context_function, " +
			"  md.annuality, " +
			"  m.dt_insert, " +
			"  m.dt_delete, " +
			"  m.user_id_insert, " +
			"  m.user_id_delete " +
			" from DOSS_MODULES m RIGHT JOIN DOSS_SECTORS s on s.id = m.sector_id" +
			" LEFT JOIN DOSS_MODULE_DETAILS md on md.module_id = m.id " +
			" where s.tenant_id = :tenantId " +
			" and m.sector_id = :sector_id")
	@RegisterBeanMapper(ModuleWithDetailNTT.class)
	List<ModuleWithDetailNTT> findAllModulesWithDetailBySectorId(@Bind("tenantId") String tenant, @Bind("sector_id") Long sectorId);


	@SqlQuery("select m.id, " +
			"  m.module_code, " +
			"  m.sector_id, " +
			"  m.workflow_code, " +
			"  md.dt_validity_start, " +
			"  md.dt_validity_end, " +
			"  md.context_function, " +
			"  md.force_read_only_context_function, " +
			"  md.annuality, " +
			"  m.dt_insert, " +
			"  m.dt_delete, " +
			"  m.user_id_insert, " +
			"  m.user_id_delete, " +
			"  m.fl_amend_module " +
			" from DOSS_MODULES m " +
			" JOIN DOSS_MODULE_DETAILS md on md.module_id = m.id " +
			" where m.id = :moduleId " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between md.dt_insert and md.dt_delete ")
	@RegisterBeanMapper(ModuleWithDetailNTT.class)
	List<ModuleWithDetailNTT> findModulesDetailById(@Bind("moduleId") Long moduleId);
}
