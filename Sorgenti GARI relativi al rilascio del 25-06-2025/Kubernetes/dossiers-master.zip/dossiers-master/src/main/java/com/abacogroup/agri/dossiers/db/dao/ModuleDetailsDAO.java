package com.abacogroup.agri.dossiers.db.dao;

import java.time.LocalDateTime;
import java.util.List;

import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import com.abacogroup.agri.dossiers.db.ntt.ModuleDetailsNTT;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateArgumentFactory;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateColumnMapper;

/**
 * @author Gennaro Tamburrelli
 * @author Alexandru Paraschiv
 * @author Rudy Barbieri
 */
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateColumnMapper.class)
public interface ModuleDetailsDAO extends IGenericHistoricizationFieldsDAO<ModuleDetailsNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_module_details_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_module_details (pkid, module_id, dt_validity_start, dt_validity_end, annuality, context_function, " +
			"force_read_only_context_function, " +
			"dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :module_id, :dt_validity_start, " +
			"       :dt_validity_end, :annuality, :context_function, :force_read_only_context_function, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ModuleDetailsNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"module_id, " +
			"dt_validity_start, " +
			"dt_validity_end, " +
			"annuality, " +
			"context_function, " +
			"force_read_only_context_function, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM doss_module_details " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ModuleDetailsNTT.class)
	List<ModuleDetailsNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE doss_module_details SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE doss_module_details SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE module_id = :moduleId " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByModuleId(@Bind("moduleId") Long id, @Bind("user_id_delete") String userDelete,
			@Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("SELECT md.pkid, " +
			"md.module_id, " +
			"md.dt_validity_start, " +
			"md.dt_validity_end, " +
			"md.annuality, " +
			"md.context_function, " +
			"md.force_read_only_context_function, " +
			"md.dt_insert, " +
			"md.dt_delete, " +
			"md.user_id_insert, " +
			"md.user_id_delete " +
			"FROM doss_module_details md left join doss_modules m on md.module_id = m.id " +
			"left join doss_sectors s on m.sector_id = s.id and s.tenant_id = :tenantId " +
			"WHERE module_id = :moduleId " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			"and §current_timestamp§ between md.dt_insert and md.dt_delete")
	@RegisterBeanMapper(ModuleDetailsNTT.class)
	List<ModuleDetailsNTT> findByModuleId(@Bind("tenantId") String tenantId, @Bind("moduleId") Long moduleId);

	@SqlQuery("SELECT md.pkid, " +
			"md.module_id, " +
			"md.dt_validity_start, " +
			"md.dt_validity_end, " +
			"md.annuality, " +
			"md.context_function, " +
			"md.force_read_only_context_function, " +
			"md.dt_insert, " +
			"md.dt_delete, " +
			"md.user_id_insert, " +
			"md.user_id_delete " +
			"FROM doss_module_details md left join doss_modules m on md.module_id = m.id " +
			"left join doss_sectors s on m.sector_id = s.id and s.tenant_id = :tenantId " +
			"WHERE module_id = :moduleId " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			"and §current_timestamp§ between md.dt_insert and md.dt_delete")
	@RegisterBeanMapper(ModuleDetailsNTT.class)
	List<ModuleDetailsNTT> findByDossierId(@Bind("tenantId") String tenantId, @Bind("moduleId") Long moduleId);

	@SqlQuery("SELECT md.pkid, " +
			"md.module_id, " +
			"md.dt_validity_start, " +
			"md.dt_validity_end, " +
			"md.annuality, " +
			"md.context_function, " +
			"md.force_read_only_context_function, " +
			"md.dt_insert, " +
			"md.dt_delete, " +
			"md.user_id_insert, " +
			"md.user_id_delete " +
			"FROM doss_module_details md left join doss_modules m on md.module_id = m.id " +
			"left join doss_sectors s on m.sector_id = s.id " +
			"WHERE m.module_code = :moduleCode " +
			"and s.tenant_id = :tenantId " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			"and §current_timestamp§ between md.dt_insert and md.dt_delete")
	@RegisterBeanMapper(ModuleDetailsNTT.class)
	List<ModuleDetailsNTT>  findByModuleCode(@Bind("tenantId") String tenantId, @Bind("moduleCode") String moduleCode);

	@SqlQuery("SELECT md.pkid, " +
			"md.module_id, " +
			"md.dt_validity_start, " +
			"md.dt_validity_end, " +
			"md.annuality, " +
			"md.context_function, " +
			"md.force_read_only_context_function, " +
			"md.dt_insert, " +
			"md.dt_delete, " +
			"md.user_id_insert, " +
			"md.user_id_delete " +
			"FROM apps_module_details md " +
			"WHERE md.pkid = :pkid " +
			"and §current_timestamp§ between md.dt_insert and md.dt_delete " +
			"and TO_CHAR(current_date, 'YYYYMMDD') between md.dt_validity_start and md.dt_validity_end")
	@RegisterBeanMapper(ModuleDetailsNTT.class)
	List<ModuleDetailsNTT> findByPkIdCheckingDtValidity(@Bind("pkid") Long pkId);
}
