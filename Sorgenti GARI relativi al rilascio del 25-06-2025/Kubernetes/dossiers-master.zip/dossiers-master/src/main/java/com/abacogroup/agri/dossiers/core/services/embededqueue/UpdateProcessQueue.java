package com.abacogroup.agri.dossiers.core.services.embededqueue;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.embededqueue.model.QueueWorkflowParams;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.workflow.sdk.beans.ProcessData;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.DELETE_FROM_QUEUE;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class UpdateProcessQueue extends WorkQueue<QueueWorkflowParams> {

	private DossiersWorkflowService dossiersWorkflowService;
	private DossierDetailsCrudService dossierDetailsCrudService;

	public UpdateProcessQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
							  DossiersWorkflowService dossiersWorkflowService, DossierDetailsCrudService dossierDetailsCrudService,
							  int numThreads, long timeoutMs) {
		super("app-update-process", repo, numThreads, timeoutMs);
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(this::consumer);
		this.setErrorListener(handleError);
		this.start();
	}

	public void executeTransition(QueueWorkflowParams queueWorkflowParams, ProcessData fatherProcessData) throws Exception {
		consumer(queueWorkflowParams, fatherProcessData);
	}

	@Override
	protected Class<QueueWorkflowParams> getJobClass() {
		return QueueWorkflowParams.class;
	}

	private void consumer(QueueWorkflowParams appParams) throws ObjectNotFoundException {
		consumer(appParams, null);
	}

	private void consumer(QueueWorkflowParams appParams, ProcessData fatherProcessData) throws ObjectNotFoundException {
		try {
			if (fatherProcessData != null) {
				dossiersWorkflowService
						.executeProcessTransitionWithFatherProcessData(appParams.getTenant(), appParams.getDossierId(), appParams.getProcessId(),
								appParams.getTransitionId(),
								appParams.getUsername(),
								appParams.getLocale(),
								appParams.getScope(),
								appParams.getNotes(),
								fatherProcessData);
			} else {
				dossiersWorkflowService
						.executeProcessTransition(appParams.getTenant(), appParams.getDossierId(), appParams.getProcessId(), appParams.getTransitionId(),
								appParams.getUsername(),
								appParams.getLocale(),
								appParams.getScope(),
								appParams.getNotes());
			}
		} catch (Exception e) {
			dossierDetailsCrudService.updateFlTransition(appParams.getTenant(), appParams.getDossierId(), appParams.getUsername(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);
			throw e;
		}
	}

	private final QueueErrorListener<QueueWorkflowParams> handleError = (appParams, exp) -> {
		try {
			dossierDetailsCrudService.updateFlTransition(appParams.getTenant(), appParams.getDossierId(), appParams.getUsername(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);
		} catch (ObjectNotFoundException e) {
			log.error(e.getMessage(), e);
		}
		return DELETE_FROM_QUEUE;
	};

}
