package com.abacogroup.agri.dossiers.core.exceptions;

public class AgriDossiersException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 748787262154109107L;

	public AgriDossiersException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public AgriDossiersException(String errorMessage) {
		super(errorMessage);
	}

	public AgriDossiersException(Throwable err) {
		super(err);
	}
}
