package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FormCatalogNTT implements IIdRs<Long> {

	private Long id;
	private String tenant_id;
	private String form_code;
	private String software_url;
	private String router_url;
	private String form_catalog_description;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getId());
	}

	@Override
	public void setKey(Long id) {
		setId(id);
	}
}
