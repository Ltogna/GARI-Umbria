package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierEnvNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * The interface Dossier env dao.
 *
 * @author Carlo Sindico
 */
public interface DossierEnvDAO extends IGenericDAO<DossierEnvNTT, DossierEnvKey> {

	@Override
	@SqlUpdate("INSERT INTO doss_config " +
			"(tenant_id, key, value, fl_client) " +
			"VALUES(:tenant_id, :key_, :value, :fl_client)")
	void insert(@BindBean DossierEnvNTT ntt);

	@Override
	@SqlUpdate("UPDATE doss_config SET " +
			"tenant_id=:tenant_id, " +
			"key=:key_, " +
			"value=:value, " +
			"fl_client=:fl_client " +
			"WHERE tenant_id=:tenant_id AND key=:key_ AND fl_client=:fl_client")
	void update(@BindBean DossierEnvNTT ntt);

	@Override
	@SqlUpdate("DELETE FROM doss_config " +
			"WHERE tenant_id=:tenant_id AND key=:key_ AND fl_client=:fl_client")
	void deleteById(@BindBean() DossierEnvKey key);

	@Override
	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM doss_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_ AND fl_client=:fl_client")
	@RegisterBeanMapper(DossierEnvNTT.class)
	List<DossierEnvNTT> findById(@BindBean DossierEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM doss_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_ AND ac.fl_client=:fl_client")
	@RegisterBeanMapper(DossierEnvNTT.class)
	DossierEnvNTT findByKey(@BindBean DossierEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM doss_config ac " +
			" WHERE ac.tenant_id=:tenant_id AND ac.key=:key_")
	@RegisterBeanMapper(DossierEnvNTT.class)
	DossierEnvNTT findByKeyWithoutFlClient(@BindBean DossierEnvKey key);

	@SqlQuery("SELECT ac.tenant_id, " +
			" ac.key as key_, " +
			" ac.value, " +
			" ac.fl_client " +
			" FROM doss_config ac " +
			" WHERE ac.tenant_id=:tenant")
	@RegisterBeanMapper(DossierEnvNTT.class)
	List<DossierEnvNTT> findAll(@Bind("tenant") String tenant);

}
