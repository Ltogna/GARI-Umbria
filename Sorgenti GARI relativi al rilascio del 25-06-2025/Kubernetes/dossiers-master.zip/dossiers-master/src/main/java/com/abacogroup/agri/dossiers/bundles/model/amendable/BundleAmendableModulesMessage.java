package com.abacogroup.agri.dossiers.bundles.model.amendable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Samuele Sbarbaro
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleAmendableModulesMessage {
	@Builder.Default
	private List<BundleAmendableModuleInDTO> amendableModules = new ArrayList<>();
}
