package com.abacogroup.agri.dossiers.core.model.dto;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierOutDTO {
	private DossierDTO dossier;
	private DossierDetailsDTO dossierDetail;
}
