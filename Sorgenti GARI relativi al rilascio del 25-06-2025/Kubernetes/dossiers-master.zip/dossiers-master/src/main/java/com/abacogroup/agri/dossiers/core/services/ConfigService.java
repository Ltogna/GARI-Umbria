package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierEnvPublicDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class ConfigService {

	private final DossierEnvCrudService dossierEnvCrudService;

	public ConfigService(DossierEnvCrudService dossierEnvCrudService) {
		this.dossierEnvCrudService = dossierEnvCrudService;
	}

	public List<DossierEnvPublicDTO> getConfig(final String tenant, final String searchKey) {
		return getConfig(tenant, searchKey, 1);

	}

	public List<DossierEnvPublicDTO> getConfig(final String tenant, final String searchKey, Integer flClient) {
		List<DossierEnvDTO> result = null;
		try {
			if (searchKey != null) {
				DossierEnvKey key = DossierEnvKey.builder()
						.tenant_id(tenant)
						.key_(searchKey)
						.fl_client(flClient)
						.build();

				return List.of(dossierEnvCrudService.findEnvironmentByKey(key))
						.stream()
						.map(env -> DossierEnvPublicDTO.builder()
								.key(env.getKey())
								.value(env.getValue())
								.build()
						)
						.collect(Collectors.toList());
			} else {
				result = dossierEnvCrudService.findAllByTenant(tenant);
			}

			return result.stream()
					.filter(env -> env.getFlClient() != 0)
					.map(env -> DossierEnvPublicDTO.builder()
							.key(env.getKey())
							.value(env.getValue())
							.build()
					)
					.collect(Collectors.toList());
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException();
		}
	}
}
