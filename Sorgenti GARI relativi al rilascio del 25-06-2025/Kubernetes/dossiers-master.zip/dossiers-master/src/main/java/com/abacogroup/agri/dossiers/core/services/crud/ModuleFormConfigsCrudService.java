package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModuleFormConfigsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleFormConfigsDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleFormConfigsDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigsNTT;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class ModuleFormConfigsCrudService extends AbstractCrudService<ModuleFormConfigsNTT, Long, ModuleFormConfigsDTO, ModuleFormConfigsMapper, Long> {

	private I18NService i18NService;

	public ModuleFormConfigsCrudService(ModuleFormConfigsDAO dao, ModuleFormConfigsMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	public List<ModuleFormConfigsDTO> findAllModuleFormConfigs(String tenantId) {
		return returnMappedList(((ModuleFormConfigsDAO) this.dao).findAllModuleFormConfigsByTenant(tenantId));
	}

	public List<ModuleFormConfigsDTO> findAllModuleFormConfigs(String tenantId, Long moduleId) {
		return returnMappedList(((ModuleFormConfigsDAO) this.dao).findAllModuleFormConfigs(tenantId, moduleId));
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<ModuleFormConfigsNTT> findRsByCustomKey(Long customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(ModuleFormConfigsNTT rs, Long customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public ModuleFormConfigsDTO insert(ModuleFormConfigsDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public ModuleFormConfigsDTO update(Long key, ModuleFormConfigsDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public ModuleFormConfigsDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleFormConfigsDAO) this.dao).findById(tenant, id))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	/**
	 * find module config filtered by dossier profiles, compile status, process status
	 *
	 * @param tenant
	 * @param moduleId
	 * @param processStatus
	 * @param profileCodeList
	 * @return
	 */
	public List<ModuleFormConfigsDTO> find(String tenant, Long moduleId, String processStatus, List<String> profileCodeList) {
		return ((ModuleFormConfigsDAO) this.dao).find(tenant, moduleId, processStatus, profileCodeList)
				.stream()
				.map(this.mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ModuleFormConfigsDTO> find(String tenant, Long moduleId, String processStatus, String contextFunction) {
		return ((ModuleFormConfigsDAO) this.dao).find(tenant, moduleId, processStatus, contextFunction)
				.stream()
				.map(this.mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public void bulkDeleteByModuleId(Long moduleId) {
		((ModuleFormConfigsDAO) this.dao).bulkDeleteByModuleId(moduleId);
	}
}
