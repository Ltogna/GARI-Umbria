package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LastPrintDTO {

	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@Schema(description = "the print date")
	private LocalDateTime printDate;
	@Schema(description = "the print file id for download")
	private String fileId;

}
