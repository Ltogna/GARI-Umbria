package com.abacogroup.agri.dossiers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierByPartyAndYearNTT {
	private Long party_id;
	private Integer referred_year;
	private String sector_code;
	private String sector_description;
	private String module_code;
	private String module_description;
	private String dossier_code;
	private Long dossier_id;
	private String process_status;
	private Long process_id;
	private LocalDate dt_closed;
	private String context_function;

}
