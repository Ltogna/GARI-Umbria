package com.abacogroup.agri.dossiers.resources;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.ProgressTypeEnum;
import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.*;
import com.abacogroup.agri.dossiers.core.services.AmendmentService;
import com.abacogroup.agri.dossiers.core.services.DossiersService;
import com.abacogroup.agri.dossiers.core.services.ConfigService;
import com.abacogroup.agri.dossiers.core.services.FormConfigService;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl.AnomalyHandlerImpl;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;
import com.abacogroup.workflow.server.model.Transition;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.validation.Valid;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;
import org.slf4j.MDC;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Timed
@Path("/{tenant}/api-priv/v1/")
@PermitAll
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RolesAllowed("DOSSIERS|USER")
public class DossiersPrivateResources {

	public static final String MODULES_PRIVATE_RESOURCES = "Modules Private Resources";
	public static final String DOSSIERS_PRIVATE_RESOURCES = "Dossiers Private Resources";
	public static final String ANOMALIES_TAG = "Anomalies Private Resources";
	public static final String AMENDMENT_TAG = "Amendment Private Resources";
	public static final String DOSSIERS_RESOURCES_SCOPE = "dossiers";

	private final DossiersService dossiersService;
	private final ConfigService configService;
	private final FormConfigService formConfigService;
	private final PrintService printService;
	private final AnomalyHandlerImpl anomalyHandler;
	private final AmendmentService amendmentService;

	public DossiersPrivateResources(DossiersService dossiersService,
									ConfigService configService, FormConfigService formConfigService, PrintService printService,
									AnomalyHandlerImpl anomalyHandler, AmendmentService amendmentService) {
		this.dossiersService = dossiersService;
		this.configService = configService;
		this.formConfigService = formConfigService;
		this.printService = printService;
		this.anomalyHandler = anomalyHandler;
		this.amendmentService = amendmentService;
	}

	@GET
	@Path("/modules")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No modules found at date - ErrCode: NO_MODULES_FOUND_AT_DATE")
	public InfiniteListResults<ModuleByPointInTimeDTO> getModulesByPointInTime(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The absolute date used in search, if null or empty, will be calculated as today") @QueryParam("point_in_time") AbsoluteDate pointInTime,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "The amend flag") @QueryParam("flAmend") @DefaultValue("0") Integer flAmend,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getModulesByPointInTime(tenant, pointInTime, flAmend, nextKey, sc);
	}

	@GET
	@Path("/all-modules")
	@Operation(description = "Returns the list of all modules", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The modules list")
	public List<ModuleByPointInTimeDTO> getModules(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The absolute date used in search, if null or empty, will be calculated as today") @QueryParam("point_in_time") AbsoluteDate pointInTime,
			@Parameter(description = "The amend flag") @QueryParam("flAmend") @DefaultValue("0") Integer flAmend,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getModulesByPointInTime(tenant, pointInTime, flAmend, sc);
	}

	@GET
	@Path("/sectors/{sector_code}/modules/{module_code}/profiles")
	@Operation(description = "Returns the list of modules, given the date", tags = { MODULES_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of modules")
	@ApiResponse(responseCode = "404", description = "No profiles with sector and module code, at date - " +
			"ErrCode: NO_PROFILES_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE")
	public InfiniteListResults<ModuleProfilePublicDTO> getModuleProfilesBySectorCodeAndModuleCode(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The sector code") @PathParam("sector_code") String sectorCode,
			@Parameter(description = "The module code") @PathParam("module_code") String moduleCode,
			@Parameter(description = "The absolute date used in search, if null or empty, will be calculated as today") @QueryParam("point_in_time") AbsoluteDate pointInTime,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getProfilesByModuleAndSector(tenant, sectorCode, moduleCode, pointInTime, nextKey);
	}

	@GET
	@Path("/dossiers/environments")
	@Operation(description = "Returns the list of environment configs, given the environment name", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of environment configs")
	@ApiResponse(responseCode = "404", description = "No environment found - ErrCode: ENVIRONMENT_NOT_FOUND_ERROR")
	public List<DossierEnvPublicDTO> getEnvironments(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
													 @Parameter(description = "Environment name", required = false) @QueryParam("environment") String environment,
													 @Parameter(hidden = true) @Auth User user,
													 @Context SecurityContext sc) {
		return configService.getConfig(tenant, environment);
	}

	@GET
	@Path("/dossiers/{dossier_id}")
	@Operation(description = "Returns the detail of the dossier", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The detail of the dossier")
	@ApiResponse(responseCode = "404", description = "No dossier found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Workflow generic error - ErrCode: WORKFLOW_GENERIC_ERROR")
	public DossierWithDetailsDTO getDossierDetail(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
												  @Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
												  @Parameter(hidden = true) @Auth User user,
												  @Context SecurityContext sc) {
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);

		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());

		res.setForms(formConfigService
				.getFormsByModuleIdAndProcessStatus(tenant,
						res.getModuleId(),
						res.getProcessStatus(),
						res.getCompileStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc,
						MDC.get(MDCPreFilter.LOCALE)));
		res.setPrints(dossiersService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						dossierId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc));
		res.setOriginalAmendedDossierId(amendmentService.getOriginalAmendedDossierId(res, tenant));
		return res;
	}

	@GET
	@Path("/dossiers/parties/{partyId}/summary")
	@Operation(description = "Returns the list of years and dossiers count of a party, given his id", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of years and dossiers count")
	@ApiResponse(responseCode = "400", description = "If partyId is not specified as query parameter")
	@ApiResponse(responseCode = "404", description = "No dossiers found - ErrCode: NO_DOSSIER_SUMMARY_FOUND")
	public DossiersSummaryByYearOutDTO getDossiersSummary(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "the Party Id") @PathParam("partyId") Long partyId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersSummaryByYear(tenant, partyId, user);
	}

	@POST
	@Path("/dossiers-async")
	@Operation(description = "Creates a new dossier", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateDossierOutDTO createDossierAsync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateDossierInDTO payload,
			@Context SecurityContext sc) {
		return dossiersService.createDossierAsync(tenant, user, payload);
	}

	@POST
	@Path("/dossiers-async/amendment-dossier")
	@Operation(description = "Creates a new dossier", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier code created and the anomalies found")
	@ApiResponse(responseCode = "409", description = "At least one severe anomaly occurred")
	public CreateAmendmentDossierOutDTO createAmendmentDossierAsync(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@Valid CreateDossierInDTO payload,
			@Context SecurityContext sc) {
		return dossiersService.createAmendmentDossierAsync(tenant, user, payload);
	}

	@GET
	@Path("/dossiers/parties/{partyId}")
	@Operation(description = "Returns the list of dossiers, given the party id, the optional flag 'closed' and the optional type list" , tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for party - ErrCode: NO_DOSSIERS_FOUND_BY_PARTY")
	public InfiniteListResults<DossierByPartyDTO> getDossiersByParty(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(description = "Filter by closed status", in = ParameterIn.QUERY) @QueryParam("includeClosed") Boolean includeClosed,
			@Parameter(description = "Filter by type list", in = ParameterIn.QUERY) @QueryParam("typeList") List<String> typeList,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersByParty(tenant, partyId, (includeClosed != null && includeClosed == true) ? 1 : 0, typeList, nextKey, user, sc);
	}

	@GET
	@Path("/dossiers/parties/{partyId}/years/{year}")
	@Operation(description = "Returns the list of dossiers, given the party id and the year", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The list of dossiers")
	@ApiResponse(responseCode = "404", description = "No dossiers found for party or year - ErrCode: NO_DOSSIERS_FOUND_BY_PARTY_AND_YEAR")
	public InfiniteListResults<DosByPartyAndYearDTO> getDossiersByPartyAndYear(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The specific party id") @PathParam("partyId") Long partyId,
			@Parameter(description = "The specific year") @PathParam("year") Integer year,
			@Parameter(description = "Next key for infinite list") @QueryParam("nextKey") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossiersByPartyAndYear(tenant, partyId, year, nextKey, user, sc);
	}

	@GET
	@Path("/dossiers/{dossier_id}/history")
	@Operation(description = "Returns the dossier's history, given the dossier id", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier's history")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<DetailedTransitionLog> getHistoryByDossierCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getDossierHistoryByDossierId(tenant, dossierId, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}/print-history")
	@Operation(description = "Returns the dossier's prints, given the dossier id", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier's generated prints")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<DossierGeneratedPrintDTO> getPrintsByDossierCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
																 @Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
																 @Parameter(hidden = true) @Auth User user,
																 @Context SecurityContext sc) {
		return dossiersService.getDossierPrintsByDossierId(tenant, dossierId, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}/on-going-prints")
	@Operation(description = "Returns the dossier's print job status list, given the dossier id", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier's generated prints")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<DossierGeneratedPrintDTO> getOngoingPrints(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
														   @Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
														   @Parameter(hidden = true) @Auth User user,
														   @Context SecurityContext sc) {
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = dossiersService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						dossierId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return dossiersService
				.checkForOngoingPrints(tenant, dossierId, modulesPrint.stream().map(PrintDetailsOutDTO::getPrintCode).collect(Collectors.toList()));
	}

	@POST
	@Path("/dossiers/{dossier_id}/prints/{print_code}")
	@Operation(description = "Start the creation print job", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The dossier's generated prints")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public DossierGeneratedPrintDTO createPrintJob(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
												   @Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
												   @Parameter(description = "The print code to print") @PathParam("print_code") String printCode,
												   @Parameter(hidden = true) @Auth User user,
												   @Context SecurityContext sc) {
		var res = dossiersService.getDossierWithDetailsById(tenant, dossierId, user, sc);
		List<String> requiredProfileCodes = res.getProfileList()
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());
		List<PrintDetailsOutDTO> modulesPrint = dossiersService
				.getPrintsByModuleIdAndProcessStatus(tenant,
						dossierId,
						res.getModuleId(),
						res.getProcessStatus(),
						requiredProfileCodes.isEmpty() ? new ArrayList<>(List.of("")) : requiredProfileCodes,
						sc);
		return printService
				.startPrintJob(tenant, dossierId, res.getPartyId(), res.getProcessStatus(), modulesPrint, printCode, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}/prints/{file_id}")
	@Produces({ MediaType.APPLICATION_OCTET_STREAM, MediaType.APPLICATION_JSON })
	@Operation(description = "Returns the generated print ", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The attached file")
	public Response getAttachment(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The attachment id") @PathParam("file_id") String fileId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return printService.getPrintFromFileStore(tenant, dossierId, fileId, user);
	}

	@GET
	@Path("/dossiers/{dossier_id}/transitions")
	@Operation(description = "Returns the dossier's available transitions, given the dossier code", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The available transitions")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public List<Transition> getAvailableTransitionByDossierCode(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return dossiersService.getAvailableTransitionListByProcessId(tenant, dossierId, user, DOSSIERS_RESOURCES_SCOPE);
	}

	@GET
	@Path("/dossiers/{dossier_id}/is-in-transition")
	@Operation(description = "Returns the dossier' in transition flag", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The current flag")
	@ApiResponse(responseCode = "404", description = "Dossier does not exists - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	public DossierInTransitionDTO getDossierTransitionFlag(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
														   @Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
														   @Parameter(hidden = true) @Auth User user,
														   @Context SecurityContext sc) {
		return dossiersService.getDossierInTransition(tenant, dossierId, user);
	}

	@PATCH
	@Path("/dossiers/{dossier_id}/progress/{transition_id}")
	@Operation(description = "Updates the process status of the dossier", tags = { DOSSIERS_PRIVATE_RESOURCES })
	@ApiResponse(description = "The process status of the task instance has been updated")
	@ApiResponse(responseCode = "404", description = "Dossier not found - ErrCode: DOSSIER_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "404", description = "Transition not found - ErrCode: TRANSITION_NOT_FOUND_ERROR")
	@ApiResponse(responseCode = "500", description = "Error progressing Dossier - errorCode: PROGRESS_WORKFLOW_ERROR")
	public Response progressDossier(ProgressDossierDTO payload,
									@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
									@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
									@Parameter(description = "Id of the transition") @PathParam("transition_id") Integer transitionId,
									@Parameter(hidden = true) @Auth User user,
									@Context SecurityContext sc) throws Exception {
		dossiersService.progress(tenant, dossierId, transitionId, user, DOSSIERS_RESOURCES_SCOPE, payload, ProgressTypeEnum.ASYNC);
		return Response.ok().build();
	}

	@GET
	@Path("/dossiers/{dossier_id}/anomalies")
	@Operation(description = "Returns the list of dossier's anomalies", tags = { ANOMALIES_TAG })
	@ApiResponse(description = "The list of dossier's compile statuses")
	public List<AnomalyDTO> getDossierCompileStatusById(
			@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(hidden = true) @Auth User user) {
		return anomalyHandler.getAnomaliesForApp(tenant, dossierId);
	}

	@GET
	@Path("/dossiers/{dossier_id}/amendment/modules")
	@Operation(description = "Returns the list of amendable modules", tags = { AMENDMENT_TAG })
	@ApiResponse(description = "The list of amendable modules")
	public InfiniteListResults<ModuleWithDetailDTO> getAmendmentModules(@Parameter(description = "Current Tenant") @PathParam("tenant") String tenant,
			@Parameter(description = "The dossier id") @PathParam("dossier_id") Long dossierId,
			@Parameter(description = "The next key") @QueryParam("next_key") String nextKey,
			@Parameter(hidden = true) @Auth User user,
			@Context SecurityContext sc) {
		return amendmentService.getAmendmentModules(tenant, dossierId, nextKey, sc);
	}
}
