package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoProfilesFoundAtDateRuntimeException extends AbstractException {

	private static final NoProfilesFoundAtDateRuntimeException.ErrorBody BODY = new NoProfilesFoundAtDateRuntimeException.ErrorBody();

	public NoProfilesFoundAtDateRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoProfilesFoundAtDateRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No modules found");
	}

	@Schema(name = "NoProfilesFoundAtDateRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_PROFILES_FOUND_WITH_SECTOR_AND_MODULE_AT_DATE";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
