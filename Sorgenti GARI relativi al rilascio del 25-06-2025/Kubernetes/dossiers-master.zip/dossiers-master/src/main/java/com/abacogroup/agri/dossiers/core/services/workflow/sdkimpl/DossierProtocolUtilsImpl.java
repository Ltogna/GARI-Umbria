package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierProtocolsDTO;
import com.abacogroup.agri.dossiers.core.services.HistoryService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierGeneratedPrintCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProtocolsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.DetailedSdkTransitionLog;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProtocol;
import com.abacogroup.applicationworkflowsdk.service.ApplicationProtocolUtils;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierProtocolUtilsImpl implements ApplicationProtocolUtils {

	private final DossiersCrudService dossiersCrudService;
	private final DossierProtocolsCrudService dossierProtocolsCrudService;
	private final DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService;
	private final HistoryService historyService;

	public DossierProtocolUtilsImpl(DossiersCrudService dossiersCrudService,
			DossierProtocolsCrudService dossierProtocolsCrudService,
			DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService, HistoryService historyService) {
		this.dossiersCrudService = dossiersCrudService;
		this.dossierProtocolsCrudService = dossierProtocolsCrudService;
		this.dossierGeneratedPrintCrudService = dossierGeneratedPrintCrudService;
		this.historyService = historyService;
	}

	@Override
	public String retrievePrintId(String tenant, Long dossierId, String printCode, User user) {
		return this.dossierGeneratedPrintCrudService.findAllGeneratedPrints(tenant, dossierId)
				.stream()
				.filter(x -> printCode == null || x.getPrintCode().equals(printCode))
				.max(Comparator.comparing(DossierGeneratedPrintDTO::getPrintDate))
				.map(DossierGeneratedPrintDTO::getFileId)
				.orElseThrow(() -> new RuntimeException("print not found"));
	}

	@Override public List<DetailedSdkTransitionLog> retrieveHistoryLog(String s, Long aLong, User user) {
		return historyService.getApplicationHistoryByApplicationId(s, aLong, user)
				.stream()
				.map(x -> DetailedSdkTransitionLog.builder()
						.id(x.getId())
						.startDate(x.getStartDate())
						.endDate(x.getEndDate())
						.userId(x.getUserId())
						.processId(x.getProcessId())
						.transitionId(x.getTransitionId())
						.notes(x.getNotes())
						.failed(x.isFailed())
						.description(x.getDescription())
						.fromNode(x.getFromNode())
						.fromNodeDescription(x.getFromNodeDescription())
						.toNode(x.getToNode())
						.toNodeDescription(x.getToNodeDescription())
						.messages(x.getMessages())
						.build())
				.collect(Collectors.toList());
	}

	@Override
	public String retrieveSectorDescription(String tenant, Long dossierId, User user, String locale) {
		var appDetails = this.dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId, locale);
		return appDetails.getSectorDescription();
	}

	@Override
	public String retrieveModuleDescription(String tenant, Long dossierId, User user, String locale) {
		var appDetails = this.dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId, locale);
		return appDetails.getModuleDescription();
	}

	@Override
	public void insertProtocolRequest(String tenant, Long dossierId, User user) {
		dossierProtocolsCrudService.insert(DossierProtocolsDTO.builder()
				.dossierId(dossierId)
				.dtRequest(LocalDateTime.now())
				.build(), user.getName());
	}

	@Override public void insertProtocolCodeAndDate(String tenant, Long dossierId, String protocolCode, LocalDateTime protocolDate, User user) {
		DossierProtocolsDTO protocol = dossierProtocolsCrudService.findAll(tenant, dossierId).stream().findFirst()
				.orElseThrow();
		protocol.setProtocol(protocolCode);
		protocol.setDtResponse(protocolDate != null ? protocolDate : LocalDateTime.now());
		dossierProtocolsCrudService.update(protocol.getPkid(), protocol, user.getName());
	}

	@Override
	public Optional<ApplicationProtocol> retrieveProtocol(String tenant, Long applicationId) {
		return dossierProtocolsCrudService.findAll(tenant, applicationId)
				.stream()
				.filter(x -> x.getProtocol() != null)
				.findFirst()
				.map(x -> ApplicationProtocol.builder()
						.applicationId(x.getDossierId())
						.protocol(x.getProtocol())
						.dtRequest(x.getDtRequest())
						.dtResponse(x.getDtResponse())
						.build());
	}

}
