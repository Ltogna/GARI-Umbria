package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.abacogroup.agri.dossiers.core.model.dto.DossiersSummaryByYearDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossiersSummaryByYearOutDTO {
	private Long partyId;

	@Builder.Default
	private List<DossiersSummaryByYearDTO> dossiersSummaryByYear = new ArrayList<>();
}
