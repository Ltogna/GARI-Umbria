package com.abacogroup.agri.dossiers.bundles.processor.env;

import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvInDTO;
import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvMessage;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.bundles.listener.tenant.TenantMessage;
import com.abacogroup.bundles.listener.tenant.TenantMessageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.List;
import java.util.stream.Collectors;

import static com.abacogroup.agri.dossiers.bundles.BundleConstants.TENANT_TEMPLATE_CODE;

/**
 * The type Dossier env new tenant processor.
 * @author Carlo Sindico
 */
@Slf4j
public class DossierEnvNewTenantProcessor implements TenantMessageProcessor {

    protected final Jdbi jdbi;
    protected final DossierEnvBundleWorker dossierEnvBundleWorker;
    public DossierEnvNewTenantProcessor(Jdbi jdbi, DossierEnvBundleWorker dossierEnvBundleWorker) {
        this.jdbi = jdbi;
        this.dossierEnvBundleWorker = dossierEnvBundleWorker;
    }

    @Override
    public void onMessage(TenantMessage message) {
        jdbi.useTransaction(handle -> {
            log.info("DossierEnvNewTenantProcessor got new tenant {}", message.getTenantId());
            checkAndInsertDossierEnvironments(message.getTenantId());
            log.info("DossierEnvNewTenantProcessor end working with new tenant {}", message.getTenantId());
        });
    }

    private void checkAndInsertDossierEnvironments(final String tenantId) {
        log.info("DossierEnvNewTenantProcessor check and insert new tenant {}", tenantId);
        DossierEnvCrudService dossierEnvCrudService = dossierEnvBundleWorker.exposeDossierEnvCrudService();

        List<DossierEnvDTO> environmentDTOs = dossierEnvCrudService.findAllByTenant(TENANT_TEMPLATE_CODE);

        List<BundleDossierEnvInDTO> bundleDossierEnvInDTOs = environmentDTOs.stream()
                .map(env -> BundleDossierEnvInDTO.builder()
                        .key(env.getKey())
                        .value(env.getValue())
                        .flClient(env.getFlClient())
                        .build())
                .collect(Collectors.toList());

        dossierEnvBundleWorker.upsertDossierEnvironments(tenantId,
                BundleDossierEnvMessage.builder()
                        .bundleDossierEnvInDTOList(bundleDossierEnvInDTOs)
                        .build()
        );
    }
}
