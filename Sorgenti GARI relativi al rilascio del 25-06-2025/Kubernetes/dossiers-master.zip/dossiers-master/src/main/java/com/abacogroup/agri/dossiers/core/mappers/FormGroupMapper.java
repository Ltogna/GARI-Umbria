package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.FormGroupDTO;
import com.abacogroup.agri.dossiers.db.ntt.FormGroupNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface FormGroupMapper extends EntityMapper<FormGroupDTO, FormGroupNTT> {

	FormGroupMapper INSTANCE = Mappers.getMapper(FormGroupMapper.class);

	@InheritInverseConfiguration()
	FormGroupDTO entityToDto(FormGroupNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "tenantId", target = "tenant_id")
	@Mapping(source = "formGroupCode", target = "form_group_code")
	@Mapping(source = "parentFormGroupId", target = "parent_form_group_id")
	@Mapping(source = "formGroupDescription", target = "form_group_desc")
	FormGroupNTT dtoToEntity(FormGroupDTO dto);

}
