package com.abacogroup.agri.dossiers.resources;

import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.codahale.metrics.annotation.Timed;
import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.glassfish.jersey.media.multipart.FormDataParam;

import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.io.InputStream;

@Timed
@Path("{tenant}/api-priv/v1/workflow")
@PermitAll
@Slf4j
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@RolesAllowed("APPLICATIONS|USER")
public class WorkflowResources {

	public static final String DOSSIERS_WORKFLOW_RESOURCES = "Dossiers Workflow Private Resources";

	private final DossiersWorkflowService dossiersWorkflowService;

	public WorkflowResources(DossiersWorkflowService dossiersWorkflowService) {
		this.dossiersWorkflowService = dossiersWorkflowService;
	}

	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Operation(description = "This method consent to install a new workflow", tags = { DOSSIERS_WORKFLOW_RESOURCES })
	@ApiResponse(responseCode = "200", description = "Workflow has been installed")
	@ApiResponse(responseCode = "500", description = "Error installing workflow - errorCode: ADD_OR_UPDATE_WORKFLOW_ERROR")
	public Response installWorkflow(@PathParam("tenant") String tenant,
			@Parameter(hidden = true) @Auth User user,
			@FormDataParam("file") InputStream inputStream) {

		dossiersWorkflowService.addOrUpdateWorkflowFromInputStream(tenant, inputStream);
		return Response.noContent()
				.status(Response.Status.OK)
				.build();
	}

}
