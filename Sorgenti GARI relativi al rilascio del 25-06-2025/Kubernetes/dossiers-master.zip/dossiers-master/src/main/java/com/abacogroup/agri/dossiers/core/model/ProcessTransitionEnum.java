package com.abacogroup.agri.dossiers.core.model;

/**
 * @author Gennaro Tamburrelli
 */
public enum ProcessTransitionEnum {
	IN_TRANSITION(1),
	NOT_IN_TRANSITION(0);

	private final int fl;

	ProcessTransitionEnum(int i) {
		this.fl = i;
	}

	public int getFl() {
		return fl;
	}
}
