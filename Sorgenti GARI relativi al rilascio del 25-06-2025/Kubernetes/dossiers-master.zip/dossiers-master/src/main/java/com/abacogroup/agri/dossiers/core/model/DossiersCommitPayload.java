package com.abacogroup.agri.dossiers.core.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DossiersCommitPayload {
    @NotNull
    private String tenant;

    @NotNull
    private Long partyId;

    @NotNull
    private String dossierSectorCode;

    @NotNull
    private String dossierModuleCode;

    @NotNull
    private Long dossierId;

    @NotNull
    private LocalDateTime transitionDate;

    @NotNull
    private String currentNode;

    @NotNull
    private String username;
}
