package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.services.crud.DossierCompileStatusCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.service.CheckCompileStatus;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public class CheckCompileStatusImpl implements CheckCompileStatus {

	private final DossierCompileStatusCrudService dossierCompileStatusCrudService;

	public CheckCompileStatusImpl(DossierCompileStatusCrudService dossierCompileStatusCrudService) {
		this.dossierCompileStatusCrudService = dossierCompileStatusCrudService;
	}

	@Override public List<ApplicationCompileStatusDTO> getStatuses(String tenant, Long dossierId) {
		return this.dossierCompileStatusCrudService.find(tenant, dossierId);
	}
}
