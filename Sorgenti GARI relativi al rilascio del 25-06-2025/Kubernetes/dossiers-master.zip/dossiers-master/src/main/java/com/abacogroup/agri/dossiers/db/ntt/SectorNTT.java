package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SectorNTT implements IIdRs<Long> {

	private Long id;
	private String tenant_id;
	private String sector_code;
	private String description;

	@Override
	public void setKey(Long id) {
		this.id = id;
	}

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(this.id);
	}
}
