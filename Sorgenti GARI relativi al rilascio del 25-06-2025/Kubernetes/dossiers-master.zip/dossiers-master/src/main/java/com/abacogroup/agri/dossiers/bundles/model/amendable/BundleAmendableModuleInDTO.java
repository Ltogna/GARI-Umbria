package com.abacogroup.agri.dossiers.bundles.model.amendable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Samuele Sbarbaro
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleAmendableModuleInDTO {
	private String moduleCode;
	private String amendableModuleCode;
}
