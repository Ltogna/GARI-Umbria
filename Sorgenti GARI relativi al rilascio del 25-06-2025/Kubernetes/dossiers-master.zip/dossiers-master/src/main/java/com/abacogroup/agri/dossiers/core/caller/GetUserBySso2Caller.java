package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;

/**
 * @author Alexandru Paraschiv
 */
public class GetUserBySso2Caller extends AbacoDtoCaller<GetUserByTenant, Void> {

	public GetUserBySso2Caller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
