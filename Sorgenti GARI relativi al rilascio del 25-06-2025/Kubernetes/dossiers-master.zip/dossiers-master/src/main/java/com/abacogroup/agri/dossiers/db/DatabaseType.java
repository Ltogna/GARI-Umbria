package com.abacogroup.agri.dossiers.db;

public enum DatabaseType {
	POSTGRES,
	ORACLE;
}
