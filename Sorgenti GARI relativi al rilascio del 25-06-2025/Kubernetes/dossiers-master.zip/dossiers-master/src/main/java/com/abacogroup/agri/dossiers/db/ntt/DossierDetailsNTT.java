package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IHistoricizationFields;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierDetailsNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long pkid;
	private Long dossier_id;
	private String dossier_code;
	private String process_status;
	private LocalDateTime dt_presentation;
	private LocalDateTime dt_closed;
	private Long amended_by_id;
	private Long amend_of_id;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;
	private Integer fl_in_transition;

	@Override public void setKey(Long id) {
		this.pkid = id;
	}

	@Override public Optional<Long> getKey() {
		return Optional.ofNullable(this.pkid);
	}
}
