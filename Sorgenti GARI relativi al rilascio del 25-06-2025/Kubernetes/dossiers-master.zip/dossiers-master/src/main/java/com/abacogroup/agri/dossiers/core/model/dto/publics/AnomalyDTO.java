package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AnomalyDTO {
	private Long pkid;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long dossierId;
	@Schema(description = "the anomaly's code")
	private String anomalyCode;
	@Schema(description = "the anomaly's description")
	private String anomalyDesc;
	@Schema(description = "the anomaly's severity")
	private String severity;
	@Schema(description = "the anomaly's creation date")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtInsert;
}
