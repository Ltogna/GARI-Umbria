package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.db.ntt.ModuleProfileNTT;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateArgumentFactory;
import com.abacogroup.agri.dossiers.db.ntt.mappers.AbsoluteDateColumnMapper;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterArgumentFactory;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.config.RegisterColumnMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
@RegisterArgumentFactory(AbsoluteDateArgumentFactory.class)
@RegisterColumnMapper(AbsoluteDateColumnMapper.class)
public interface ModuleProfileDAO extends IGenericHistoricizationFieldsDAO<ModuleProfileNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_module_profiles_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_module_profiles (pkid, module_id, profile_code, dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :module_id, :profile_code, :current_timestamp, " +
			"TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean ModuleProfileNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"module_id, " +
			"profile_code, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM doss_module_profiles " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(ModuleProfileNTT.class)
	List<ModuleProfileNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT mp.pkid, " +
			"mp.module_id, " +
			"mp.profile_code, " +
			"§i18n(:tenantId, 'doss_module_profiles', 'profile_code', mp.profile_code, :lang)§ as profile_code_description, " +
			"mp.dt_insert, " +
			"mp.dt_delete, " +
			"mp.user_id_insert, " +
			"mp.user_id_delete " +
			"FROM doss_module_profiles mp " +
			"LEFT JOIN doss_modules m ON mp.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE mp.module_id = :module_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between mp.dt_insert and mp.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ModuleProfileNTT.class)
	List<ModuleProfileNTT> findByModuleId(@Bind("tenantId") String tenant, @Bind("module_id") Long moduleId, @Bind("lang") String lang);

	@SqlQuery("SELECT mp.pkid, " +
			"mp.module_id, " +
			"mp.profile_code, " +
			"mp.dt_insert, " +
			"mp.dt_delete, " +
			"mp.user_id_insert, " +
			"mp.user_id_delete " +
			"FROM doss_module_profiles mp " +
			"LEFT JOIN doss_modules m ON mp.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE mp.module_id = :module_id AND s.tenant_id = :tenantId " +
			"AND mp.profile_code = :profileCode " +
			"AND §current_timestamp§ BETWEEN mp.dt_insert and mp.dt_delete")
	@RegisterBeanMapper(ModuleProfileNTT.class)
	List<ModuleProfileNTT> findByModuleIdAndProfileCode(@Bind("tenantId") String tenant, @Bind("module_id") Long moduleId,
			@Bind("profileCode") String profile_code);

	@SqlQuery("SELECT mp.pkid, " +
			"mp.module_id, " +
			"mp.profile_code, " +
			"§i18n(:tenantId, 'doss_module_profiles', 'profile_code', mp.profile_code, :lang)§ as profile_code_description, " +
			"mp.dt_insert, " +
			"mp.dt_delete, " +
			"mp.user_id_insert, " +
			"mp.user_id_delete " +
			"FROM doss_module_profiles mp " +
			"LEFT JOIN doss_modules m ON mp.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"LEFT JOIN doss_module_details md ON m.id = md.module_id " +
			"WHERE m.module_code = :module_code AND s.tenant_id = :tenantId " +
			"AND s.sector_code = :sector_code " +
			"AND :point_in_time BETWEEN md.dt_validity_start AND md.dt_validity_end " +
			"AND §current_timestamp§ BETWEEN mp.dt_insert and mp.dt_delete " +
			"AND §current_timestamp§ BETWEEN md.dt_insert and md.dt_delete " +
			"AND §current_timestamp§ BETWEEN m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(ModuleProfileNTT.class)
	ResultIterator<ModuleProfileNTT> find(@Bind("tenantId") String tenant, @Bind("sector_code") String sectorCode,
			@Bind("module_code") String moduleCode, @Bind("point_in_time") AbsoluteDate pointInTime, @Bind("lang") String lang);

	@Override
	@SqlUpdate("UPDATE doss_module_profiles SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE doss_module_profiles SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE module_id = :moduleId " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteByModuleId(@Bind("moduleId") Long moduleId, @Bind("user_id_delete") String userDelete,
			@Bind("current_timestamp") LocalDateTime currentTimestamp);
}
