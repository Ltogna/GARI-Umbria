package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierDTO {
	@Schema(description = "The dossier id")
	private Long dossierId;
	@Schema(description = "the party id related to current dossier")
	private Long partyId;
	@Schema(description = "the dossier's referred year")
	private Integer referredYear;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long moduleId;
	@Schema(description = "the dossier's workflow process id")
	private Long processId;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String userIdDelete;
	@Schema(description = "the dossier's date of creation")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtInsert;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtDelete;
}
