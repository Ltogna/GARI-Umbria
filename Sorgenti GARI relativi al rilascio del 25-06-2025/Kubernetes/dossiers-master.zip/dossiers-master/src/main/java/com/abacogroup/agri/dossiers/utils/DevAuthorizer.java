package com.abacogroup.agri.dossiers.utils;

import io.dropwizard.auth.Authorizer;
import jakarta.annotation.Priority;
import jakarta.ws.rs.container.ContainerRequestContext;

import java.security.Principal;

/**
 * @author Gennaro Tamburrelli
 */
@Priority(1000)
public class DevAuthorizer<P extends Principal> implements Authorizer<P> {

	private final boolean isAuthorized;

	public DevAuthorizer(boolean isAuthorized) {
		this.isAuthorized = isAuthorized;
	}

	@Override
	public boolean authorize(P principal, String role, ContainerRequestContext requestContext) {
		return this.isAuthorized;
	}
}
