package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Optional;

/**
 * The type Dossier env ntt.
 *
 * @author Carlo Sindico
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierEnvNTT implements IIdRs<DossierEnvKey> {

    private String tenant_id;
    private String key_;
    private String value;
    private Integer fl_client;


    public Optional<DossierEnvKey> getKey() {
        return Optional.ofNullable(DossierEnvKey.builder()
                .tenant_id(tenant_id)
                .key_(key_)
                        .fl_client(fl_client)
                .build()
        );
    }

    public void setKey(DossierEnvKey key) {
        this.tenant_id = key.getTenant_id();
        this.key_ = key.getKey_();
        this.fl_client = key.getFl_client();
    }

}
