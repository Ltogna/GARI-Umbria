package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
public interface ModuleFormConfigsDAO extends IGenericDAO<ModuleFormConfigsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(doss_module_form_configs_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_module_form_configs " +
			"(id, module_id, process_status, form_id, form_group_id, sort_order, fl_readonly, compile_status_identifier, context_function, " +
			" force_read_only_context_function) " +
			"VALUES(:id, :module_id, :process_status, :form_id, :form_group_id, :sort_order, :fl_readonly, :compile_status_identifier, :context_function, " +
			" :force_read_only_context_function)")
	void insert(@BindBean ModuleFormConfigsNTT moduleFormConfigs);

	@SqlQuery("select mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" from doss_module_form_configs mfc " +
			" left join doss_form_catalog afc on afc.id = mfc.form_id " +
			" where afc.tenant_id=:tenantId ")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> findAllModuleFormConfigsByTenant(@Bind("tenantId") String tenant);

	@SqlQuery("select mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" from doss_module_form_configs mfc " +
			" left join doss_form_catalog afc on afc.id = mfc.form_id " +
			" where afc.tenant_id=:tenantId " +
			" and mfc.module_id=:moduleId")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> findAllModuleFormConfigs(@Bind("tenantId") String tenant, @Bind("moduleId") Long moduleId);

	@Override
	@SqlQuery("select mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" from doss_module_form_configs mfc " +
			" where mfc.id=:id ")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> findById(@Bind("id") Long id);

	@SqlQuery("select mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" from doss_module_form_configs mfc " +
			" left join doss_modules am on am.id = mfc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where mfc.id=:id" +
			" and s.tenant_id=:tenantId")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> findById(@Bind("tenantId") String tenant, @Bind("id") Long id);

	@SqlQuery("SELECT mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" FROM doss_module_form_configs mfc " +
			" LEFT JOIN doss_modules am ON am.id = mfc.module_id " +
			" LEFT JOIN doss_sectors s ON s.id = am.sector_id " +
			" WHERE mfc.module_id=:module_id" +
			" AND mfc.process_status=:process_status" +
			" AND s.tenant_id=:tenantId " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" AND ((SELECT required_profile_code " +
			"      FROM doss_module_form_config_profiles " +
			"      WHERE module_form_config_id = mfc.id) is null OR " +
			"      (SELECT required_profile_code " +
			"      FROM doss_module_form_config_profiles " +
			"      WHERE module_form_config_id = mfc.id) IN (<app_profile_list>))")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("process_status") String processStatus,
			@BindList("app_profile_list") List<String> appProfileList);

	@SqlQuery("SELECT mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" FROM doss_module_form_configs mfc " +
			" LEFT JOIN doss_modules am ON am.id = mfc.module_id " +
			" LEFT JOIN doss_sectors s ON s.id = am.sector_id " +
			" WHERE mfc.module_id=:module_id" +
			" AND mfc.process_status=:process_status" +
			" AND s.tenant_id=:tenantId " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" AND (mfc.context_function = :context_function OR (:context_function IS NULL AND mfc.context_function IS NULL)) ")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("process_status") String processStatus,
			@Bind("context_function") String contextFunction);

	@SqlQuery("select mfc.id, " +
			" mfc.module_id, " +
			" mfc.process_status, " +
			" mfc.form_id, " +
			" mfc.form_group_id, " +
			" mfc.sort_order, " +
			" mfc.fl_readonly, " +
			" mfc.compile_status_identifier, " +
			" mfc.context_function, " +
			" mfc.force_read_only_context_function " +
			" from doss_module_form_configs mfc " +
			" left join doss_modules am on am.id = mfc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where mfc.form_id=:form_id" +
			" and s.tenant_id=:tenantId" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModuleFormConfigsNTT.class)
	List<ModuleFormConfigsNTT> findByFormId(@Bind("tenantId") String tenant, @Bind("form_id") Long formId);

	@Override
	@SqlUpdate("UPDATE doss_module_form_configs SET " +
			"module_id=:module_id, " +
			"process_status=:process_status, " +
			"form_id=:form_id, " +
			"form_group_id=:form_group_id, " +
			"sort_order=:sort_order, " +
			"fl_readonly=:fl_readonly, " +
			"context_function=:context_function, " +
			"force_read_only_context_function=:force_read_only_context_function, " +
			"compile_status_identifier=:compile_status_identifier " +
			"WHERE id=:id")
	void update(@BindBean ModuleFormConfigsNTT sector);

	@Override
	@SqlUpdate("DELETE FROM doss_module_form_configs " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long id);

	@SqlUpdate("DELETE FROM apps_module_form_configs " +
			"WHERE module_id=:moduleId")
	void bulkDeleteByModuleId(@Bind("moduleId") Long moduleId);
}
