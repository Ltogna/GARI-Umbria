package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.SectorNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface SectorDAO extends IGenericDAO<SectorNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(doss_sectors_id_seq)§")
	Long nextSequenceVal();

	@SqlUpdate("INSERT INTO doss_sectors " +
			"(TENANT_ID, ID, SECTOR_CODE) " +
			"VALUES(:tenant_id, :id, :sector_code)")
	void insert(@BindBean SectorNTT sector);

	@SqlQuery("select s.tenant_id, " +
			"s.id, " +
			"s.sector_code, " +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as description " +
			"from doss_sectors s " +
			"where s.tenant_id = :tenant_id")
	@RegisterBeanMapper(SectorNTT.class)
	ResultIterator<SectorNTT> findInfiniteAllSectors(@Bind("tenant_id") String tenant, @Bind("lang") String lang);

	@SqlQuery("select s.tenant_id, " +
			"s.id, " +
			"s.sector_code " +
			"from doss_sectors s " +
			"where s.tenant_id=:tenantId")
	@RegisterBeanMapper(SectorNTT.class)
	List<SectorNTT> findAllSectors(@Bind("tenantId") String tenant);

	@SqlQuery("SELECT s.id, " +
			"s.tenant_id, " +
			"s.sector_code " +
			"FROM doss_sectors s " +
			"WHERE s.id=:sectorId AND tenant_id=:tenantId")
	@RegisterBeanMapper(SectorNTT.class)
	List<SectorNTT> findById(@Bind("tenantId") String tenantId, @Bind("sectorId") Long sectorId);

	@SqlQuery("SELECT s.id, " +
			"s.tenant_id, " +
			"s.sector_code " +
			"FROM doss_sectors s " +
			"WHERE s.id=:sectorId")
	@RegisterBeanMapper(SectorNTT.class)
	List<SectorNTT> findById(@Bind("sectorId") Long sectorId);

	@SqlQuery("SELECT s.id, " +
			"s.tenant_id, " +
			"s.sector_code " +
			"FROM doss_sectors s " +
			"WHERE s.sector_code=:sectorCode AND s.tenant_id=:tenantId")
	@RegisterBeanMapper(SectorNTT.class)
	List<SectorNTT> findByCode(@Bind("tenantId") String tenantId, @Bind("sectorCode") String sectorCode);

	@SqlUpdate("UPDATE doss_sectors SET " +
			"sector_code=:sector_code " +
			"WHERE id=:id ")
	void update(@BindBean SectorNTT sector);

	@SqlUpdate("UPDATE doss_sectors SET " +
			"sector_code=:sectorCode " +
			"WHERE id=:sectorId " +
			"and tenant_id=:tenantId")
	void updateById(@Bind("tenantId") String tenantId, @Bind("sectorId") Long sectorId, @Bind("sectorCode") String sectorCode);

	@SqlUpdate("DELETE FROM doss_sectors " +
			"WHERE tenant_id=:tenantId AND id=:sectorId")
	void deleteById(@Bind("tenantId") String tenantId, @Bind("sectorId") Long sectorId);

	@SqlUpdate("DELETE FROM doss_sectors " +
			"WHERE id=:sectorId")
	void deleteById(@Bind("sectorId") Long sectorId);

}
