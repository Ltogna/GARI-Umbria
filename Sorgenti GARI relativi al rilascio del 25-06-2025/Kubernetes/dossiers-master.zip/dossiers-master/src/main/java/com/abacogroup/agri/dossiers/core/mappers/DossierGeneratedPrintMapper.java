package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.DossierGeneratedPrintDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DossierGeneratedPrintMapper extends EntityMapper<DossierGeneratedPrintDTO, DossierGeneratedPrintNTT> {

	DossierGeneratedPrintMapper INSTANCE = Mappers.getMapper(DossierGeneratedPrintMapper.class);

	@InheritInverseConfiguration()
	DossierGeneratedPrintDTO entityToDto(DossierGeneratedPrintNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "printCode", target = "print_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "printDescription", target = "print_description")
	@Mapping(source = "printDate", target = "print_date")
	@Mapping(source = "printJobUuid", target = "print_job_uuid")
	@Mapping(source = "fileId", target = "file_id")
	@Mapping(source = "username", target = "username")
	@Mapping(source = "printStatus", target = "status")
	DossierGeneratedPrintNTT dtoToEntity(DossierGeneratedPrintDTO dto);
}
