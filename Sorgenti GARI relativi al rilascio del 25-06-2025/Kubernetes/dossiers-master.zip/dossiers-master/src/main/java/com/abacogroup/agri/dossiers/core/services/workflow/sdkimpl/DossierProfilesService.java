package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.ProfileCodeNotExistsRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.service.UpsertApplicationProfiles;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierProfilesService implements UpsertApplicationProfiles {
	private final Jdbi jdbi;
	private final DossiersCrudService dossiersCrudService;
	private final DossierProfilesCrudService dossierProfilesCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;

	public DossierProfilesService(Jdbi jdbi,
								  DossiersCrudService dossiersCrudService,
								  DossierProfilesCrudService dossierProfilesCrudService,
								  ModuleProfilesCrudService moduleProfilesCrudService) {
		this.jdbi = jdbi;
		this.dossiersCrudService = dossiersCrudService;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
		this.moduleProfilesCrudService = moduleProfilesCrudService;
	}

	public List<ModuleProfileDTO> getModuleProfileByModuleId(String tenant, Long moduleId) {
		return moduleProfilesCrudService.find(tenant, moduleId);
	}

	public void putDossierProfiles(String tenant, Long dossierId, List<String> profileCodeList, User user) {
		putDossierProfiles(tenant, dossierId, profileCodeList, user, false);
	}

	public void putDossierProfiles(String tenant, Long dossierId, List<String> profileCodeList, User user,
								   boolean upsert) {
		jdbi.useTransaction(handle -> {
			if (!upsert) {
				log.info("logically delete all profiles...");
				dossierProfilesCrudService.bulkLogicallyDeleteByDossierId(tenant, dossierId, user.getName());
				log.info("logically delete all profiles...done");
			}

			log.info("insert by profile code list...");
			var dossier = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
			var moduleProfileList = getModuleProfileByModuleId(tenant, dossier.getModuleId())
					.stream()
					.map(ModuleProfileDTO::getProfileCode)
					.filter(Objects::nonNull)
					.collect(Collectors.toList());
			profileCodeList.forEach(code -> {
				if (moduleProfileList.contains(code)) {
					if (upsert) { // this will only update dates
						var optAppProfile = dossierProfilesCrudService.findByUnique(tenant, dossierId, code);
						if (optAppProfile.isPresent()) {
							var appProfile = optAppProfile.get();
							dossierProfilesCrudService.update(appProfile.getPkid(), appProfile, user.getName());
						} else {
							dossierProfilesCrudService.insert(DossierProfileDTO.builder()
									.profileCode(code)
									.dossierId(dossier.getDossierId())
									.build(), user.getName());
						}
					} else { // else insert
						dossierProfilesCrudService.insert(DossierProfileDTO.builder()
								.profileCode(code)
								.dossierId(dossier.getDossierId())
								.build(), user.getName());
					}
				} else {
					throw new ProfileCodeNotExistsRuntimeException();
				}
			});
		});
	}

	@Override
	public void upsertApplicationProfiles(String tenant, Long dossierId, List<String> profileCodeList, User user) {
		this.putDossierProfiles(tenant, dossierId, profileCodeList, user, true);
	}

	@Override
	public void deleteApplicationProfile(String tenant, Long dossierId, String profileCode, User user) {
		dossierProfilesCrudService.findByUnique(tenant, dossierId, profileCode)
				.ifPresent(prf -> dossierProfilesCrudService.delete(prf.getPkid(), user.getName()));
	}

}
