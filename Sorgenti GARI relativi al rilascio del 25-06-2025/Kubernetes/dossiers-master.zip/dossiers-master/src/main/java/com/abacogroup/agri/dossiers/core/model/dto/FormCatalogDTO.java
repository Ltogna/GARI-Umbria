package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FormCatalogDTO {
	private Long id;
	private String tenantId;
	private String formCode;
	private String softwareUrl;
	private String routerUrl;
	private String formCatalogDescription;

}
