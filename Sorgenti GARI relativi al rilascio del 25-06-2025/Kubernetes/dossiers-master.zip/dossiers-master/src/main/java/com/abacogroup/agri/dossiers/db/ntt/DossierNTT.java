package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IHistoricizationFields;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierNTT implements IIdRs<Long>, IHistoricizationFields {

	private Long id;
	private Long party_id;
	private Integer referred_year;
	private Long module_id;
	private Long process_id;
	private String user_id_insert;
	private String user_id_delete;
	private LocalDateTime dt_insert;
	private LocalDateTime dt_delete;

	@Override
	public Optional<Long> getKey() {
		return Optional.ofNullable(getId());
	}

	@Override
	public void setKey(Long id) {
		setId(id);
	}
}
