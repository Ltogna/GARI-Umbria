package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.model.dto.PartyDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationCompileStatusDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.FormWithGroupHierarchyPublicDTO;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierWithDetailsDTO extends DossierDTO {
	@Schema(description = "the dossier's code")
	private String dossierCode;
	@Schema(description = "the dossier's process status code")
	private String processStatus;
	@Schema(description = "the dossier's process status optional description")
	private String processStatusDescription;
	@Schema(description = "the dossier's process date of presentation")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtPresentation;
	@Schema(description = "the dossier's process date of closure")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtClosed;
	@Schema(description = "the dossier's process date of protocol request")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtProtocolRequest;
	@Schema(description = "the dossier's process date of protocol response")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtProtocolResponse;
	@Schema(description = "the dossier's protocol code")
	private String protocolCode;
	@Schema(description = "the dossier's sector code")
	private String sectorCode;
	@Schema(description = "the dossier's sector description")
	private String sectorDescription;
	@Schema(description = "the dossier's module code")
	private String moduleCode;
	@Schema(description = "the dossier's module description")
	private String moduleDescription;
	@Schema(description = "the dossier's related forms")
	private List<FormWithGroupHierarchyPublicDTO> forms;
	@Schema(description = "the dossier's related prints")
	private List<PrintDetailsOutDTO> prints;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private List<ApplicationCompileStatusDTO> compileStatus;
	@Schema(description = "the dossier's related profile list")
	@Builder.Default
	private List<DossierProfileDTO> profileList = new ArrayList<>();
	@Schema(description = "the dossier's last movement")
	private String lastMovement;
	@Schema(description = "the dossier's last movement date")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtLastMovement;
	@Schema(description = "the user id who executed last movement ")
	private String lastMovementUserIdExecutor;
	@Schema(description = "the party dto")
	private PartyDTO party;
	@Schema(description = "The amend dossier id")
	private Long amendmentDossierId;
	@Schema(description = "The amended dossier id")
	private Long amendedDossierId;
	@Schema(description = "The origin dossier id")
	private Long originalAmendedDossierId;
}
