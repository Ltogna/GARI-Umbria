package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.ModuleProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ModuleProfilePublicMapper {

	ModuleProfilePublicMapper INSTANCE = Mappers.getMapper(ModuleProfilePublicMapper.class);

	@InheritInverseConfiguration()
	ModuleProfileDTO publicToDto(ModuleProfilePublicDTO entity);

	@Mapping(source = "profileCode", target = "profileCode")
	@Mapping(source = "profileCodeDescription", target = "profileCodeDescription")
	ModuleProfilePublicDTO dtoToPublic(ModuleProfileDTO dto);

}
