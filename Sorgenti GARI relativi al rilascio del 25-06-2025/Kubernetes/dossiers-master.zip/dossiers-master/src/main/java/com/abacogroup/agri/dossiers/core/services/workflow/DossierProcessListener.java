package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.DossiersCommitPayload;
import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.model.ApplicationsWorkflowParams;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.workflow.server.model.ProcessTransitionResult;
import com.abacogroup.workflow.server.services.ProcessListener;
import lombok.extern.slf4j.Slf4j;
import org.jdbi.v3.core.Jdbi;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;

import static com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService.FIND_EXPIRED;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class DossierProcessListener implements ProcessListener {

	private final DossiersCrudService dossiersCrudService;
	private final DossierDetailsCrudService dossierDetailsCrudService;
	private final DossiersWorkflowService dossiersWorkflowService;
	private final Jdbi jdbi;
	private final AbstractWorkQueue<DossiersCommitPayload, ?> msgQueue;
	private final Sso2Client sso2Client;

	public DossierProcessListener(DossiersCrudService dossiersCrudService,
								  DossierDetailsCrudService dossierDetailsCrudService,
								  DossiersWorkflowService dossiersWorkflowService, Jdbi jdbi, AbstractWorkQueue<DossiersCommitPayload, ?> msgQueue, Sso2Client sso2Client) {
		this.dossiersCrudService = dossiersCrudService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
		this.dossiersWorkflowService = dossiersWorkflowService;
		this.jdbi = jdbi;
		this.msgQueue = msgQueue;
		this.sso2Client = sso2Client;
	}

	private void callOnUpdate(ProcessTransitionResult processTransitionResult) {
		try {
			Map<String, Object> globalVars = processTransitionResult.getGlobalVars();
			ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);
			log.debug("updating details...");
			dossierDetailsCrudService.updateProcessStatusAndFlTransition(params.getTenant(),
					params.getApplicationId(), processTransitionResult.getCurrentNode(),
					processTransitionResult.getLastTransitionLog().getUserId(), ProcessTransitionEnum.NOT_IN_TRANSITION);
			log.debug("updating details...done");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private void callOnCompleted(ProcessTransitionResult processTransitionResult) {
		try {
			Map<String, Object> globalVars = processTransitionResult.getGlobalVars();
			ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);
			log.debug("is creation, updating process id");
			dossiersCrudService.getDossierAndUpdateProcessId(params.getTenant(), params.getApplicationId(),
					processTransitionResult.getProcessId(), FIND_EXPIRED);
			log.debug("is creation, updating process id...done");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void onProcessCreated(ProcessTransitionResult processTransitionResult) {
		log.debug("executing onProcessCreated");
		this.callOnCompleted(processTransitionResult);
		log.debug("executing onProcessCreated...done");
	}

	@Override
	public void onTransitionCompleted(ProcessTransitionResult processTransitionResult) {
		log.debug("executing onTransitionCompleted");
		this.callOnUpdate(processTransitionResult);

		// Preparing message send
		Map<String, Object> globalVars = processTransitionResult.getGlobalVars();
		ApplicationsWorkflowParams params = (ApplicationsWorkflowParams) globalVars.get(ApplicationsWorkflowParams.KEY);
        log.debug("sending transition completion message for dossier {}", params.getApplicationId());

        DossiersCommitPayload dossierCommitPayload = null;
        try {
            dossierCommitPayload = createDossierCommitPayload(params, processTransitionResult);
			this.msgQueue.add(dossierCommitPayload, System.currentTimeMillis());
        } catch (ObjectNotFoundException e) {
            throw new RuntimeException(e);
        }

		log.debug("executing onTransitionCompleted...done");
	}

	private DossiersCommitPayload createDossierCommitPayload(ApplicationsWorkflowParams applicationsWorkflowParams,
															 ProcessTransitionResult processTransitionResult) throws ObjectNotFoundException {
		var dossierDetails = dossiersCrudService.findWithDetailsByDossierCode(
				applicationsWorkflowParams.getTenant(),
				applicationsWorkflowParams.getApplicationCode()
		);
		return DossiersCommitPayload.builder()
				.tenant(applicationsWorkflowParams.getTenant())
				.partyId(applicationsWorkflowParams.getPartyId())
				.dossierSectorCode(dossierDetails.getSectorCode())
				.dossierModuleCode(dossierDetails.getModuleCode())
				.dossierId(applicationsWorkflowParams.getApplicationId())
				.transitionDate(
						LocalDateTime.ofInstant(
								processTransitionResult.getLastTransitionLog().getEndDate(),
								ZoneId.of("UTC"))
				)
				.currentNode(processTransitionResult.getCurrentNode())
				.username(applicationsWorkflowParams.getUsername())
				.build();
	}
}