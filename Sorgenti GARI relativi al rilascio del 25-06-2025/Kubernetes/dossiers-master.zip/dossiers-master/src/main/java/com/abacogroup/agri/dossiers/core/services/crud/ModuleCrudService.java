package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.mappers.ModuleMapper;
import com.abacogroup.agri.dossiers.core.mappers.ModuleWithDetailMapper;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.ModuleByPointInTimeDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.abacogroup.agri.dossiers.utils.PagingParamsFactory.DEFAULT_PAGE_SIZE;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class ModuleCrudService extends AbstractHistoricizationFieldsCrudService<ModuleNTT, Long, ModuleDTO, ModuleMapper, Void> {

	public static final String I18N_MODULES_TABLE = "doss_modules";
	private final I18NService i18NService;

	public ModuleCrudService(ModuleDAO dao, ModuleMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override protected Void retrieveCustomKeyByResultSet(ModuleNTT rs) {
		return null;
	}

	@Override protected ModuleNTT adjustR(ModuleNTT rs) throws Exception {
		return rs;
	}

	@Override
	protected Optional<ModuleNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	public List<ModuleDTO> findAllModulesBySectorId(String tenantId, Long sectorId) {
		return ((ModuleDAO) dao).findAllModulesBySectorId(tenantId, sectorId).stream()
				.map(mapper::entityToDto)
				.collect(Collectors.toList());
	}

	public Optional<ModuleDTO> findById(Long moduleId) {
		log.info("Invoking findByCode with params moduleId: {}", moduleId);
		return returnOptionalRecord(dao.findById(moduleId));
	}

	public Optional<ModuleDTO> findByCode(String tenant, String moduleCode) {
		return returnOptionalRecord(((ModuleDAO) dao).findByCode(tenant, moduleCode));
	}

	public Optional<ModuleDTO> findByModuleCodeAndSectorCode(String tenant, String moduleCode, String sectorCode) {
		log.info("Invoking findByModuleCodeAndSectorCode with params tenant: {} moduleCode: {} sectorCode: {}", tenant, moduleCode, sectorCode);
		return returnOptionalRecord(((ModuleDAO) dao).findByModuleCodeAndSectorCode(tenant, moduleCode, sectorCode));
	}

	public ModuleDTO insert(ModuleDTO in, String username) {
		log.info("Invoking insert with params in: {} username: {}", in, username);
		return this.insert(in, username, null, this.dao.getCurrentTimestamp());
	}

	public ModuleDTO update(Long key, ModuleDTO in, String username) {
		log.info("Invoking update with params key: {} in: {} username: {}", key, in, username);
		return this.update(key, in, username, null);
	}

	public void updateWorkflwoCode(Long key, String workflowCode) {
		log.info("Invoking updateWorkflwoCode with params key: {} workflowCode: {}", key, workflowCode);
		((ModuleDAO) this.dao).updateWorkflowCode(key, workflowCode);
	}

	public void delete(Long key, String username) {
		log.info("Invoking delete with params key: {} username: {}", key, username);
		this.delete(key, username, null);
	}

	public List<ModuleWithDetailDTO> findAllModulesWithDetail(String tenantId) {
		return ((ModuleDAO) this.dao).findAllModulesWithDetail(tenantId)
				.stream()
				.map(ModuleWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ModuleWithDetailDTO> findValidAmendModulesWithDetailByModuleId(String tenantId, Long moduleId, Integer flAmendModule, AbsoluteDate dtValidity) {
		return ((ModuleDAO) this.dao).findValidModulesWithDetailByModuleId(tenantId, moduleId, dtValidity, flAmendModule, MDC.get(MDCPreFilter.LOCALE))
				.stream()
				.map(ModuleWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ModuleWithDetailDTO> findModulesWithDetailByModuleIds(String tenantId, List<Long> moduleIds, Integer flAmendModule, AbsoluteDate dtValidity) {
		if (Optional.ofNullable(moduleIds).isEmpty() || moduleIds.isEmpty()) {
			return Collections.emptyList();
		}

		return ((ModuleDAO) this.dao).findModulesWithDetailByModuleIds(tenantId, moduleIds, dtValidity, flAmendModule, MDC.get(MDCPreFilter.LOCALE))
				.stream()
				.map(ModuleWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public List<ModuleWithDetailDTO> findAllModulesWithDetailBySectorId(String tenant, Long sectorId) {
		return ((ModuleDAO) this.dao).findAllModulesWithDetailBySectorId(tenant, sectorId).stream()
				.map(ModuleWithDetailMapper.INSTANCE::entityToDto)
				.collect(Collectors.toList());
	}

	public List<RsI18N> getAllModuleI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_MODULES_TABLE, code);
	}

	public void insertModuleI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_MODULES_TABLE, ModuleCrudService.MODULE_I18N.MODULE_CODE.code, lang, code, description);
	}

	public void deleteModuleI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_MODULES_TABLE, ModuleCrudService.MODULE_I18N.MODULE_CODE.code, code, lang);
	}

	/**
	 * Find by point in time
	 *
	 * @param tenant      current tenant
	 * @param pointInTime absolute date as point in time - ex: 20220919
	 * @return the infinite list of modules by point in time
	 */
	public InfiniteListResults<ModuleByPointInTimeDTO> find(String tenant, AbsoluteDate pointInTime, Integer flAmend, String nextKey) {
		return returnInfiniteResults(this.dao.infinite(() -> ((ModuleDAO) this.dao).find(tenant, pointInTime, flAmend, MDC.get(MDCPreFilter.LOCALE)),
				nextKey,
				DEFAULT_PAGE_SIZE),
				Function.identity()
		);
	}

	public List<ModuleByPointInTimeDTO> find(String tenant, AbsoluteDate pointInTime, Integer flAmend) {
		return ((ModuleDAO) this.dao).findByDateAndAmendFl(tenant, pointInTime, flAmend, MDC.get(MDCPreFilter.LOCALE));
	}

	public enum MODULE_I18N {
		MODULE_CODE("module_code");

		private final String code;

		MODULE_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

	public ModuleWithDetailDTO findModuleWithDetail(Long moduleId) {
		return ((ModuleDAO) this.dao).findModulesDetailById(moduleId)
				.stream()
				.findFirst()
				.map(ModuleWithDetailMapper.INSTANCE::entityToDto)
				.orElseThrow(ObjectNotFoundRuntimeException::new);
	}
}
