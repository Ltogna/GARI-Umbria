package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.mappers.DossierProfilePublicMapper;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleProfilesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationProfilePublicDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import com.abacogroup.applicationworkflowsdk.service.GetApplicationProfiles;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class GetDossierProfilesImpl implements GetApplicationProfiles {

	private final DossiersCrudService dossiersCrudService;
	private final ModuleProfilesCrudService moduleProfilesCrudService;
	private final DossierProfilesCrudService dossierProfilesCrudService;

	public GetDossierProfilesImpl(DossiersCrudService dossiersCrudService,
								  ModuleProfilesCrudService moduleProfilesCrudService,
								  DossierProfilesCrudService dossierProfilesCrudService) {
		this.dossiersCrudService = dossiersCrudService;
		this.moduleProfilesCrudService = moduleProfilesCrudService;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
	}

	@Override
	public List<ApplicationProfilePublicDTO> getAllApplicationProfiles(String tenant, Long dossierId, String locale) {
		return dossierProfilesCrudService.findAll(tenant, dossierId, locale)
				.stream()
				.map(DossierProfilePublicMapper.INSTANCE::dtoToPublic)
				.collect(Collectors.toList());
	}

	@Override
	public List<ModuleProfileDTO> getAllModuleProfiles(String tenant, Long dossierId, String locale) {
		var app = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
		return moduleProfilesCrudService.findWithLocale(tenant, app.getModuleId(), locale);
	}
}
