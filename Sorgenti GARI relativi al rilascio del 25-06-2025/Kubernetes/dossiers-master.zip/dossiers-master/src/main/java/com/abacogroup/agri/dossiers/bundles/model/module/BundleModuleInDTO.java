package com.abacogroup.agri.dossiers.bundles.model.module;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import com.abacogroup.agri.dossiers.bundles.model.form.BundleFormsInDTO;
import com.abacogroup.agri.dossiers.bundles.model.form.BundleModulePrintInDTO;
import com.abacogroup.agri.dossiers.bundles.model.form.BundleModuleProfileInDTO;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleModuleInDTO {
	private String moduleCode;
	private String sectorCode;
	private String workflowCode;
	private Integer annuality;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
	private AbsoluteDate dtValidityStart;
	private AbsoluteDate dtValidityEnd;
	private List<I18nPair> i18n;
	private BundleFormsInDTO forms;
	private List<BundleModuleProfileInDTO> moduleProfiles;
	private List<BundleModulePrintInDTO> modulePrints;
	private Boolean flAmendModule;
}
