package com.abacogroup.agri.dossiers.core.model.dto;

public enum PrintJobStatus {

	ACKNOWLEDGE,
	PROGRESS,
	ERROR,
	READY
}
