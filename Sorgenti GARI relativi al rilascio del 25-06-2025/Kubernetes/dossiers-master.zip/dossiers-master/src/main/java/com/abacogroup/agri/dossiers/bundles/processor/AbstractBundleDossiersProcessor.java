package com.abacogroup.agri.dossiers.bundles.processor;

import com.abacogroup.bundles.listener.configdata.ConfigDataMessage;
import com.abacogroup.bundles.listener.configdata.ConfigMessageProcessor;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jdbi.v3.core.Jdbi;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;

public abstract class AbstractBundleDossiersProcessor<T> implements ConfigMessageProcessor {

	protected final ObjectMapper objectMapper;
	protected final Jdbi jdbi;

	protected AbstractBundleDossiersProcessor(ObjectMapper objectMapper, Jdbi jdbi) {
		this.objectMapper = objectMapper;
		this.jdbi = jdbi;
	}

	@Override
	public final void onMessage(ConfigDataMessage message) {
		jdbi.useTransaction(handle -> onMessageInTransaction(message));
	}

	protected abstract TypeReference<T> getTypeReference();

	protected abstract void onMessageInTransaction(ConfigDataMessage message);

	public void processFile(String tenantId, File file) {
		T message;
		try {
			message = objectMapper.readValue(file, this.getTypeReference());
		} catch (IOException e) {
			throw new IllegalStateException(MessageFormat.format("Error processing file {0}  for tenant {1}", file.getName(), tenantId), e);
		}

		if (file.getAbsolutePath().endsWith(".delete.json")) {
			delete(tenantId, message);
		} else {
			doInsertOrUpdate(tenantId, message);
		}
	}

	protected abstract void delete(String tenantId, T message);

	protected abstract void doInsertOrUpdate(String tenantId, T message);
}
