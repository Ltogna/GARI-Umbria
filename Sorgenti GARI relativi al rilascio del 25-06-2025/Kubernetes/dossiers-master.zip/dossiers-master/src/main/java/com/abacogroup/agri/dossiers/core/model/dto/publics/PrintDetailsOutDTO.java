package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PrintDetailsOutDTO {

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long printConfigId;
	private String printCode;
	private String printDescription;
	private Integer sortOrder;
	private Map<String, String> params;
	private LastPrintDTO lastPrint;
}
