package com.abacogroup.agri.dossiers.bundles.model.env;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Bundle dossier env message.
 * @author Carlo Sindico
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleDossierEnvMessage {

    @Builder.Default
    private List<BundleDossierEnvInDTO> bundleDossierEnvInDTOList = new ArrayList<>();
}
