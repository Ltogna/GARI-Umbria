package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.AnomalyCatalogNTT;
import com.abacogroup.agri.dossiers.db.ntt.AnomalyCatalogWIthModuleCodeNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.AnomalyCatalogKey;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface AnomalyCatalogDAO extends IGenericDAO<AnomalyCatalogNTT, AnomalyCatalogKey> {

	@Override
	@SqlUpdate("INSERT INTO DOSS_ANOMALY_CATALOG " +
			"(anomaly_code, " +
			"severity, " +
			"module_id) " +
			"VALUES(:anomaly_code, :severity, :module_id)")
	void insert(@BindBean AnomalyCatalogNTT ntt);

	@SqlQuery("select a.anomaly_code," +
			"  a.severity," +
			"  a.module_id " +
			" from DOSS_ANOMALY_CATALOG a" +
			" where a.anomaly_code = :anomaly_code and a.module_id = :module_id")
	@RegisterBeanMapper(AnomalyCatalogNTT.class)
	List<AnomalyCatalogNTT> findById(@BindBean AnomalyCatalogKey anomalyCode);

	@SqlUpdate("UPDATE DOSS_ANOMALY_CATALOG " +
			" SET severity = :severity, " +
			" SET module_id = :module_id " +
			" where anomaly_code = :anomaly_code")
	void update(@BindBean AnomalyCatalogNTT anomaly);

	@SqlUpdate("DELETE FROM DOSS_ANOMALY_CATALOG a " +
			" where a.anomaly_code = :anomaly_code")
	void deleteById(@Bind("anomaly_code") String anomalyCode);

	@SqlUpdate("DELETE FROM DOSS_ANOMALY_CATALOG a " +
			" where a.anomaly_code = :anomaly_code and module_id =:module_id")
	void deleteByIdAndModuleId(@Bind("anomaly_code") String anomalyCode, @Bind("module_id") Long moduleId);

	@SqlQuery("select an.anomaly_code," +
			"   an.severity," +
			"   an.module_id," +
			"   §i18n(:tenant_id, 'doss_anomaly_catalog', 'anomaly_code', a.anomaly_code, :lang)§ as anomaly_desc " +
			" from DOSS_ANOMALY_CATALOG an INNER JOIN DOSS_MODULES am ON an.module_id = am.id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyCatalogNTT.class)
	List<AnomalyCatalogNTT> findByModuleId(@Bind("tenant_id") String tenant, @Bind("module_id") Long moduleId, @Bind("lang") String lang);

	@SqlQuery("select an.anomaly_code," +
			"   an.severity," +
			"   am.module_code " +
			" from DOSS_ANOMALY_CATALOG an LEFT JOIN DOSS_MODULES am ON an.module_id = am.id " +
			" LEFT JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyCatalogWIthModuleCodeNTT.class)
	List<AnomalyCatalogWIthModuleCodeNTT> findAllByTenant(@Bind("tenant_id") String tenant);

}
