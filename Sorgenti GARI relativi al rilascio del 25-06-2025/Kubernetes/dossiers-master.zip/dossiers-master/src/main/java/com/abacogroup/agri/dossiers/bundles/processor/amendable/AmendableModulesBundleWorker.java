package com.abacogroup.agri.dossiers.bundles.processor.amendable;

import com.abacogroup.agri.dossiers.bundles.BundleConstants;
import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModuleInDTO;
import com.abacogroup.agri.dossiers.bundles.model.amendable.BundleAmendableModulesMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleDetailsCrudService;
import lombok.extern.slf4j.Slf4j;

import java.text.MessageFormat;

/**
 * @author Samuele Sbarbaro
 */
@Slf4j
public class AmendableModulesBundleWorker {

    private final AmendableModuleCrudService amendableModuleCrudService;
    private final ModuleCrudService moduleCrudService;
    private final ModuleDetailsCrudService moduleDetailsCrudService;

    public AmendableModulesBundleWorker(AmendableModuleCrudService amendableModuleCrudService,
                                        ModuleCrudService moduleCrudService,
                                        ModuleDetailsCrudService moduleDetailsCrudService) {
        this.amendableModuleCrudService = amendableModuleCrudService;
        this.moduleCrudService = moduleCrudService;
        this.moduleDetailsCrudService = moduleDetailsCrudService;
    }

    public AmendableModuleCrudService exposeAmendableModuleCrudService() {
        return this.amendableModuleCrudService;
    }

    public ModuleCrudService exposeModuleCrudService() {
        return this.moduleCrudService;
    }

    public ModuleDetailsCrudService exposeModuleDetailsCrudService() {
        return this.moduleDetailsCrudService;
    }

    public void insertBundleModules(final String tenantId, BundleAmendableModulesMessage message) {
        log.info("DossierEnvBundleWorker: processing file with tenant {}", tenantId);
        message.getAmendableModules()
                .forEach(amendableModule -> {
                    try {


                        AmendableModuleDTO amendableModuleToUpdate = getAmendableModuleDTO(tenantId, amendableModule);

                        log.info("AmendableModule already existing: skipping insert");

                        AmendableModuleDTO amendableModuleUpdated = AmendableModuleDTO.builder()
                                .amendableModuleId(amendableModuleToUpdate.getAmendableModuleId())
                                .moduleId(amendableModuleToUpdate.getModuleId())
                                .build();

                        amendableModuleCrudService.update(amendableModuleToUpdate.getAmendableModuleId(), amendableModuleUpdated, amendableModuleToUpdate.getUserIdInsert());
                    } catch (ObjectNotFoundException e) {
                        log.info("DossierEnvBundleWorker: inserting environment with tenant {}", tenantId);


                        ModuleDetailsDTO amendableModuleIdToInsert = moduleDetailsCrudService.findByModuleCode(tenantId, amendableModule.getAmendableModuleCode());

                        ModuleDetailsDTO moduleIdToInsert = moduleDetailsCrudService.findByModuleCode(tenantId, amendableModule.getModuleCode());

                        AmendableModuleDTO amendableModuleToInsert = AmendableModuleDTO.builder()
                                .amendableModuleId(amendableModuleIdToInsert.getModuleId())
                                .moduleId(moduleIdToInsert.getModuleId())
                                .build();

                        amendableModuleCrudService.insert(amendableModuleToInsert, BundleConstants.BUNDLE_SYSTEM_USERNAME);
                    }
                });
    }

    public void deleteBundleAmendableModules(final String tenantId, BundleAmendableModulesMessage message) {
        log.info("DossierEnvBundleWorker: processing delete file with tenant {}", tenantId);
        message.getAmendableModules()
                .forEach(amendableModule -> {
                    try {

                        AmendableModuleDTO amendableModuleToDelete = getAmendableModuleDTO(tenantId, amendableModule);
                        log.info("Deleting amendableModule {}", amendableModuleToDelete.getPkid());
                        amendableModuleCrudService.delete(amendableModuleToDelete.getPkid(), BundleConstants.BUNDLE_SYSTEM_USERNAME);
                        log.info("amendableModule deleted");
                    } catch (ObjectNotFoundException e) {
                        log.info("Environment not found: cannot be deleted");
                    }
                });
    }

    public AmendableModuleDTO getAmendableModuleDTO(String tenantId, BundleAmendableModuleInDTO amendableModule) throws ObjectNotFoundException {

        ModuleDTO moduleDTO = moduleCrudService.findByCode(tenantId, amendableModule.getModuleCode())
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", amendableModule.getModuleCode())));

        ModuleDTO amendableModuleDTO = moduleCrudService.findByCode(tenantId, amendableModule.getAmendableModuleCode())
                .orElseThrow(() -> new ObjectNotFoundRuntimeException(MessageFormat.format("Module with code: {0} not found", amendableModule.getAmendableModuleCode())));

        return amendableModuleCrudService.findByModuleIdAndAmendableModuleId(moduleDTO.getModuleId(), amendableModuleDTO.getModuleId());

    }
}
