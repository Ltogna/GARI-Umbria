package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Alexandru Paraschiv
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleDTO {
	private Long moduleId;
	private String moduleCode;
	private Long sectorId;
	private String workflowCode;
	private Boolean flAmendModule;
}
