package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.service.SetApplicationClosureDate;
import com.abacogroup.applicationworkflowsdk.service.SetApplicationPresentationDate;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 * @author Alexandru Paraschiv
 */
@Slf4j
public class SetClosureDateServiceImpl implements SetApplicationClosureDate {

	private final DossierDetailsCrudService dossierDetailsCrudService;

	public SetClosureDateServiceImpl(DossierDetailsCrudService dossierDetailsCrudService) {
		this.dossierDetailsCrudService = dossierDetailsCrudService;
	}

	public void conditionallySetClosureDate(String tenant, Long dossierId, String username) {
		try {
			var appDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);
			Optional.ofNullable(appDetails.getDtClosed()).ifPresentOrElse(date -> log.info("dossier closure date is already set"),
					() -> {
						appDetails.setDtClosed(LocalDateTime.now());
						dossierDetailsCrudService.update(appDetails.getPkid(), appDetails, username);
						log.info("dossier closure date set");
					});
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("dossier not found");
		}

	}

	@Override
	public void setClosureDate(String tenant, Long dossierId, String username) {
		this.conditionallySetClosureDate(tenant, dossierId, username);
	}
}
