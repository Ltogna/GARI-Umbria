package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierByPartyDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierByPartyNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DossiersByPartyMapper extends EntityMapper<DossierByPartyDTO, DossierByPartyNTT> {

	DossiersByPartyMapper INSTANCE = Mappers.getMapper(DossiersByPartyMapper.class);

	@InheritInverseConfiguration()
	DossierByPartyDTO entityToDto(DossierByPartyNTT entity);

	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "year", target = "referred_year")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "sectorDescription", target = "sector_description")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "moduleDescription", target = "module_description")
	@Mapping(source = "dossierCode", target = "dossier_code")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "dtClosed", target = "dt_closed")
	DossierByPartyNTT dtoToEntity(DossierByPartyDTO dto);

}
