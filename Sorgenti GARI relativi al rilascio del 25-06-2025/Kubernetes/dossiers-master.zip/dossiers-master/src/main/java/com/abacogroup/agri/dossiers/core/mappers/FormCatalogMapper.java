package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.FormCatalogDTO;
import com.abacogroup.agri.dossiers.db.ntt.FormCatalogNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface FormCatalogMapper extends EntityMapper<FormCatalogDTO, FormCatalogNTT> {

	FormCatalogMapper INSTANCE = Mappers.getMapper(FormCatalogMapper.class);

	@InheritInverseConfiguration()
	FormCatalogDTO entityToDto(FormCatalogNTT entity);

	@Mapping(source = "id", target = "id")
	@Mapping(source = "tenantId", target = "tenant_id")
	@Mapping(source = "formCode", target = "form_code")
	@Mapping(source = "softwareUrl", target = "software_url")
	@Mapping(source = "routerUrl", target = "router_url")
	@Mapping(source = "formCatalogDescription", target = "form_catalog_description")
	FormCatalogNTT dtoToEntity(FormCatalogDTO dto);
}
