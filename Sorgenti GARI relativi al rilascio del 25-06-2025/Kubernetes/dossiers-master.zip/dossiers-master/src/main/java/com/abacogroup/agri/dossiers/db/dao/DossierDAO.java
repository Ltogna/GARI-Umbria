package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierByPartyAndYearNTT;
import com.abacogroup.agri.dossiers.db.ntt.DossierByPartyNTT;
import com.abacogroup.agri.dossiers.db.ntt.DossierNTT;
import com.abacogroup.agri.dossiers.db.ntt.DossierWithDetailsNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 * @author Gennaro Tamburrelli
 */
public interface DossierDAO extends IGenericHistoricizationFieldsDAO<DossierNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_dossier_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO DOSS_DOSSIERS " +
			"(id, " +
			"party_id, " +
			"referred_year, " +
			"module_id, " +
			"process_id, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:id, :party_id, :referred_year, :module_id, :process_id, :user_id, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean DossierNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" where a.id = :id")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE DOSS_DOSSIERS SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE id = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.dossier_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  ad.dt_closed," +
			"  s.sector_code as sector_code," +
			"  §i18n(:tenant_id, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  am.module_code as module_code," +
			"  §i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete" +
			" from DOSS_DOSSIERS a " +
			" INNER JOIN DOSS_DOSSIERS_DETAILS ad on ad.dossier_id = a.id " +
			" INNER JOIN DOSS_MODULES am on am.id = a.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where ad.dossier_code = :code " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(DossierWithDetailsNTT.class)
	List<DossierWithDetailsNTT> findWithDetailByCode(@Bind("tenant_id") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.dossier_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  ad.dt_closed," +
			"  s.sector_code, " +
			"  am.module_code, " +
			"  §i18n(:tenant_id, 'doss_sectors', 'sector_code', s.sector_code, :lang)§ as sector_description," +
			"  §i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete, " +
			" ad.amended_by_id, " +
			" ad.amend_of_id " +
			" from DOSS_DOSSIERS a " +
			" INNER JOIN DOSS_DOSSIERS_DETAILS ad on ad.dossier_id = a.id " +
			" INNER JOIN DOSS_MODULES am on am.id = a.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where a.id = :doss_id " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(DossierWithDetailsNTT.class)
	List<DossierWithDetailsNTT> findWithDetailById(@Bind("tenant_id") String tenant, @Bind("doss_id") Long dosId, @Bind("lang") String lang);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" left join doss_modules m ON a.module_id = m.id " +
			" left join doss_sectors s ON m.sector_id = s.id " +
			" where a.party_id = :partyId and s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete" +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findAllByPartyId(@Bind("tenant") String tenant, @Bind("partyId") Long partyId);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" left join doss_modules m ON a.module_id = m.id " +
			" left join doss_sectors s ON m.sector_id = s.id " +
			" where a.module_id = :moduleId and s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findAllByModuleId(@Bind("tenant") String tenant, @Bind("moduleId") Long moduleId);

	@SqlQuery("select a.id," +
			"  a.party_id," +
			"  a.referred_year," +
			"  a.module_id," +
			"  a.process_id," +
			"  ad.dossier_code," +
			"  ad.process_status," +
			"  ad.dt_presentation," +
			"  ad.dt_closed," +
			"  ad.dt_insert," +
			"  ad.dt_delete," +
			"  ad.user_id_insert," +
			"  ad.user_id_delete" +
			" from DOSS_DOSSIERS a " +
			" INNER JOIN DOSS_DOSSIERS_DETAILS ad on ad.dossier_id = a.id " +
			" INNER JOIN DOSS_MODULES am on am.id = a.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where a.module_id = :moduleId and s.tenant_id = :tenant_id " +
			" and a.party_id = :partyId " +
			" and a.referred_year = :referredYear " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(DossierWithDetailsNTT.class)
	List<DossierWithDetailsNTT> findAllByModuleIdAndPartyIdAndReferredYear(@Bind("tenant_id") String tenant, @Bind("moduleId") Long moduleId,
                                                                           @Bind("partyId") Long partyId,
                                                                           @Bind("referredYear") Integer referredYear);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.DOSSIER_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as DOSSIER_ID, " +
			"aad.DT_CLOSED, " +
			"aad.context_function " +
			"FROM DOSS_DOSSIERS aa LEFT JOIN DOSS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN DOSS_DOSSIERS_DETAILS aad ON aa.id = aad.DOSSIER_ID " +
			"LEFT JOIN DOSS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE aa.PARTY_ID = :party_id " +
			"AND aa.REFERRED_YEAR = :year " +
			"AND as2.TENANT_ID = :tenant_id" +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(DossierByPartyAndYearNTT.class)
	ResultIterator<DossierByPartyAndYearNTT> find(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId, @Bind("year") Integer year,
												  @Bind("lang") String lang);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.DOSSIER_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as DOSSIER_ID, " +
			"aad.DT_CLOSED " +
			"FROM DOSS_DOSSIERS aa LEFT JOIN DOSS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN DOSS_DOSSIERS_DETAILS aad ON aa.id = aad.DOSSIER_ID " +
			"LEFT JOIN DOSS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE aa.PARTY_ID = :party_id " +
			"AND aa.REFERRED_YEAR = :year " +
			"AND as2.TENANT_ID = :tenant_id " +
			"AND am.module_code = :module_code " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(DossierByPartyAndYearNTT.class)
	List<DossierByPartyAndYearNTT> find(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId, @Bind("year") Integer year,
										@Bind("module_code") String moduleCode, @Bind("lang") String lang);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.DOSSIER_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as DOSSIER_ID, " +
			"aad.DT_CLOSED " +
			"FROM DOSS_DOSSIERS aa LEFT JOIN DOSS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN DOSS_DOSSIERS_DETAILS aad ON aa.id = aad.DOSSIER_ID " +
			"LEFT JOIN DOSS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE as2.TENANT_ID = :tenant_id " +
			"AND (:year IS NULL OR aa.REFERRED_YEAR = :year) " +
			"AND (:party_id IS NULL OR aa.PARTY_ID = :party_id)" +
			"AND (:module_code IS NULL OR am.module_code = :module_code) " +
			"AND (:process_status IS NULL OR aad.PROCESS_STATUS = :process_status) " +
			"AND aa.ID in (<dossier_id_list>) " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(DossierByPartyAndYearNTT.class)
	ResultIterator<DossierByPartyAndYearNTT> findInfinite(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId,
														  @Bind("year") Integer year, @Bind("module_code") String moduleCode, @Bind("process_status") String processStatus,
														  @BindList(onEmpty = BindList.EmptyHandling.NULL_VALUE, value = "dossier_id_list") List<Long> dossierIdList, @Bind("lang") String lang);

	@SqlQuery("SELECT aa.PARTY_ID," +
			"aa.REFERRED_YEAR," +
			"as2.SECTOR_CODE," +
			"§i18n(:tenant_id, 'doss_sectors', 'sector_code', as2.sector_code, :lang)§ as sector_description, " +
			"am.MODULE_CODE," +
			"§i18n(:tenant_id, 'doss_modules', 'module_code', am.module_code, :lang)§ as module_description," +
			"aad.DOSSIER_CODE," +
			"aad.PROCESS_STATUS," +
			"aa.PROCESS_ID, " +
			"aa.ID as DOSSIER_ID, " +
			"aad.DT_CLOSED " +
			"FROM DOSS_DOSSIERS aa LEFT JOIN DOSS_MODULES am ON aa.MODULE_ID = am.id " +
			"LEFT JOIN DOSS_DOSSIERS_DETAILS aad ON aa.id = aad.DOSSIER_ID " +
			"LEFT JOIN DOSS_SECTORS as2 ON am.SECTOR_ID = as2.id " +
			"WHERE as2.TENANT_ID = :tenant_id " +
			"AND (:year IS NULL OR aa.REFERRED_YEAR = :year) " +
			"AND (:party_id IS NULL OR aa.PARTY_ID = :party_id)" +
			"AND (:module_code IS NULL OR am.module_code = :module_code) " +
			"AND (:process_status IS NULL OR aad.PROCESS_STATUS = :process_status) " +
			" and §current_timestamp§ between aa.dt_insert and aa.dt_delete" +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete" +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(DossierByPartyAndYearNTT.class)
	ResultIterator<DossierByPartyAndYearNTT> findInfinite(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId,
														  @Bind("year") Integer year, @Bind("module_code") String moduleCode, @Bind("process_status") String processStatus,
														  @Bind("lang") String lang);

	@SqlQuery("SELECT doss.PARTY_ID, " +
			" doss.REFERRED_YEAR, " +
			" sec.SECTOR_CODE, " +
			" §i18n(:tenant_id, 'doss_sectors', 'sector_code', sec.sector_code, :lang)§ as sector_description, " +
			" mod.MODULE_CODE, " +
			" §i18n(:tenant_id, 'doss_modules', 'module_code', mod.module_code, :lang)§ as module_description, " +
			" det.DOSSIER_CODE, " +
			" det.PROCESS_STATUS, " +
			" doss.PROCESS_ID, " +
			" doss.ID as DOSSIER_ID, " +
			" det.DT_PRESENTATION," +
			" det.DT_CLOSED " +
			"FROM DOSS_DOSSIERS doss " +
			" LEFT JOIN DOSS_MODULES mod ON doss.MODULE_ID = mod.id " +
			" LEFT JOIN DOSS_DOSSIERS_DETAILS det ON doss.id = det.DOSSIER_ID " +
			" LEFT JOIN DOSS_SECTORS sec ON mod.SECTOR_ID = sec.id " +
			"WHERE doss.PARTY_ID = :party_id " +
			" AND sec.TENANT_ID = :tenant_id " +
			" AND (:include_closed = 1 OR det.dt_closed IS NULL) " +	//include_closed = 1 -> takes all. include_closed = 0 OR null, takes only not closed.
			" AND ((<type_list>) IS NULL OR mod.MODULE_CODE in (<type_list>)) " +
			" AND §current_timestamp§ BETWEEN doss.dt_insert AND doss.dt_delete " +
			" AND §current_timestamp§ BETWEEN det.dt_insert AND det.dt_delete " +
			" AND §current_timestamp§ BETWEEN mod.dt_insert AND mod.dt_delete ")
	@RegisterBeanMapper(DossierByPartyNTT.class)
	ResultIterator<DossierByPartyNTT> find(@Bind("tenant_id") String tenant, @Bind("party_id") Long partyId, @Bind("include_closed") Integer includeClosed,
										   @BindList(onEmpty = BindList.EmptyHandling.NULL_STRING, value = "type_list") List<String> typeList, @Bind("lang") String lang);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" left join DOSS_DOSSIERS_DETAILS aad ON a.id = aad.DOSSIER_ID" +
			" left join doss_modules m ON a.module_id = m.id" +
			" left join doss_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and aad.DOSSIER_CODE = :dossier_code" +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between aad.dt_insert and aad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findByCode(@Bind("tenant") String tenant, @Bind("dossier_code") String dossierCode);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" left join doss_modules m ON a.module_id = m.id" +
			" left join doss_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and a.id = :dossier_id " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findById(@Bind("tenant") String tenant, @Bind("dossier_id") Long dossierId);

	@SqlQuery("select a.id," +
			" a.party_id," +
			" a.referred_year," +
			" a.module_id," +
			" a.process_id," +
			" a.dt_insert," +
			" a.dt_delete," +
			" a.user_id_insert," +
			" a.user_id_delete" +
			" from DOSS_DOSSIERS a" +
			" left join doss_modules m ON a.module_id = m.id" +
			" left join doss_sectors s ON m.sector_id = s.id" +
			" where s.tenant_id = :tenant" +
			" and a.id = :dossier_id " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierNTT.class)
	List<DossierNTT> findByIdAlsoExpired(@Bind("tenant") String tenant, @Bind("dossier_id") Long dossierId);

	@SqlUpdate("UPDATE doss_dossiers " +
			"SET process_id = :process_id " +
			"WHERE id = :id")
	void updateProcessId(@Bind("id") Long id, @Bind("process_id") Long processId);
}
