package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class CallPartyServicesErrorRuntimeException extends AbstractException {

	private static final ErrorBody BODY = new ErrorBody();

	public CallPartyServicesErrorRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public CallPartyServicesErrorRuntimeException() {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, "Error calling party services");
	}

	@Schema(name = "CallAvepaServicesErrorRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "CALL_AVEPA_SERVICES_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
