package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.ActionNotAuthorizedRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.workflow.DossiersWorkflowService;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.workflow.server.model.DetailedTransitionLog;

import java.util.Collections;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public class HistoryService {

	private final DossiersCrudService dossiersCrudService;
	private final CheckPartyService checkPartyService;
	private final DossiersWorkflowService dossiersWorkflowService;

	public HistoryService(DossiersCrudService dossiersCrudService, CheckPartyService checkPartyService,
			DossiersWorkflowService dossiersWorkflowService) {
		this.dossiersCrudService = dossiersCrudService;
		this.checkPartyService = checkPartyService;
		this.dossiersWorkflowService = dossiersWorkflowService;
	}

	public List<DetailedTransitionLog> getApplicationHistoryByApplicationId(String tenant, Long applicationId, User user) {
		try {
			var application = dossiersCrudService.findByIdAlsoExpired(tenant, applicationId);
			try {
				this.checkPartyService.checkCanReadParty(tenant, application.getPartyId(), user);
			} catch (ActionNotAuthorizedRuntimeException e) {
				return Collections.emptyList();
			}
			return dossiersWorkflowService.getProcessTransitionHistory(tenant, application.getProcessId(), user);
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(e.getMessage());
		}
	}
}
