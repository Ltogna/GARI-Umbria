package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.DossierAnomaly;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import lombok.extern.slf4j.Slf4j;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Alexandru Paraschiv
 */
@Slf4j
public class AnomaliesService {
	private static final String PROCESS_STATUS_DELETED = "DELETED"; // TODO to be moved?
	private static final String PROCESS_STATUS_WAIVED = "WAIVED"; // TODO to be moved?

	public static final String METADATA_KEY_MULTIPLE_DOSSIERS = "multiple-dossiers-allowed";
	public static final String MULTIPLE_DOSSIERS_ERROR_CODE = "NOT_ALLOWED_MULTIPLE_DOSSIERS_ERROR";
	public static final String MULTIPLE_DOSSIERS_ERROR_MSG = "Multiple dossiers are not allowed for this dossier";
	public static final Boolean NOT_ALLOWED_MULTIPLE_DOSSIERS_VALUE = false;
	public static final Boolean ALLOWED_MULTIPLE_DOSSIERS_VALUE = true;

	public static final String MODULE_VALIDITY_EXPIRED_ERROR_CODE = "CREATING_DOSSIER_NOT_IN_VALIDITY_PERIOD_ERROR_CODE";
	public static final String MODULE_VALIDITY_EXPIRED_ERROR_MSG = "This module's validity is expired";

	public static final String NOT_AMENDMENT_MODULE_ERROR_CODE = "NOT_AMENDMENT_MODULE_ERROR_CODE";
	public static final String NOT_AMENDMENT_MODULE_ERROR_MSG = "This is not an amendment module";

	public static final String ALREADY_AMENDED_DOSSIER_ERROR_CODE = "ALREADY_AMENDED_DOSSIER_ERROR_CODE";
	public static final String ALREADY_AMENDED_DOSSIER_ERROR_MSG = "It is not possible to create a new amendment dossier art. 15: amendment dossier already exists";

	public static final String WAIVED_DOSSIER_ERROR_CODE = "WAIVED_DOSSIER_ERROR_CODE";
	public static final String WAIVED_DOSSIER_ERROR_MSG = "It is not possible to create a new amendment dossier art. 15: dossier waived";

	private final DossiersService dossiersService;
	private final DossiersCrudService dossiersCrudService;
	private final ModuleCrudService moduleCrudService;
	private final DossierDetailsCrudService dossierDetailsCrudService;

	public AnomaliesService(DossiersService dossiersService,
							ModuleCrudService moduleCrudService,
							DossiersCrudService dossiersCrudService,
							DossierDetailsCrudService dossierDetailsCrudService) {
		this.dossiersCrudService = dossiersCrudService;
		this.moduleCrudService = moduleCrudService;
		this.dossiersService = dossiersService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
	}

	public List<DossierAnomaly> checkForModuleDateValidity(ModuleDetailsDTO moduleDetails) {
		List<DossierAnomaly> anomalies = new ArrayList<>();
		LocalDate today = LocalDate.now();
		LocalDate start = moduleDetails.getDtValidityStart().get();
		LocalDate end = moduleDetails.getDtValidityEnd().get();
		if (start.isBefore(today) && end.isAfter(today)) {
			log.info("dossier can be created because today is within module's validity range");
		} else {
			anomalies.add(DossierAnomaly.builder()
					.code(MODULE_VALIDITY_EXPIRED_ERROR_CODE)
					.message(MODULE_VALIDITY_EXPIRED_ERROR_MSG)
					.build());
		}
		return anomalies;
	}

	public List<DossierAnomaly> checkForAmendmentModule(ModuleDTO module) {
		List<DossierAnomaly> anomalies = new ArrayList<>();

		if (Boolean.TRUE.equals(module.getFlAmendModule())) {
			log.info("Amendment dossier can be created because the module is of amendment");
		} else {
			anomalies.add(DossierAnomaly.builder()
					.code(NOT_AMENDMENT_MODULE_ERROR_CODE)
					.message(NOT_AMENDMENT_MODULE_ERROR_MSG)
					.build());
		}

		return anomalies;
	}

	public List<DossierAnomaly> checkForDossierNotAmended(String tenant, Long dossierId) {
		List<DossierAnomaly> anomalies = new ArrayList<>();
		try {
			DossierDetailsDTO dossierDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);

			if (Optional.ofNullable(dossierDetails.getAmendedById()).isPresent()) {
				DossierDetailsDTO amendDossierDetails = dossierDetailsCrudService
						.findDossierDetailById(tenant, dossierDetails.getAmendedById());

				if (!PROCESS_STATUS_DELETED.equals(amendDossierDetails.getProcessStatus()))
					anomalies.add(DossierAnomaly.builder()
							.code(ALREADY_AMENDED_DOSSIER_ERROR_CODE)
							.message(ALREADY_AMENDED_DOSSIER_ERROR_MSG)
							.build());
			} else {
				log.info("Amended dossier can be created because the dossier is not amended by an amendment dossier");
			}
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(MessageFormat.format("Dossier with id {0} not found", dossierId));
		}

		return anomalies;
	}

	public List<DossierAnomaly> checkForDossierWaived(String tenant, Long dossierId) {
		List<DossierAnomaly> anomalies = new ArrayList<>();
		try {
			DossierDetailsDTO dossierDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);

			if (PROCESS_STATUS_WAIVED.equals(dossierDetails.getProcessStatus())) {
				anomalies.add(DossierAnomaly.builder()
						.code(WAIVED_DOSSIER_ERROR_CODE)
						.message(WAIVED_DOSSIER_ERROR_MSG)
						.build());
			} else {
				log.info("Amended dossier can be created because the dossier is not amended by an amendment dossier");
			}
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException(MessageFormat.format("Dossier with id {0} not found", dossierId));
		}

		return anomalies;
	}

	public List<DossierAnomaly> checkForMultipleDossier(String tenantId, String moduleCode, Long partyId, Integer referredYear) {
		Optional<ModuleDTO> moduleDTO = moduleCrudService.findByCode(tenantId, moduleCode);
		if (moduleDTO.isEmpty()) {
			throw new ObjectNotFoundRuntimeException(MessageFormat.format("Module not found by tenant: {0} code: {1}", tenantId, moduleCode));
		}

		return this.checkForMultipleDossier(tenantId, moduleDTO.get(), partyId, referredYear, null);

	}

	public List<DossierAnomaly> checkForMultipleDossier(String tenantId, ModuleDTO moduleDTO, Long partyId, Integer referredYear,
														Long dossierId) {
		return dossiersCrudService.findAllByModuleIdAndPartyIdAndReferredYear(tenantId, moduleDTO.getModuleId(), partyId, referredYear)
				.stream()
				.filter(x -> dossierId == null || !x.getDossierId().equals(dossierId))
				.map(app -> {
					Map<String, Object> appMetadata = dossiersService.checkForMetadata(tenantId, app);
					if (appMetadata.containsKey(METADATA_KEY_MULTIPLE_DOSSIERS) && appMetadata.get(METADATA_KEY_MULTIPLE_DOSSIERS)
							.equals(NOT_ALLOWED_MULTIPLE_DOSSIERS_VALUE)) {
						return DossierAnomaly.builder()
								.code(MULTIPLE_DOSSIERS_ERROR_CODE)
								.message(MULTIPLE_DOSSIERS_ERROR_MSG)
								.build();
					} else {
						return null;
					}
				})
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
	}

}
