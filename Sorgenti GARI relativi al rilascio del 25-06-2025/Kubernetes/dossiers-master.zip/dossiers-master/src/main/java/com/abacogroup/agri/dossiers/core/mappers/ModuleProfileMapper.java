package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.db.ntt.ModuleProfileNTT;
import com.abacogroup.applicationworkflowsdk.model.io.output.ModuleProfileDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ModuleProfileMapper extends EntityMapper<ModuleProfileDTO, ModuleProfileNTT> {

	ModuleProfileMapper INSTANCE = Mappers.getMapper(ModuleProfileMapper.class);

	@InheritInverseConfiguration()
	ModuleProfileDTO entityToDto(ModuleProfileNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "profileCode", target = "profile_code")
	@Mapping(source = "profileCodeDescription", target = "profile_code_description")
	ModuleProfileNTT dtoToEntity(ModuleProfileDTO dto);

}
