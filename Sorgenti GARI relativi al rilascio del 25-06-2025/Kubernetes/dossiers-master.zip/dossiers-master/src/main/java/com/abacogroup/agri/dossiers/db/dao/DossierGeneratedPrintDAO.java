package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierGeneratedPrintNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface DossierGeneratedPrintDAO extends IGenericDAO<DossierGeneratedPrintNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(doss_dossiers_generated_prints_seq_id)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO DOSS_DOSSIERS_GENERATED_PRINTS " +
			"(pkid, " +
			"dossier_id, " +
			"process_status, " +
			"print_code, " +
			"print_date, " +
			"print_job_uuid, " +
			"file_id," +
			"username," +
			"status) " +
			"VALUES(:pkid, :dossier_id, :process_status, :print_code, :print_date, :print_job_uuid, :file_id, :username, :status)")
	void insert(@BindBean DossierGeneratedPrintNTT ntt);

	@SqlQuery("select a.pkid, " +
			"  a.dossier_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from DOSS_DOSSIERS_GENERATED_PRINTS a" +
			" where a.pkid = :id")
	@RegisterBeanMapper(DossierGeneratedPrintNTT.class)
	List<DossierGeneratedPrintNTT> findById(@Bind("id") Long pkid);

	@SqlUpdate("UPDATE DOSS_DOSSIERS_GENERATED_PRINTS " +
			"  SET dossier_id = :dossier_id , " +
			"  process_status = :process_status, " +
			"  print_code = :print_code, " +
			"  print_date = :print_date, " +
			"  print_job_uuid = :print_job_uuid, " +
			"  username = :username, " +
			"  status = :status, " +
			"  file_id = :file_id " +
			" where pkid = :pkid")
	void update(@BindBean DossierGeneratedPrintNTT anomaly);

	@SqlUpdate("DELETE FROM DOSS_DOSSIERS_GENERATED_PRINTS a " +
			" where a.pkid = :pkid")
	void deleteById(@Bind("pkid") Long pkid);

	@SqlQuery("select a.pkid, " +
			"  a.dossier_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  §i18n(:tenant_id, 'doss_module_print_configs', 'print_code', a.print_code, :lang)§ as print_description," +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from DOSS_DOSSIERS_GENERATED_PRINTS a INNER JOIN DOSS_DOSSIERS aa ON a.dossier_id = aa.id " +
			" INNER JOIN DOSS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :dossier_id " +
			" and ((a.file_id is not null and a.status = 'READY') or (a.file_id is null and a.status = 'ERROR')) " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" ORDER BY a.print_date DESC")
	@RegisterBeanMapper(DossierGeneratedPrintNTT.class)
	List<DossierGeneratedPrintNTT> findCompletedPrintsByDossierId(@Bind("tenant_id") String tenant, @Bind("dossier_id") Long dossierId,
																  @Bind("lang") String lang);

	@SqlQuery("select a.pkid, " +
			"  a.dossier_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  §i18n(:tenant_id, 'doss_module_print_configs', 'print_code', a.print_code, :lang)§ as print_description," +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from DOSS_DOSSIERS_GENERATED_PRINTS a INNER JOIN DOSS_DOSSIERS aa ON a.dossier_id = aa.id " +
			" INNER JOIN DOSS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :dossier_id " +
			" and a.file_id = :file_id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(DossierGeneratedPrintNTT.class)
	List<DossierGeneratedPrintNTT> findByDossierIdAndFileId(@Bind("tenant_id") String tenant, @Bind("dossier_id") Long dossierId,
															@Bind("lang") String lang, @Bind("file_id") String fileId);

	@SqlQuery("select a.pkid, " +
			"  a.dossier_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  §i18n(:tenant_id, 'doss_module_print_configs', 'print_code', a.print_code, :lang)§ as print_description," +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from DOSS_DOSSIERS_GENERATED_PRINTS a INNER JOIN DOSS_DOSSIERS aa ON a.dossier_id = aa.id " +
			" INNER JOIN DOSS_MODULES am on am.id = aa.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where s.tenant_id = :tenant_id " +
			" and aa.id = :dossier_id " +
			" and a.print_code = :print_code " +
			" and ((:ongoing = 0 and a.status is not null) or (:ongoing = 1 and a.file_id is null and a.status is null)) " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" and a.print_date = (select MAX(print_date) " +
			"                        from DOSS_DOSSIERS_GENERATED_PRINTS " +
			"                        where dossier_id = :dossier_id " +
			"                        and print_code =:print_code " +
			"                        and ((:ongoing = 0 and a.file_id is not null) or (:ongoing = 1 and a.file_id is null)))")
	@RegisterBeanMapper(DossierGeneratedPrintNTT.class)
	List<DossierGeneratedPrintNTT> findLastGeneratedPrintByCode(@Bind("tenant_id") String tenant, @Bind("dossier_id") Long dossierId,
																@Bind("print_code") String printCode, @Bind("lang") String lang, @Bind("ongoing") Integer ongoing);

	@SqlQuery("select a.pkid, " +
			"  a.dossier_id, " +
			"  a.process_status, " +
			"  a.print_code, " +
			"  a.print_date, " +
			"  a.print_job_uuid, " +
			"  a.username, " +
			"  a.status, " +
			"  a.file_id " +
			" from DOSS_DOSSIERS_GENERATED_PRINTS a" +
			" where a.print_job_uuid = :print_job_uuid")
	@RegisterBeanMapper(DossierGeneratedPrintNTT.class)
	DossierGeneratedPrintNTT findByUuid(@Bind("print_job_uuid") String uuid);
}
