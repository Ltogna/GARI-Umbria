package com.abacogroup.agri.dossiers.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CheckCanReadKey {
	private String tenant;
	private String username;
	private Long partyId;
}
