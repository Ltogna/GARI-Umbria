package com.abacogroup.agri.dossiers.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PrintConfigProfileKey {

	private Long module_print_config_id;
	private String required_profile_code;
}
