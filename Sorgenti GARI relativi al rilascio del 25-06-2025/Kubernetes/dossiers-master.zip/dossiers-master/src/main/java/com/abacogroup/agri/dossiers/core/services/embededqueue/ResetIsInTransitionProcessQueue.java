package com.abacogroup.agri.dossiers.core.services.embededqueue;

import com.abacogroup.agri.dossiers.core.model.ProcessTransitionEnum;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.embededqueue.model.ResetInTransitionParams;
import com.abacogroup.embeddedqueue.QueueErrorListener;
import com.abacogroup.embeddedqueue.ThrowingConsumer;
import com.abacogroup.embeddedqueue.WorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.codahale.metrics.MetricRegistry;
import com.fasterxml.jackson.databind.ObjectMapper;

import static com.abacogroup.embeddedqueue.QueueErrorListener.ErrorAction.DELETE_FROM_QUEUE;

/**
 * @author Gennaro Tamburrelli
 */
public class ResetIsInTransitionProcessQueue extends WorkQueue<ResetInTransitionParams> {

	private DossierDetailsCrudService dossierDetailsCrudService;

	public ResetIsInTransitionProcessQueue(JdbiRepository repo, ObjectMapper objectMapper, MetricRegistry registry,
										   DossierDetailsCrudService dossierDetailsCrudService, int numThreads, long timeoutMs) {
		super("app-reset-tran-proc", repo, numThreads, timeoutMs);
		this.dossierDetailsCrudService = dossierDetailsCrudService;
		this.setObjectMapper(objectMapper);
		this.setMetricRegistry(registry);
		this.setConsumer(doTheJob);
		this.setErrorListener(handleError);
		this.start();
	}

	@Override
	protected Class<ResetInTransitionParams> getJobClass() {
		return ResetInTransitionParams.class;
	}

	private final ThrowingConsumer<ResetInTransitionParams> doTheJob = appParams ->
			dossierDetailsCrudService.updateFlTransition(appParams.getTenant(),
					appParams.getDossierId(),
					appParams.getUsername(),
					ProcessTransitionEnum.NOT_IN_TRANSITION);

	private final QueueErrorListener<ResetInTransitionParams> handleError = (appParams, exp) -> {
		return DELETE_FROM_QUEUE;
	};

}
