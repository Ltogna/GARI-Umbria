package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.applicationworkflowsdk.service.SetApplicationPresentationDate;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 * @author Alexandru Paraschiv
 */
@Slf4j
public class SetPresentationDateServiceImpl implements SetApplicationPresentationDate {

	private final DossierDetailsCrudService dossierDetailsCrudService;

	public SetPresentationDateServiceImpl(DossierDetailsCrudService dossierDetailsCrudService) {
		this.dossierDetailsCrudService = dossierDetailsCrudService;
	}

	public void conditionallySetPresentationDate(String tenant, Long dossierId, String username) {
		try {
			var appDetails = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);
			Optional.ofNullable(appDetails.getDtPresentation()).ifPresentOrElse(date -> log.info("dossier presentation date is already set"),
					() -> {
						appDetails.setDtPresentation(LocalDateTime.now());
						dossierDetailsCrudService.update(appDetails.getPkid(), appDetails, username);
						log.info("dossier presentation date set");
					});
		} catch (ObjectNotFoundException e) {
			throw new DossierNotFoundRuntimeException("dossier not found");
		}

	}

	@Override
	public void setPresentationDate(String tenant, Long dossierId, String username) {
		this.conditionallySetPresentationDate(tenant, dossierId, username);
	}
}
