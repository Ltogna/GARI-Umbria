package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class CuaaAndDescriptionNotValorisedRuntimeException extends AbstractException {

	private static final CuaaAndDescriptionNotValorisedRuntimeException.ErrorBody BODY = new CuaaAndDescriptionNotValorisedRuntimeException.ErrorBody();

	public CuaaAndDescriptionNotValorisedRuntimeException(String message) {
		super(Response.Status.BAD_REQUEST, BODY, message);
	}

	@Schema(name = "CuaaAndDescriptionNotValorisedErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "CUAA_AND_DESCRIPTION_NOT_VALORISED_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
