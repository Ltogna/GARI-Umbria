package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SectorDTO {
	private String tenantId;
	private Long sectorId;
	private String sectorCode;
	private String description;
}
