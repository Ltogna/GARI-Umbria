package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class ProgressWorkflowRuntimeException extends AbstractException {

	private static final ProgressWorkflowRuntimeException.ErrorBody BODY = new ProgressWorkflowRuntimeException.ErrorBody();

	public ProgressWorkflowRuntimeException(String message) {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, message);
	}

	public ProgressWorkflowRuntimeException() {
		super(Response.Status.INTERNAL_SERVER_ERROR, BODY, "generic error");
	}

	@Schema(name = "UpdateWorkflowRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "PROGRESS_WORKFLOW_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
