package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProfileNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DossierProfileMapper extends EntityMapper<DossierProfileDTO, DossierProfileNTT> {

	DossierProfileMapper INSTANCE = Mappers.getMapper(DossierProfileMapper.class);

	@InheritInverseConfiguration()
	DossierProfileDTO entityToDto(DossierProfileNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "profileCode", target = "profile_code")
	@Mapping(source = "profileCodeDescription", target = "profile_code_description")
	DossierProfileNTT dtoToEntity(DossierProfileDTO dto);

}
