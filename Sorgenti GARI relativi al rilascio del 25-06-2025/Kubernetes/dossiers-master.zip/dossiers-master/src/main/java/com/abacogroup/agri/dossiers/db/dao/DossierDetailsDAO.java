package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierDetailsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Mauro Pozzana
 */
public interface DossierDetailsDAO extends IGenericHistoricizationFieldsDAO<DossierDetailsNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_dossiers_details_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_dossiers_details (pkid, dossier_id, dossier_code, process_status, dt_presentation, dt_closed, " +
			" amended_by_id, amend_of_id, dt_insert, dt_delete, user_id_insert, user_id_delete, fl_in_transition) " +
			"VALUES(:pkid, :dossier_id, :dossier_code, :process_status, " +
			"       :dt_presentation, :dt_closed, :amended_by_id, :amend_of_id, :current_timestamp, " +
			"       TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL, :fl_in_transition)")
	void insert(@BindBean DossierDetailsNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"dossier_id, " +
			"dossier_code, " +
			"process_status, " +
			"dt_presentation, " +
			"dt_closed, " +
			"amended_by_id, " +
			"amend_of_id, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"fl_in_transition " +
			"FROM doss_dossiers_details " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(DossierDetailsNTT.class)
	List<DossierDetailsNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.dossier_id, " +
			"ad.dossier_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"ad.dt_closed, " +
			"amended_by_id, " +
			"amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM doss_dossiers_details ad " +
			"LEFT JOIN doss_dossiers a ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE ad.dossier_code = :code AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierDetailsNTT.class)
	List<DossierDetailsNTT> findByCode(@Bind("tenant") String tenant, @Bind("code") String code);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.dossier_id, " +
			"ad.dossier_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"ad.dt_closed, " +
			"ad.amended_by_id, " +
			"ad.amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM doss_dossiers_details ad " +
			"LEFT JOIN doss_dossiers a ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierDetailsNTT.class)
	List<DossierDetailsNTT> findByDossierId(@Bind("tenant") String tenant, @Bind("doss_id") Long dosId);

	@SqlQuery("SELECT ad.pkid, " +
			"ad.dossier_id, " +
			"ad.dossier_code, " +
			"ad.process_status, " +
			"ad.dt_presentation, " +
			"ad.dt_closed, " +
			"ad.amended_by_id, " +
			"ad.amend_of_id, " +
			"ad.dt_insert, " +
			"ad.dt_delete, " +
			"ad.user_id_insert, " +
			"ad.user_id_delete, " +
			"fl_in_transition " +
			"FROM doss_dossiers_details ad " +
			"LEFT JOIN doss_dossiers a ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierDetailsNTT.class)
	List<DossierDetailsNTT> findByDossierIdAlsoExpired(@Bind("tenant") String tenant, @Bind("doss_id") Long dosId);

	@SqlQuery("SELECT MIN(ad.dt_insert) " +
			"FROM doss_dossiers_details ad " +
			"LEFT JOIN doss_dossiers a ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenant " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	LocalDateTime findFirstDtInsert(@Bind("tenant") String tenant, @Bind("doss_id") Long dosId);

	@Override
	@SqlUpdate("UPDATE doss_dossiers_details SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);
}
