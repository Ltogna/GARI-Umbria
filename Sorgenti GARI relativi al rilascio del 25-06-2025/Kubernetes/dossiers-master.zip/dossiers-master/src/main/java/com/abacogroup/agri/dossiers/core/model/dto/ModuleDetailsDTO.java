package com.abacogroup.agri.dossiers.core.model.dto;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleDetailsDTO {
	private Long pkid;
	private Long moduleId;
	private Integer annuality;
	private String contextFunction;
	private String forceReadOnlyContextFunction;
	private AbsoluteDate dtValidityStart;
	private AbsoluteDate dtValidityEnd;
}
