package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.services.AnomaliesService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import com.abacogroup.applicationworkflowsdk.service.CheckForMultipleApplications;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class CheckForMultipleDossierImpl implements CheckForMultipleApplications {

	private final AnomaliesService anomaliesService;
	private final DossiersCrudService dossiersCrudService;
	private final ModuleCrudService moduleCrudService;

	public CheckForMultipleDossierImpl(AnomaliesService anomaliesService,
									   DossiersCrudService dossiersCrudService,
									   ModuleCrudService moduleCrudService) {
		this.anomaliesService = anomaliesService;
		this.dossiersCrudService = dossiersCrudService;
		this.moduleCrudService = moduleCrudService;
	}

	@Override public boolean checkForMultipleApplications(String tenant, Long dossierId, Long partyId, Integer referredYear) {
		var app = dossiersCrudService.findWithDetailsByDossierId(tenant, dossierId);
		var moduleDto = moduleCrudService.findById(app.getModuleId());
		if (moduleDto.isPresent()) {
			return anomaliesService.checkForMultipleDossier(tenant, moduleDto.get(), partyId, referredYear, dossierId).isEmpty();
		} else {
			return false;
		}
	}
}
