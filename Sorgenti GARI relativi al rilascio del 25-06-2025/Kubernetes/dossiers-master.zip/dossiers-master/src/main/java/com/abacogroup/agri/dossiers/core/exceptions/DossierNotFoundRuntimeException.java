package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class DossierNotFoundRuntimeException extends AbstractException {

	private static final DossierNotFoundRuntimeException.ErrorBody BODY = new DossierNotFoundRuntimeException.ErrorBody();

	public DossierNotFoundRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	@Schema(name = "DossierNotFoundByCodeRuntimeExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "DOSSIER_NOT_FOUND_ERROR";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
