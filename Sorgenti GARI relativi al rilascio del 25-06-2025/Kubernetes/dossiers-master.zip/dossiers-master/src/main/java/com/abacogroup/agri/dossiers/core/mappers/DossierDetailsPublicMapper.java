package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.applicationworkflowsdk.model.io.output.ApplicationDetailsPublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DossierDetailsPublicMapper extends EntityMapper<ApplicationDetailsPublicDTO, DossierWithDetailsDTO> {

	DossierDetailsPublicMapper INSTANCE = Mappers.getMapper(DossierDetailsPublicMapper.class);

	@InheritInverseConfiguration()
	ApplicationDetailsPublicDTO entityToDto(DossierWithDetailsDTO entity);

	@Mapping(source = "applicationId", target = "dossierId")
	@Mapping(source = "applicationCode", target = "dossierCode")
	@Mapping(source = "partyId", target = "partyId")
	@Mapping(source = "referredYear", target = "referredYear")
	@Mapping(source = "processStatus", target = "processStatus")
	@Mapping(source = "processId", target = "processId")
	@Mapping(source = "dtPresentation", target = "dtPresentation")
	@Mapping(source = "dtClosed", target = "dtClosed")
	@Mapping(source = "sectorDescription", target = "sectorDescription")
	@Mapping(source = "moduleDescription", target = "moduleDescription")
	DossierWithDetailsDTO dtoToEntity(ApplicationDetailsPublicDTO dto);

}
