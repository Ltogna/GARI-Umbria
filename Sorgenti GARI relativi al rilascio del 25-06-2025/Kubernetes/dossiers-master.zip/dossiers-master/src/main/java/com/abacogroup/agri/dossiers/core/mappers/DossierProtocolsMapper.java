package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierProtocolsDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierProtocolsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DossierProtocolsMapper extends EntityMapper<DossierProtocolsDTO, DossierProtocolsNTT> {

	DossierProtocolsMapper INSTANCE = Mappers.getMapper(DossierProtocolsMapper.class);

	@InheritInverseConfiguration()
	DossierProtocolsDTO entityToDto(DossierProtocolsNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "dtRequest", target = "dt_request")
	@Mapping(source = "dtResponse", target = "dt_response")
	@Mapping(source = "protocol", target = "protocol")
	DossierProtocolsNTT dtoToEntity(DossierProtocolsDTO dto);

}
