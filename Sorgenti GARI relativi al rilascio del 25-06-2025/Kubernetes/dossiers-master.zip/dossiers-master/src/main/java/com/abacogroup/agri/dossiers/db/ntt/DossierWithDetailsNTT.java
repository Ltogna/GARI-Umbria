package com.abacogroup.agri.dossiers.db.ntt;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Alexandru Paraschiv
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierWithDetailsNTT extends DossierNTT {

	private String dossier_code;
	private String process_status;
	private LocalDateTime dt_presentation;
	private LocalDateTime dt_closed;
	private String sector_code;
	private String sector_description;
	private String module_code;
	private String module_description;
	private Long amended_by_id;
	private Long amend_of_id;
}
