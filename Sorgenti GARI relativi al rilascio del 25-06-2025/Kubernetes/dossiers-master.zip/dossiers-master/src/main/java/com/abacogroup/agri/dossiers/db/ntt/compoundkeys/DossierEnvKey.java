package com.abacogroup.agri.dossiers.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Dossier env key.
 * @author Carlo Sindico
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossierEnvKey {
    private String tenant_id;
    private String key_;
    private Integer fl_client;

}
