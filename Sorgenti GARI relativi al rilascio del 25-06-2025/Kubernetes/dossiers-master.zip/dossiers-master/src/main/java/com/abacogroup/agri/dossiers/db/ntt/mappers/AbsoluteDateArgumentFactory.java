package com.abacogroup.agri.dossiers.db.ntt.mappers;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import org.jdbi.v3.core.argument.AbstractArgumentFactory;
import org.jdbi.v3.core.argument.Argument;
import org.jdbi.v3.core.config.ConfigRegistry;

import java.sql.Types;

public class AbsoluteDateArgumentFactory extends AbstractArgumentFactory<AbsoluteDate>
{

	public AbsoluteDateArgumentFactory()
	{
		super(Types.VARCHAR);
	}

	@Override
	protected Argument build(AbsoluteDate value, ConfigRegistry config)
	{
		return (position, statement, ctx) -> statement.setString(position, value.toString());
	}

}
