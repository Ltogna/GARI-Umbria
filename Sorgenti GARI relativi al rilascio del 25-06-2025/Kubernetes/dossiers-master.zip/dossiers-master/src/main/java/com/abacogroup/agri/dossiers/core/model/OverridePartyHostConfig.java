package com.abacogroup.agri.dossiers.core.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OverridePartyHostConfig {
	private Boolean active;
	private String overriddenHost;
}
