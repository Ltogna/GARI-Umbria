package com.abacogroup.agri.dossiers.db.ntt.compoundkeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FormConfigProfileKey {

	private Long module_form_config_id;
	private String required_profile_code;
}
