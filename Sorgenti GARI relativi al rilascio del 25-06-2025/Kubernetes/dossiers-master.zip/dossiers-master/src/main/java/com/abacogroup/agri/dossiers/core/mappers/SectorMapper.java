package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.SectorDTO;
import com.abacogroup.agri.dossiers.db.ntt.SectorNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SectorMapper extends EntityMapper<SectorDTO, SectorNTT> {

	SectorMapper INSTANCE = Mappers.getMapper(SectorMapper.class);

	@InheritInverseConfiguration()
	SectorDTO entityToDto(SectorNTT entity);

	@Mapping(source = "tenantId", target = "tenant_id")
	@Mapping(source = "sectorId", target = "id")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "description", target = "description", ignore = true)
	SectorNTT dtoToEntity(SectorDTO dto);

}
