package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.caller.GetPartiesOutput;
import com.abacogroup.agri.dossiers.core.model.dto.PartyDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface PartyMapper extends EntityMapper<PartyDTO, GetPartiesOutput> {

	PartyMapper INSTANCE = Mappers.getMapper(PartyMapper.class);

	@Mapping(source = "partyId", target = "partyId")
	@Mapping(source = "code", target = "cuaa")
	@Mapping(source = "description", target = "description")
	PartyDTO callerOutToDTO(GetPartiesOutput dto);

}
