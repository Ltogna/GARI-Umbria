package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleWithDetailNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface ModuleWithDetailMapper extends EntityMapper<ModuleWithDetailDTO, ModuleWithDetailNTT> {

	ModuleWithDetailMapper INSTANCE = Mappers.getMapper(ModuleWithDetailMapper.class);

	@InheritInverseConfiguration()
	ModuleWithDetailDTO entityToDto(ModuleWithDetailNTT entity);

	@Mapping(source = "moduleId", target = "id")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "sectorId", target = "sector_id")
	@Mapping(source = "workflowCode", target = "workflow_code")
	@Mapping(source = "annuality", target = "annuality")
	@Mapping(source = "contextFunction", target = "context_function")
	@Mapping(source = "forceReadOnlyContextFunction", target = "force_read_only_context_function")
	@Mapping(source = "dtValidityStart", target = "dt_validity_start")
	@Mapping(source = "dtValidityEnd", target = "dt_validity_end")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "sectorDescription", target = "sector_description")
	@Mapping(source = "moduleDescription", target = "module_description")
	@Mapping(source = "flAmendModule", target = "fl_amend_module")
	ModuleWithDetailNTT dtoToEntity(ModuleWithDetailDTO dto);

	default boolean map(Integer value) {
		return value != null && (value == 1);
	}
	default int map(Boolean value) {
		return value == null ? 0 : (value ? 1 : 0);
	}

}
