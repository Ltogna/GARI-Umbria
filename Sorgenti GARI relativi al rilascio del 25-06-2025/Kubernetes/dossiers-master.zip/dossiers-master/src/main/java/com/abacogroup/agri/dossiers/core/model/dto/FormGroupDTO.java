package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FormGroupDTO {

	private Long id;
	private String tenantId;
	private String formGroupCode;
	private String formGroupDescription;
	private Long parentFormGroupId;
}
