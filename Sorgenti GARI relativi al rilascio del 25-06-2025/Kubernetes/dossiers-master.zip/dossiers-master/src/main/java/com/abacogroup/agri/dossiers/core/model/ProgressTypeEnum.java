package com.abacogroup.agri.dossiers.core.model;

/**
 * @author Gennaro Tamburrelli
 */
public enum ProgressTypeEnum {

	SYNC,
	ASYNC;
}
