package com.abacogroup.agri.dossiers.bundles;

/**
 * @author Gennaro Tamburrelli
 * @author Alexandru Paraschiv
 */
public class BundleConstants {

	private BundleConstants() {
	}

	public static final String TENANT_TEMPLATE_CODE = "*";
	public static final String BUNDLE_SYSTEM_USERNAME = "BUNDLE";
}
