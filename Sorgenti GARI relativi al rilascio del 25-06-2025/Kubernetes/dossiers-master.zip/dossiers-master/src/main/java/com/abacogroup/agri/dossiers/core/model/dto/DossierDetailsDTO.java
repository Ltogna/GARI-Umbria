package com.abacogroup.agri.dossiers.core.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Mauro Pozzana
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DossierDetailsDTO {
	private Long pkid;
	private Long dossierId;
	private String dossierCode;
	private String processStatus;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtPresentation;
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private LocalDateTime dtClosed;
	private Long amendedById;
	private Long amendOfId;
	private String userIdInsert;
	private String userIdDelete;
	private LocalDateTime dtInsert;
	private LocalDateTime dtDelete;
	private Integer flInTransition;
}
