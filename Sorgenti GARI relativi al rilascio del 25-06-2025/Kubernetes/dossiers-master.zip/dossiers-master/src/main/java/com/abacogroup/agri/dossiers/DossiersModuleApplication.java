package com.abacogroup.agri.dossiers;

import com.abacogroup.agri.dossiers.bundles.model.BundleConfig;
import com.abacogroup.agri.dossiers.bundles.processor.amendable.AmendableModuleNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.amendable.AmendableModulesBundleWorker;
import com.abacogroup.agri.dossiers.bundles.processor.amendable.BundleAmendableModulesProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.anomaly.AnomalyCatalogBundleWorker;
import com.abacogroup.agri.dossiers.bundles.processor.anomaly.AnomalyCatalogNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.anomaly.BundleAnomalyCatalogProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.env.DossierEnvBundleWorker;
import com.abacogroup.agri.dossiers.bundles.processor.env.DossierEnvNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.env.BundleDossierEnvProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.module.BundleModulesProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.module.ModuleNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.module.ModulesBundleWorker;
import com.abacogroup.agri.dossiers.bundles.processor.sector.BundleSectorsProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.sector.SectorNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.sector.SectorsBundleWorker;
import com.abacogroup.agri.dossiers.bundles.processor.workflow.BundleWorkflowsProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.workflow.WorkflowNewTenantProcessor;
import com.abacogroup.agri.dossiers.bundles.processor.workflow.WorkflowsBundleWorker;
import com.abacogroup.agri.dossiers.core.caller.*;
import com.abacogroup.agri.dossiers.core.exceptions.AgriDossiersException;
import com.abacogroup.agri.dossiers.core.mappers.*;
import com.abacogroup.agri.dossiers.core.model.DossiersCommitPayload;
import com.abacogroup.agri.dossiers.core.model.QueueProcessorConfig;
import com.abacogroup.agri.dossiers.core.model.RabbitMqConfig;
import com.abacogroup.agri.dossiers.core.services.*;
import com.abacogroup.agri.dossiers.core.services.crud.*;
import com.abacogroup.agri.dossiers.core.services.embededqueue.CreateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.ResetIsInTransitionProcessQueue;
import com.abacogroup.agri.dossiers.core.services.embededqueue.UpdateProcessQueue;
import com.abacogroup.agri.dossiers.core.services.print.PrintMessageListener;
import com.abacogroup.agri.dossiers.core.services.print.PrintService;
import com.abacogroup.agri.dossiers.core.services.protocol.ProtocolListener;
import com.abacogroup.agri.dossiers.core.services.workflow.*;
import com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl.*;
import com.abacogroup.agri.dossiers.db.dao.*;
import com.abacogroup.agri.dossiers.resources.DossiersPrivateResources;
import com.abacogroup.agri.dossiers.resources.DossiersPublicResources;
import com.abacogroup.agri.dossiers.resources.WorkflowResources;
import com.abacogroup.agri.dossiers.services.factory.ProcedureEnvironmentFactory;
import com.abacogroup.agri.dossiers.utils.*;
import com.abacogroup.applicationworkflowsdk.caller.factory.CallerFactory;
import com.abacogroup.applicationworkflowsdk.service.*;
import com.abacogroup.bundles.initializer.BundleInitServiceBuilder;
import com.abacogroup.bundles.listener.ListenerBuilder;
import com.abacogroup.bundles.listener.configdata.ProcessorOrderPolicyEnum;
import com.abacogroup.bundles.listener.configdata.builder.ConfigDataConsumerBuilder;
import com.abacogroup.bundles.listener.tenant.builder.NewTenantEventConsumerBuilder;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.dropwizard.auth.sso2.SsoAuthorizer;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.embeddedqueue.AbstractWorkQueue;
import com.abacogroup.embeddedqueue.db.JdbiRepository;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisher;
import com.abacogroup.embeddedqueue.rabbitmq.RabbitMqPublisherWorkQueue;
import com.abacogroup.filestore.client.FileStoreClient;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.filter.MDCPostFilter;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import com.abacogroup.jaxrsutils.model.AbacoTechUser;
import com.abacogroup.jdbi.OraJdbiPlugin;
import com.abacogroup.jdbi.PgJdbiPlugin;
import com.abacogroup.jdbi.config.AbacoJdbiConfig;
import com.abacogroup.workflow.server.services.ProcessService;
import com.abacogroup.workflow.server.services.WorkflowService;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.Application;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.db.DataSourceFactory;
import io.dropwizard.jdbi3.JdbiFactory;
import io.dropwizard.jdbi3.bundles.JdbiExceptionsBundle;
import io.dropwizard.migrations.MigrationsBundle;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.SwaggerConfiguration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration;
import jakarta.ws.rs.client.Client;
import lombok.extern.slf4j.Slf4j;
import oracle.jdbc.OracleConnection;
import org.apache.commons.lang3.StringUtils;
import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.jdbi.v3.core.Jdbi;
import org.jdbi.v3.core.statement.Slf4JSqlLogger;
import org.jdbi.v3.sqlobject.SqlObjectPlugin;
import org.locationtech.jts.geom.Geometry;

import java.io.IOException;
import java.net.URI;
import java.sql.DatabaseMetaData;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.abacogroup.agri.dossiers.core.services.print.PrintService.PRINT_DESTINATION;
import static com.abacogroup.applicationworkflowsdk.model.Constants.GENERIC_CALLER_SERVICE_KEY;

@Slf4j
public class DossiersModuleApplication extends Application<DossiersModuleConfiguration> {
	public static void main(String[] args) throws Exception {
		new DossiersModuleApplication().run(args);
	}

	@Override
	public void initialize(Bootstrap<DossiersModuleConfiguration> bootstrap) {
		bootstrap.addBundle(new JdbiExceptionsBundle());
		bootstrap.addBundle(new MigrationsBundle<>() {
			@Override
			public DataSourceFactory getDataSourceFactory(DossiersModuleConfiguration configuration) {
				return configuration.getDatabase();
			}
		});
		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
	}

	private static final String EXCHANGE_NAME = "dossiers-events";
	private static final String QUEUE_ID = "dossiers-queue";
	private AbstractWorkQueue<DossiersCommitPayload, ?> createMessageQueue(Environment environment, Jdbi jdbi,
																		   Connection rabbitmqConnection, DossiersModuleConfiguration dossiersModuleConfiguration)
			throws IOException
	{
		if (rabbitmqConnection == null)
			return null;

		RabbitMqPublisherWorkQueue<DossiersCommitPayload> queue = new RabbitMqPublisherWorkQueue<>(QUEUE_ID, new JdbiRepository(jdbi)) {
			@Override
			protected Class<DossiersCommitPayload> getJobClass() {
				return DossiersCommitPayload.class;
			}
		};
		queue.setMetricRegistry(environment.metrics());
		var publisher = new RabbitMqPublisher<DossiersCommitPayload>(rabbitmqConnection) {
			@Override
			protected String getExchangeName() {
				return EXCHANGE_NAME;
			}

			@Override
			protected String getRoutingKey(DossiersCommitPayload payload) {
				return String.format("dossier_transition.%s.%s.%s",
						payload.getDossierSectorCode(),
						payload.getDossierModuleCode(),
						payload.getCurrentNode());
			}

			@Override
			protected Map<String, Object> getMessageHeaders(DossiersCommitPayload payload) {
				return Map.of("tenant", payload.getTenant());
			}
		};
		queue.setConsumer(publisher);

		if (!dossiersModuleConfiguration.isDevMode())
			queue.start();

		return queue;
	}

	@Override
	public void run(DossiersModuleConfiguration config, Environment environment) throws Exception {
		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		final Jdbi jdbi = getJdbi(config.getDatabase(), environment, "dossiers", "doss", true);
		Map<String, Jdbi> procedureEnironmentJdbis = new HashMap<>();
		if (!"DISABLED".equals(config.getDatabase().getUrl())) {
			final Jdbi jdbiForms = getJdbi(config.getDatabase(), environment, "FORMS", null, false);
			procedureEnironmentJdbis.put("FORMS", jdbiForms);
		}
		// DAOs Initialization
		I18NDAO i18NDAO = jdbi.onDemand(I18NDAO.class);
		SectorDAO sectorDAO = jdbi.onDemand(SectorDAO.class);
		ModuleDAO moduleDAO = jdbi.onDemand(ModuleDAO.class);
		ModuleDetailsDAO moduleDetailsDAO = jdbi.onDemand(ModuleDetailsDAO.class);
		DossierDetailsDAO dossierDetailsDAO = jdbi.onDemand(DossierDetailsDAO.class);
		DossierDAO dossierDAO = jdbi.onDemand(DossierDAO.class);
		FormCatalogDAO formCatalogDAO = jdbi.onDemand(FormCatalogDAO.class);
		ModuleFormConfigsDAO moduleFormConfigsDAO = jdbi.onDemand(ModuleFormConfigsDAO.class);
		FormGroupDAO formGroupDAO = jdbi.onDemand(FormGroupDAO.class);
		ModuleFormConfigParamDAO moduleFormConfigParamDAO = jdbi.onDemand(ModuleFormConfigParamDAO.class);
		DossierProfileDAO dossierProfileDAO = jdbi.onDemand(DossierProfileDAO.class);
		ModuleFormConfigProfileDAO moduleFormConfigProfileDAO = jdbi.onDemand(ModuleFormConfigProfileDAO.class);
		ModuleProfileDAO moduleProfilesDAO = jdbi.onDemand(ModuleProfileDAO.class);
		DossierCompileStatusDAO dossierCompileStatusDAO = jdbi.onDemand(DossierCompileStatusDAO.class);
		AnomalyDAO anomalyDAO = jdbi.onDemand(AnomalyDAO.class);
		AnomalyCatalogDAO anomalyCatalogDAO = jdbi.onDemand(AnomalyCatalogDAO.class);
		ModulePrintConfigsDAO modulePrintConfigsDAO = jdbi.onDemand(ModulePrintConfigsDAO.class);
		ModulePrintConfigParamDAO modulePrintConfigParamDAO = jdbi.onDemand(ModulePrintConfigParamDAO.class);
		ModulePrintConfigProfileDAO modulePrintConfigProfileDAO = jdbi.onDemand(ModulePrintConfigProfileDAO.class);
		DossierGeneratedPrintDAO dossierGeneratedPrintDAO = jdbi.onDemand(DossierGeneratedPrintDAO.class);
		DossierEnvDAO dossierEnvDAO = jdbi.onDemand(DossierEnvDAO.class);
		DossierProtocolsDAO dossierProtocolsDAO = jdbi.onDemand(DossierProtocolsDAO.class);
		AmendableModuleDAO amendableModuleDAO = jdbi.onDemand(AmendableModuleDAO.class);

		// build http client
		JerseyClientConfiguration clientConfig = config.getJerseyClientConfiguration();
		final Client client = new JerseyClientBuilder(environment).using(clientConfig)
				.build(getName());

		// SSO2 Client
		Sso2Client sso2Client = new Sso2Client(config.getSso2TokenSecretAuth(), client.target(config.getSso2Url()));
		GenericCallerService genericCallerService = new GenericCallerService(client, new AbacoTechUser());
		GetUserBySso2Caller getUserBySso2Caller = new GetUserBySso2Caller(genericCallerService);

		FileStoreClient fileStoreClient = new FileStoreClient(URI.create(config.getFileStoreUrl()), objectMapper);
		FileStoreService fileStoreService = new FileStoreService(fileStoreClient);

		AuthContextFactory authContextFactory = new AuthContextFactory(sso2Client);
		FileFactory fileFactory = new FileFactory();

		// caller
		GetPartiesCaller getPartiesCaller = new GetPartiesCaller(genericCallerService);
		GetPartyByPartyIdCaller getPartyByPartyIdCaller = new GetPartyByPartyIdCaller(genericCallerService);
		GetPartiesRegistryCaller getPartiesRegistryCaller = new GetPartiesRegistryCaller(genericCallerService);
		GetPartyRegistryByPartyIdCaller getPartyRegistryByPartyIdCaller = new GetPartyRegistryByPartyIdCaller(genericCallerService);

		// Service init
		I18NService i18NService = new I18NService(i18NDAO);
		SectorsCrudService sectorsCrudService = new SectorsCrudService(sectorDAO, SectorMapper.INSTANCE, i18NService);
		ModuleCrudService moduleCrudService = new ModuleCrudService(moduleDAO, ModuleMapper.INSTANCE, i18NService);
		ModuleDetailsCrudService moduleDetailsCrudService = new ModuleDetailsCrudService(moduleDetailsDAO, ModuleDetailsMapper.INSTANCE);
		DossierDetailsCrudService dossierDetailsCrudService = new DossierDetailsCrudService(dossierDetailsDAO,
				DossierDetailsMapper.INSTANCE);
		DossiersCrudService dossiersCrudService = new DossiersCrudService(dossierDAO, DossierMapper.INSTANCE);
		DossierEnvCrudService dossierEnvCrudService = new DossierEnvCrudService(dossierEnvDAO,
				DossierEnvMapper.INSTANCE);
		ConfigService configService = new ConfigService(dossierEnvCrudService);
		PartyService partyService = new PartyService(configService, getPartiesCaller, getPartyByPartyIdCaller, getPartiesRegistryCaller,
				getPartyRegistryByPartyIdCaller, config.getOverridePartyHostConfig());

		JdbiRepository jdbiRepository = new JdbiRepository(jdbi);
		QueueProcessorConfig queueProcessorConfig = config.getQueueProcessorConfig();
		ResetIsInTransitionProcessQueue resetIsInTransitionProcessQueue = new ResetIsInTransitionProcessQueue(jdbiRepository, objectMapper,
				environment.metrics(),
				dossierDetailsCrudService, queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());

		DossierProfilesCrudService dossierProfilesCrudService = new DossierProfilesCrudService(dossierProfileDAO,
				DossierProfileMapper.INSTANCE, i18NService);

		FormCatalogsCrudService formCatalogsCrudService = new FormCatalogsCrudService(formCatalogDAO, FormCatalogMapper.INSTANCE, i18NService);
		ModuleFormConfigsCrudService moduleFormConfigsCrudService = new ModuleFormConfigsCrudService(moduleFormConfigsDAO, ModuleFormConfigsMapper.INSTANCE,
				i18NService);
		FormGroupsCrudService formGroupsCrudService = new FormGroupsCrudService(formGroupDAO, FormGroupMapper.INSTANCE, i18NService);
		ModuleFormConfigParamCrudService moduleFormConfigParamCrudService = new ModuleFormConfigParamCrudService(moduleFormConfigParamDAO,
				ModuleFormConfigParamMapper.INSTANCE, i18NService);

		ModuleProfilesCrudService moduleProfilesCrudService = new ModuleProfilesCrudService(moduleProfilesDAO, ModuleProfileMapper.INSTANCE, i18NService);
		DossierCompileStatusCrudService dossierCompileStatusCrudService = new DossierCompileStatusCrudService(dossierCompileStatusDAO,
				DossierCompileStatusMapper.INSTANCE);
		AnomaliesCrudService anomaliesCrudService = new AnomaliesCrudService(anomalyDAO, AnomalyMapper.INSTANCE);
		AnomalyCatalogCrudService anomalyCatalogCrudService = new AnomalyCatalogCrudService(anomalyCatalogDAO, AnomalyCatalogMapper.INSTANCE, i18NService);

		ModulePrintConfigsCrudService modulePrintConfigsCrudService = new ModulePrintConfigsCrudService(modulePrintConfigsDAO,
				ModulePrintConfigsMapper.INSTANCE, i18NService);
		ModulePrintConfigProfilesCrudService modulePrintConfigProfilesCrudService = new ModulePrintConfigProfilesCrudService(modulePrintConfigProfileDAO,
				ModulePrintConfigProfileMapper.INSTANCE);
		ModulePrintConfigParamCrudService modulePrintConfigParamCrudService = new ModulePrintConfigParamCrudService(modulePrintConfigParamDAO,
				ModulePrintConfigParamMapper.INSTANCE);
		DossierGeneratedPrintCrudService dossierGeneratedPrintCrudService = new DossierGeneratedPrintCrudService(dossierGeneratedPrintDAO,
				DossierGeneratedPrintMapper.INSTANCE);

		DossierProtocolsCrudService dossierProtocolsCrudService = new DossierProtocolsCrudService(dossierProtocolsDAO,
				DossierProtocolsMapper.INSTANCE);
		AmendableModuleCrudService amendableModuleCrudService = new AmendableModuleCrudService(amendableModuleDAO,
				AmendableModuleMapper.INSTANCE);
		AmendmentService amendmentService = new AmendmentService(moduleCrudService,
				dossiersCrudService, amendableModuleCrudService, dossierDetailsCrudService);

		ModuleFormConfigProfilesCrudService moduleFormConfigProfilesCrudService = new ModuleFormConfigProfilesCrudService(moduleFormConfigProfileDAO,
				ModuleFormConfigProfileMapper.INSTANCE);

		FormConfigService formConfigService = new FormConfigService(formCatalogsCrudService, formGroupsCrudService, moduleFormConfigsCrudService,
				moduleFormConfigParamCrudService, moduleProfilesCrudService, modulePrintConfigsCrudService, modulePrintConfigParamCrudService,
				dossierGeneratedPrintCrudService, moduleCrudService, moduleFormConfigProfilesCrudService, modulePrintConfigProfilesCrudService);
		// Workflow
		WorkflowService workflowService = new WorkflowService(jdbi);
		ProcedureEnvironmentFactory procedureEnvironmentFactory = new ProcedureEnvironmentFactory(jdbi, procedureEnironmentJdbis, client,
				config.getEnvironmentId());

		// Workflow services
		CallerFactory callerFactory = new CallerFactory();
		AnomalyHandler anomalyHandler = new AnomalyHandlerImpl(anomaliesCrudService);
		CheckCanReadPartyCaller checkCanReadPartyCaller = new CheckCanReadPartyCaller(genericCallerService);
		CheckPartyService checkPartyService = new CheckPartyService(checkCanReadPartyCaller, dossierEnvCrudService, config.getCheckCanReadConfig(),
				config.getCheckCanReadAllPartiesConfig());
		CheckCompileStatus checkCompileStatus = new CheckCompileStatusImpl(dossierCompileStatusCrudService);
		GetFormConfigs getFormConfigs = new GetFormConfigsImpl(dossiersCrudService, dossierProfilesCrudService, dossierCompileStatusCrudService,
				formConfigService, sso2Client);
		GetApplicationProfiles getDossierProfiles = new GetDossierProfilesImpl(dossiersCrudService, moduleProfilesCrudService,
				dossierProfilesCrudService);
		CheckApplicationProfiles checkDossierProfiles = new CheckApplicationProfiles(getDossierProfiles);
		SetApplicationPresentationDate setPresentationDateService = new SetPresentationDateServiceImpl(dossierDetailsCrudService);
		SetApplicationClosureDate setClosureDateService = new SetClosureDateServiceImpl(dossierDetailsCrudService);
		StopTransitionService stopTransitionService = new StopTransitionService();


		DossiersWorkflowUtils dossiersWorkflowUtils = new DossiersWorkflowUtils(workflowService);

		LogicallyDeleteDossierImpl logicallyDeleteDossier = new LogicallyDeleteDossierImpl(dossiersCrudService);
		DossierProfilesService dossierProfilesService = new DossierProfilesService(jdbi, dossiersCrudService, dossierProfilesCrudService,
				moduleProfilesCrudService);

		CreatePrintJobCaller createPrintJobCaller = new CreatePrintJobCaller(genericCallerService);

		Map<String, Object> utilsMap = new HashMap<>();
		utilsMap.put(CheckCompileStatus.KEY, checkCompileStatus);
		utilsMap.put(GetFormConfigs.KEY, getFormConfigs);
		utilsMap.put(GetApplicationProfiles.KEY, getDossierProfiles);
		utilsMap.put(CheckApplicationProfiles.KEY, checkDossierProfiles);
		utilsMap.put(GENERIC_CALLER_SERVICE_KEY, genericCallerService);
		utilsMap.put(AnomalyHandler.KEY, anomalyHandler);
		utilsMap.put(CallerFactory.KEY, callerFactory);
		utilsMap.put(StopTransitionService.KEY, stopTransitionService);
		utilsMap.put(WorkflowUtils.KEY, dossiersWorkflowUtils);
		utilsMap.put(SetPresentationDateServiceImpl.KEY, setPresentationDateService);
		utilsMap.put(SetApplicationClosureDate.KEY, setClosureDateService);
		utilsMap.put(LogicallyDeleteApplication.KEY, logicallyDeleteDossier);
		utilsMap.put(UpsertApplicationProfiles.KEY, dossierProfilesService);

		Connection rabbitMQConnection = createRabbitmqConnection(config.getRabbitmqConfig());

		AbstractWorkQueue<DossiersCommitPayload, ?> msgQueue = createMessageQueue(environment, jdbi, rabbitMQConnection, config);

		ProcessService<?> processService = procedureEnvironmentFactory.createProcessService(utilsMap); // listener is added later

		DossiersWorkflowService dossiersWorkflowService = new DossiersWorkflowService(workflowService, processService, authContextFactory,
				fileFactory, dossierProfilesCrudService);

		HistoryService historyService = new HistoryService(dossiersCrudService, checkPartyService, dossiersWorkflowService);
		DossierProtocolUtilsImpl dossierProtocolUtils = new DossierProtocolUtilsImpl(dossiersCrudService, dossierProtocolsCrudService,
				dossierGeneratedPrintCrudService, historyService);
		utilsMap.put(ApplicationProtocolUtils.KEY, dossierProtocolUtils); // put in utils map

		ForceReadOnlyContextCheckerService forceReadOnlyContextCheckerService = new ForceReadOnlyContextCheckerService(
				dossiersCrudService, moduleCrudService, sso2Client);

		PrintService printService = new PrintService(dossiersCrudService, checkPartyService, moduleCrudService, dossiersWorkflowService,
				modulePrintConfigsCrudService, modulePrintConfigParamCrudService, dossierGeneratedPrintCrudService,
				createPrintJobCaller,
				fileStoreService, config.getPrintsBucket(), config.getPrintEngineUrl(), forceReadOnlyContextCheckerService);
		PrintUtilsImpl printUtils = new PrintUtilsImpl(dossiersCrudService, dossierProfilesCrudService, printService, sso2Client);
		utilsMap.put(PrintUtils.KEY, printUtils); // put in utils map

		CreateProcessQueue createProcessQueue = new CreateProcessQueue(jdbiRepository, objectMapper, environment.metrics(), dossiersWorkflowService,
				queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());
		UpdateProcessQueue updateProcessQueue = new UpdateProcessQueue(jdbiRepository, objectMapper, environment.metrics(), dossiersWorkflowService,
				dossierDetailsCrudService,
				queueProcessorConfig.getNumThreads(), queueProcessorConfig.getTimeoutMs());



		ProgressService progressService = new ProgressService(jdbi, dossiersWorkflowService, dossiersCrudService, dossierDetailsCrudService,
				forceReadOnlyContextCheckerService, updateProcessQueue);

		DossierAmendImpl dossierAmend = new DossierAmendImpl(progressService, dossierDetailsCrudService);
		utilsMap.put(AmendApplication.KEY, dossierAmend); // put in utils map

		DossiersService dossiersService = new DossiersService(jdbi,
				dossiersWorkflowService,
				checkPartyService,
				partyService,
				moduleCrudService,
				moduleDetailsCrudService,
				dossiersCrudService,
				dossierDetailsCrudService,
				dossierProfilesCrudService,
				dossierCompileStatusCrudService,
				moduleFormConfigsCrudService,
				moduleProfilesCrudService,
				modulePrintConfigsCrudService,
				modulePrintConfigParamCrudService,
				createProcessQueue,
				progressService,
				dossierGeneratedPrintCrudService,
				sectorsCrudService,
				formConfigService,
				dossierProtocolsCrudService,
				amendmentService,
				printService,
				forceReadOnlyContextCheckerService);
		AnomaliesService anomaliesService = new AnomaliesService(dossiersService, moduleCrudService, dossiersCrudService,
				dossierDetailsCrudService);

		dossiersService.setAnomaliesService(anomaliesService);

		CheckForMultipleDossierImpl checkForMultiplecheckForMultipleDossier = new CheckForMultipleDossierImpl(anomaliesService, dossiersCrudService,
				moduleCrudService);
		utilsMap.put(CheckForMultipleApplications.KEY, checkForMultiplecheckForMultipleDossier);

		processService.addProcessListener(new DossierProcessListener(dossiersCrudService, dossierDetailsCrudService, dossiersWorkflowService,
				jdbi, msgQueue, sso2Client));

		// RabbitMQ queue configuration
		WorkflowsBundleWorker workflowsBundleWorker = new WorkflowsBundleWorker(dossiersWorkflowService);
		SectorsBundleWorker sectorsBundleWorker = new SectorsBundleWorker(sectorsCrudService);
		ModulesBundleWorker modulesBundleWorker = new ModulesBundleWorker(moduleCrudService, moduleDetailsCrudService, sectorsCrudService,
				formCatalogsCrudService, formGroupsCrudService, moduleFormConfigsCrudService, moduleFormConfigParamCrudService,
				moduleFormConfigProfilesCrudService, modulePrintConfigsCrudService, modulePrintConfigParamCrudService, modulePrintConfigProfilesCrudService,
				moduleProfilesCrudService, formConfigService);
		AnomalyCatalogBundleWorker anomalyCatalogBundleWorker = new AnomalyCatalogBundleWorker(anomalyCatalogCrudService, moduleCrudService);
		DossierEnvBundleWorker dossierEnvBundleWorker = new DossierEnvBundleWorker(dossierEnvCrudService);
		AmendableModulesBundleWorker amendableModulesBundleWorker = new AmendableModulesBundleWorker(amendableModuleCrudService, moduleCrudService,
				moduleDetailsCrudService);

		createBundleInfrastructure(config.getActivateBundleConfig(), rabbitMQConnection, jdbi, objectMapper,
				workflowsBundleWorker, sectorsBundleWorker, modulesBundleWorker, anomalyCatalogBundleWorker,
				dossierEnvBundleWorker, config.getBundleConfig(), config.getBundleServiceId(), amendableModulesBundleWorker);

		// async print listener
		PrintMessageListener printMessageListener = new PrintMessageListener(rabbitMQConnection, PRINT_DESTINATION, objectMapper,
				dossierGeneratedPrintCrudService,
				jdbi);

		// async protocol listener
		ProtocolListener protocolListener = new ProtocolListener(rabbitMQConnection, objectMapper, dossierProtocolsCrudService, jdbi);
		// Resources Registration
		environment.jersey().register(new WorkflowResources(dossiersWorkflowService));
		environment.jersey().register(
				new DossiersPublicResources(dossiersService, dossierProfilesService, formConfigService, (AnomalyHandlerImpl) anomalyHandler,
						(SetClosureDateServiceImpl) setClosureDateService, printService));
		environment.jersey()
				.register(new DossiersPrivateResources(dossiersService, configService, formConfigService, printService,
						(AnomalyHandlerImpl) anomalyHandler, amendmentService));

		environment.jersey().register(new MDCPreFilter());
		environment.jersey().register(new MDCPostFilter());
		environment.jersey().register(MultiPartFeature.class);

		registerAuthFilters(sso2Client, config, environment);

		// register cors filter
		setupCORS(environment);

		// init open api
		initOpenApi(environment);

	}

	private Jdbi getJdbi(DataSourceFactory dataSourceFactory, Environment environment, String dbname, String tablePrefix, boolean mainDb)
			throws AgriDossiersException {

		JdbiFactory factory = new JdbiFactory();
		final Jdbi jdbi = factory.build(environment, dataSourceFactory, dbname);
		jdbi.setSqlLogger(new Slf4JSqlLogger());
		boolean isPostgres = jdbi.withHandle(h -> {
			String db = h.queryMetadata(DatabaseMetaData::getDatabaseProductName);
			log.info("Database connection is '{}'", db);
			return db.toLowerCase().contains("postgresql");
		});

		if (mainDb) {
			DbUtils.mainDbIsPostgres = isPostgres;
		}

		// jdbi database configuration
		jdbi.installPlugin(new SqlObjectPlugin());
		if (isPostgres) {
			jdbi.installPlugin(new PgJdbiPlugin());
		} else {
			var params = new OraJdbiPlugin.OraJdbiPluginParams(cnn -> cnn.unwrap(OracleConnection.class), true);
			jdbi.installPlugin(new OraJdbiPlugin(params));
		}

		if (tablePrefix != null) {
			jdbi.configure(AbacoJdbiConfig.class, cfg -> cfg.setTablesPrefix(tablePrefix));
		}

		return jdbi;
	}

	private void registerAuthFilters(Sso2Client client, DossiersModuleConfiguration config, Environment environment) {
		if (config.isSecureAuth()) {
			AuthUtils.installAuthFilter(environment, client, new SsoAuthorizer(client));
		} else {
			environment.jersey().register(new DevFilter.Builder<User>()
					.setAuthenticator(new DevAuthenticator())
					.setAuthorizer(new DevAuthorizer<>(config.getDevUser()))
					.setRealm("DEV Env")
					.buildAuthFilter());
			environment.jersey().register(new AuthValueFactoryProvider.Binder<>(User.class));
		}

	}

	private void initOpenApi(Environment environment) {
		OpenAPI oas = new OpenAPI();

		oas.info(new Info()
				.title("ABACO AGRI Applications")
				.description("Applications")
				.version("1.0")
				// .termsOfService("http://example.com/terms")
				.contact(new Contact().email("info@abacogroup.eu")));
		SwaggerConfiguration oasConfig = new SwaggerConfiguration()
				.openAPI(oas)
				.prettyPrint(true)
				.resourcePackages(Stream.of("com.abacogroup.agri.dossiers.resources")
						.collect(Collectors.toSet()));

		environment.jersey().register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		objectMapper.disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
		// objectMapper.registerModule(new JavaTimeModule());

		SimpleModule module = new SimpleModule("custom-deserializers", Version.unknownVersion());
		module.addSerializer(Geometry.class, new WKTGeometrySerializer());
		module.addDeserializer(Geometry.class, new WKTGeometryDeserializer());

		objectMapper.registerModule(module);
	}

	private void setupCORS(Environment environment) {
		log.info("CORS is enabled");

		FilterRegistration.Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,PATCH,DELETE");

		// OPTIONS pre-flight request will be served by the filter ONLY and not passed ahead
		// cors.setInitParameter(CrossOriginFilter.CHAIN_PREFLIGHT_PARAM, "false");

		// Add URL mapping
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	protected Connection createRabbitmqConnection(RabbitMqConfig rabbitmqConfig) {
		if (rabbitmqConfig == null) {
			return null;
		}

		if (StringUtils.isBlank(rabbitmqConfig.getHost())) {
			return null;
		}

		ConnectionFactory factory = new ConnectionFactory();
		factory.setHost(rabbitmqConfig.getHost());

		if (!StringUtils.isBlank(rabbitmqConfig.getUser())) {
			factory.setUsername(rabbitmqConfig.getUser());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getPassword())) {
			factory.setPassword(rabbitmqConfig.getPassword());
		}
		if (!StringUtils.isBlank(rabbitmqConfig.getVirtualhost())) {
			factory.setVirtualHost(rabbitmqConfig.getVirtualhost());
		}
		if (rabbitmqConfig.getPort() != null) {
			factory.setPort(rabbitmqConfig.getPort());
		}
		factory.setAutomaticRecoveryEnabled(true);

		try {
			return factory.newConnection();
		} catch (IOException | TimeoutException e) {
			throw new IllegalStateException("Cannot connect to rabbit mq", e);
		}
	}

	private void createBundleInfrastructure(boolean activateBundleConfig, Connection rabbitMQConnection, Jdbi jdbi, ObjectMapper objectMapper,
			WorkflowsBundleWorker workflowsBundleWorker,
			SectorsBundleWorker sectorsBundleWorker,
			ModulesBundleWorker modulesBundleWorker,
			AnomalyCatalogBundleWorker anomalyCatalogBundleWorker,
			DossierEnvBundleWorker dossierEnvBundleWorker,
			BundleConfig bundleConfig, String serviceName,
			AmendableModulesBundleWorker amendableModulesBundleWorker) {

		if (rabbitMQConnection == null) {
			throw new IllegalStateException("Connection to RabbitMQ instance failed but needed");
		}
		if (activateBundleConfig) {
			try {
				// Listener
				ListenerBuilder.newBuilder(rabbitMQConnection)
						.withConfigDataConsumer(ConfigDataConsumerBuilder.newBuilder(jdbi, rabbitMQConnection)
								.route(serviceName)
								.processors(
										new BundleWorkflowsProcessor(workflowsBundleWorker, jdbi),
										new BundleSectorsProcessor(objectMapper, sectorsBundleWorker, jdbi),
										new BundleModulesProcessor(objectMapper, modulesBundleWorker, jdbi),
										new BundleAnomalyCatalogProcessor(objectMapper, anomalyCatalogBundleWorker, jdbi),
										new BundleDossierEnvProcessor(objectMapper, dossierEnvBundleWorker, jdbi),
										new BundleAmendableModulesProcessor(objectMapper, amendableModulesBundleWorker, jdbi))
								.withOrderPolicy(ProcessorOrderPolicyEnum.PROCESSOR)
								.build())
						.withNewTenantEventConsumer(NewTenantEventConsumerBuilder.newBuilder(jdbi)
								.route(serviceName)
								.processors(
										new WorkflowNewTenantProcessor(jdbi, workflowsBundleWorker),
										new SectorNewTenantProcessor(jdbi, sectorsBundleWorker),
										new ModuleNewTenantProcessor(jdbi, modulesBundleWorker),
										new AnomalyCatalogNewTenantProcessor(jdbi, anomalyCatalogBundleWorker),
										new DossierEnvNewTenantProcessor(jdbi, dossierEnvBundleWorker),
										new AmendableModuleNewTenantProcessor(jdbi, amendableModulesBundleWorker))
								.build())
						.buildListener()
						.start();

			} catch (Exception e) {
				throw new IllegalStateException("Error starting rabbitmq listener", e);
			}
			try {
				// Producer
				BundleInitServiceBuilder.producer(rabbitMQConnection)
						.configLocation(bundleConfig.getConfigLocation())
						.build()
						.start();

			} catch (Exception e) {
				throw new IllegalStateException("Error starting rabbitmq producer", e);
			}
		}
	}

}
