package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.AnomalyNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface AnomalyDAO extends IGenericHistoricizationFieldsDAO<AnomalyNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(DOSS_DOSSIERS_ANOMALIES_ID_SEQ)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO DOSS_ANOMALIES " +
			"(pkid, " +
			"dossier_id, " +
			"anomaly_code, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:pkid, :dossier_id, :anomaly_code, :user_insert, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean AnomalyNTT ntt, @Bind("user_insert") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select a.pkid," +
			"  a.dossier_id," +
			"  a.anomaly_code," +
			"  a.dt_insert," +
			"  a.dt_delete," +
			"  a.user_id_insert," +
			"  a.user_id_delete" +
			" from DOSS_ANOMALIES a" +
			" where a.pkid = :id")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE DOSS_ANOMALIES SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select an.pkid," +
			"   an.dossier_id," +
			"   an.anomaly_code," +
			"   ac.severity," +
			"   §i18n(:tenant_id, 'doss_anomaly_catalog', 'anomaly_code', an.anomaly_code, :lang)§ as anomaly_desc," +
			"   an.dt_insert," +
			"   an.dt_delete," +
			"   an.user_id_insert," +
			"   an.user_id_delete" +
			" from DOSS_ANOMALIES an LEFT JOIN DOSS_DOSSIERS a ON an.dossier_id = a.id " +
			" LEFT JOIN DOSS_ANOMALY_CATALOG ac on an.anomaly_code = ac.anomaly_code " +
			" LEFT JOIN DOSS_DOSSIERS_DETAILS ad on ad.dossier_id = a.id " +
			" LEFT JOIN DOSS_MODULES am on am.id = a.module_id " +
			" LEFT JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where an.dossier_id = :dossier_id " +
			" and s.tenant_id = :tenant_id " +
			" and ac.module_id = am.id " +
			" and §current_timestamp§ between an.dt_insert and an.dt_delete " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> find(@Bind("tenant_id") String tenant, @Bind("dossier_id") Long dossierId, @Bind("lang") String lang);

	@SqlQuery("select an.pkid," +
			"   an.dossier_id," +
			"   an.anomaly_code," +
			"   ac.severity," +
			"   §i18n(:tenant_id, 'doss_anomaly_catalog', 'anomaly_code', an.anomaly_code, :lang)§ as anomaly_desc," +
			"   an.dt_insert," +
			"   an.dt_delete," +
			"   an.user_id_insert," +
			"   an.user_id_delete" +
			" from DOSS_ANOMALIES an INNER JOIN DOSS_DOSSIERS a ON an.dossier_id = a.id " +
			" INNER JOIN DOSS_ANOMALY_CATALOG ac on an.anomaly_code = ac.anomaly_code " +
			" INNER JOIN DOSS_DOSSIERS_DETAILS ad on ad.dossier_id = a.id " +
			" INNER JOIN DOSS_MODULES am on am.id = a.module_id " +
			" INNER JOIN DOSS_SECTORS s on s.id = am.sector_id " +
			" where an.dossier_id = :dossier_id " +
			" and an.anomaly_code = :anomaly_code " +
			" and s.tenant_id = :tenant_id " +
			" and §current_timestamp§ between an.dt_insert and an.dt_delete " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(AnomalyNTT.class)
	List<AnomalyNTT> find(@Bind("tenant_id") String tenant, @Bind("dossier_id") Long dossierId, @Bind("anomaly_code") String anomalyCode,
			@Bind("lang") String lang);
}
