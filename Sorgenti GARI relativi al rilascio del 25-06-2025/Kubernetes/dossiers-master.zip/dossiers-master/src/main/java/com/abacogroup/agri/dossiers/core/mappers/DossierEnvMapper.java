package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierEnvNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * The interface Dossier env mapper.
 * @author Carlo Sindico
 */
@Mapper
public interface DossierEnvMapper extends EntityMapper<DossierEnvDTO, DossierEnvNTT> {

    DossierEnvMapper INSTANCE = Mappers.getMapper(DossierEnvMapper.class);

    @InheritInverseConfiguration()
    DossierEnvDTO entityToDto(DossierEnvNTT entity);

    @Mapping(source = "tenant", target = "tenant_id")
    @Mapping(source = "key", target = "key_")
    @Mapping(source = "value", target = "value")
    @Mapping(source = "flClient", target = "fl_client")
    DossierEnvNTT dtoToEntity(DossierEnvDTO dto);

}
