package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.applicationworkflowsdk.service.LogicallyDeleteApplication;
import com.abacogroup.dropwizard.auth.sso2.User;
import lombok.extern.slf4j.Slf4j;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class LogicallyDeleteDossierImpl implements LogicallyDeleteApplication {

	private final DossiersCrudService dossiersCrudService;

	public LogicallyDeleteDossierImpl(DossiersCrudService dossiersCrudService) {
		this.dossiersCrudService = dossiersCrudService;
	}

	@Override
	public void logicallyDeleteApplication(String tenant, Long dossierId, User user) {
		dossiersCrudService.delete(dossierId, user.getName());
		log.info("logically deleted dossier id {}", dossierId);
	}
}
