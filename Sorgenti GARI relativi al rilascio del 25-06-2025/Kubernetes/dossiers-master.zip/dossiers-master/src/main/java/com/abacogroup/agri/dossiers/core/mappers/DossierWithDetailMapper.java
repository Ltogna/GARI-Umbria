package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.db.ntt.DossierWithDetailsNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface DossierWithDetailMapper extends EntityMapper<DossierWithDetailsDTO, DossierWithDetailsNTT> {

	DossierWithDetailMapper INSTANCE = Mappers.getMapper(DossierWithDetailMapper.class);

	@InheritInverseConfiguration()
    DossierWithDetailsDTO entityToDto(DossierWithDetailsNTT entity);

	@Mapping(source = "dossierId", target = "id")
	@Mapping(source = "partyId", target = "party_id")
	@Mapping(source = "referredYear", target = "referred_year")
	@Mapping(source = "moduleId", target = "module_id")
	@Mapping(source = "processId", target = "process_id")
	@Mapping(source = "dossierCode", target = "dossier_code")
	@Mapping(source = "processStatus", target = "process_status")
	@Mapping(source = "dtClosed", target = "dt_closed")
	@Mapping(source = "dtPresentation", target = "dt_presentation")
	@Mapping(source = "sectorDescription", target = "sector_description")
	@Mapping(source = "moduleDescription", target = "module_description")
	@Mapping(source = "sectorCode", target = "sector_code")
	@Mapping(source = "moduleCode", target = "module_code")
	@Mapping(source = "userIdInsert", target = "user_id_insert")
	@Mapping(source = "userIdDelete", target = "user_id_delete")
	@Mapping(source = "dtInsert", target = "dt_insert")
	@Mapping(source = "dtDelete", target = "dt_delete")
	@Mapping(source = "amendmentDossierId", target = "amended_by_id")
	@Mapping(source = "amendedDossierId", target = "amend_of_id")
	DossierWithDetailsNTT dtoToEntity(DossierWithDetailsDTO dto);

}
