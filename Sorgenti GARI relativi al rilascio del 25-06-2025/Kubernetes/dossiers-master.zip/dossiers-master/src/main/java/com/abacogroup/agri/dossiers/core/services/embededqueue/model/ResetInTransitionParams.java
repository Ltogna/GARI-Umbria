package com.abacogroup.agri.dossiers.core.services.embededqueue.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResetInTransitionParams {
	private String tenant;
	private Long dossierId;
	private String username;
}
