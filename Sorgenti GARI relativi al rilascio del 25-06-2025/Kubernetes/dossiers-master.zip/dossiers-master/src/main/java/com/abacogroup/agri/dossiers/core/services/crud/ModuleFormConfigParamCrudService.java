package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModuleFormConfigParamMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleFormConfigParamDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModuleFormConfigParamDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModuleFormConfigParamNTT;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.FormConfigParamKey;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModuleFormConfigParamCrudService
		extends AbstractCrudService<ModuleFormConfigParamNTT, Void, ModuleFormConfigParamDTO, ModuleFormConfigParamMapper, FormConfigParamKey> {

	private final I18NService i18NService;

	public ModuleFormConfigParamCrudService(ModuleFormConfigParamDAO dao, ModuleFormConfigParamMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	@Override
	protected boolean hasPrimaryKey() {
		return false;
	}

	@Override
	protected Void retrievePrimaryKey(FormConfigParamKey customKey) {
		return null;
	}

	@Override
	protected Optional<ModuleFormConfigParamNTT> findRsByCustomKey(FormConfigParamKey customKey) {
		return ((ModuleFormConfigParamDAO) this.dao).findById(customKey.getModule_form_config_id(), customKey.getParameter_name())
				.stream()
				.findFirst();
	}

	@Override
	protected void deleteByCustomKey(FormConfigParamKey customKey) {
		((ModuleFormConfigParamDAO) this.dao).deleteById(customKey.getModule_form_config_id(), customKey.getParameter_name());
	}

	@Override
	protected void setCustomSearchKey(ModuleFormConfigParamNTT rs, FormConfigParamKey customKey) {
		rs.setModule_form_config_id(customKey.getModule_form_config_id());
		rs.setParameter_name(customKey.getParameter_name());
	}

	public ModuleFormConfigParamDTO insert(ModuleFormConfigParamDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, FormConfigParamKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public ModuleFormConfigParamDTO update(ModuleFormConfigParamDTO in) {
		log.info("Invoking update with params in: {}", in);
		return this.update(null, in, FormConfigParamKey.builder()
				.module_form_config_id(in.getModuleFormConfigId())
				.parameter_name(in.getParameterName())
				.build());
	}

	public void delete(FormConfigParamKey key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(null, key);
	}

	public void deleteByModuleFormConfigId(Long moduleFormConfigId) {
		((ModuleFormConfigParamDAO) this.dao).deleteByModuleFormConfigId(moduleFormConfigId);
	}

	public ModuleFormConfigParamDTO findById(String tenant, FormConfigParamKey id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModuleFormConfigParamDAO) this.dao).findById(tenant, id.getModule_form_config_id(), id.getParameter_name()))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModuleFormConfigParamDTO> find(String tenant, Long formConfig) {
		log.info("Invoking findById with params tenant: {} formConfigId: {}", tenant, formConfig);
		return returnMappedList(((ModuleFormConfigParamDAO) this.dao).find(tenant, formConfig));
	}

	public void bulkDeleteByModuleId(Long moduleId) {
		((ModuleFormConfigParamDAO) this.dao).bulkDeleteByModuleId(moduleId);
	}

}
