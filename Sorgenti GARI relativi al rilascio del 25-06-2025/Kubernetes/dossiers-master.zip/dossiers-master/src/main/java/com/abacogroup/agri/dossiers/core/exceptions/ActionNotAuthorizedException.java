package com.abacogroup.agri.dossiers.core.exceptions;

public class ActionNotAuthorizedException extends Exception {

	/**
	 *
	 */
	private static final long serialVersionUID = 748787262154109107L;

	public ActionNotAuthorizedException(String errorMessage, Throwable err) {
		super(errorMessage, err);
	}

	public ActionNotAuthorizedException(String errorMessage) {
		super(errorMessage);
	}

	public ActionNotAuthorizedException(Throwable err) {
		super(err);
	}
}
