package com.abacogroup.agri.dossiers.core.model.dto.publics;

import com.abacogroup.agri.dossiers.core.model.DossierAnomaly;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mauro Pozzana
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateDossierOutDTO {
	private Long dossierId;
	private String dossierCode;
	@Builder.Default
	private List<DossierAnomaly> anomalies = new ArrayList<>();
}
