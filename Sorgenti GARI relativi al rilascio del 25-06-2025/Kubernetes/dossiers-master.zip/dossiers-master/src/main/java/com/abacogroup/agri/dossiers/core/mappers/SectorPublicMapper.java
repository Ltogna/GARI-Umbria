package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.SectorDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.SectorPublicDTO;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface SectorPublicMapper {

	SectorPublicMapper INSTANCE = Mappers.getMapper(SectorPublicMapper.class);

	@InheritInverseConfiguration()
	SectorDTO publicToDto(SectorPublicDTO entity);

	@Mapping(source = "sectorId", target = "sectorId")
	@Mapping(source = "sectorCode", target = "sectorCode")
	@Mapping(source = "description", target = "description")
	SectorPublicDTO dtoToPublic(SectorDTO dto);

}
