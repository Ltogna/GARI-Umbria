package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ModulePrintConfigsDTO {
	private Long id;
	private Long moduleId;
	private String processStatus;
	private String printCode;
	private String printDescription;
	private Integer sortOrder;
	private String contextFunction;
}
