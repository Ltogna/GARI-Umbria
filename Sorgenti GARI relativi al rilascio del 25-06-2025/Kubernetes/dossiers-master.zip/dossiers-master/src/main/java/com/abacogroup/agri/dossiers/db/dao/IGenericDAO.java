package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.utils.DbUtils;
import com.abacogroup.jdbi.EnhancedSqlObject;
import com.abacogroup.jdbi.paging.PagingParams;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;
import org.jdbi.v3.sqlobject.transaction.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @param <T> The RS type class
 * @param <D> The RS type's ID type
 * @author Gennaro Tamburrelli
 */
public interface IGenericDAO<T, D> extends EnhancedSqlObject, Transactional<IGenericDAO<T, D>> {

	@SqlQuery
	D nextSequenceVal();

	@SqlQuery
	List<T> findPagedType(PagingParams pp);

	@SqlQuery
	List<T> findById(D id);

	@SqlUpdate
	void insert(T rs);

	@SqlUpdate
	void update(T rs);

	@SqlUpdate
	void deleteById(D id);

	@SqlQuery("select §current_timestamp§")
	LocalDateTime getCurrentTimestampPostgres();

	@SqlQuery("select §current_timestamp§ from dual")
	LocalDateTime getCurrentTimestampOracle();

	default LocalDateTime getCurrentTimestamp() {
		if (Boolean.TRUE.equals(DbUtils.mainDbIsPostgres)) {
			return this.getCurrentTimestampPostgres();
		} else {
			return this.getCurrentTimestampOracle();
		}
	}
}
