package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.DossierProfileNTT;
import org.jdbi.v3.core.result.ResultIterator;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface DossierProfileDAO extends IGenericHistoricizationFieldsDAO<DossierProfileNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_dossiers_profiles_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_dossiers_profiles (pkid, dossier_id, profile_code, dt_insert, dt_delete, user_id_insert, user_id_delete) " +
			"VALUES(:pkid, :dossier_id, :profile_code, :current_timestamp, " +
			"TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'), :user_id, NULL)")
	void insert(@BindBean DossierProfileNTT rs, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"dossier_id, " +
			"profile_code, " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM doss_dossiers_profiles " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(DossierProfileNTT.class)
	List<DossierProfileNTT> findById(@Bind("id") Long id);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'doss_dossiers_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE ad.dossier_code = :code AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	ResultIterator<DossierProfileNTT> findInfinite(@Bind("tenantId") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'doss_dossiers_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	ResultIterator<DossierProfileNTT> findInfinite(@Bind("tenantId") String tenant, @Bind("doss_id") Long dosId, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'doss_dossiers_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE ad.dossier_code = :code AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	List<DossierProfileNTT> find(@Bind("tenantId") String tenant, @Bind("code") String code, @Bind("lang") String lang);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	List<DossierProfileNTT> find(@Bind("tenantId") String tenant, @Bind("doss_id") Long dosId);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenantId " +
			"and ap.profile_code = :profile_code " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	List<DossierProfileNTT> findByUnique(@Bind("tenantId") String tenant, @Bind("doss_id") Long dosId, @Bind("profile_code") String profileCode);

	@SqlQuery("SELECT ap.pkid, " +
			"ap.dossier_id, " +
			"ap.profile_code, " +
			"§i18n(:tenantId, 'doss_dossiers_profiles', 'profile_code', ap.profile_code, :lang)§ as profile_code_description, " +
			"ap.dt_insert, " +
			"ap.dt_delete, " +
			"ap.user_id_insert, " +
			"ap.user_id_delete " +
			"FROM doss_dossiers_profiles ap " +
			"LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			"LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			"LEFT JOIN doss_modules m ON a.module_id = m.id " +
			"LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			"WHERE a.id = :doss_id AND s.tenant_id = :tenantId " +
			"and §current_timestamp§ between ap.dt_insert and ap.dt_delete " +
			"and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			"and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			"and §current_timestamp§ between m.dt_insert and m.dt_delete")
	@RegisterBeanMapper(DossierProfileNTT.class)
	List<DossierProfileNTT> find(@Bind("tenantId") String tenant, @Bind("doss_id") Long dosId, @Bind("lang") String lang);

	@Override
	@SqlUpdate("UPDATE doss_dossiers_profiles SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlUpdate("UPDATE doss_dossiers_profiles SET " +
			"  user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			"  WHERE pkid in " +
			"(SELECT ap.pkid " +
			" FROM doss_dossiers_profiles ap " +
			" LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			" LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			" LEFT JOIN doss_modules m ON a.module_id = m.id " +
			" LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			" WHERE ad.dossier_code = :dossier_code AND s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between ap.dt_insert and ap.dt_delete)")
	void bulkLogicallyDeleteByDossierCode(@Bind("tenant") String tenant, @Bind("dossier_code") String dossierCode,
			@Bind("user_id_delete") String userIdDelete);

	@SqlUpdate("UPDATE doss_dossiers_profiles SET " +
			"  user_id_delete = :user_id_delete, dt_delete = §current_timestamp§ " +
			"  WHERE pkid in " +
			"(SELECT ap.pkid " +
			" FROM doss_dossiers_profiles ap " +
			" LEFT JOIN doss_dossiers a ON ap.dossier_id = a.id " +
			" LEFT JOIN doss_dossiers_details ad ON ad.dossier_id = a.id " +
			" LEFT JOIN doss_modules m ON a.module_id = m.id " +
			" LEFT JOIN doss_sectors s ON m.sector_id = s.id " +
			" WHERE a.id = :doss_id AND s.tenant_id = :tenant " +
			" and §current_timestamp§ between a.dt_insert and a.dt_delete " +
			" and §current_timestamp§ between ad.dt_insert and ad.dt_delete " +
			" and §current_timestamp§ between m.dt_insert and m.dt_delete " +
			" and §current_timestamp§ between ap.dt_insert and ap.dt_delete)")
	void bulkLogicallyDeleteByDossierId(@Bind("tenant") String tenant, @Bind("doss_id") Long dosId,
			@Bind("user_id_delete") String userIdDelete);
}
