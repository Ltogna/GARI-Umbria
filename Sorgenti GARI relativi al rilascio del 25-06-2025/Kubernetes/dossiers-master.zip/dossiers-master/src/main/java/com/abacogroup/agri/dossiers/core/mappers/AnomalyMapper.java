package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.dossiers.db.ntt.AnomalyNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AnomalyMapper extends EntityMapper<AnomalyDTO, AnomalyNTT> {

	AnomalyMapper INSTANCE = Mappers.getMapper(AnomalyMapper.class);

	@InheritInverseConfiguration()
	AnomalyDTO entityToDto(AnomalyNTT entity);

	@Mapping(source = "pkid", target = "pkid")
	@Mapping(source = "dossierId", target = "dossier_id")
	@Mapping(source = "anomalyCode", target = "anomaly_code")
	@Mapping(source = "anomalyDesc", target = "anomaly_desc")
	@Mapping(source = "dtInsert", target = "dt_insert")
	AnomalyNTT dtoToEntity(AnomalyDTO dto);

}
