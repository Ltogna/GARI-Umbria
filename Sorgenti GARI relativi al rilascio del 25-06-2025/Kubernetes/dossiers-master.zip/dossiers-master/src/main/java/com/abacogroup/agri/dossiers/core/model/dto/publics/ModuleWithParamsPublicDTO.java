package com.abacogroup.agri.dossiers.core.model.dto.publics;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModuleWithParamsPublicDTO {
	@Schema(description = "The module's code")
	private String moduleCode;
	@Schema(description = "The module's configs")
	private List<ModuleFormConfigsPublicDTO> configs;
}
