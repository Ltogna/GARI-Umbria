package com.abacogroup.agri.dossiers.bundles.processor.env;

import com.abacogroup.agri.dossiers.bundles.model.env.BundleDossierEnvMessage;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.model.dto.DossierEnvDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierEnvCrudService;
import com.abacogroup.agri.dossiers.db.ntt.compoundkeys.DossierEnvKey;
import lombok.extern.slf4j.Slf4j;

/**
 * The type Dossier env bundle worker.
 *
 * @author Carlo Sindico
 */
@Slf4j
public class DossierEnvBundleWorker {

    private final DossierEnvCrudService dossierEnvCrudService;

    public DossierEnvBundleWorker(DossierEnvCrudService dossierEnvCrudService) {
        this.dossierEnvCrudService = dossierEnvCrudService;
    }

    public DossierEnvCrudService exposeDossierEnvCrudService() {
        return this.dossierEnvCrudService;
    }

    public void upsertDossierEnvironments(final String tenantId, BundleDossierEnvMessage message) {
        log.info("DossierEnvBundleWorker: processing file with tenant {}", tenantId);
        message.getBundleDossierEnvInDTOList()
                .forEach(env -> {
                    try {
                        DossierEnvKey key = DossierEnvKey.builder()
                                .tenant_id(tenantId)
                                .key_(env.getKey())
                                .fl_client(env.getFlClient())
                                .build();

                        dossierEnvCrudService.findEnvironmentByKey(key);

                        log.info("Environment already existing: skipping insert");

                        DossierEnvDTO dossierEnvDTO = DossierEnvDTO.builder()
                                .tenant(tenantId)
                                .key(env.getKey())
                                .value(env.getValue())
                                .flClient(env.getFlClient())
                                .build();

                        dossierEnvCrudService.update(key, dossierEnvDTO);
                    } catch (ObjectNotFoundException e) {
                        log.info("DossierEnvBundleWorker: inserting environment with tenant {} and name {}", tenantId, env.getKey());

                        DossierEnvDTO dossierEnvDTO = DossierEnvDTO.builder()
                                .tenant(tenantId)
                                .key(env.getKey())
                                .value(env.getValue())
                                .flClient(env.getFlClient())
                                .build();

                        dossierEnvCrudService.insert(dossierEnvDTO);
                    }
                });
    }

    public void deleteDossierEnvironments(final String tenantId, BundleDossierEnvMessage message) {
        log.info("DossierEnvBundleWorker: processing delete file with tenant {}", tenantId);
        message.getBundleDossierEnvInDTOList()
                .forEach(env -> {
                    try {
                        DossierEnvKey key = DossierEnvKey.builder()
                                .tenant_id(tenantId)
                                .key_(env.getKey())
                                .build();

                        dossierEnvCrudService.findEnvironmentByKey(key);
                        log.info("Deleting sector {}", env.getKey());
                        dossierEnvCrudService.delete(key);
                        log.info("Environment deleted");
                    } catch (ObjectNotFoundException e) {
                        log.info("Environment not found: cannot be deleted");
                    }
                });
    }
}
