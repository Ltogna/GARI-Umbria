package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;

import jakarta.ws.rs.core.Response;

public class NoMandatoryInputPartyIdRuntimeException extends AbstractException {

	private static final NoMandatoryInputPartyIdRuntimeException.ErrorBody BODY = new NoMandatoryInputPartyIdRuntimeException.ErrorBody();

	public NoMandatoryInputPartyIdRuntimeException(String message) {
		super(Response.Status.BAD_REQUEST, BODY, message);
	}

	public NoMandatoryInputPartyIdRuntimeException() {
		super(Response.Status.BAD_REQUEST, BODY, "Party id is mandatory");
	}

	@Schema(name = "NoMandatoryInputPartyIdExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_PARTY_ID_FOUND";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
