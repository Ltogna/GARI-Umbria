package com.abacogroup.agri.dossiers.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * @author Mattia Perini
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateAmendmentDossierOutDTO extends CreateDossierOutDTO {
	private Long amendmentDossierId;
}
