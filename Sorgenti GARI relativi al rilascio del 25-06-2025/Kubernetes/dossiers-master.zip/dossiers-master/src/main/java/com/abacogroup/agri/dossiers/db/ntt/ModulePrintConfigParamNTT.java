package com.abacogroup.agri.dossiers.db.ntt;

import com.abacogroup.agri.dossiers.db.ntt.dossiers.IIdRs;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModulePrintConfigParamNTT implements IIdRs<Void> {

	private Long module_print_config_id;
	private String parameter_name;
	private String parameter_value;

	@Override public void setKey(Void id) {
		// not in use
	}

	@Override public Optional<Void> getKey() {
		return Optional.empty();
	}

}
