package com.abacogroup.agri.dossiers.core.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Mauro Pozzana
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DossiersSummaryByYearDTO {
	private Integer year;
	private Integer dossiersNumber;
}
