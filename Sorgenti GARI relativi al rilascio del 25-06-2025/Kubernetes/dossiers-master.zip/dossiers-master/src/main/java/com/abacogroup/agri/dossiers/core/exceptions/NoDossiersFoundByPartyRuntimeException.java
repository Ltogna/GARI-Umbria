package com.abacogroup.agri.dossiers.core.exceptions;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.ws.rs.core.Response;

public class NoDossiersFoundByPartyRuntimeException extends AbstractException {

	private static final NoDossiersFoundByPartyRuntimeException.ErrorBody BODY = new NoDossiersFoundByPartyRuntimeException.ErrorBody();

	public NoDossiersFoundByPartyRuntimeException(String message) {
		super(Response.Status.NOT_FOUND, BODY, message);
	}

	public NoDossiersFoundByPartyRuntimeException() {
		super(Response.Status.NOT_FOUND, BODY, "No dossiers found");
	}

	@Schema(name = "NoDossiersFoundByPartyAndYearExceptionErrorBody")
	public static class ErrorBody implements ExceptionErrorBody {
		private static final String ERR = "NO_DOSSIERS_FOUND_BY_PARTY";

		@Override
		@Schema(allowableValues = ERR)
		public String getErrorCode() {
			return ERR;
		}
	}
}
