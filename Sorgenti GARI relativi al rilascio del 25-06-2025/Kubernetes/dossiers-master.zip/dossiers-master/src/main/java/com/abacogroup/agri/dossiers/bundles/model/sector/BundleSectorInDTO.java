package com.abacogroup.agri.dossiers.bundles.model.sector;

import com.abacogroup.agri.dossiers.bundles.model.I18nPair;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BundleSectorInDTO {
	private String sectorCode;
	private List<I18nPair> i18n;

}
