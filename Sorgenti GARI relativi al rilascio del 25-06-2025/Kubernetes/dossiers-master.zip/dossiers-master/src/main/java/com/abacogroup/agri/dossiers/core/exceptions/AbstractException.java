package com.abacogroup.agri.dossiers.core.exceptions;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;
import lombok.Data;

public abstract class AbstractException extends WebApplicationException {
	private final String code;
	private final String message;

	protected AbstractException(Response.Status status, ExceptionErrorBody body, String message) {
		super(message,
				Response.status(status).entity(new DossiersExceptionBody(body.getErrorCode(), message)).build());
		this.code = body.getErrorCode();
		this.message = message;
	}

	public interface ExceptionErrorBody {
		String getErrorCode();
	}

	@Data
	public static class DossiersExceptionBody {

		private String errorCode;
		private String message;

		public DossiersExceptionBody(String errorCode, String message) {
			this.errorCode = errorCode;
			this.message = message;
		}
	}
}
