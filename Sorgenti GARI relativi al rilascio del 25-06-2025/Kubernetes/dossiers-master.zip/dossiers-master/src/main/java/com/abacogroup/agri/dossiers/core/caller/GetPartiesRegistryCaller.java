package com.abacogroup.agri.dossiers.core.caller;

import com.abacogroup.agri.dossiers.core.model.dto.PartyRegistryDTO;
import com.abacogroup.jaxrsutils.GenericCallerService;
import com.abacogroup.jaxrsutils.callerv2.AbacoDtoCaller;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;

/**
 * @author Gennaro Tamburrelli
 */
public class GetPartiesRegistryCaller extends AbacoDtoCaller<GetPartiesRegistryInput, InfiniteListResultsImpl<PartyRegistryDTO>> {

	public GetPartiesRegistryCaller(GenericCallerService genericCallerService) {
		super(genericCallerService);
	}

}
