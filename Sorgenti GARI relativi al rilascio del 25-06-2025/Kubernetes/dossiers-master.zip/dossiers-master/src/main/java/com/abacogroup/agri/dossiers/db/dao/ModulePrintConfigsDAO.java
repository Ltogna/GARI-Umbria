package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.ModulePrintConfigsNTT;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.customizer.BindList;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.util.List;

/**
 * @author Gennaro Tamburrelli
 */
public interface ModulePrintConfigsDAO extends IGenericDAO<ModulePrintConfigsNTT, Long> {

	@Override
	@SqlQuery("§select_nextval(doss_module_print_configs_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO doss_module_print_configs " +
			"(id, module_id, process_status, print_code, sort_order, context_function) " +
			"VALUES(:id, :module_id, :process_status, :print_code, :sort_order, :context_function)")
	void insert(@BindBean ModulePrintConfigsNTT moduleFormConfigs);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigsByTenant(@Bind("tenantId") String tenant);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId " +
			" and mpc.module_id=:moduleId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigs(@Bind("tenantId") String tenant, @Bind("moduleId") Long moduleId);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" §i18n(s.tenant_id, 'doss_module_print_configs', 'print_code', mpc.print_code, :lang)§ as print_description," +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where mpc.module_id=:moduleId " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findAllModulePrintConfigsByModuleId(@Bind("moduleId") Long moduleId, @Bind("lang") String lang);

	@Override
	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" where mpc.id=:id ")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findById(@Bind("id") Long id);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" §i18n(:tenantId, 'doss_module_print_configs', 'print_code', mpc.print_code, :lang)§ as print_description," +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId and " +
			" mpc.id = :id " +
			" and §current_timestamp§ between am.dt_insert and am.dt_delete")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findById(@Bind("tenantId") String tenant, @Bind("id") Long id, @Bind("lang") String lang);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" §i18n(:tenantId, 'doss_module_print_configs', 'print_code', mpc.print_code, :lang)§ as print_description," +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND mpc.process_status=:process_status" +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete " +
			" AND ((SELECT required_profile_code " +
			"      FROM doss_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) is null OR " +
			"      (SELECT required_profile_code " +
			"      FROM doss_module_print_config_profiles " +
			"      WHERE module_print_config_id = mpc.id) IN (<app_profile_list>))")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("process_status") String processStatus,
			@BindList("app_profile_list") List<String> appProfileList,
			@Bind("lang") String lang);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId  " +
			" AND mpc.module_id = :module_id " +
			" AND mpc.print_code=:print_code " +
			" AND mpc.process_status=:process_status " +
			" AND §current_timestamp§ between am.dt_insert and am.dt_delete ")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> find(@Bind("tenantId") String tenant,
			@Bind("module_id") Long moduleId,
			@Bind("print_code") String printCode,
			@Bind("process_status") String processStatus);

	@SqlQuery("select mpc.id, " +
			" mpc.module_id, " +
			" mpc.process_status, " +
			" mpc.print_code, " +
			" mpc.sort_order, " +
			" mpc.context_function " +
			" from doss_module_print_configs mpc " +
			" left join doss_modules am on am.id = mpc.module_id " +
			" left join doss_sectors s on s.id = am.sector_id " +
			" where s.tenant_id=:tenantId and " +
			" mpc.print_code = :print_code")
	@RegisterBeanMapper(ModulePrintConfigsNTT.class)
	List<ModulePrintConfigsNTT> findByPrintCode(@Bind("tenantId") String tenant, @Bind("print_code") String printCode);

	@Override
	@SqlUpdate("UPDATE doss_module_print_configs SET " +
			"module_id=:module_id, " +
			"process_status=:process_status, " +
			"print_code=:print_code, " +
			"sort_order=:sort_order, " +
			"context_function=:context_function " +
			"WHERE id=:id")
	void update(@BindBean ModulePrintConfigsNTT sector);

	@Override
	@SqlUpdate("DELETE FROM doss_module_print_configs " +
			"WHERE id=:id")
	void deleteById(@Bind("id") Long id);

}
