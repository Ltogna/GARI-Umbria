package com.abacogroup.agri.dossiers.bundles.model.sector;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Alexandru Paraschiv
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BundleSectorsMessage {
	@Builder.Default
	private List<BundleSectorInDTO> sectors = new ArrayList<>();
}
