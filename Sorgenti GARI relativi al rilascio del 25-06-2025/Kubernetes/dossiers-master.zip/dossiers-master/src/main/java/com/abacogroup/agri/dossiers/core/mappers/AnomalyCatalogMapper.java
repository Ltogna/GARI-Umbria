package com.abacogroup.agri.dossiers.core.mappers;

import com.abacogroup.agri.dossiers.core.model.dto.publics.AnomalyCatalogDTO;
import com.abacogroup.agri.dossiers.db.ntt.AnomalyCatalogNTT;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = AbsoluteDateMapper.class)
public interface AnomalyCatalogMapper extends EntityMapper<AnomalyCatalogDTO, AnomalyCatalogNTT> {

	AnomalyCatalogMapper INSTANCE = Mappers.getMapper(AnomalyCatalogMapper.class);

	@InheritInverseConfiguration()
	AnomalyCatalogDTO entityToDto(AnomalyCatalogNTT entity);

	@Mapping(source = "anomalyCode", target = "anomaly_code")
	@Mapping(source = "severity", target = "severity")
	@Mapping(source = "anomalyDesc", target = "anomaly_desc")
	@Mapping(source = "moduleId", target = "module_id")
	AnomalyCatalogNTT dtoToEntity(AnomalyCatalogDTO dto);

}
