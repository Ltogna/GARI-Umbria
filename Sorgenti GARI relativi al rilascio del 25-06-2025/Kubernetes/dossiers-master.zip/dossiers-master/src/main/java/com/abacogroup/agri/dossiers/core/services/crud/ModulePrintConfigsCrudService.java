package com.abacogroup.agri.dossiers.core.services.crud;

import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.mappers.ModulePrintConfigsMapper;
import com.abacogroup.agri.dossiers.core.model.dto.ModulePrintConfigsDTO;
import com.abacogroup.agri.dossiers.core.services.I18NService;
import com.abacogroup.agri.dossiers.db.dao.ModulePrintConfigsDAO;
import com.abacogroup.agri.dossiers.db.ntt.ModulePrintConfigsNTT;
import com.abacogroup.agri.dossiers.db.ntt.dossiers.RsI18N;
import com.abacogroup.jaxrsutils.filter.MDCPreFilter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.MDC;

import java.util.List;
import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class ModulePrintConfigsCrudService extends AbstractCrudService<ModulePrintConfigsNTT, Long, ModulePrintConfigsDTO, ModulePrintConfigsMapper, Void> {

	public static final String I18N_DOSSIER_PRINTS_TABLE = "doss_module_print_configs";
	private I18NService i18NService;

	public ModulePrintConfigsCrudService(ModulePrintConfigsDAO dao, ModulePrintConfigsMapper mapper, I18NService i18NService) {
		super(dao, mapper);
		this.i18NService = i18NService;
	}

	public List<ModulePrintConfigsDTO> findAllModulePrintConfigsByTenant(String tenantId) {
		return returnMappedList(((ModulePrintConfigsDAO) this.dao).findAllModulePrintConfigsByTenant(tenantId));
	}

	public List<ModulePrintConfigsDTO> findAllModulePrintConfigs(String tenantId, Long moduleId) {
		return returnMappedList(((ModulePrintConfigsDAO) this.dao).findAllModulePrintConfigs(tenantId, moduleId));
	}

	@Override
	protected boolean hasPrimaryKey() {
		return true;
	}

	@Override
	protected Optional<ModulePrintConfigsNTT> findRsByCustomKey(Void customKey) {
		return Optional.empty();
	}

	@Override
	protected void deleteByCustomKey(Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	@Override
	protected void setCustomSearchKey(ModulePrintConfigsNTT rs, Void customKey) {
		throw new NotImplementedException("Not implemented.");
	}

	public ModulePrintConfigsDTO insert(ModulePrintConfigsDTO in) {
		log.info("Invoking insert with params in: {}", in);
		return this.insert(in, null);
	}

	public ModulePrintConfigsDTO update(Long key, ModulePrintConfigsDTO in) {
		log.info("Invoking update with params key: {} in: {}", key, in);
		return this.update(key, in, null);
	}

	public void delete(Long key) {
		log.info("Invoking delete with params key: {}", key);
		this.delete(key, null);
	}

	public ModulePrintConfigsDTO findById(String tenant, Long id) throws ObjectNotFoundException {
		log.info("Invoking findById with params tenant: {} id: {}", tenant, id);
		return returnOptionalRecord(((ModulePrintConfigsDAO) this.dao).findById(tenant, id, MDC.get(MDCPreFilter.LOCALE)))
				.orElseThrow(OBJECT_NOT_FOUND_EXCEPTION_SUPPLIER);
	}

	public List<ModulePrintConfigsDTO> find(String tenant, Long moduleId, String processStatus, List<String> profileCodeList) {
		return returnMappedList(((ModulePrintConfigsDAO) this.dao).find(tenant, moduleId, processStatus, profileCodeList, MDC.get(MDCPreFilter.LOCALE)));
	}

	public Optional<ModulePrintConfigsDTO> find(String tenant, Long moduleId, String printCode, String processStatus) {
		return returnOptionalRecord(((ModulePrintConfigsDAO) this.dao).find(tenant, moduleId, printCode, processStatus));
	}

	public void insertPrintCodeI18N(String tenant, String code, String lang, String description) {
		this.i18NService.insertI18N(tenant, I18N_DOSSIER_PRINTS_TABLE, PRINT_CODE_I18N.PROFILE_CODE.code, lang, code, description);
	}

	public void deletePrintCodeI18N(String tenant, String code, String lang) {
		this.i18NService.deleteI18N(tenant, I18N_DOSSIER_PRINTS_TABLE, PRINT_CODE_I18N.PROFILE_CODE.code, code, lang);
	}

	public List<RsI18N> getAllPrintCodeI18NByTenantAndCode(String tenant, String code) {
		return this.i18NService.getAllI18NbyCode(tenant, I18N_DOSSIER_PRINTS_TABLE, code);
	}

	public enum PRINT_CODE_I18N {
		PROFILE_CODE("print_code");

		private final String code;

		PRINT_CODE_I18N(String val) {
			this.code = val;
		}

		public String getCode() {
			return this.code;
		}
	}

}
