package com.abacogroup.agri.dossiers.core.model;

/**
 * @author Gennaro Tamburrelli
 */
public enum CompileStatusEnum {
	PROGRESS,
	COMPLETED
}
