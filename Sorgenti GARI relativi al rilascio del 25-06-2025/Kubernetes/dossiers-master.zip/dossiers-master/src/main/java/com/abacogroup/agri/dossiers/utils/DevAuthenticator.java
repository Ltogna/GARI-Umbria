package com.abacogroup.agri.dossiers.utils;

import com.abacogroup.dropwizard.auth.sso2.User;
import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Optional;

/**
 * @author Gennaro Tamburrelli
 */
public class DevAuthenticator implements Authenticator<BasicCredentials, User> {

	private final String username;
	private final String tenant;

	public DevAuthenticator() {
		this.username = "ADMIN";
		this.tenant = "master";

	}

	public DevAuthenticator(String username, String tenant) {
		this.username = username;
		this.tenant = tenant;
	}

	@Override
	public Optional<User> authenticate(BasicCredentials basicCredentials) throws AuthenticationException {
		return Optional.of(new User(this.username, this.tenant, "", this.username));
	}
}
