package com.abacogroup.agri.dossiers.db.dao;

import com.abacogroup.agri.dossiers.db.ntt.*;
import org.jdbi.v3.sqlobject.config.RegisterBeanMapper;
import org.jdbi.v3.sqlobject.customizer.Bind;
import org.jdbi.v3.sqlobject.customizer.BindBean;
import org.jdbi.v3.sqlobject.statement.SqlQuery;
import org.jdbi.v3.sqlobject.statement.SqlUpdate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author Samuele Sbarbaro
 */
public interface DossierProtocolsDAO extends IGenericHistoricizationFieldsDAO<DossierProtocolsNTT, Long, Void> {

	@Override
	@SqlQuery("§select_nextval(doss_dossier_protocols_id_seq)§")
	Long nextSequenceVal();

	@Override
	@SqlUpdate("INSERT INTO DOSS_DOSSIER_PROTOCOLS " +
			"(pkid, " +
			"dossier_id, " +
			"dt_request, " +
			"dt_response, " +
			"protocol, " +
			"user_id_insert, " +
			"user_id_delete, " +
			"dt_insert, " +
			"dt_delete) " +
			"VALUES(:pkid, :dossier_id, :dt_request, :dt_response, :protocol, :user_id, NULL, :current_timestamp, TO_TIMESTAMP('9999-12-3123:59:59','YYYY-MM-DDHH24:MI:SS'))")
	void insert(@BindBean DossierProtocolsNTT ntt, @Bind("user_id") String userId, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@Override
	@SqlQuery("SELECT pkid, " +
			"dossier_id, " +
			"dt_request, " +
			"dt_response, " +
			"protocol,  " +
			"dt_insert, " +
			"dt_delete, " +
			"user_id_insert, " +
			"user_id_delete " +
			"FROM DOSS_DOSSIER_PROTOCOLS " +
			"WHERE pkid = :id")
	@RegisterBeanMapper(DossierProtocolsNTT.class)
	List<DossierProtocolsNTT> findById(@Bind("id") Long id);

	@Override
	@SqlUpdate("UPDATE DOSS_DOSSIER_PROTOCOLS SET " +
			"user_id_delete = :user_id_delete, dt_delete = :current_timestamp " +
			"WHERE pkid = :id " +
			"and §current_timestamp§ between dt_insert and dt_delete")
	void logicallyDeleteById(@Bind("id") Long id, @Bind("user_id_delete") String userDelete, @Bind("current_timestamp") LocalDateTime currentTimestamp);

	@SqlQuery("select\n" +
			"\tap.pkid,\n" +
			"\tap.dossier_id,\n" +
			"\tdt_request,\n" +
			"\tdt_response,\n" +
			"\tap.protocol,\n" +
			"\tap.dt_insert,\n" +
			"\tap.dt_delete,\n" +
			"\tap.user_id_insert,\n" +
			"\tap.user_id_delete\n" +
			"from\n" +
			"\tDOSS_DOSSIER_PROTOCOLS ap\n" +
			"left join doss_dossiers a on\n" +
			"\tap.dossier_id = a.id\n" +
			"left join doss_dossiers_details ad on\n" +
			"\tad.dossier_id = a.id\n" +
			"left join doss_modules m on\n" +
			"\ta.module_id = m.id\n" +
			"left join doss_sectors s on\n" +
			"\tm.sector_id = s.id\n" +
			"where\n" +
			"\ta.id = :doss_id\n" +
			"\tand s.tenant_id = :tenantId\n" +
			"\tand current_timestamp between ap.dt_insert and ap.dt_delete\n" +
			"\tand current_timestamp between a.dt_insert and a.dt_delete\n" +
			"\tand current_timestamp between ad.dt_insert and ad.dt_delete\n" +
			"\tand current_timestamp between m.dt_insert and m.dt_delete\n" +
			"order by\n" +
			"\tap.pkid desc")
	@RegisterBeanMapper(DossierProtocolsNTT.class)
	List<DossierProtocolsNTT> find(@Bind("tenantId") String tenant, @Bind("doss_id") Long dosId);


}
