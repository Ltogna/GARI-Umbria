package com.abacogroup.agri.dossiers.core.services;

import com.abacogroup.agri.dossiers.core.exceptions.DossierNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundException;
import com.abacogroup.agri.dossiers.core.exceptions.ObjectNotFoundRuntimeException;
import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.abacogroup.agri.dossiers.core.model.dto.AmendableModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.DossierDetailsDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleDTO;
import com.abacogroup.agri.dossiers.core.model.dto.ModuleWithDetailDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierDTO;
import com.abacogroup.agri.dossiers.core.model.dto.publics.DossierWithDetailsDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AmendableModuleCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossierDetailsCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.DossiersCrudService;
import com.abacogroup.agri.dossiers.core.services.crud.ModuleCrudService;
import com.abacogroup.jdbi.paging.InfiniteListResults;
import com.abacogroup.jdbi.paging.impl.InfiniteListResultsImpl;
import jakarta.ws.rs.core.SecurityContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * The type Amendment service.
 *
 * @author Mattia Perini
 * @author Samuele Sbarbaro
 * @author Mauro Pozzana
 * @author Carlo Sindico
 */
@Slf4j
public class AmendmentService {
	// TODO move constants to dedicated class
	private static final String PROCESS_STATUS_DELETED = "DELETED";
	private static final String PROCESS_STATUS_PROTOCOLED = "PROTOCOLED";
	private static final String PROCESS_STATUS_COMPLIANT = "COMPLIANT";
	private static final Integer FIND_ONLY_AMEND_MODULES = 1;

	private final DossiersCrudService dossiersCrudService;
	private final ModuleCrudService moduleCrudService;
	private final AmendableModuleCrudService amendableModuleCrudService;
	private final DossierDetailsCrudService dossierDetailsCrudService;

	public AmendmentService(ModuleCrudService moduleCrudService,
			DossiersCrudService dossiersCrudService,
			AmendableModuleCrudService amendableModuleCrudService,
			DossierDetailsCrudService dossierDetailsCrudService) {
		this.moduleCrudService = moduleCrudService;
		this.amendableModuleCrudService = amendableModuleCrudService;
		this.dossiersCrudService = dossiersCrudService;
		this.dossierDetailsCrudService = dossierDetailsCrudService;
	}

	public InfiniteListResults<ModuleWithDetailDTO> getAmendmentModules(final String tenant, final Long dossierId, String nextKey, SecurityContext sc) {
		DossierDTO dossierDTO = dossiersCrudService.findById(dossierId)
				.orElseThrow(() -> new DossierNotFoundRuntimeException(MessageFormat.format("Dossier with id {0} not found", dossierId)));

		List<AmendableModuleDTO> amendableModules = amendableModuleCrudService.findByAmendableModuleId(tenant, dossierDTO.getModuleId());
		List<Long> amendableModuleIds = amendableModules.stream().map(AmendableModuleDTO::getModuleId).collect(Collectors.toList());

		log.info("Found {} amendable modules with the module id {}", amendableModules.size(), dossierDTO.getModuleId());

		List<ModuleWithDetailDTO> moduleWithDetails = moduleCrudService.findModulesWithDetailByModuleIds(tenant, amendableModuleIds,
				FIND_ONLY_AMEND_MODULES, new AbsoluteDate(LocalDate.now())).stream()
				.filter(x -> StringUtils.isAllBlank(x.getContextFunction()) || Optional.ofNullable(sc)
						.map(xsc -> xsc.isUserInRole(x.getContextFunction()))
						.orElse(true))
				.collect(Collectors.toList());

		return new InfiniteListResultsImpl<>(moduleWithDetails, nextKey);
	}

	public Long getOriginalAmendedDossierId(DossierWithDetailsDTO dossier, String tenant) {

		if (dossier.getAmendedDossierId() != null) {
			do {
				dossier = dossiersCrudService.findWithDetailsByDossierId(tenant, dossier.getAmendedDossierId());
			} while (dossier.getAmendedDossierId() != null);
			return dossier.getDossierId();
		} else {
			return null;
		}
	}

	public Boolean checkAmendmentStatus(String tenant, Long dossierId, String moduleCode) {
		try {
			DossierDetailsDTO dossierDetailsDTO = dossierDetailsCrudService.findDossierDetailById(tenant, dossierId);

			// verify dossier process status is PROTOCOLED or COMPLIANT
			boolean isValidProcessStatus = PROCESS_STATUS_PROTOCOLED.equals(dossierDetailsDTO.getProcessStatus()) ||
					PROCESS_STATUS_COMPLIANT.equals(dossierDetailsDTO.getProcessStatus());

			Optional<ModuleDTO> module = moduleCrudService.findByCode(tenant, moduleCode);

			// verify module fl amendable status
			boolean isAmendModule = false;
			if (module.isPresent()) {
				//check if exist a valid amend module for this module
				List<AmendableModuleDTO> amendableModules = amendableModuleCrudService.findByAmendableModuleId(tenant, module.get().getModuleId());
				isAmendModule = amendableModules.stream().anyMatch(m -> isAmendModule(tenant, m.getModuleId()));
			}

			return isAmendModule && isValidProcessStatus;
		} catch (ObjectNotFoundException e) {
			throw new ObjectNotFoundRuntimeException(MessageFormat.format("dossier with id {0} not found", dossierId));
		}
	}

	public Boolean isDossierAmendable(String tenant, Long amendmentDossierId) {
		try {
			DossierWithDetailsDTO dossierWithDetailsDTO = dossiersCrudService.findWithDetailsByDossierId(tenant, amendmentDossierId);

			return Optional.ofNullable(dossierWithDetailsDTO).isPresent() && !PROCESS_STATUS_DELETED.equals(dossierWithDetailsDTO.getProcessStatus());
		} catch (DossierNotFoundRuntimeException e) {
			return false;
		}
	}

	public Boolean isAmendModule(String tenant, Long moduleId) {
		List<ModuleWithDetailDTO> amendModules = moduleCrudService.findValidAmendModulesWithDetailByModuleId(tenant, moduleId,
				FIND_ONLY_AMEND_MODULES, new AbsoluteDate(LocalDate.now()));

		return !amendModules.isEmpty();
	}
}
