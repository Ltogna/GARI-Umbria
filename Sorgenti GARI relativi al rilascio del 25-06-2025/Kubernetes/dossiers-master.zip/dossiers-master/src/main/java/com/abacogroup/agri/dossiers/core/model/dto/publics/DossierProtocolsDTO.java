package com.abacogroup.agri.dossiers.core.model.dto.publics;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.LocalDateTime;

/**
 * @author Samuele Sbarbaro
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DossierProtocolsDTO {
	private Long pkid;
	private Long dossierId;
	private LocalDateTime dtRequest;
	private LocalDateTime dtResponse;
	private String protocol;
}
