package com.abacogroup.agri.dossiers.jackson;

import com.abacogroup.agri.dossiers.core.model.AbsoluteDate;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;

public class AbsoluteDateSerializer extends StdSerializer<AbsoluteDate>
{

	private static final long serialVersionUID = -2949226772254559419L;

	public AbsoluteDateSerializer()
	{
		super(AbsoluteDate.class);
	}

	@Override
	public void serialize(AbsoluteDate value, JsonGenerator gen, SerializerProvider provider) throws IOException
	{
		gen.writeString(value.toString());
	}

}
