package com.abacogroup.agri.dossiers.core.services.workflow.sdkimpl;

import com.abacogroup.agri.dossiers.core.model.dto.publics.AnomalyDTO;
import com.abacogroup.agri.dossiers.core.services.crud.AnomaliesCrudService;
import com.abacogroup.applicationworkflowsdk.model.io.output.AnomalyOutDTO;
import com.abacogroup.applicationworkflowsdk.service.AnomalyHandler;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
@Slf4j
public class AnomalyHandlerImpl implements AnomalyHandler {

	private final AnomaliesCrudService anomaliesCrudService;

	public AnomalyHandlerImpl(AnomaliesCrudService anomaliesCrudService) {
		this.anomaliesCrudService = anomaliesCrudService;
	}

	@Override
	public void insertAnomaly(String tenant, Long dossierId, String anomalyCode, String username) {
		var insertAnomaly = AnomalyDTO.builder()
				.anomalyCode(anomalyCode)
				.dossierId(dossierId)
				.build();
		var existingAnomaly = this.anomaliesCrudService.find(tenant, dossierId, anomalyCode);
		try {
			existingAnomaly.ifPresentOrElse(x -> {
						log.info("anomaly already present, updating it");
						this.anomaliesCrudService.update(x.getPkid(), insertAnomaly, username);
					},
					() -> this.anomaliesCrudService.insert(AnomalyDTO.builder()
							.anomalyCode(anomalyCode)
							.dossierId(dossierId)
							.build(), username));
		} catch (Exception e) {
			log.error("error during updating anomaly");
		}

	}

	@Override
	public void deleteAnomaly(String tenant, Long dossierId, String anomalyCode, String username) {
		log.info("called delete anomaly for dossier id {} anomaly code {} username {}", dossierId, anomalyCode, username);
		this.anomaliesCrudService.deleteByAnomalyCode(tenant, dossierId, anomalyCode, username);
	}

	@Override
	public List<AnomalyOutDTO> getAnomalies(String tenant, Long dossierId) {
		return this.anomaliesCrudService.find(tenant, dossierId)
				.stream()
				.map(x -> AnomalyOutDTO.builder()
						.pkid(x.getPkid())
						.severity(x.getSeverity())
						.anomalyCode(x.getAnomalyCode())
						.anomalyDesc(x.getAnomalyDesc())
						.build())
				.collect(Collectors.toList());
	}

	public List<AnomalyDTO> getAnomaliesForApp(String tenant, Long dossierId) {
		return this.anomaliesCrudService.find(tenant, dossierId);
	}
}
