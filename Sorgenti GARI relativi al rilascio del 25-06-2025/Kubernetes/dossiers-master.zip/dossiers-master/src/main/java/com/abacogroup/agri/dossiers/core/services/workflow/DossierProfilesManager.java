package com.abacogroup.agri.dossiers.core.services.workflow;

import com.abacogroup.agri.dossiers.core.model.dto.DossierProfileDTO;
import com.abacogroup.agri.dossiers.core.services.crud.DossierProfilesCrudService;
import com.abacogroup.workflow.sdk.profiles.ProfilesManager;
import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.LoadingCache;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Gennaro Tamburrelli
 */
public class DossierProfilesManager implements ProfilesManager {

	private final LoadingCache<ProfileCacheKey, List<String>> dossierProfilesCache;
	private final String tenant;
	private final Long dossierId;

	private final DossierProfilesCrudService dossierProfilesCrudService;

	public DossierProfilesManager(String tenant, Long dossierId, DossierProfilesCrudService dossierProfilesCrudService) {
		this.tenant = tenant;
		this.dossierId = dossierId;
		this.dossierProfilesCrudService = dossierProfilesCrudService;
		this.dossierProfilesCache = Caffeine.newBuilder()
				.build(key -> this.getAllProfiles(key.getTenant(), key.getDossierId()));
	}

	private List<String> createList(String... strings) {
		return Arrays.asList(strings);
	}

	private ProfileCacheKey createKey() {
		return ProfileCacheKey.builder()
				.tenant(this.tenant)
				.dossierId(this.dossierId)
				.build();
	}

	@Override
	public boolean haveAnyOf(String... strings) {
		List<String> anyOf = this.createList(strings);
		return Objects.requireNonNull(this.dossierProfilesCache.get(this.createKey()))
				.stream()
				.anyMatch(anyOf::contains);
	}

	@Override
	public boolean haveAllOf(String... strings) {
		List<String> allOf = this.createList(strings);

		return Objects.requireNonNull(this.dossierProfilesCache.get(this.createKey())).containsAll(allOf);
	}

	public List<String> getAllProfiles(String tenant, Long dossierId) {
		return dossierProfilesCrudService.find(tenant, dossierId)
				.stream()
				.map(DossierProfileDTO::getProfileCode)
				.collect(Collectors.toList());
	}

}
