# AGRI APPLICATIONS

## Bundles Infrastructure integration

The application must be connected to a RabbitMQ instance.

The bundles infrastructure will automatically set up to allow automatic configuration.

The application module id is `applications` and the supported changeset domains are:

```
📂 applications
┣ 📂 <client-id>-<nnnn>
┣ ┣ 📂 workflows
    ┣ 📜 <any file>.jar|.zip
    📂 modules
    ┣ 📜 <any file>.json
    📂 sectors
    ┣ 📜 <any file>.json
```

n = one digit (0..9)

The workflow file(s) is a jar or zip containing the workflow definition.

The modules JSON file(s) must have the following structure where moduleProfile, modulePrints and flAmendModule can be omitted:

```
{
  "modules": [
    {
      "moduleCode": "String (mandatory)",
      "sectorCode": "String (mandatory)",
      "workflowCode": "String (mandatory)",
      "annuality": "Integer (mandatory)",
      "contextFunction": "String (optional)",	
      "forceReadOnlyContextFunction": "String (optional)",
      "dtValidityStart": "AbsoluteDate (mandatory)",
      "dtValidityEnd": "AbsoluteDate (mandatory)",
      "i18n": [
        {
          "lang": "String (mandatory)",
          "description": "String (mandatory)"
        }
      ]
    }
  ],
  "forms": {
    "formCatalogs": [
      {
        "formCode": "String (mandatory)",
        "softwareUrl": "String (mandatory)",
        "routerUrl": "String (mandatory)",
        "i18n": [
          {
            "lang": "String (mandatory)",
            "description": "String (mandatory)"
          }
        ]
      }
    ],
    "formGroups": [
      {
        "formGroupCode": "String (mandatory)",
        "formGroupChildren": [
          {
            "formGroupCode": "String (mandatory)",
            "formGroupChildren": [],
            "i18n": [
              {
                "lang": "String (mandatory)",
                "description": "String (mandatory)"
              }
            ]
          }
        ],
        "i18n": [
          {
            "lang": "String (mandatory)",
            "description": "String (mandatory)"
          }
        ]
      }
    ],
    "moduleFormConfigs": [
      {
        "moduleCode": "String (mandatory)",
        "formCode": "String (mandatory)",
        "formGroupCode": "String (mandatory)",
        "processStatus": "String (mandatory)",
        "processStatusList" : "String[] (optional if processStatus present)"
        "sortOrder": "Integer (mandatory)",
        "flReadOnly": "1|0 (mandatory)",
        "compileStatusIdentifier": "String (optional)",
        "contextFunction": "String (optional)",
        "forceReadOnlyContextFunction": "String (optional)",
        "contextFunctionList": "String[] (optional)""
        "requiredProfiles": "String[] | undefined",
        "params": {
          "name": "String (mandatory)",
          "surname": "String (mandatory)"
        } (if no params -> "params": {})
      }
    ]
  }, 
  "moduleProfiles": [
    "prfCode": "String (mandatory)",
    "i18n": [
      {
        "lang": "String (mandatory)",
        "description": "String (mandatory)"
      }
    ]
  ],
  "modulePrints": [
    "printCode": "String (mandatory)",
    "processStatus": "String (mandatory)", 
    "processStatusList": "String[] (optional if processStatus present)",
    "sortOrder": "Integer (mandatory)",
    "contextFunction": "String (optional)",
    "i18n": [
      "lang": "String (mandatory)",
      "description": "String (mandatory)"
    ],
    "params": {...} "(optional)",
    "requiredProfiles": "String[] (optional)"
  ],
  "flAmendModule": "1|0 (optional)"
}
```

The sectors JSON file(s) must have the following structure:

```
{
  "sectors": [
    {
      "sectorCode": "String (mandatory)",
      "i18n": [
        {
          "lang": "String (mandatory)",
          "description": "String (mandatory)"
        }
      ]
    }
  ]
}
```

## Environment variables

- ACTIVATE_JWT_AUTH: BOOLEAN If TRUE, activate the JWT Filter, which verify the jwt token in the header Authorization, with schema "JWT". Example:
  Authorization: "JWT >token<". if FALSE, a Dev Filter is activated, which does not verify any Authorization header and inject an User with username: "ADMIN"
  and tenant: "tenant"
- SSO2_URL: STRING the url from which the application downloads the certificates to verify the JWT token signature
- DATABASE_TYPE: STRING
  "oracle" or "postgresql", defines which database the application should connect
- DATABASE_DRIVER: STRING the database driver in form of full defined class name
- JDBC_URL: STRING jdbc url for connecting to database
- JDBC_USER: STRING user for connecting to database
- JDBC_PASSWORD: STRING password for database
- JDBC_VALIDATION_QUERY: STRING a validation query for certify that connection is working (required by JDBI)

## SSO context|function
The allowed SSO context|function are:
- DOSSIERS|USER:
  - it enables the user to dossiers
- DOSSIERS|READ_ONLY:
  - it enables the user to read dossiers

### Special context function
For the front-end of FVG it has been declared a context function DOSSIERS|EDITOR to be able to show tabs (document, applications) that are otherwise hidden. [#154445](https://abacogroup.easyredmine.com/issues/154445)
