import type { GeoJsonGeometryModel } from "@/models/utils";
import Feature from "ol/Feature";
import {
	Geometry,
	LineString,
	MultiLineString,
	MultiPoint,
	MultiPolygon,
	Point,
	Polygon,
} from "ol/geom";
import Map from "ol/Map";
import View from "ol/View";
import { onBeforeUnmount, onMounted, ref } from "vue";

export enum ZoomValue {
	MinZoom = 2,
	MaxZoom = Infinity,
}

let view = getView();

let map = new Map({
	controls: [],
	view,
});

function getView(projection?: string): View {
	return new View({
		projection,
		rotation: 0,
		zoom: 8,
		center: [3139880.24789847, 5961935.332187176],
	});
}

export function useMap(
	padding = [100, 100, 100, 100],
	projection = "EPSG:3857"
) {
	if (!map) {
		view = getView(projection);
		map = new Map({
			controls: [],
			view,
		});
	}

	const mapRef = ref<HTMLDivElement>();
	if (projection && map.getView().getProjection().getCode() !== projection) {
		view = getView(projection);
		map.setView(view);
	}

	// onMounted(async () => {
	//   if (mapRef.value) {
	//     map.setTarget(mapRef.value);
	//   }
	// });

	// #region ZOOM
	const currentZoom = (): number => {
		return map.getView().getZoom() || ZoomValue.MinZoom;
	};
	const zoomIn = () => {
		// view.setZoom(currentZoom() + 1);
		map.getView().animate({
			zoom: currentZoom() + 1,
			duration: 400,
		});
	};
	const zoomOut = () => {
		// view.setZoom(currentZoom() - 1);
		map.getView().animate({
			zoom: currentZoom() - 1,
			duration: 400,
		});
	};
	//#endregion

	//#region FULLSCREEN
	const isFullscreen = ref(checkFullscreen());

	function checkFullscreen() {
		return !!document.fullscreenElement;
	}

	function fullscreenHandler() {
		isFullscreen.value = checkFullscreen();
	}

	onMounted(() => {
		document.addEventListener("fullscreenchange", fullscreenHandler);
	});

	onBeforeUnmount(() => {
		document.removeEventListener("fullscreenchange", fullscreenHandler);
	});

	// document.fullscreenElement is unreliable to be reactive
	function toggleFullscreen() {
		document.fullscreenElement
			? document.exitFullscreen()
			: // eslint-disable-next-line @typescript-eslint/ban-ts-comment
				// @ts-ignore
				map.getTarget().requestFullscreen() || Promise.resolve();
	}

	//#endregion

	return {
		mapRef,
		map,
		view,
		currentZoom,
		zoomIn,
		zoomOut,
		toggleFullscreen,
		isFullscreen,
		padding,
	};
}

export function createGeometry(
	data: GeoJsonGeometryModel
): Geometry | undefined {
	let geometry: Geometry | undefined = undefined;
	switch (data.type) {
		case "Point": {
			geometry = new Point(data.coordinates);
			break;
		}
		case "LineString": {
			geometry = new LineString(data.coordinates);
			break;
		}
		case "Polygon": {
			geometry = new Polygon(data.coordinates);
			break;
		}
		case "MultiPoint": {
			geometry = new MultiPoint(data.coordinates);
			break;
		}
		case "MultiLineString": {
			geometry = new MultiLineString(data.coordinates);
			break;
		}
		case "MultiPolygon": {
			geometry = new MultiPolygon(data.coordinates);
			break;
		}
	}
	return geometry;
}

export function createFeature(data: GeoJsonGeometryModel): Feature<Geometry> {
	const geometry = createGeometry(data);
	return new Feature({
		geometry,
	});
}
