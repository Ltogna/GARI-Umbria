import { inject } from "vue";

export default function (): string {
	return inject("moduleId") as string;
}
