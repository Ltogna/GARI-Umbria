import type { RouteRecordRaw } from "vue-router";

const routes: RouteRecordRaw[] = [];

routes.push(
	/*
	Pua routes
	five year routes:
	1) /tipoligia dichiarazione : tipo dichairazione
	2) /dichiarazione-pua-con-fertilizzanti-chimici: ChemicalFertilizer
	2) /dichiarazione-pua-con-fertilizzanti-chimici-e-organici/ChemicalAndOrganicFertilizer: ChemicalAndOrganicFertilizer
	3) /allegati : allegati 
	4) /dichiarazione finale: IMPORTED_FROM dynamicDocuments
	5) firma: IMPORTED_FROM dynamicDocuments
	*/
	{
		path: "/tipologia-dichiarazione",
		name: "DeclarationYearForm",
		component: () =>
			import("../components/declarationTypeForm/DeclarationYearForm.vue"),
	},
	{
		path: "/dichiarazione-pua-con-fertilizzanti-chimici",
		name: "ChemicalFertilizer",
		component: () =>
			import("../components/ChemicalFertilizer/ChemicalFertilizer.vue"),
	},
	{
		path: "/dichiarazione-pua-con-fertilizzanti-chimici-e-organici",
		name: "ChemicalAndOrganicFertilizer",
		component: () =>
			import(
				"../components/ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizer.vue"
			),
	},
	{
		path: "/dichiarazione-pua-con-fertilizzanti-chimici-e-organici/fertilizzanti-precedenti-form",
		name: "ChemicalAndOrganicFertilizerForm",
		component: () =>
			import(
				"../components/ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizerForm/ChemicalAndOrganicFertilizerForm.vue"
			),
	},
	{
		path: "/dichiarazione-consistenza-animali",
		name: "animalConsistency",
		component: () =>
			import("../components/AnimalConsistency/AnimalConsistency.vue"),
	},
	{
		path: "/allegati",
		name: "Attachment",
		component: () => import("../components/attachment/AttachmentForm.vue"),
	},
	{
		path: "/verifica-indici-bilancio",
		name: "balanceIndices",
		component: () => import("../components/balanceIndices/balanceIndices.vue"),
	},
	{
		path: "/balance-indices-details",
		name: "balanceIndicesDetails",
		component: () =>
			import("../components/balanceIndices/balanceIndicesDetails.vue"),
	},
	/*
	five year routes:
	1) /tipoligia dichiarazione: IMPORTED_FROM pua
	2) /dichiarazione-quinquennale: pagina tabelle
	3) /five-year-comunication-cadastral-parcel: cadastra edit
	4) /allegati: IMPORTED_FROM pua
	5) /dichiarazione-finale: IMPORTED_FROM dynamicDocuments
	*/
	{
		path: "/dichiarazione-spandimenti",
		name: "FertSpreadingDeclaration",
		component: () =>
			import(
				"../components/fertSpreadingDeclaration/FertSpreadingDeclaration.vue"
			),
	},
	{
		path: "/dichiarazione-quinquennale",
		name: "fiveYearComunicationForm",
		component: () =>
			import("../components/fiveYearComunication/FiveYearComunication.vue"),
	},
	{
		path: "/dichiarazione-quinquennale-particella-catastale",
		name: "CadastralParcel",
		component: () =>
			import(
				"../components/fiveYearComunication/cadastralParcel/CadastralParcelForm.vue"
			),
	},

	/*
	dynamic documents routes:
	1) /dynamic-documents: dynamic-documents
	2) /declarations-yes-or-no: yes-no-static dynamic documents 
	*/
	{
		path: "/documento-firmato",
		name: "documento-firmato",
		component: () =>
			import("../components/dynamicDocument/dynamicDocument.vue"),
	},
	{
		path: "/declarations-yes-or-no",
		name: "dynamicDocumentRadioYesOrNo",
		component: () =>
			import("../components/dynamicDocument/dynamicDocumentRadioYesOrNo.vue"),
	},

	/*
	five year routes:
	1) /comunicazione spandimenti: IMPORTED_FROM pua
	*/

	/*
	five year routes:
	1) /tipoligia dichiarazione: IMPORTED_FROM pua
	2) /comunicazione-spandimenti: pagina tabelle
	3) /comunicazione-spandimenti-form: FertSpreadingDeclarationForm edit
	4) /allegati: IMPORTED_FROM pua
	5) /dichiarazione-finale: IMPORTED_FROM dynamicDocuments
	*/
	{
		path: "/comunicazione-spandimenti",
		name: "comunicazioneSpandimenti",
		component: () =>
			import(
				"../components/fertSpreadingDeclaration/FertSpreadingDeclaration.vue"
			),
	},
	{
		path: "/comunicazione-spandimenti-form",
		name: "comunicazioneSpandimentiForm",
		component: () =>
			import(
				"../components/fertSpreadingDeclaration/fertSpreadingDeclarationForm/FertSpreadingDeclarationForm.vue"
			),
	},

	/*
	no spreading periods routes:
	1) /no-spreading-periodse: pagina tabella divieto di spandimenti
	*/
	{
		path: "/no-spreading-periods",
		name: "noSpreadingPeriods",
		component: () =>
			import("../components/noSpreadingPeriods/noSpreadingPeriods.vue"),
	}
);

export default routes;
