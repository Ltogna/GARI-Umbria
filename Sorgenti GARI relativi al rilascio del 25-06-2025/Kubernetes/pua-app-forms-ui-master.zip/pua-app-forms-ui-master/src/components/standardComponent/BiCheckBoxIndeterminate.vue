<script setup lang="ts">
// Vue
import { ref, watch } from "vue";

//Boootstrap Italia components
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import type { IconSize } from "@abaco/bootstrap-italia-components/src/models/icon";

const { getColor } = useColors();

const emit = defineEmits(["update:modelValue"]);

const props = withDefaults(
	defineProps<{
		sideSize?: number;
		iconSize?: IconSize;
		value?: boolean | null;
		extraButtonClasses?: string;
		isDisabled?: boolean;
		includeIndeterminate?: boolean;
	}>(),
	{
		sideSize: 16,
		iconSize: "sm",
		value: false,
		extraButtonClasses: "",
		isDisabled: false,
		includeIndeterminate: true,
	}
);

const internalValue = ref<boolean | null>(props.value);

watch(
	() => props.value,
	val => {
		internalValue.value = val;
	}
);

function onClick() {
	switch (internalValue.value) {
		case true:
			internalValue.value = props.includeIndeterminate ? null : false;
			break;
		case false:
			internalValue.value = true;
			break;
		case null:
			internalValue.value = false;
			break;
	}
	emit("update:modelValue", internalValue.value);
}
</script>
<template>
	<div>
		<BiButton
			:width="props.sideSize"
			:height="props.sideSize"
			:isDisabled="props.isDisabled"
			:is-outlined="true"
			:class="`${getColor(
				'button',
				'primary',
				internalValue === false && !props.isDisabled ? 'outline' : undefined
			)} ${props.extraButtonClasses} ${
				internalValue === false ? 'border-grey' : 'border-green'
			} ${props.isDisabled ? '' : 'btn-not-disabled'}`"
			@click="onClick()">
			<template v-slot:default>
				<label
					class="form-check-label"
					:class="{
						true: internalValue === true,
						indeterminate: internalValue === null,
						disabled: isDisabled,
					}"></label>
			</template>
		</BiButton>
	</div>
</template>
<style scoped>
.true {
	position: relative;
	top: -2px;
	left: 0px;
	width: 6px;
	height: 11px;
	border-style: solid;
	border-width: 2px;
	border-color: transparent #fff #fff transparent;
	transform: rotate(40deg);
	backface-visibility: hidden;
	transform-origin: 200% -20%;
	opacity: 0.9;
}

.indeterminate {
	position: relative;
	top: -3px;
	left: -4px;
	width: 8px;
	height: 11px;
	border: 0;
	border-top: 2px solid #fff;
	backface-visibility: hidden;
	transform-origin: 200% -20%;
	opacity: 0.9;
}

.btn-not-disabled {
	padding: 7px !important;
	box-shadow: none !important;
	border: 2px solid hsl(210deg, 17.6470588235%, 43.35%);
	border-radius: 4px;
}

.border-grey {
	border-color: hsl(210deg, 17.6470588235%, 43.35%) !important;
}

.border-green {
	border-color: hsl(142deg, 100%, 12.5%) !important;
}
</style>
