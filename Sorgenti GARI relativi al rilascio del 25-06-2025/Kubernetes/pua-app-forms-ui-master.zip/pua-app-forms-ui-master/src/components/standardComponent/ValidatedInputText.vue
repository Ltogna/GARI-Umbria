<script setup lang="ts">
import { useI18n } from "vue-i18n";

import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import { inject, onMounted, ref } from "vue";
import { setValidationRecord } from "@/stores/validationStore";

const moduleId = inject("moduleId");
const { t } = useI18n({});

const inputValue = defineModel<string | null | undefined>("inputValue");
const uuid = ref<string>(generateUuid());

const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
const minLengthErrorMessage = t(`${moduleId}.general.minLength`);
const mandatoryErrorMessage = t(`${moduleId}.general.required`);

const props = defineProps<{
	isDisabled: boolean;
	label: string;
	maxLength?: number;
	minLength?: number;
	isMandatory?: boolean;
}>();

onMounted(() => {
	fieldValidation(inputValue.value);
	setValidationRecord(uuid.value, errors.value.length === 0);
});

function generateUuid() {
	return "validated-xxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
		/[xy]/g,
		(c): string => {
			const r = (Math.random() * 16) | 0;
			const v = c === "x" ? r : (r & 0x3) | 0x8;
			return v.toString(16);
		}
	);
}

const errors = ref<string[]>([]);

function fieldValidation(value?: any | null) {
	errors.value = [];
	if (props.maxLength) {
		if (value && value.length > props.maxLength) {
			errors.value.push(maxLengthErrorMessage);
		}
	}
	if (props.minLength) {
		if (value && value.length < props.minLength) {
			errors.value.push(minLengthErrorMessage);
		}
	}
	if (props.isMandatory) {
		if (!value) {
			errors.value.push(mandatoryErrorMessage);
		}
	}
}

function update(value: string) {
	fieldValidation(value);
	setValidationRecord(uuid.value, errors.value.length === 0);

	inputValue.value = value;
}
</script>
<template>
	<BiTextarea
		:label="label"
		:model-value="inputValue"
		:isDisabled="isDisabled"
		:errors="errors"
		@update:model-value="
			value => {
				update(value);
			}
		" />
</template>
