<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

// Boootstrap Italia components
import type { IEditElement } from "@/components/fertSpreadingDeclaration/FertSpreadingDeclaration.vue";
import type {
	getCadastralParticelResponse,
	SaveCadastralParticelResponse,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRoute, useRouter } from "vue-router";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";

// const component
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();
const router = useRouter();
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();
const municipalityListResponseMap = ref<IListMap>({});
const isDataTableReady = ref<boolean>(false);

const cadastralParcelId = ref<number>();
const isConfirmDeleteModalOpen = ref<boolean>(false);
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const cadastralParticelList = computed(
	() => applicationFormsStore.getCadastralParticelListResponse
);

const cadastralParticelListSelf = computed(() => {
	return applicationFormsStore.getCadastralParticelListResponse.filter(
		el => el?.partyId == null
	);
});

const cadastralParticelListExternal = computed(() => {
	return applicationFormsStore.getCadastralParticelListResponse.filter(
		el => el?.partyId !== null
	);
});

const isAddEditModalOpen = ref<boolean>(false);

onMounted(async () => {
	queryFieldsStore.populateState();

	await loadCadastralParticelListAndMapMunicipality();
});

function toggleAddEditModal(
	element: getCadastralParticelResponse,
	isExternaCompany: boolean
) {
	if (element) {
		const { id, partyId, company } = element;
		const editElement: IEditElement = { id, partyId, company };
		applicationFormsStore.saveDataInStore(
			"FiveYearComunicationForm",
			"editElement",
			editElement
		);

		if (!isExternaCompany) {
			applicationFormsStore.clearSelectedSubject();
			applicationFormsStore.clearDataInStore(
				"FiveYearComunicationForm",
				"isExternalCompany"
			);
		} else {
			applicationFormsStore.saveDataInStore(
				"FiveYearComunicationForm",
				"isExternalCompany",
				true
			);
		}
		changeRouteToCadastralParcel();
		applicationFormsStore.resetBodyScroll();
	}
}

function toggleConfirmDeleteModal(elementId?: number) {
	if (elementId) {
		cadastralParcelId.value = elementId;
	}
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function addSelfCadastralParticel() {
	applicationFormsStore.clearSelectedSubject();
	applicationFormsStore.clearDataInStore(
		"FiveYearComunicationForm",
		"editElement"
	);
	applicationFormsStore.clearDataInStore(
		"FiveYearComunicationForm",
		"isExternalCompany"
	);
	changeRouteToCadastralParcel();
}

function addExternalCadastralParticel() {
	applicationFormsStore.clearSelectedSubject();
	applicationFormsStore.clearDataInStore(
		"FiveYearComunicationForm",
		"editElement"
	);
	applicationFormsStore.saveDataInStore(
		"FiveYearComunicationForm",
		"isExternalCompany",
		true
	);

	changeRouteToCadastralParcel();
}

function changeRouteToCadastralParcel() {
	router.push({
		name: "CadastralParcel",
		query: {
			...route.query,
		},
	});
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

const municipalityCodeList = computed(() =>
	applicationFormsStore.getCadastralParticelListResponse.reduce(
		(acc: string[], el: getCadastralParticelResponse) => {
			if (el && !acc.includes(el.sectorCode)) {
				acc.push(el.sectorCode);
			}
			return acc;
		},
		[]
	)
);

async function loadCadastralParticelListAndMapMunicipality() {
	await applicationFormsStore.getCadastralParticelList();

	if (cadastralParticelList.value.length > 0) {
		await tableDataMappingDescriptionFromCodeForMunicipalitysAndLandUse();
	}
}

async function tableDataMappingDescriptionFromCodeForMunicipalitysAndLandUse() {
	isDataTableReady.value = false;
	await applicationFormsStore.loadMunicipalityListFromCode(
		municipalityCodeList.value
	);
	createMapMunicipalityList();
	cadastralParticelList.value.map(
		(cadastralParticelItem: SaveCadastralParticelResponse) => {
			if (cadastralParticelItem && cadastralParticelItem.sectorCode) {
				cadastralParticelItem.sectorDescription =
					municipalityListResponseMap.value[cadastralParticelItem.sectorCode];
				cadastralParticelItem.usedAreaSqm = (
					+cadastralParticelItem.usedAreaSqm / 10000
				).toFixed(4);

				cadastralParticelItem.cadastralAreaSqm = (
					+cadastralParticelItem.cadastralAreaSqm / 10000
				).toFixed(4);
			}
			return cadastralParticelItem;
		}
	);
	isDataTableReady.value = true;
}

async function deleteCadastralParcel() {
	if (cadastralParcelId.value) {
		await applicationFormsStore.deleteCadastralParcel(cadastralParcelId.value);
		toggleConfirmDeleteModal();
		await loadCadastralParticelListAndMapMunicipality();
	}
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-else class="pb-3 pt-3">
			<div class="col-10">
				<h5 class="fw-bold" :class="getColor('text', 'primary')">
					{{ t(`${moduleId}.fiveYearsComunication.page.title`) }}
				</h5>
			</div>
			<div class="row my-3 justify-content-start">
				<div class="d-flex justify-content-between">
					<div class="col-10">
						<h6 class="fw-bold" :class="getColor('text', 'primary')">
							<p>
								{{ t(`${moduleId}.fiveYearsComunication.table.title_1`) }}
							</p>
						</h6>
					</div>
					<BiButton
						v-if="
							(!isReadOnly && !applicationFormsStore.loading) ||
							(applicationFormsStore.loading && isAddEditModalOpen)
						"
						type="submit"
						class="mx-1 mb-2 col-auto"
						:class="`${getColor('button', 'primary', 'outline')}`"
						@click.stop="addSelfCadastralParticel()">
						{{ t(`${moduleId}.fiveYearsComunication.button.add`) }}
					</BiButton>
				</div>
				<BiTable
					class="table-responsive"
					extraTableClasses="table-head-bg"
					isResponsive>
					<template v-slot:head>
						<tr
							class="bg-light text-start"
							:class="getColor('text', 'secondary')">
							<th scope="col">
								{{
									t(
										`${moduleId}.fiveYearsComunication.table.cadastralReferences`
									)
								}}
							</th>
							<th scope="col">
								{{ t(`${moduleId}.fiveYearsComunication.table.areaUsed`) }}
							</th>
							<th scope="col"></th>
						</tr>
					</template>
					<template
						v-slot:body
						v-if="
							cadastralParticelListSelf &&
							cadastralParticelListSelf.length > 0 &&
							isDataTableReady
						">
						<tr
							class="align-middle"
							v-for="element in cadastralParticelListSelf"
							:key="JSON.stringify(element)">
							<td
								:data-label="
									t(
										`${moduleId}.fiveYearsComunication.table.cadastralReferences`
									)
								"
								class="text-start">
								{{
									element?.sectorCode +
									" " +
									element?.sectorDescription +
									" FG. " +
									element?.blockCode
								}}
								<span>
									{{ " PT. " + element?.parcelCode }}
								</span>
								<span v-if="element && element.subParcelCode">
									{{ "/" + element.subParcelCode }}
								</span>
							</td>
							<td
								:data-label="
									t(`${moduleId}.fiveYearsComunication.table.areaUsed`)
								"
								class="text-start">
								{{ element?.usedAreaSqm || "" }}
							</td>
							<td class="text-end text-nowrap">
								<div>
									<BiTooltip
										:title="
											t(`${moduleId}.fiveYearsComunication.table.tooltip.edit`)
										"
										:aria-label="
											t(`${moduleId}.fiveYearsComunication.table.tooltip.edit`)
										">
										<BiButton
											:aria-label="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											:aria-labelledby="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											:alt="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											v-if="!isReadOnly"
											@click.stop.prevent="
												() => {
													toggleAddEditModal(element, false);
												}
											"
											:width="40"
											class="mx-1 my-0"
											:class="`${getColor('button', 'success', 'outline')}`">
											<span>
												<BiIcon icon="pencil" size="xl" icon-style="regular" />
											</span>
										</BiButton>
									</BiTooltip>
									<BiTooltip
										:title="
											t(
												`${moduleId}.fiveYearsComunication.table.tooltip.delete`
											)
										"
										:aria-label="
											t(
												`${moduleId}.fiveYearsComunication.table.tooltip.delete`
											)
										">
										<BiButton
											:aria-label="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											:aria-labelledby="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											:alt="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											v-if="!isReadOnly"
											@click.stop.prevent="
												toggleConfirmDeleteModal(element?.id)
											"
											isPrimary
											:width="40"
											class="mx-1 my-0"
											:class="`${getColor('button', 'danger', 'outline')}`">
											<span>
												<BiIcon icon="trash" size="xl" icon-style="regular" />
											</span>
										</BiButton>
									</BiTooltip>
								</div>
							</td>
						</tr>
					</template>
					<template v-slot:body v-else>
						<tr>
							<td colspan="3" class="text-start">
								{{ t(`${moduleId}.general.noData`) }}
							</td>
						</tr>
					</template>
				</BiTable>
			</div>
			<div class="row my-3 justify-content-start">
				<div class="d-flex justify-content-between">
					<div class="col-10">
						<h6 class="fw-bold" :class="getColor('text', 'primary')">
							<p>
								{{ t(`${moduleId}.fiveYearsComunication.table.title_2`) }}
							</p>
						</h6>
					</div>

					<BiButton
						v-if="
							(!isReadOnly && !applicationFormsStore.loading) ||
							(applicationFormsStore.loading && isAddEditModalOpen)
						"
						type="submit"
						class="mx-1 mb-2 col-auto"
						:class="`${getColor('button', 'primary', 'outline')}`"
						@click.stop="addExternalCadastralParticel()">
						{{ t(`${moduleId}.fiveYearsComunication.button.add`) }}
					</BiButton>
				</div>
				<BiTable
					class="table-responsive"
					extraTableClasses="table-head-bg"
					isResponsive>
					<template v-slot:head>
						<tr
							class="bg-light text-start"
							:class="getColor('text', 'secondary')">
							<th scope="col">
								{{ t(`${moduleId}.fiveYearsComunication.table.company`) }}
							</th>
							<th scope="col">
								{{ t(`${moduleId}.fiveYearsComunication.table.cuaa`) }}
							</th>
							<th scope="col">
								{{
									t(
										`${moduleId}.fiveYearsComunication.table.cadastralReferences`
									)
								}}
							</th>
							<th scope="col">
								{{ t(`${moduleId}.fiveYearsComunication.table.areaUsed`) }}
							</th>
							<th scope="col"></th>
						</tr>
					</template>
					<template
						v-slot:body
						v-if="
							cadastralParticelListExternal &&
							cadastralParticelListExternal.length > 0 &&
							isDataTableReady
						">
						<tr
							class="align-middle"
							v-for="element in cadastralParticelListExternal"
							:key="JSON.stringify(element)">
							<td
								:data-label="
									t(`${moduleId}.fiveYearsComunication.table.company`)
								"
								class="text-start">
								{{ element?.company || "" }}
								<!-- {{ element?.denomination || "" }} -->
							</td>
							<td
								:data-label="t(`${moduleId}.fiveYearsComunication.table.cuaa`)"
								class="text-start">
								{{ element?.cuaa || "" }}
							</td>
							<td
								:data-label="
									t(
										`${moduleId}.fiveYearsComunication.table.cadastralReferences`
									)
								"
								class="text-start">
								{{
									element?.sectorCode +
									" " +
									element?.sectorDescription +
									" FG. " +
									element?.blockCode
								}}
								<span>
									{{ " PT. " + element?.parcelCode }}
								</span>
								<span v-if="element && element.subParcelCode">
									{{ "/" + element.subParcelCode }}
								</span>
							</td>
							<td
								:data-label="
									t(`${moduleId}.fiveYearsComunication.table.areaUsed`)
								"
								class="text-start">
								{{ element?.usedAreaSqm || "" }}
							</td>
							<td class="text-end text-nowrap">
								<div>
									<BiTooltip
										:title="
											t(`${moduleId}.fiveYearsComunication.table.tooltip.edit`)
										"
										:aria-label="
											t(`${moduleId}.fiveYearsComunication.table.tooltip.edit`)
										">
										<BiButton
											:aria-label="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											:aria-labelledby="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											:alt="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.edit`
												)
											"
											v-if="!isReadOnly"
											@click.stop.prevent="
												() => {
													toggleAddEditModal(element, true);
												}
											"
											:width="40"
											class="mx-1 my-0"
											:class="`${getColor('button', 'success', 'outline')}`">
											<span>
												<BiIcon icon="pencil" size="xl" icon-style="regular" />
											</span>
										</BiButton>
									</BiTooltip>
									<BiTooltip
										:title="
											t(
												`${moduleId}.fiveYearsComunication.table.tooltip.delete`
											)
										"
										:aria-label="
											t(
												`${moduleId}.fiveYearsComunication.table.tooltip.delete`
											)
										">
										<BiButton
											:aria-label="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											:aria-labelledby="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											:alt="
												t(
													`${moduleId}.fiveYearsComunication.table.tooltip.delete`
												)
											"
											v-if="!isReadOnly"
											@click.stop.prevent="
												toggleConfirmDeleteModal(element?.id)
											"
											isPrimary
											:width="40"
											class="mx-1 my-0"
											:class="`${getColor('button', 'danger', 'outline')}`">
											<span>
												<BiIcon icon="trash" size="xl" icon-style="regular" />
											</span>
										</BiButton>
									</BiTooltip>
								</div>
							</td>
						</tr>
					</template>
					<template v-slot:body v-else>
						<tr>
							<td colspan="3" class="text-start">
								{{ t(`${moduleId}.general.noData`) }}
							</td>
						</tr>
					</template>
				</BiTable>
			</div>
		</div>

		<!-- confirm delete modal -->
		<BiModal
			:disabled-teleport="true"
			:extra-footer-class="'justify-content-center'"
			v-model="isConfirmDeleteModalOpen"
			:aria-labelledby="
				t(`${moduleId}.fiveYearsComunication.modal.delete.title`)
			"
			:title="t(`${moduleId}.fiveYearsComunication.modal.delete.title`)"
			:prevent-dismiss="true">
			<template #body>
				<div class="col-12 mb-3">
					<BiAlert isWarn>
						<template #body>
							{{ t(`${moduleId}.fiveYearsComunication.modal.delete.body`) }}
						</template>
					</BiAlert>
				</div>
			</template>
			<template #footer>
				<div class="d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="
							() => {
								toggleConfirmDeleteModal();
							}
						">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						class="mx-1"
						isPrimary
						:class="getColor('button', 'success')"
						@click.stop="deleteCadastralParcel()">
						{{ t(`${moduleId}.general.confirm`) }}
					</BiButton>
				</div>
				<div
					v-if="applicationFormsStore.getLoading"
					class="d-flex row justify-content-center mb-3">
					<div class="d-flex col-2 justify-content-center px-0">
						<BiProgressIndicator type="spinner"></BiProgressIndicator>
					</div>
				</div>
			</template>
		</BiModal>
	</div>
</template>

<style scoped>
ul {
	list-style-type: none;
	padding-left: 0;
}

.change-color {
	background-color: #f6f8fa;
}

.title {
	font-weight: bold;
	font-size: 1.111em;
}

@media (max-width: 1200px) {
	div.form-check.form-check-inline {
		margin-right: 0.1rem !important;
	}
}
</style>
