<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import {
	type getPartyRegistryResponse,
	type MunicipalityRecordListResponse,
	MunicipalityRecordListResponseSchema,
	type SaveCadastralParticelModel,
	type SearchSubjectDescriptionResponse,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";

import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// other
import type { IListMap } from "@/components/ChemicalFertilizer/ChemicalFertilizer.vue";
import { toTypedSchema } from "@vee-validate/zod";
import debounce from "lodash/debounce";
import { useField, useForm } from "vee-validate";
import { useRoute, useRouter } from "vue-router";
import { z } from "zod";
import searchSubjectFormHelper from "../../searchSubjectFormHelper/SearchSubjectFormHelper.vue";

const applicationFormsStore = useApplicationFormsStore();
const route = useRoute();
const router = useRouter();
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const queryFieldsStore = useQueryFieldsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const cadastralParcelId = computed(
	() =>
		applicationFormsStore.saveInStore?.FiveYearComunicationForm?.editElement?.id
);

const partyIdSelf = computed(() => queryFieldsStore.getPartyId);
const cadastralAreaSqmRef = ref();
const cadastralAreaSqmInputId = "cadastralAreaId";
let cadastralAreaSqmOldValue: string | undefined;

const usedAreaSqmRef = ref();
const usedAreaSqmInputId = "usedAreaSqmId";
let usedAreaSqmOldValue: string | undefined;

function validateNumberOrNumberWithFourDecimalCadastralAreaSqm() {
	if (cadastralAreaSqm.value != null) {
		cadastralAreaSqmOldValue = cadastralAreaSqm.value.toString();
	}
	const result = applicationFormsStore.validateNumberOrNumberWithFourDecimal(
		cadastralAreaSqmInputId,
		cadastralAreaSqm,
		cadastralAreaSqmOldValue
	);
	if (result == false) {
		return false;
	} else {
		cadastralAreaSqmOldValue = result;
	}
}

function validateNumberOrNumberWithFourDecimalUsedAreaSqm() {
	if (cadastralAreaSqm.value != null) {
		cadastralAreaSqmOldValue = cadastralAreaSqm.value.toString();
	}
	const result = applicationFormsStore.validateNumberOrNumberWithFourDecimal(
		usedAreaSqmInputId,
		usedAreaSqm,
		usedAreaSqmOldValue
	);
	if (result == false) {
		return false;
	} else {
		usedAreaSqmOldValue = result;
	}
}

const getCadastralParticelResponse = computed(
	() => applicationFormsStore.getCadastralParticelResponse
);
const isExternalCompany = computed(() => {
	if (
		applicationFormsStore.saveInStore &&
		applicationFormsStore.saveInStore.FiveYearComunicationForm &&
		applicationFormsStore.saveInStore.FiveYearComunicationForm.isExternalCompany
	) {
		return applicationFormsStore.saveInStore.FiveYearComunicationForm
			.isExternalCompany;
	} else if (
		getCadastralParticelResponse.value &&
		getCadastralParticelResponse.value.partyId
	) {
		return getCadastralParticelResponse.value.partyId !== partyIdSelf.value;
	} else {
		return false;
	}
});

const subordinate = ref<string>("");

const partyId = computed(() => {
	if (applicationFormsStore.selectedSubject) {
		return applicationFormsStore.selectedSubject?.id;
	} else {
		return applicationFormsStore.saveInStore?.FiveYearComunicationForm
			?.editElement?.partyId;
	}
});

const companyName = computed(
	() =>
		applicationFormsStore.saveInStore?.FiveYearComunicationForm?.editElement
			?.company
);

const minCharFilter = ref<number>(3);
const municipalityList = ref<MunicipalityRecordListResponse[]>([]);
const municipalityCodeFilter = ref<string>("");
const isMunicipalityListLoadingDataFilter = ref<boolean>(false);

const municipalityListResponse = computed(
	() => applicationFormsStore.municipalityList
);

const municipalityListResponseMap = ref<IListMap>({});

const saveCadastralParticelResponse = computed(
	() => applicationFormsStore.saveCadastralParticelResponse
);

const editCadastralParcelResponse = computed(
	() => applicationFormsStore.editCadastralParcelResponse
);

const isValidUsedArea = ref<boolean>(true);
const isValidStartDateOperationAndEndDateOperation = ref<boolean>(true);

const selectedSubject = computed(() => {
	if (
		applicationFormsStore.selectedSubject &&
		!applicationFormsStore.selectedSubject.description
	) {
		applicationFormsStore.selectedSubject.description =
			applicationFormsStore.selectedSubject.lastName +
			" " +
			applicationFormsStore.selectedSubject.firstName;
	}

	return applicationFormsStore.selectedSubject;
});

const isNextMunicipalityValid = ref<string | null | undefined>(null);
const isDataPresentInBackEnd = ref<boolean>(false);
const searchSubjectFormHelperRef = ref();

onMounted(async () => {
	queryFieldsStore.populateState();
	clearGetCadastralParcel();
	getDeclarationStoredInBackEndAndRequestType();
});

function clearGetCadastralParcel() {
	applicationFormsStore.clearGetCadastralParticelResponse();
}

function initItemObjectToPage() {
	if (
		getCadastralParticelResponse.value &&
		getCadastralParticelResponse.value.dayFrom &&
		getCadastralParticelResponse.value.dayTo
	) {
		getCadastralParticelResponse.value.usedAreaSqm =
			+getCadastralParticelResponse.value.usedAreaSqm / 10000;
		getCadastralParticelResponse.value.cadastralAreaSqm =
			+getCadastralParticelResponse.value.cadastralAreaSqm / 10000;
		getCadastralParticelResponse.value.dayFrom =
			applicationFormsStore.addSeparatorInStringForDate(
				getCadastralParticelResponse.value.dayFrom
			);

		getCadastralParticelResponse.value.dayTo =
			applicationFormsStore.addSeparatorInStringForDate(
				getCadastralParticelResponse.value.dayTo
			);
	}
}

function setValueInForm() {
	sectorCode.value = {} as MunicipalityRecordListResponse;
	if (
		municipalityListResponseMap.value &&
		sectorCode.value &&
		getCadastralParticelResponse.value &&
		getCadastralParticelResponse.value.id &&
		getCadastralParticelResponse.value.dayFrom &&
		getCadastralParticelResponse.value.dayTo &&
		getCadastralParticelResponse.value.sectorCode
	) {
		sectorCode.value.description =
			municipalityListResponseMap.value[
				getCadastralParticelResponse.value.sectorCode
			];
		sectorCode.value.sector_code =
			getCadastralParticelResponse.value.sectorCode;
		blockCode.value = getCadastralParticelResponse.value.blockCode;
		parcelCode.value = getCadastralParticelResponse.value.parcelCode;
		subordinate.value = getCadastralParticelResponse.value.subParcelCode
			? getCadastralParticelResponse.value.subParcelCode
			: "";
		cadastralAreaSqm.value =
			getCadastralParticelResponse.value.cadastralAreaSqm;
		dayFrom.value = getCadastralParticelResponse.value.dayFrom;
		dayTo.value = getCadastralParticelResponse.value.dayTo;
		usedAreaSqm.value = getCadastralParticelResponse.value.usedAreaSqm;
		if (isExternalCompany.value && partyId.value) {
			const selectedSubject = {} as getPartyRegistryResponse;
			if (selectedSubject) {
				selectedSubject.description = companyName.value;
				selectedSubject.id = partyId.value;
				applicationFormsStore.setSelectedSubject(selectedSubject);
			}
		}
	}
}

async function loadMunicipalityListFromCodeFn() {
	if (
		getCadastralParticelResponse.value &&
		getCadastralParticelResponse.value.id &&
		getCadastralParticelResponse.value.sectorCode
	) {
		await applicationFormsStore.loadMunicipalityListFromCode([
			getCadastralParticelResponse.value.sectorCode,
		]);
	}
}

async function getDeclarationStoredInBackEndAndRequestType() {
	if (cadastralParcelId.value) {
		await applicationFormsStore.getCadastralParticel(
			String(cadastralParcelId.value)
		);
		isDataPresentInBackEnd.value = true;

		await loadMunicipalityListFromCodeFn();
		createMapMunicipalityList();
		initItemObjectToPage();
		setValueInForm();
	}
}

function checkCadastralAreaIsMajorOfAreaUsed() {
	if (
		cadastralAreaSqm.value &&
		usedAreaSqm.value &&
		cadastralAreaSqm.value >= usedAreaSqm.value
	) {
		isValidUsedArea.value = true;
	} else {
		isValidUsedArea.value = false;
	}
}

function checkIsValidStartDateOperationAndEndDateOperation() {
	if (dayFrom.value && dayTo.value) {
		isValidStartDateOperationAndEndDateOperation.value =
			new Date(dayTo.value) >= new Date(dayFrom.value);
	}
}

function goInDichiarazioneQuinquennale() {
	router.push({
		name: "fiveYearComunicationForm",
		query: {
			...route.query,
		},
	});
}

async function cancelTab() {
	goInDichiarazioneQuinquennale();
}

async function checkIfTabCompletedAndSaveOrEditCadastralParcelAndGoInTableParentComponent() {
	checkCadastralAreaIsMajorOfAreaUsed();
	checkIsValidStartDateOperationAndEndDateOperation();

	if (
		sectorCode.value &&
		sectorCode.value.sector_code &&
		blockCode.value &&
		cadastralAreaSqm.value &&
		dayFrom.value &&
		dayTo.value &&
		usedAreaSqm.value &&
		parcelCode.value &&
		isValidUsedArea.value &&
		isValidStartDateOperationAndEndDateOperation.value &&
		(!isExternalCompany.value ||
			(isExternalCompany.value &&
				(partyId.value || (selectedSubject.value && selectedSubject.value.id))))
	) {
		const saveData: SaveCadastralParticelModel = {
			partyId: isExternalCompany.value
				? partyId.value
					? (partyId.value as number)
					: (selectedSubject.value?.id as number)
				: null,
			sectorCode: sectorCode.value.sector_code,
			blockCode: blockCode.value,
			parcelCode: parcelCode.value,
			subParcelCode: subordinate.value,
			cadastralAreaSqm:
				+String(cadastralAreaSqm.value).replaceAll(",", ".") * 10000,
			dayFrom: dayFrom.value.toString().replaceAll(/[-/]/gi, ""),
			dayTo: dayTo.value.toString().replaceAll(/[-/]/gi, ""),
			usedAreaSqm: +String(usedAreaSqm.value).replaceAll(",", ".") * 10000,
		};

		await SaveOrEditCadastralParcelAndGoInTableParentComponent(saveData);
	}
}

async function SaveOrEditCadastralParcelAndGoInTableParentComponent(
	saveData: SaveCadastralParticelModel
) {
	if (isDataPresentInBackEnd.value) {
		saveData.id = Number(cadastralParcelId.value);
		await applicationFormsStore.editCadastralParcel(saveData);
	} else {
		await applicationFormsStore.saveCadastralParticel(saveData);
	}

	if (
		(saveCadastralParticelResponse.value &&
			saveCadastralParticelResponse.value.id) ||
		(editCadastralParcelResponse.value && editCadastralParcelResponse.value.id)
	) {
		goInDichiarazioneQuinquennale();
	}
}

function onMunicipalityListCodeSearchChange(val: string) {
	municipalityCodeFilter.value = val;
}

const municipalityCodeChange = debounce(async () => {
	if (municipalityCodeFilter.value.length >= 3) {
		isMunicipalityListLoadingDataFilter.value = true;
		await applicationFormsStore.loadMunicipalityList(
			municipalityCodeFilter.value
		);
		initMunicipalityList();
		isNextMunicipalityValid.value =
			applicationFormsStore.municipalityList?.nextKey;
		isMunicipalityListLoadingDataFilter.value = false;
	} else {
		municipalityList.value = [];
	}
}, 500);

function initMunicipalityList() {
	municipalityList.value =
		municipalityList.value &&
		municipalityList.value &&
		municipalityListResponse.value
			? municipalityListResponse.value.records
			: [];
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

function subordinateUpperCase() {
	if (typeof subordinate.value !== "number") {
		subordinate.value = subordinate.value.toUpperCase();
	}
}

const { handleSubmit, setErrors, isSubmitting, errors } =
	useForm<SaveCadastralParticelModel>({
		initialValues: {
			sectorCode: null,
			blockCode: undefined,
			parcelCode: undefined,
			cadastralAreaSqm: undefined,
			dayFrom: null,
			dayTo: null,
			usedAreaSqm: undefined,
		},
	});

const { value: sectorCode } = useField<MunicipalityRecordListResponse | null>(
	"sectorCode",
	toTypedSchema(MunicipalityRecordListResponseSchema.nullish())
);
const { value: blockCode } = useField<number | null>(
	"blockCode",
	toTypedSchema(z.number().or(z.string()).nullish())
);
const { value: parcelCode } = useField<number | null>(
	"parcelCode",
	toTypedSchema(z.number().or(z.string()).nullish())
);
const { value: cadastralAreaSqm } = useField<string | number | null>(
	"cadastralAreaSqm",
	toTypedSchema(z.number().or(z.string()).nullish())
);
const { value: dayFrom } = useField<string | null>(
	"dayFrom",
	toTypedSchema(z.string().nullish())
);
const { value: dayTo } = useField<string | null>(
	"dayTo",
	toTypedSchema(z.string().nullish())
);
const { value: usedAreaSqm } = useField<string | number | null>(
	"usedAreaSqm",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const validateForm = (saveCadastralParcticel: SaveCadastralParticelModel) => {
	if (!saveCadastralParcticel.sectorCode) {
		setErrors({
			sectorCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!saveCadastralParcticel.blockCode) {
		setErrors({
			blockCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveCadastralParcticel.parcelCode) {
		setErrors({
			parcelCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveCadastralParcticel.cadastralAreaSqm) {
		setErrors({
			cadastralAreaSqm: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveCadastralParcticel.dayFrom) {
		setErrors({
			dayFrom: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveCadastralParcticel.dayTo) {
		setErrors({
			dayTo: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!saveCadastralParcticel.usedAreaSqm) {
		setErrors({
			usedAreaSqm: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
};

const onSubmit = handleSubmit.withControlled(async values => {
	validateForm(values);
	const errorSearchSubjectComponent = ref<SearchSubjectDescriptionResponse>({});
	if (isExternalCompany.value) {
		errorSearchSubjectComponent.value = validateFormChildComponent();
	}

	applicationFormsStore.resetScrollToTop(window);

	if (
		(errorSearchSubjectComponent.value &&
			errorSearchSubjectComponent.value.description) ||
		errors.value.sectorCode ||
		errors.value.blockCode ||
		errors.value.parcelCode ||
		errors.value.cadastralAreaSqm ||
		errors.value.dayFrom ||
		errors.value.dayTo ||
		errors.value.usedAreaSqm
	) {
		return;
	} else {
		await checkIfTabCompletedAndSaveOrEditCadastralParcelAndGoInTableParentComponent();
	}
	return true;
});

function validateFormChildComponent() {
	if (searchSubjectFormHelperRef.value) {
		const errorSearchSubjectComponent =
			searchSubjectFormHelperRef.value.validateForm("");

		return errorSearchSubjectComponent;
	}
}
</script>

<template>
	<form class="container col-12 px-3 mx-0">
		<div class="pb-3 pt-3">
			<div class="col-12 my-3">
				<h5 class="fw-bold" :class="getColor('text', 'primary')">
					{{ t(`${moduleId}.cadastralParcel.fiveYearsComunication`) }}
				</h5>
			</div>

			<div class="row">
				<h6 class="fw-bold" :class="getColor('text', 'primary')">
					<p>
						{{ t(`${moduleId}.cadastralParcel.cadastralParcel`) }}
					</p>
				</h6>
			</div>

			<BiAlert isError v-if="!isValidUsedArea">
				<template #body>
					{{
						t(
							`${moduleId}.cadastralParcel.errors.USED_AREA_MAJOR_THAN_CADASTRAL_AREA`
						)
					}}
				</template>
			</BiAlert>

			<BiAlert isError v-if="!isValidStartDateOperationAndEndDateOperation">
				<template #body>
					{{
						t(
							`${moduleId}.cadastralParcel.errors.STARD_DATE_OPERATION_MUST_BE_LESS_THEN_OR_EQUAL_OF_END_DATE_OPERATION`
						)
					}}
				</template>
			</BiAlert>

			<div v-if="isExternalCompany">
				<div class="row">
					<h6 class="fw-bold" :class="getColor('text', 'primary')">
						<p>
							{{
								t(`${moduleId}.cadastralParcel.landMadeAvailableOtherCompanies`)
							}}
						</p>
					</h6>
				</div>

				<div class="row">
					<searchSubjectFormHelper
						ref="searchSubjectFormHelperRef"></searchSubjectFormHelper>
				</div>
			</div>

			<div class="row">
				<div class="col-12 mb-5">
					<BiAutocompleteNext
						ref="autocompleteRef"
						name="sectorCodeId"
						:id="'sectorCodeId'"
						:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
						:items="municipalityList"
						:isAutocomplete="true"
						:loading="isMunicipalityListLoadingDataFilter"
						:showNoResults="!isMunicipalityListLoadingDataFilter"
						v-model="sectorCode"
						@searchChange="onMunicipalityListCodeSearchChange"
						@keyup="municipalityCodeChange"
						:minSearchLenght="minCharFilter"
						:labelNoResult="
							t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
							` ${municipalityCodeFilter}`
						"
						:labelMinCharachter="
							t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
						"
						:labelNoItems="
							t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
							` ${minCharFilter}`
						"
						:itemTitle="'description'"
						:errors="errors.sectorCode ? [errors.sectorCode] : []"
						:disabled="isReadOnly">
						<template #afterList>
							<div
								class="autocomplete-after-search-template"
								v-if="isNextMunicipalityValid">
								{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
							</div>
						</template>
					</BiAutocompleteNext>
				</div>
			</div>
			<div class="row">
				<div class="col-4 mb-5">
					<BiInput
						name="blockCodeId"
						:id="'blockCodeId'"
						class="mb-4"
						type="number"
						:errors="errors.blockCode ? [errors.blockCode] : []"
						:label="t(`${moduleId}.cadastralParcel.sheet`)"
						v-model="blockCode" />
				</div>

				<div class="col-4 mb-5">
					<BiInput
						name="parcelCodeId"
						:id="'parcelCodeId'"
						class="mb-4"
						type="number"
						:errors="errors.parcelCode ? [errors.parcelCode] : []"
						:label="t(`${moduleId}.cadastralParcel.number`)"
						v-model="parcelCode" />
				</div>

				<div class="col-4 mb-5">
					<BiInput
						name="subordinateId"
						:id="'subordinateId'"
						@change="subordinateUpperCase()"
						class="mb-4"
						:label="t(`${moduleId}.cadastralParcel.subordinate`)"
						v-model="subordinate" />
				</div>
			</div>

			<div class="row">
				<div class="col-6 mb-5">
					<BiDatepicker
						name="dayFromId"
						:id="'dayFromId'"
						:is-disabled="isReadOnly"
						v-model="dayFrom"
						:max="dayTo ?? ''"
						class="mb-4"
						:errors="errors.dayFrom ? [errors.dayFrom] : []"
						:label="
							t(`${moduleId}.cadastralParcel.startDateOperation`)
						"></BiDatepicker>
				</div>

				<div class="col-6 mb-5">
					<BiDatepicker
						name="dayToId"
						:id="'dayToId'"
						:is-disabled="isReadOnly"
						v-model="dayTo"
						:min="dayFrom ?? ''"
						class="mb-4"
						:errors="errors.dayTo ? [errors.dayTo] : []"
						:label="
							t(`${moduleId}.cadastralParcel.endDateOperation`)
						"></BiDatepicker>
				</div>
			</div>

			<div class="row">
				<div class="col-6 mb-5">
					<BiInput
						name="cadastralAreaId"
						:id="'cadastralAreaId'"
						class="mb-4"
						type="text"
						ref="cadastralAreaSqmRef"
						@input="validateNumberOrNumberWithFourDecimalCadastralAreaSqm()"
						:errors="errors.cadastralAreaSqm ? [errors.cadastralAreaSqm] : []"
						:label="t(`${moduleId}.cadastralParcel.cadastralArea`)"
						v-model="cadastralAreaSqm" />
				</div>

				<div class="col-6 mb-5">
					<BiInput
						name="usedAreaSqmId"
						:id="'usedAreaSqmId'"
						ref="usedAreaSqmRef"
						class="mb-4"
						type="text"
						@input="validateNumberOrNumberWithFourDecimalUsedAreaSqm()"
						:errors="errors.usedAreaSqm ? [errors.usedAreaSqm] : []"
						:label="t(`${moduleId}.cadastralParcel.areaUsed`)"
						v-model="usedAreaSqm" />
				</div>
			</div>
		</div>

		<div class="mb-0 mt-5 pt-3 d-flex justify-content-center">
			<BiButton
				v-if="!isReadOnly && !applicationFormsStore.loading"
				type="submit"
				form="cadastralParcelFOrm"
				class="mx-1 mb-4"
				:class="getColor('button', 'primary')"
				:is-disabled="isSubmitting"
				@click="cancelTab()">
				{{ t(`${moduleId}.general.cancel`) }}
			</BiButton>
			<BiButton
				v-if="!isReadOnly && !applicationFormsStore.loading"
				type="submit"
				form="cadastralParcelForm"
				class="mx-1 mb-4"
				:class="getColor('button', 'primary')"
				:is-disabled="isSubmitting"
				@click="onSubmit">
				{{ t(`${moduleId}.general.saveCard`) }}
			</BiButton>
			<BiProgressIndicator
				v-if="applicationFormsStore.loading"
				type="spinner"></BiProgressIndicator>
		</div>
	</form>
</template>
