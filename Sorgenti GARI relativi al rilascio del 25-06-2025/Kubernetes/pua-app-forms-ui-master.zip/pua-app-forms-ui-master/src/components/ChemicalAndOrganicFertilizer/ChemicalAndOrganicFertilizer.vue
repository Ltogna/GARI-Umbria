<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";
import { useRoute, useRouter } from "vue-router";

// Boootstrap Italia components
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// const component
import {
	MunicipalityRecordListResponseSchema,
	type getPlotLandResponse,
	type getPlotLandValidationResponse,
	type LandUseRecordListResponse,
	type MunicipalityRecordListResponse,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { toTypedSchema } from "@vee-validate/zod";
import { debounce } from "lodash";
import { useField } from "vee-validate";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";
import ToggleImportOrManualAdd from "../ToggleImportOrManualAdd/ToggleImportOrManualAdd.vue";
import TableRow from "./TableRow/TableRow.vue";

export interface IFilterChemicalAndOrganicaFertilizer {
	sectorCode: string;
	landUseCode: string;
}

export interface IFilterStoreChemicalAndOrganicaFertilizer {
	sectorCode: MunicipalityRecordListResponse;
	landUseCode: LandUseRecordListResponse;
}

export interface IFilterChipChemicalAndOrganicaFertilizer {
	sectorDescription: string;
	landUseDescription: string;
}

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();
const router = useRouter();
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();

const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);
const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const chemicalAndOrganicFertilizerId = ref<number>(0);
const isDataTableReady = ref<boolean>(false);
const landUseListResponseMap = ref<IListMap>({});
const cycleListResponseMap = ref<IListMap>({});
const precessionListResponseMap = ref<IListMap>({});
const typologyListResponseMap = ref<IListMap>({});
const municipalityListResponseMap = ref<IListMap>({});
const toggleHandlerImportOrManualAdd = ref<boolean | null>(null);
const isSelectAllWithSameLandUseCode = ref<boolean>(false);
const showFilterForSearchModal = ref<boolean>(false);
const isFilterForSectorCodeVisible = ref<boolean>(false);
const isFilterForLandUseCodeVisible = ref<boolean>(false);

const municipalityList = ref<MunicipalityRecordListResponse[]>([]);
const municipalityCodeFilter = ref<string>("");
const isMunicipalityListLoadingDataFilter = ref<boolean>(false);
const minSearchLenghtMunicipality = ref<number>(3);

const municipalityListResponse = computed(
	() => applicationFormsStore.municipalityList
);
const isNextMunicipalityValid = ref<string | null | undefined>(null);

const landUseList = ref<LandUseRecordListResponse[]>([]);
const landUseCodeFilter = ref<string>("");
const isLandUseCodeLoadingDataFilter = ref<boolean>(false);

const landUseCode = ref<LandUseRecordListResponse>();
const landUseListResponse = computed(() => applicationFormsStore.landUseList);
const minSearchLenghtLandUse = ref<number>(3);
const isNextLandUseValid = ref<string | null | undefined>(null);

const showAlertInTableIsPresentAlmostOneElementImport = ref<boolean>(false);
const showAlertInTableIsPresentAlmostOneElementHandlerManualAdd =
	ref<boolean>(false);

const plotsLandList = computed(
	() => applicationFormsStore.getPlotLandListAndPreviousManureResponse
);

const getDeclarationYear = computed(
	() => applicationFormsStore.getDeclarationYearResponse
);

const chipFilterDescription = ref<IFilterChipChemicalAndOrganicaFertilizer>({
	sectorDescription: "",
	landUseDescription: "",
});

const municipalityCodeList = computed(() =>
	applicationFormsStore.getPlotLandListAndPreviousManureResponse.reduce(
		(acc: string[], el: getPlotLandResponse) => {
			if (el && el.sectorCode && !acc.includes(el.sectorCode)) {
				acc.push(el.sectorCode);
			}
			return acc;
		},
		[]
	)
);

const landUseCodeList = computed(() =>
	applicationFormsStore.getPlotLandListAndPreviousManureResponse.reduce(
		(acc: string[], el: getPlotLandValidationResponse) => {
			if (el && el.landUseCode && !acc.includes(el.landUseCode)) {
				acc.push(el.landUseCode);
			}
			return acc;
		},
		[]
	)
);

const isTwoElementSelectedForMassiveEdit = computed(
	() =>
		plotsLandList.value.filter(plotLand => plotLand.isSelected == true)
			.length >= 2
);

const takeLandUseCodeFromFirstCheckBoxSelected = ref<string | null>(null);

function selectedPlotLand(plotLand: getPlotLandResponse) {
	const isOnePLotLandSelected = plotsLandList.value.filter(
		plotLand => plotLand.isSelected == true
	);

	if (
		isOnePLotLandSelected.length == 1 &&
		plotLand != null &&
		plotLand.landUseCode != null
	) {
		takeLandUseCodeFromFirstCheckBoxSelected.value = plotLand.landUseCode;
	} else if (isOnePLotLandSelected.length == 0) {
		takeLandUseCodeFromFirstCheckBoxSelected.value = null;
		isSelectAllWithSameLandUseCode.value = false;
	}
}

function selectAllPlotLandWithSameLandUseCodeOrDeselectAll() {
	if (plotsLandList.value == null) return;

	if (isSelectAllWithSameLandUseCode.value == true) {
		plotsLandList.value
			.filter(
				(el: getPlotLandResponse) =>
					el?.landUseCode == takeLandUseCodeFromFirstCheckBoxSelected.value
			)
			.map((plotLand: getPlotLandValidationResponse) => {
				if (plotLand?.isSelected != null) {
					plotLand.isSelected = true;
				}
				return plotLand;
			});
	} else if (isSelectAllWithSameLandUseCode.value == false) {
		plotsLandList.value.map((plotLand: getPlotLandValidationResponse) => {
			if (plotLand?.isSelected != null) {
				plotLand.isSelected = false;
			}
			return plotLand;
		});
		takeLandUseCodeFromFirstCheckBoxSelected.value = null;
	}
}

const getPlotLandFilterObject = computed(() => {
	const getPlotLandFilterObjectFn =
		{} as IFilterStoreChemicalAndOrganicaFertilizer;

	if (sectorCode.value != null && sectorCode.value.sector_code != null) {
		getPlotLandFilterObjectFn.sectorCode = sectorCode.value;
	}

	if (landUseCode.value != null && landUseCode.value.land_uses_code != null) {
		getPlotLandFilterObjectFn.landUseCode = landUseCode.value;
	}

	return getPlotLandFilterObjectFn;
});

const filterObjectFromStore = computed(
	() => applicationFormsStore.saveInStore?.ChemicalAndOrganic.filterObject
);

onMounted(async () => {
	queryFieldsStore.populateState();
	await applicationFormsStore.getDeclarationYear();
	setFilterObjectFromStoreAndChipBeforeTable();
	await getPlotLandListOrPLotLandListFitler();
});

function setValueForToggleHandlerImportOrManualAdd() {
	if (plotsLandList.value.length > 0) {
		toggleHandlerImportOrManualAdd.value =
			plotsLandList.value &&
			plotsLandList.value[0] &&
			plotsLandList.value[0].declCode != null &&
			plotsLandList.value[0].plotCode != null &&
			plotsLandList.value[0].planId != null &&
			plotsLandList.value[0].declarationVersion != null
				? false
				: true;
	}
}

function setFilterObjectFromStoreAndChipBeforeTable() {
	sectorCode.value = {} as MunicipalityRecordListResponse;
	landUseCode.value = {} as LandUseRecordListResponse;

	if (filterObjectFromStore.value != null) {
		if (
			sectorCode.value != null &&
			filterObjectFromStore.value.sectorCode != null &&
			filterObjectFromStore.value.sectorCode.sector_code != null &&
			filterObjectFromStore.value.sectorCode.sector_code.length > 0
		) {
			sectorCode.value = filterObjectFromStore.value.sectorCode;
		}
		if (
			landUseCode.value != null &&
			filterObjectFromStore.value.landUseCode != null &&
			filterObjectFromStore.value.landUseCode.land_uses_code != null &&
			filterObjectFromStore.value.landUseCode.land_uses_code.length > 0
		) {
			landUseCode.value = filterObjectFromStore.value.landUseCode;
		}
	}

	setChipFilterDescriptionForChipBeforeTable();
}

async function plotLandListFilterAndSaveFilterObjectInStore() {
	setChipFilterDescriptionForChipBeforeTable();
	toggleFilterSearch(false);

	applicationFormsStore.saveDataInStore(
		"ChemicalAndOrganic",
		"filterObject",
		getPlotLandFilterObject.value
	);

	takeLandUseCodeFromFirstCheckBoxSelected.value = null;
	await getPlotLandListOrPLotLandListFitler();
}

async function getPlotLandListOrPLotLandListFitler() {
	//  da aggiungere il passaggio dei filtri tra i componenti
	// per adesso non usato preparato per dopo da aggiungere la logica next key per adesso non usato
	const nextKey = 0;

	if (
		getPlotLandFilterObject.value != null &&
		((getPlotLandFilterObject.value.sectorCode != null &&
			getPlotLandFilterObject.value.sectorCode.sector_code != null &&
			getPlotLandFilterObject.value.sectorCode.sector_code.length > 0) ||
			(getPlotLandFilterObject.value.landUseCode != null &&
				getPlotLandFilterObject.value.landUseCode.land_uses_code != null &&
				getPlotLandFilterObject.value.landUseCode.land_uses_code.length > 0))
	) {
		let sectorCode = "";
		if (
			getPlotLandFilterObject.value.sectorCode != null &&
			getPlotLandFilterObject.value.sectorCode.sector_code != null
		) {
			sectorCode = getPlotLandFilterObject.value.sectorCode.sector_code;
		}

		let landUseCode = "";
		if (
			getPlotLandFilterObject.value.landUseCode != null &&
			getPlotLandFilterObject.value.landUseCode.land_uses_code != null
		) {
			landUseCode = getPlotLandFilterObject.value.landUseCode.land_uses_code;
		}

		await applicationFormsStore.getPlotLandListFilter(
			{ sectorCode, landUseCode },
			nextKey
		);
	} else {
		await loadPlotsLandListAndMapLandUse();
	}

	setValueForToggleHandlerImportOrManualAdd();

	if (plotsLandList.value.length > 0) {
		await tableDataMappingDescriptionFromCodeForPlotLandAndLandUse();
	} else {
		isDataTableReady.value = true;
	}
}

function setChipFilterDescriptionForChipBeforeTable() {
	isFilterForSectorCodeVisible.value = false;
	isFilterForLandUseCodeVisible.value = false;

	if (sectorCode.value != null && sectorCode.value.sector_code != null) {
		isFilterForSectorCodeVisible.value = true;

		chipFilterDescription.value["sectorDescription"] =
			t(`${moduleId}.ChemicalAndOrganicFertilizer.table.municipality`) +
			` ${sectorCode.value.description}`;
	}

	if (landUseCode.value != null && landUseCode.value.land_uses_code != null) {
		isFilterForLandUseCodeVisible.value = true;

		chipFilterDescription.value["landUseDescription"] =
			t(`${moduleId}.ChemicalAndOrganicFertilizer.table.plantSpecies`) +
			` ${landUseCode.value.description}`;
	}
}

async function loadPlotsLandListAndMapLandUse() {
	await applicationFormsStore.getPlotsLandListAndPreviousManure();

	if (plotsLandList.value.length > 0) {
		toggleHandlerImportOrManualAdd.value =
			plotsLandList.value &&
			plotsLandList.value[0] &&
			plotsLandList.value[0].declCode != null &&
			plotsLandList.value[0].plotCode != null &&
			plotsLandList.value[0].planId != null &&
			plotsLandList.value[0].declarationVersion != null
				? false
				: true;
	}
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

function createMapLandUseListMap() {
	if (applicationFormsStore.landUseListFromCodeResponse) {
		applicationFormsStore.landUseListFromCodeResponse.land_uses_codes_list.map(
			el => {
				landUseListResponseMap.value[el.land_uses_code] = el.description;
			}
		);
	}
}

function createMapCycleListMap() {
	if (applicationFormsStore.getCycleResponse) {
		applicationFormsStore.getCycleResponse.map(el => {
			cycleListResponseMap.value[el.Ciclo_Cod] = el.Ciclo_Des;
		});
	}
}

function createPrecessionListMap() {
	if (applicationFormsStore.getPrecessionResponse) {
		applicationFormsStore.getPrecessionResponse.map(el => {
			if (el && el.code && el.description) {
				precessionListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function createTypologyListMap() {
	if (applicationFormsStore.getTypologyFromCodeResponse) {
		applicationFormsStore.getTypologyFromCodeResponse.map(el => {
			if (el && el.productTypeCode && el.productTypeDescr) {
				typologyListResponseMap.value[el.productTypeCode] = el.productTypeDescr;
			}
		});
	}
}

async function tableDataMappingDescriptionFromCodeForPlotLandAndLandUse() {
	isDataTableReady.value = false;
	await applicationFormsStore.loadLandUseListFromCode(landUseCodeList.value);
	createMapLandUseListMap();

	await applicationFormsStore.loadMunicipalityListFromCode(
		municipalityCodeList.value
	);
	createMapMunicipalityList();

	await applicationFormsStore.getCycle();
	createMapCycleListMap();

	await applicationFormsStore.getTypologyFromLandUseCodeList(
		landUseCodeList.value
	);
	createTypologyListMap();

	await applicationFormsStore.getPrecession();
	createPrecessionListMap();

	initItemListFiltersInEmptyArray();

	plotsLandList.value.map((plotsLandItem: getPlotLandValidationResponse) => {
		if (
			plotsLandItem &&
			plotsLandItem.sectorCode &&
			plotsLandItem.landUseCode &&
			plotsLandItem.areaSqm != null &&
			plotsLandItem.totalNitrogen != null
		) {
			plotsLandItem.sectorDescription =
				municipalityListResponseMap.value[plotsLandItem.sectorCode];

			plotsLandItem.landUseDescription =
				landUseListResponseMap.value[plotsLandItem.landUseCode];

			plotsLandItem.areaSqm = (Number(plotsLandItem.areaSqm) / 10000).toFixed(
				4
			);

			plotsLandItem.totalNitrogen = plotsLandItem.totalNitrogen / 10000;

			plotsLandItem.isSelected =
				toggleHandlerImportOrManualAdd.value == false ? false : null;

			if (plotsLandItem.cycle != null && plotsLandItem.precessionCode != null) {
				plotsLandItem.cycleDescription =
					cycleListResponseMap.value[plotsLandItem.cycle];

				plotsLandItem.precessionCodeDescription =
					precessionListResponseMap.value[plotsLandItem.precessionCode];
			}

			if (plotsLandItem.typology != null) {
				plotsLandItem.typologyDescription =
					typologyListResponseMap.value[plotsLandItem.typology];
			}

			if (!toggleHandlerImportOrManualAdd.value) {
				municipalityList.value.push({
					description: plotsLandItem.sectorDescription,
					sector_code: plotsLandItem.sectorCode,
				});
				landUseList.value.push({
					description: plotsLandItem.landUseDescription,
					land_uses_code: plotsLandItem.landUseCode,
				});
			}
		}
		return plotsLandItem;
	});

	const uniqueArrMunicipalityList: readonly MunicipalityRecordListResponse[] =
		Object.freeze(
			Array.from(
				municipalityList.value
					.reduce((map, obj) => {
						map.set(`${obj?.description}`, obj);
						return map;
					}, new Map<string, MunicipalityRecordListResponse>())
					.values()
			)
		);

	municipalityList.value = uniqueArrMunicipalityList.slice();

	const uniqueArrlandUseList: readonly LandUseRecordListResponse[] =
		Object.freeze(
			Array.from(
				landUseList.value
					.reduce((map, obj) => {
						map.set(`${obj?.description}`, obj);
						return map;
					}, new Map<string, LandUseRecordListResponse>())
					.values()
			)
		);

	landUseList.value = uniqueArrlandUseList.slice();

	isDataTableReady.value = true;
}

function initItemListFiltersInEmptyArray() {
	municipalityList.value = [];
	landUseList.value = [];
}

function routeInAddOrEditPageAndSaveInStoreElementSelected() {
	const idElementsSelectedFilter = plotsLandList.value.filter(
		plotLand => plotLand.isSelected == true
	);

	const idElementsSelected = idElementsSelectedFilter.reduce(
		(acc: number[], el: getPlotLandResponse) => {
			if (el != null && el.ids != null && el.ids[0] != null) {
				acc.push(el.ids[0]);
			}
			return acc;
		},
		[]
	);

	applicationFormsStore.saveDataInStore(
		"ChemicalAndOrganic",
		"editMassive",
		idElementsSelected
	);

	const storeFirstPLotLandForTakeDataInEditFormInEditmassive: getPlotLandResponse =
		plotsLandList.value.filter(
			(el: getPlotLandResponse) => el?.ids?.[0] == idElementsSelected[0]
		)[0];

	applicationFormsStore.saveDataInStore(
		"ChemicalAndOrganic",
		"editElementDetailsPage",
		storeFirstPLotLandForTakeDataInEditFormInEditmassive
	);

	changeRouteToChemicalAndOrganicForm();
}

function routeInAddOrEditPage(element?: getPlotLandResponse) {
	applicationFormsStore.clearDataInStore("ChemicalAndOrganic", "editElement");

	if (element != null) {
		applicationFormsStore.saveDataInStore(
			"ChemicalAndOrganic",
			"editElementDetailsPage",
			element
		);
	}
	changeRouteToChemicalAndOrganicForm();
}

async function deletePlotLand(chemicalAndOrganicFertilizerId: number) {
	await applicationFormsStore.deletePlotLand(chemicalAndOrganicFertilizerId);
	toggleConfirmDeleteModal();
	await getPlotLandListOrPLotLandListFitler();
}

function toggleConfirmImportModal(isOpen: boolean) {
	showAlertInTableIsPresentAlmostOneElementImport.value = isOpen ? true : false;
}

function toggleConfirmHandlerManualAddModal(isOpen: boolean) {
	showAlertInTableIsPresentAlmostOneElementHandlerManualAdd.value = isOpen
		? true
		: false;
}

function changeRouteToChemicalAndOrganicForm() {
	router.push({
		name: "ChemicalAndOrganicFertilizerForm",
		query: {
			...route.query,
		},
	});
}

async function showConfirmImportModalOrImportPlots() {
	if (plotsLandList.value.length > 0) {
		toggleConfirmImportModal(true);
	} else if (plotsLandList.value.length == 0) {
		await deleteAllPlotsLandListAndImportPlotsLandList();
	}
}

async function showConfirmDeletePlotsLandListAndSetToggleManualAdd() {
	initItemListFiltersInEmptyArray();
	if (plotsLandList.value.length > 0) {
		toggleConfirmHandlerManualAddModal(true);
	} else if (plotsLandList.value.length == 0) {
		await deleteAllPlotsLandListAndHandlerManualAdd();
	}
}

async function deleteAllPlotsLandListAndHandlerManualAdd() {
	toggleConfirmHandlerManualAddModal(false);
	await applicationFormsStore.deleteAllPlotsLandList();
	await getPlotLandListOrPLotLandListFitler();
	toggleHandlerImportOrManualAdd.value = true;
}

async function deleteAllPlotsLandListAndImportPlotsLandList() {
	toggleConfirmImportModal(false);
	if (getDeclarationYear.value) {
		await applicationFormsStore.importPlotsLandList(
			getDeclarationYear.value.year
		);
		await getPlotLandListOrPLotLandListFitler();
		toggleHandlerImportOrManualAdd.value = false;
	}
}

function UpdatePLotLandSelectedAndSetFirstLandUseCode(
	plotLand: getPlotLandResponse
) {
	selectedPlotLand(plotLand);
}

function toggleFilterSearch(toggleValue: boolean) {
	showFilterForSearchModal.value = toggleValue;
}

async function resetFilterValueAndClearFilterInStore() {
	toggleFilterSearch(false);

	if (
		sectorCode.value?.sector_code == null &&
		landUseCode.value?.land_uses_code == null
	) {
		return;
	}
	sectorCode.value = null;
	landUseCode.value = null;

	applicationFormsStore.clearDataInStore("ChemicalAndOrganic", "filterObject");
	await plotLandListFilterAndSaveFilterObjectInStore();
}

function onSearchChangeMunicipalityListCode(val: string) {
	municipalityCodeFilter.value = val;
}

const { value: sectorCode } = useField<MunicipalityRecordListResponse>(
	"sectorCode",
	toTypedSchema(MunicipalityRecordListResponseSchema.nullish())
);

const onKeyupMunicipalityCode = debounce(async () => {
	if (toggleHandlerImportOrManualAdd.value) {
		if (municipalityCodeFilter.value.length >= 3) {
			isMunicipalityListLoadingDataFilter.value = true;
			await applicationFormsStore.loadMunicipalityList(
				municipalityCodeFilter.value
			);
			initMunicipalityList();
			isNextMunicipalityValid.value =
				applicationFormsStore.municipalityList?.nextKey;
			isMunicipalityListLoadingDataFilter.value = false;
		} else {
			municipalityList.value = [];
		}
	}
}, 500);

function initMunicipalityList() {
	municipalityList.value =
		municipalityList.value && municipalityListResponse.value
			? municipalityListResponse.value.records
			: [];
}

function onSearchChangeLandUseCode(val: string) {
	landUseCodeFilter.value = val;
}

const onKeyupLandUseCode = debounce(async () => {
	if (toggleHandlerImportOrManualAdd.value) {
		if (landUseCodeFilter.value.length >= 3) {
			isLandUseCodeLoadingDataFilter.value = true;
			await applicationFormsStore.loadLandUseList(landUseCodeFilter.value);
			initLandUseList();
			isNextLandUseValid.value = applicationFormsStore.landUseList?.nextKey;
			isLandUseCodeLoadingDataFilter.value = false;
		} else {
			landUseList.value = [];
		}
	}
}, 500);

function initLandUseList() {
	landUseList.value =
		landUseListResponse.value && landUseList && landUseList.value
			? landUseListResponse.value.records
			: [];
}

function toggleConfirmDeleteModal(element?: getPlotLandResponse) {
	if (element?.ids?.[0] != null) {
		chemicalAndOrganicFertilizerId.value = element.ids[0];
	}

	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading || !isDataTableReady"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div
			v-show="!(applicationFormsStore.getLoading || !isDataTableReady)"
			class="pb-3 pt-3">
			<div class="row my-3 justify-content-start">
				<div class="row d-flex justify-content-between pe-0">
					<div class="col-8">
						<h5 class="fw-bold" :class="getColor('text', 'primary')">
							{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.title`) }}
						</h5>
						<div class="d-flex justify-content-start p-0">
							<div class="form-check form-check-inline">
								<ToggleImportOrManualAdd
									:toggleHandlerImportOrManualAdd="
										toggleHandlerImportOrManualAdd
									"
									:isReadOnly="isReadOnly"
									@showConfirmModalImportAndSetToggleImport="
										showConfirmImportModalOrImportPlots()
									"
									@showConfirmModalDeleteAllAndSetToggleManualAdd="
										showConfirmDeletePlotsLandListAndSetToggleManualAdd()
									"></ToggleImportOrManualAdd>
							</div>
						</div>
					</div>
					<div class="col-4">
						<div class="d-flex justify-content-end">
							<BiTooltip
								:title="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
									)
								"
								:aria-label="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
									)
								">
								<BiButton
									v-if="!isReadOnly && !applicationFormsStore.loading"
									type="submit"
									class="mx-1 mb-2 col-auto"
									:class="`${getColor('button', 'primary', 'outline')}`"
									@click.stop.prevent="toggleFilterSearch(true)">
									<span>
										<BiIcon icon="plus" size="lg" icon-style="regular" />
										{{
											t(
												`${moduleId}.ChemicalAndOrganicFertilizer.button.filters`
											)
										}}
									</span>
								</BiButton>
							</BiTooltip>
						</div>
						<div
							class="d-flex justify-content-end"
							v-if="toggleHandlerImportOrManualAdd == false">
							<BiTooltip
								:title="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.button.editMassive`
									)
								"
								:aria-label="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.button.editMassive`
									)
								">
								<BiButton
									v-if="!isReadOnly && !applicationFormsStore.loading"
									type="submit"
									class="mx-1 mb-2 col-auto"
									:class="`${getColor('button', 'primary', 'outline')}`"
									@click.stop.prevent="
										routeInAddOrEditPageAndSaveInStoreElementSelected()
									"
									:isDisabled="
										!(
											toggleHandlerImportOrManualAdd == false &&
											isTwoElementSelectedForMassiveEdit
										)
									">
									<span>
										<BiIcon
											icon="pencil"
											size="lg"
											icon-style="regular"
											class="me-2" />
										{{
											t(
												`${moduleId}.ChemicalAndOrganicFertilizer.button.editMassive`
											)
										}}
									</span>
								</BiButton>
							</BiTooltip>
						</div>
					</div>
				</div>

				<div
					v-if="
						plotsLandList.length === 0 &&
						toggleHandlerImportOrManualAdd == false
					"
					class="my-5"
					:data-label="
						t(
							`${moduleId}.ChemicalAndOrganicFertilizer.table.errors.CHEMICAL_AND_ORGANIC_NO_BREEDING_NOT_FOUND`
						)
					">
					<BiAlert class="mb-0 d-flex flex-nowrap text-nowrap">
						<template #body>
							<i18n-t
								:keypath="`${moduleId}.ChemicalAndOrganicFertilizer.table.errors.CHEMICAL_AND_ORGANIC_NO_BREEDING_NOT_FOUND`"
								scope="global">
								<template #bold>
									{{
										t(
											`${moduleId}.ChemicalAndOrganicFertilizer.table.errors.CHEMICAL_AND_ORGANIC_NO_BREEDING_NOT_FOUND`
										).toLowerCase()
									}}
								</template>
							</i18n-t>
						</template>
					</BiAlert>
				</div>

				<div class="d-flex justify-content-end">
					<BiButton
						v-if="
							((!isReadOnly && !applicationFormsStore.loading) ||
								(applicationFormsStore.loading && isAddEditModalOpen)) &&
							toggleHandlerImportOrManualAdd == true
						"
						type="submit"
						class="mx-1 mb-2 col-auto"
						:class="`${getColor('button', 'primary', 'outline')}`"
						@click.stop="routeInAddOrEditPage()">
						{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.button.add`) }}
					</BiButton>
				</div>
				<div>
					<BiChip
						v-model="isFilterForSectorCodeVisible"
						:label="chipFilterDescription.sectorDescription" />
					<BiChip
						v-model="isFilterForLandUseCodeVisible"
						:label="chipFilterDescription.landUseDescription" />
				</div>
				<BiTable
					class="table-responsive"
					extraTableClasses="table-head-bg"
					isResponsive>
					<template v-slot:head>
						<tr
							class="bg-light text-start"
							:class="getColor('text', 'secondary')">
							<th
								scope="col"
								v-if="
									toggleHandlerImportOrManualAdd == false &&
									plotsLandList?.[0]?.isSelected != null
								">
								<div>
									<BiCheckbox
										:name="`selectAllWithSameLandUseCode`"
										:id="`selectAllWithSameLandUseCodes`"
										class="mb-4"
										:isDisabled="
											takeLandUseCodeFromFirstCheckBoxSelected == null
										"
										:title="
											t(
												`${moduleId}.ChemicalAndOrganicFertilizer.page.selectAllPlotLandWithSameLandUseCode`
											)
										"
										:alt="
											t(
												`${moduleId}.ChemicalAndOrganicFertilizer.page.selectAllPlotLandWithSameLandUseCode`
											)
										"
										v-model="isSelectAllWithSameLandUseCode"
										@change="
											selectAllPlotLandWithSameLandUseCodeOrDeselectAll()
										" />
								</div>
							</th>
							<th scope="col">
								{{
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.table.municipality`
									)
								}}
							</th>
							<th scope="col">
								{{
									t(`${moduleId}.ChemicalAndOrganicFertilizer.table.plotLand`)
								}}
							</th>
							<th scope="col">
								{{
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.table.plantSpecies`
									)
								}}
							</th>
							<th scope="col">
								{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.zvn`) }}
							</th>
							<th scope="col">
								{{
									t(`${moduleId}.ChemicalAndOrganicFertilizer.table.surface`)
								}}
							</th>
							<th scope="col">
								{{
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.table.nitrogenDistributable`
									)
								}}
							</th>
							<th scope="col">
								{{
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.table.totalNitrogen`
									)
								}}
							</th>
							<th scope="col"></th>
						</tr>
					</template>

					<template
						v-slot:body
						v-if="
							plotsLandList && plotsLandList.length > 0 && isDataTableReady
						">
						<TableRow
							@routeInAddOrEditPage="routeInAddOrEditPage"
							@deletePlotLand="toggleConfirmDeleteModal"
							@selectedPlotLand="selectedPlotLand"
							v-for="plotLand in plotsLandList"
							:key="plotLand?.ids?.[0]"
							v-model="plotLand.isSelected"
							@update:model-value="
								UpdatePLotLandSelectedAndSetFirstLandUseCode(plotLand)
							"
							:firstLandUseCode="takeLandUseCodeFromFirstCheckBoxSelected"
							:plotLand="plotLand"
							:toggleHandlerImportOrManualAdd="toggleHandlerImportOrManualAdd"
							:is-read-only="isReadOnly" />
					</template>
					<template v-slot:body v-else>
						<tr>
							<td colspan="3" class="text-start">
								{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.noData`) }}
							</td>
						</tr>
					</template>
				</BiTable>
			</div>
		</div>
	</div>

	<!-- confirm delete tableData and import plotsLandList -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showAlertInTableIsPresentAlmostOneElementImport"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.import.title`)
		"
		:title="t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.import.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{
							t(
								`${moduleId}.ChemicalAndOrganicFertilizer.modal.import.importAndDeleteAllDataInTable`
							)
						}}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmImportModal(false);
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.prevent.stop="deleteAllPlotsLandListAndImportPlotsLandList()">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- confirm delete tableData and handler manual add plotsLandList -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showAlertInTableIsPresentAlmostOneElementHandlerManualAdd"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.import.title`)
		"
		:title="t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.import.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{
							t(
								`${moduleId}.ChemicalAndOrganicFertilizer.modal.deleteAllDataInTableAndContinueWithHandlerManualAdd.title`
							)
						}}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmHandlerManualAddModal(false);
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteAllPlotsLandListAndHandlerManualAdd()">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.delete.title`)
		"
		:title="t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{
							t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.delete.body`)
						}}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop.prevent="
						() => {
							toggleConfirmDeleteModal();
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop.prevent="deletePlotLand(chemicalAndOrganicFertilizerId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- filter for search modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showFilterForSearchModal"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:title="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="filterChemicalAndOrganicFertilizer"
				class="needs-validation"
				@submit.stop.prevent="plotLandListFilterAndSaveFilterObjectInStore()">
				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="municipalityCodeId"
							:id="'municipalityCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
							:items="municipalityList"
							:isAutocomplete="true"
							:loading="isMunicipalityListLoadingDataFilter"
							:showNoResults="!isMunicipalityListLoadingDataFilter"
							v-model="sectorCode"
							@searchChange="onSearchChangeMunicipalityListCode"
							@keyup="onKeyupMunicipalityCode"
							:minSearchLenght="minSearchLenghtMunicipality"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${municipalityCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtMunicipality}`
							"
							:itemTitle="'description'"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextMunicipalityValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							name="landUseCodeId"
							:id="'landUseCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.landUseCode`)"
							:items="landUseList"
							:isAutocomplete="true"
							:loading="isLandUseCodeLoadingDataFilter"
							:showNoResults="!isLandUseCodeLoadingDataFilter"
							v-model="landUseCode"
							@searchChange="onSearchChangeLandUseCode"
							@keyup="onKeyupLandUseCode"
							:minSearchLenght="minSearchLenghtLandUse"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${landUseCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtLandUse}`
							"
							:itemTitle="'description'"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextLandUseValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>
			</form>
		</template>
		<template #footer>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
			<div v-else class="mt-3 mb-5 d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop.prevent="resetFilterValueAndClearFilterInStore()">
					{{ t(`${moduleId}.general.delete`) }}
				</BiButton>
				<BiButton
					type="submit"
					form="filterChemicalAndOrganicFertilizer"
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')">
					{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.button.applyFilter`) }}
				</BiButton>
			</div>
		</template>
	</BiModal>
</template>

<style scoped>
ul {
	list-style-type: none;
	padding-left: 0;
}

.change-color {
	background-color: #f6f8fa;
}

.title {
	font-weight: bold;
	font-size: 1.111em;
}

.toggles.bring-toggle-in-middle label input[type="checkbox"] + .lever:before,
.toggles.bring-toggle-in-middle label input[type="checkbox"] + .lever:after {
	left: 10px;
}

div.toggles label input[type="checkbox"] + .lever:before,
div.toggles label input[type="checkbox"] + .lever:after {
	background-image: none;
	background-color: hsl(142, 100%, 12.5%);
}

@media (max-width: 1200px) {
	div.form-check.form-check-inline {
		margin-right: 0.1rem !important;
	}
}
</style>
