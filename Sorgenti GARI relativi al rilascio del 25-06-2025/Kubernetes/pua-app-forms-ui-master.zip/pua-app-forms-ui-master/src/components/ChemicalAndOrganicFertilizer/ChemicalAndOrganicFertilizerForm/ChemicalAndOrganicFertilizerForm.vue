<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components

import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";

import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// other
import type { IListMap } from "@/components/ChemicalFertilizer/ChemicalFertilizer.vue";
import {
	EffluentResponseSchema,
	LandUseRecordListResponseSchema,
	MunicipalityRecordListResponseSchema,
	type editPlotLandRequestResponse,
	type EffluentResponse,
	type getCycleResponse,
	type getPlotLandResponse,
	type getPlotLandValidationResponse,
	type getPrecessionResponse,
	type getPreviousManureResponse,
	type getPreviousManureValidationResponse,
	type getTypologyResponse,
	type LandUseRecordListResponse,
	type MunicipalityRecordListResponse,
	type savePlotLandRequestResponse,
	type savePreviousManureResponse,
} from "@/models/applicationForms";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { debounce } from "lodash";
import { useField, useForm } from "vee-validate";
import { useRoute, useRouter } from "vue-router";
import { z } from "zod";

const applicationFormsStore = useApplicationFormsStore();
const route = useRoute();
const router = useRouter();
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const trRef = ref(null);
const numberTotalTd = ref<number>(0);

const queryFieldsStore = useQueryFieldsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const previousManureId = ref<number>(0);

const isEditMode = ref<boolean>(false);
const modalKey = ref<number>(0);

const minCharFilterEffluent = ref<number>(0);
const effluentListResponseMap = ref<IListMap>({});
const frequencyListResponseMap = ref<IListMap>({});
const isDataTableReady = ref<boolean>(false);
const isSetValueFn = ref<boolean>(false);
const isMasDisabled = ref<boolean>(false);

const effluentList = ref<EffluentResponse[]>([]);
const effluentFilter = ref<string>("");
const isEffluentListLoadingDataFilter = ref<boolean>(false);
const effluentListResponse = computed(
	() => applicationFormsStore.getEffuentListResponse
);

const flZvn = ref<boolean>(false);

const areaSqmRef = ref();
const areaSqmId = "areaSqmId";
let areaSqmOldValue: string | undefined;

function validateNumberOrNumberWithFourDecimalAreaSqm() {
	if (areaSqm.value != null) {
		areaSqmOldValue = areaSqm.value.toString();
	}
	const result = applicationFormsStore.validateNumberOrNumberWithFourDecimal(
		areaSqmId,
		areaSqm,
		areaSqmOldValue
	);

	if (result == false) {
		return false;
	} else {
		areaSqmOldValue = result;
	}
}

const frequencySelected = computed(
	() =>
		applicationFormsStore.getFrequencyFromEffluentCodeResponse.filter(
			el => el?.code == frequency.value
		)[0]
);

const totalNitrogenCalculated = computed(() => {
	const previousManureListFn: getPreviousManureResponse[] =
		plotLand.value?.ids?.[0] != null && idEditMassive.value == null
			? plotLand.value?.previousEffluents
			: previousManureListFromPLotLandManual.value;

	return previousManureListFn
		.reduce((acc: number, el) => {
			if (el != null && el.residualNitrogen != null) {
				acc = acc + el.residualNitrogen;
			}
			return acc;
		}, 0)
		.toFixed(4);
});

const frequencyList = computed(() => {
	const frequencyList = ref<ISelectOptions[]>([]);
	applicationFormsStore.getFrequencyFromEffluentCodeResponse.reduce(
		(acc: ISelectOptions[], el) => {
			if (el && el.code && el.description) {
				const frequencyItemFormatted: ISelectOptions = {
					id: el.code,
					text: el.description,
				};
				acc.push(frequencyItemFormatted);
			}
			return acc;
		},
		frequencyList.value
	);

	return frequencyList.value;
});

const plotLand = computed(() => {
	let plotLandFn = {} as getPlotLandResponse;
	if (
		plotLandFn != null &&
		applicationFormsStore.saveInStore?.ChemicalAndOrganic
			?.editElementDetailsPage != null
	) {
		plotLandFn =
			applicationFormsStore.saveInStore?.ChemicalAndOrganic
				?.editElementDetailsPage;

		if (applicationFormsStore.getPlotLandResponse?.previousEffluents != null) {
			plotLandFn.previousEffluents =
				applicationFormsStore.getPlotLandResponse?.previousEffluents;
		}
	}

	return plotLandFn;
});

const idEditMassive = computed(
	() => applicationFormsStore.saveInStore?.ChemicalAndOrganic?.editMassive
);

const editMassivePlotLandResponse = computed(
	() => applicationFormsStore.editMassivePlotLandResponse
);

const editPlotLandResponse = computed(
	() => applicationFormsStore.editPlotLandResponse
);

const savePlotLandResponse = computed(
	() => applicationFormsStore.savePlotLandResponse
);

const plotLandLandUseCode = computed(() => plotLand.value?.landUseCode);
const getMasFromLandUseCodeResponse = computed(
	() => applicationFormsStore.getMasFromLandUseCodeResponse[0].nitrogenQt
);

const isFabbisgnoButtonDisabledIfMissingRequiredFields = computed(() => {
	let isFabbisgnoRequiredFieldsReadyFn = true;
	if (
		((plotLand.value && plotLand.value.landUseCode != null) ||
			landUseCode.value) &&
		(typology.value != null ||
			(typology.value == null && isTypologyDisabled.value)) &&
		yieldField.value != null &&
		precessionCode.value != null
	) {
		isFabbisgnoRequiredFieldsReadyFn = false;
	}
	return isFabbisgnoRequiredFieldsReadyFn;
});

export interface ISelectOptions {
	id: string;
	text: string;
}

const precessionCodeList = computed(() => {
	const precessionCodeListFormatted = ref<ISelectOptions[]>([]);
	applicationFormsStore.getPrecessionResponse?.map(
		(el: getPrecessionResponse) => {
			if (el && el.code && el.description) {
				precessionCodeListFormatted.value.push({
					id: el.code,
					text: el.description,
				});
			}
		}
	);

	return precessionCodeListFormatted.value;
});

const typologyList = computed(() => {
	const tipologyListFormatted = ref<ISelectOptions[]>([]);
	applicationFormsStore.getTypologyResponse
		?.reduce((acc: getTypologyResponse[], el: getTypologyResponse) => {
			if (
				el &&
				el.productTypeCode &&
				!acc.some(elAcc => elAcc.productTypeDescr === el.productTypeDescr)
			) {
				acc.push(el);
			}
			return acc;
		}, [])
		.map((el: getTypologyResponse) => {
			if (el && el.productTypeCode != null && el.productTypeDescr) {
				tipologyListFormatted.value.push({
					id: el.productTypeCode,
					text: el.productTypeDescr,
				});
			}
		});

	return tipologyListFormatted.value;
});

const cycleList = computed(() => {
	const cycleListFormatted = ref<ISelectOptions[]>([]);
	applicationFormsStore.getCycleResponse?.map((el: getCycleResponse) => {
		if (el && el.Ciclo_Cod != null && el.Ciclo_Des) {
			cycleListFormatted.value.push({
				id: String(el.Ciclo_Cod),
				text: el.Ciclo_Des,
			});
		}
	});

	return cycleListFormatted.value;
});

const previousManureListFromPLotLandManual = ref<getPreviousManureResponse[]>(
	[]
);

const indexPreviousManureListFromPLotLandManual = ref<number | null>(null);

const previousManureListResponse = computed(() => {
	if (plotLand.value?.ids?.[0] && idEditMassive.value == null) {
		return plotLand.value.previousEffluents;
	} else {
		return previousManureListFromPLotLandManual.value;
	}
});

const frequencyCodeList = computed(() => {
	let frequencyCodeListFn: string[] = [];
	if (plotLand.value != null && plotLand.value?.previousEffluents?.length > 0) {
		frequencyCodeListFn = plotLand.value.previousEffluents.reduce(
			(acc: string[], el) => {
				if (el && el.effluent && !acc.includes(el.effluent)) {
					acc.push(el.effluent);
				}
				return acc;
			},
			[]
		);
	} else if (previousManureListResponse.value?.length > 0) {
		frequencyCodeListFn = previousManureListResponse.value.reduce(
			(acc: string[], el) => {
				if (el && el.effluent && !acc.includes(el.effluent)) {
					acc.push(el.effluent);
				}
				return acc;
			},
			[]
		);
	}

	return frequencyCodeListFn;
});

const landUseList = ref<LandUseRecordListResponse[]>([]);
const landUseCodeFilter = ref<string>("");
const isLandUseCodeLoadingDataFilter = ref<boolean>(false);
const landUseListResponse = computed(() => applicationFormsStore.landUseList);
const isNextLandUseValid = ref<string | null | undefined>(null);
const minCharFilterLandUse = ref<number>(3);

const municipalityList = ref<MunicipalityRecordListResponse[]>([]);
const municipalityCodeFilter = ref<string>("");
const isMunicipalityListLoadingDataFilter = ref<boolean>(false);
const minSearchLenghtMunicipality = ref<number>(3);

const municipalityListResponse = computed(
	() => applicationFormsStore.municipalityList
);
const isNextMunicipalityValid = ref<string | null | undefined>(null);

const isDataPresentInBackEndPlotLand = ref<boolean>(false);

async function onChangeEffluentGetFrequency() {
	if (effluent.value && effluent.value.code) {
		await applicationFormsStore.getFrequencyFromEffluentCode(
			effluent.value.code
		);
	}

	if (
		effluent.value != null &&
		effluent.value.descriptionUom != null &&
		effluent.value.nitrogen != null
	) {
		measurementUnit.value = effluent.value.descriptionUom;
		nitrogenContent.value = effluent.value.nitrogen;
	}

	onChangeQuantityCalculateResidualNitrogen();
}

function onChangeFrequencyUpdateReductionAndNitrogenResiduo() {
	reduction.value = frequencySelected.value.nitrogen;
	onChangeQuantityCalculateResidualNitrogen();
}

function onChangeQuantityCalculateResidualNitrogen() {
	if (
		frequency.value &&
		frequencySelected.value.nitrogen != null &&
		quantity.value != null &&
		+quantity.value != 0 &&
		nitrogenContent.value != null &&
		reduction.value != null
	) {
		residualNitrogen.value = (
			quantity.value *
			nitrogenContent.value *
			reduction.value
		).toFixed(4);
	} else {
		residualNitrogen.value = null;
	}
}

onMounted(async () => {
	queryFieldsStore.populateState();
	await initOrFilterEffluentCodeList();

	await applicationFormsStore.getCycle();
	await applicationFormsStore.getPrecession();
	await getDeclarationStoredInBackEndAndRequestType();

	if (plotLand.value) {
		await tableDataMappingDescriptionFromCodeForEffluentAndPlotDescription();
	}
});

async function getTypologyAndCacolateTypologyStatus() {
	let plotLandLandUseCodeFn = "";
	if (plotLandLandUseCode.value != null) {
		plotLandLandUseCodeFn = plotLandLandUseCode.value;
	} else if (plotLand.value && plotLand.value.landUseCode != null) {
		plotLandLandUseCodeFn = plotLand.value.landUseCode;
	}

	if (plotLandLandUseCodeFn.length > 0) {
		await applicationFormsStore.getTipology(plotLandLandUseCodeFn);
	}
	calcolateTypologyStatus();
}

function calcolateTypologyStatus() {
	isTypologyDisabled.value =
		applicationFormsStore.getTypologyResponse.length == 0 ? true : false;
	typology.value = null;
}

function createMapEffluentList() {
	if (applicationFormsStore.getEffuentListResponse) {
		applicationFormsStore.getEffuentListResponse.map(el => {
			if (el && el.code && el.description) {
				effluentListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function createMapFrequencyList() {
	if (applicationFormsStore.getFrequencyFromEffluentCodeListResponse) {
		applicationFormsStore.getFrequencyFromEffluentCodeListResponse.map(el => {
			if (el && el.code && el.description) {
				frequencyListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function onEffluentListCodeSearchChange(val: string) {
	effluentFilter.value = val;
}

const effluentCodeChange = debounce(async () => {
	await initOrFilterEffluentCodeList();
}, 500);

async function initOrFilterEffluentCodeList() {
	effluentList.value = [];
	isEffluentListLoadingDataFilter.value = true;
	const isFilterForFrequency = true;
	await applicationFormsStore.loadEffulentList(isFilterForFrequency);
	initOrUpdateEffulentList();

	isEffluentListLoadingDataFilter.value = false;
}

function initOrUpdateEffulentList() {
	if (effluentListResponse.value) {
		effluentList.value = effluentListResponse.value;
	}
}

function setValueInForm() {
	isSetValueFn.value = true;

	if (
		plotLand.value &&
		plotLand.value.cycle != null &&
		plotLand.value.typology !== undefined &&
		plotLand.value.precessionCode != null &&
		plotLand.value.yield != null
	) {
		isTypologyDisabled.value = plotLand.value.typology == null ? true : false;

		cycle.value = plotLand.value.cycle;
		typology.value = plotLand.value.typology;
		precessionCode.value = String(plotLand.value.precessionCode);
		yieldField.value = plotLand.value.yield.toFixed(4);
	}

	isSetValueFn.value = false;
}

async function getDeclarationStoredInBackEndAndRequestType() {
	await getTypologyAndCacolateTypologyStatus();

	if (plotLand.value?.ids?.[0] != null) {
		isDataPresentInBackEndPlotLand.value = true;

		if (idEditMassive.value == null) {
			await loadChemicalAndOrganicAndPreviousManure();
			setValueInForm();
		}
	}
}

async function tableDataMappingDescriptionFromCodeForEffluentAndPlotDescription() {
	isDataTableReady.value = false;

	if (frequencyCodeList.value != null) {
		await applicationFormsStore.getFrequencyFromEffluentCodeList(
			frequencyCodeList.value
		);
		createMapFrequencyList();
	}

	createMapEffluentList();

	if (previousManureListResponse.value) {
		previousManureListResponse.value.map(
			(previousManureItem: getPreviousManureResponse, index: number) => {
				if (
					previousManureItem &&
					previousManureItem.effluent &&
					previousManureListResponse.value &&
					previousManureItem.frequency
				) {
					previousManureItem.effluentDescription =
						effluentListResponseMap.value[previousManureItem.effluent];

					previousManureItem.frequencyDescription =
						frequencyListResponseMap.value[previousManureItem.frequency];

					previousManureListResponse.value[index] = previousManureItem;
				}
				return previousManureListResponse;
			}
		);
	}
	isDataTableReady.value = true;
}

function goInChemicalAndOrganicFertilizerAndClearDataInStore() {
	resetDataInStore();
	router.push({
		name: "ChemicalAndOrganicFertilizer",
		query: {
			...route.query,
		},
	});
}

async function cancelTab() {
	goInChemicalAndOrganicFertilizerAndClearDataInStore();
}

async function cancelTabPreviousManure() {
	toggleAddEditModal(false);
	resetFormPreviousManure();
}

async function checkIfTabCompletedAndSaveOrEditChemicalAndOrganicFormAndGoInTableParentComponent() {
	let saveData: editPlotLandRequestResponse | savePlotLandRequestResponse;

	const isEditFieldOk: boolean =
		cycle.value != null &&
		(typology.value != null ||
			(typology.value == null && isTypologyDisabled.value)) &&
		precessionCode.value != null &&
		yieldField.value != null;

	if (
		(typeof cycle.value == "string" || typeof cycle.value == "number") &&
		yieldField.value != null &&
		typeof precessionCode.value == "string" &&
		((plotLand.value?.ids?.[0] && isEditFieldOk) ||
			(!plotLand.value?.ids?.[0] &&
				isEditFieldOk &&
				sectorCode.value &&
				areaSqm.value &&
				landUseCode.value &&
				cropDuration.value &&
				(mas.value || (!mas.value && isMasDisabled.value))))
	) {
		saveData = {
			ids:
				idEditMassive.value != null
					? idEditMassive.value
					: [plotLand.value?.ids?.[0]],
			cycle: +cycle.value,
			typology: typology.value,
			precessionCode: +precessionCode.value,
			yield: +yieldField.value,
		} as editPlotLandRequestResponse;

		if (
			!isDataPresentInBackEndPlotLand.value &&
			landUseCode.value &&
			sectorCode.value &&
			areaSqm.value != null &&
			!plotLand.value?.ids?.[0]
		) {
			saveData = {
				sectorCode: sectorCode.value.sector_code,
				landUseCode: landUseCode.value.land_uses_code,
				flZvn: flZvn.value,
				areaSqm: +String(areaSqm.value).replaceAll(",", ".") * 10000,
				cropDuration: String(cropDuration.value),
				mas: mas.value,
				...saveData,
			} as savePlotLandRequestResponse;
		}

		await SaveOrEditPlotLandAndGoInChemicalAndOrganicFertilizer(saveData);
	}
}

async function SaveOrEditPlotLandAndGoInChemicalAndOrganicFertilizer(
	saveData: editPlotLandRequestResponse | savePlotLandRequestResponse
) {
	applicationFormsStore.clearPLotLandResponseForChemicalAndOrganicFertilizerForm();

	if (
		saveData &&
		isDataPresentInBackEndPlotLand.value &&
		idEditMassive.value != null &&
		isEditPlotLandOrSavePlotLandTypeSafe(saveData)
	) {
		saveData = {
			previousEffluents: previousManureListFromPLotLandManual.value,
			...saveData,
		} as editPlotLandRequestResponse;

		await applicationFormsStore.editMassivePlotLand(saveData);
	} else if (
		saveData &&
		isDataPresentInBackEndPlotLand.value &&
		plotLand.value?.ids?.[0] &&
		isEditPlotLandOrSavePlotLandTypeSafe(saveData)
	) {
		await applicationFormsStore.editPlotLand(saveData.ids[0], saveData);
	} else if (
		saveData &&
		!isDataPresentInBackEndPlotLand.value &&
		!isEditPlotLandOrSavePlotLandTypeSafe(saveData) &&
		!plotLand.value?.ids?.[0]
	) {
		saveData = {
			previousEffluents: previousManureListFromPLotLandManual.value,
			...saveData,
		} as savePlotLandRequestResponse;
		await applicationFormsStore.savePlotLand(saveData);
	}
}

function isEditPlotLandOrSavePlotLandTypeSafe(
	plotLand: editPlotLandRequestResponse | savePlotLandRequestResponse
): plotLand is editPlotLandRequestResponse {
	return (plotLand as editPlotLandRequestResponse).ids[0] != null;
}
async function checkIfTabCompletedAndSaveOrEditPreviousManureForm() {
	if (
		nitrogenContent.value != null &&
		measurementUnit.value != null &&
		quantity.value &&
		frequency.value != null &&
		reduction.value != null &&
		residualNitrogen.value != null &&
		effluent.value != null &&
		effluent.value.code != null
	) {
		const saveData: savePreviousManureResponse = {
			id: null,
			parentId: null,
			nitrogenContent: nitrogenContent.value,
			effluent: effluent.value.code,
			measurementUnit: measurementUnit.value,
			quantity: quantity.value,
			frequency: frequency.value,
			reduction: reduction.value,
			residualNitrogen: +residualNitrogen.value,
		};

		await SaveOrEditPreviousManureAndToggleModal(saveData);

		resetFormPreviousManure();
	}
}

function resetFormPreviousManure() {
	effluent.value =
		nitrogenContent.value =
		measurementUnit.value =
		quantity.value =
		frequency.value =
		reduction.value =
		residualNitrogen.value =
			null;
}

async function SaveOrEditPreviousManureAndToggleModal(
	saveData: savePreviousManureResponse
) {
	if (!plotLand.value?.ids?.[0] || idEditMassive.value != null) {
		if (indexPreviousManureListFromPLotLandManual.value != null) {
			previousManureListFromPLotLandManual.value[
				indexPreviousManureListFromPLotLandManual.value
			] = saveData;
			indexPreviousManureListFromPLotLandManual.value = null;
		} else {
			previousManureListFromPLotLandManual.value.push(saveData);
		}
	} else if (plotLand.value?.ids?.[0]) {
		saveData.parentId = plotLand.value.ids[0];
		if (saveData && isEditMode.value) {
			saveData.id = previousManureId.value;
			await applicationFormsStore.editPreviousManure(saveData);
		} else {
			await applicationFormsStore.savePreviousManure(saveData);
		}

		await loadChemicalAndOrganicAndPreviousManure();
	}
	await tableDataMappingDescriptionFromCodeForEffluentAndPlotDescription();
}

const {
	handleSubmit: handleSubmitPlotLand,
	setErrors: setErrorsPlotLand,
	isSubmitting: isSubmittingPlotLand,
	errors: errorsPlotLand,
} = useForm<getPlotLandValidationResponse>({
	initialValues: {
		sectorCode: null,
		areaSqm: null,
		landUseCode: null,
		cropDuration: null,
		mas: null,
		distributableNitrogen: null,
		cycle: null,
		typology: null,
		precessionCode: null,
		yield: null,
	},
});

const { value: cycle } = useField<number | null>(
	"cycle",
	toTypedSchema(z.number().or(z.string()).nullish())
);
const { value: typology } = useField<string | null>(
	"typology",
	toTypedSchema(z.string().nullish())
);
const { value: precessionCode } = useField<string | null>(
	"precessionCode",
	toTypedSchema(z.string().nullish())
);
const { value: yieldField } = useField<string | number | null>(
	"yield",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: sectorCode } = useField<MunicipalityRecordListResponse>(
	"sectorCode",
	toTypedSchema(MunicipalityRecordListResponseSchema.nullish())
);

const { value: areaSqm } = useField<string | number | null>(
	"areaSqm",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: landUseCode } = useField<LandUseRecordListResponse>(
	"landUseCode",
	toTypedSchema(LandUseRecordListResponseSchema.nullish())
);

const { value: cropDuration } = useField<number | null>(
	"cropDuration",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: mas } = useField<number | null>(
	"mas",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: distributableNum } = useField<string | number | null>(
	"distributableNum",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const validateForm = (plotLand: getPlotLandValidationResponse) => {
	if (plotLand.cycle == null) {
		setErrorsPlotLand({
			cycle: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!plotLand.typology && !isTypologyDisabled.value) {
		setErrorsPlotLand({
			typology: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (plotLand.precessionCode == null) {
		setErrorsPlotLand({
			precessionCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (plotLand.yield == null) {
		setErrorsPlotLand({
			yield: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!plotLand.ids?.[0]) {
		if (!plotLand.sectorCode) {
			setErrorsPlotLand({
				sectorCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}

		if (!plotLand.areaSqm) {
			setErrorsPlotLand({
				areaSqm: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}

		if (!plotLand.landUseCode) {
			setErrorsPlotLand({
				landUseCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}

		if (!plotLand.cropDuration) {
			setErrorsPlotLand({
				cropDuration: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}

		if (!plotLand.mas && !isMasDisabled.value) {
			setErrorsPlotLand({
				mas: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}
	}
};

const onSubmitPlotLand = handleSubmitPlotLand.withControlled(async values => {
	validateForm(values);

	const isEditFieldOk: boolean =
		!errorsPlotLand.value.cycle != null &&
		!errorsPlotLand.value.typology &&
		!errorsPlotLand.value.precessionCode &&
		!errorsPlotLand.value.yield;

	applicationFormsStore.resetScrollToTop(window);

	if (
		(plotLand.value?.ids?.[0] && isEditFieldOk) ||
		(!plotLand.value?.ids?.[0] &&
			isEditFieldOk &&
			!errorsPlotLand.value.sectorCode &&
			!errorsPlotLand.value.areaSqm &&
			!errorsPlotLand.value.landUseCode &&
			!errorsPlotLand.value.cropDuration &&
			!errorsPlotLand.value.mas)
	) {
		await checkIfTabCompletedAndSaveOrEditChemicalAndOrganicFormAndGoInTableParentComponent();

		if (
			editMassivePlotLandResponse.value?.[0]?.ids?.[0] != null ||
			editPlotLandResponse.value?.ids?.[0] != null ||
			savePlotLandResponse.value?.ids?.[0] != null
		) {
			goInChemicalAndOrganicFertilizerAndClearDataInStore();
		}
	}
});

function resetDataInStore() {
	applicationFormsStore.clearDataInStore("ChemicalAndOrganic", "editMassive");
	applicationFormsStore.clearDataInStore(
		"ChemicalAndOrganic",
		"editElementDetailsPage"
	);
}

const {
	handleSubmit: handleSubmitPreviousManure,
	setErrors: setErrorsPreviousManure,
	isSubmitting: isSubmittingPreviousManure,
	errors: errorsPreviousManure,
} = useForm<getPreviousManureValidationResponse>({
	initialValues: {
		effluent: null,
		measurementUnit: null,
		quantity: null,
		nitrogenContent: null,
		frequency: null,
		reduction: null,
		residualNitrogen: null,
	},
});

watch(
	() => applicationFormsStore.getDistributedNeedsResponse,
	() => {
		if (
			applicationFormsStore.getDistributedNeedsResponse?.ListaFabbisogni?.[0]
				.N_Fabbisogno != null
		) {
			distributableNum.value =
				applicationFormsStore.getDistributedNeedsResponse.ListaFabbisogni[0].N_Fabbisogno.toFixed(
					4
				);
		}
	}
);

watch(
	() => [yieldField.value, precessionCode.value, typology.value, cycle.value],
	() => {
		if (!isSetValueFn.value) {
			distributableNum.value = null;
		}
	}
);

watch(trRef, async () => {
	if (trRef.value) {
		numberTotalTd.value = (trRef.value[0] as HTMLElement).children.length - 1;
	}
});

const { value: effluent } = useField<EffluentResponse | null>(
	"effluent",
	toTypedSchema(EffluentResponseSchema.nullish())
);

const { value: measurementUnit } = useField<string | null>(
	"measurementUnit",
	toTypedSchema(z.string().nullish())
);

const { value: quantity } = useField<number | null>(
	"quantity",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: nitrogenContent } = useField<number | null>(
	"nitrogenContent",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: frequency } = useField<string | null>(
	"frequency",
	toTypedSchema(z.string().nullish())
);

const { value: reduction } = useField<number | null>(
	"reduction",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: residualNitrogen } = useField<string | null>(
	"residualNitrogen",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const validateFormTable = (previousManure: getPreviousManureResponse) => {
	if (previousManure?.effluent == null) {
		setErrorsPreviousManure({
			effluent: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (previousManure?.measurementUnit == null) {
		setErrorsPreviousManure({
			measurementUnit: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!previousManure?.quantity) {
		setErrorsPreviousManure({
			quantity: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (previousManure?.nitrogenContent == null) {
		setErrorsPreviousManure({
			nitrogenContent: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (previousManure?.frequency == null) {
		setErrorsPreviousManure({
			frequency: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (previousManure?.reduction == null) {
		setErrorsPreviousManure({
			reduction: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (previousManure?.residualNitrogen == null) {
		setErrorsPreviousManure({
			residualNitrogen: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
};

const onSubmitPreviousManure = handleSubmitPreviousManure.withControlled(
	async values => {
		validateFormTable(values);

		if (
			!errorsPreviousManure.value.effluent &&
			!errorsPreviousManure.value.measurementUnit &&
			!errorsPreviousManure.value.quantity &&
			!errorsPreviousManure.value.nitrogenContent &&
			!errorsPreviousManure.value.frequency &&
			!errorsPreviousManure.value.reduction &&
			!errorsPreviousManure.value.residualNitrogen
		) {
			await checkIfTabCompletedAndSaveOrEditPreviousManureForm();

			toggleAddEditModal(false);
			resetFormPreviousManure();
		}
	}
);

async function calcolateDistributableneeded() {
	const typologyDefault = 0;
	const totResidualNitrogen = totalNitrogenCalculated.value;
	let landUseCodeFn = "";
	let declCodeFn = "0";
	if (
		(typology.value != null ||
			(typology.value == null && isTypologyDisabled.value)) &&
		yieldField.value != null &&
		precessionCode.value != null
	) {
		if (landUseCode.value) {
			landUseCodeFn = landUseCode.value.land_uses_code;
		} else if (plotLand.value) {
			if (plotLand.value.landUseCode) {
				landUseCodeFn = plotLand.value.landUseCode;
			}
			if (plotLand.value.declCode != null) {
				declCodeFn = plotLand.value.declCode;
			}
		}

		await applicationFormsStore.getDistributedNeeds(
			landUseCodeFn,
			declCodeFn,
			typology.value != null ? +typology.value : typologyDefault,
			+yieldField.value,
			+precessionCode.value,
			totResidualNitrogen
		);
	}
}

function toggleAddEditModal(isEdit?: boolean) {
	isEdit ? (isEditMode.value = true) : (isEditMode.value = false);
	isAddEditModalOpen.value = !isAddEditModalOpen.value;
	!isAddEditModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function editPreviousManure(element: getPreviousManureResponse, index: number) {
	toggleAddEditModal(true);

	effluent.value = {} as EffluentResponse;
	if (
		effluent.value != null &&
		element != null &&
		element.effluent != null &&
		element.measurementUnit != null &&
		element.quantity &&
		element.nitrogenContent != null &&
		element.frequency != null &&
		element.reduction != null &&
		element.residualNitrogen != null
	) {
		if (index != null) {
			indexPreviousManureListFromPLotLandManual.value = index;
		}

		if (element.id) {
			previousManureId.value = element.id;
		}

		effluent.value.code = element.effluent;
		effluent.value.description =
			effluentListResponseMap.value[element.effluent];
		measurementUnit.value = element.measurementUnit;
		quantity.value = element.quantity;
		nitrogenContent.value = element.nitrogenContent;
		onChangeEffluentGetFrequency();
		frequency.value = element.frequency;
		reduction.value = element.reduction;
		residualNitrogen.value = element.residualNitrogen.toFixed(4);
	}
}

function toggleConfirmDeleteModal(
	element?: getPreviousManureResponse,
	index?: number
) {
	if (element && element.id) {
		previousManureId.value = element.id;
	}

	if (index != null) {
		indexPreviousManureListFromPLotLandManual.value = index;
	}

	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function deletePreviousManure(previousManureId: number) {
	if (
		(!plotLand.value?.ids?.[0] &&
			indexPreviousManureListFromPLotLandManual.value != null) ||
		idEditMassive.value != null
	) {
		previousManureListFromPLotLandManual.value =
			previousManureListFromPLotLandManual.value.filter(
				(_, index) => index != indexPreviousManureListFromPLotLandManual.value
			);
		indexPreviousManureListFromPLotLandManual.value = null;
	} else {
		await applicationFormsStore.deletePreviousManure(previousManureId);
	}
	toggleConfirmDeleteModal();
	await loadChemicalAndOrganicAndPreviousManure();
	await tableDataMappingDescriptionFromCodeForEffluentAndPlotDescription();
}

async function loadChemicalAndOrganicAndPreviousManure() {
	if (plotLand.value?.ids?.[0]) {
		await applicationFormsStore.getPlotLand(plotLand.value?.ids?.[0]);
	}
}

function onTypologyChange() {
	const yieldFilter = applicationFormsStore.getTypologyResponse.filter(
		el => el.productTypeCode === typology.value
	);

	if (yieldFilter && yieldFilter[0] && yieldFilter[0].yield != null) {
		yieldField.value = yieldFilter[0].yield.toFixed(4);
	} else {
		yieldField.value = 0;
	}
}

function onSearchChangeLandUseCode(val: string) {
	landUseCodeFilter.value = val;
}
const isTypologyDisabled = ref<boolean>(false);
async function onCloseLandUseCode() {
	if (landUseCode.value && landUseCode.value.land_uses_code) {
		setMatFromLandUseCodeSelected(landUseCode.value.land_uses_code);
		await applicationFormsStore.getTipology(landUseCode.value.land_uses_code);
		calcolateTypologyStatus();
	}
}

async function setMatFromLandUseCodeSelected(landUseCode: string) {
	await applicationFormsStore.getMasFromLandUseCode(landUseCode);

	if (getMasFromLandUseCodeResponse.value != null) {
		mas.value = getMasFromLandUseCodeResponse.value;
		isMasDisabled.value = false;
	} else if (getMasFromLandUseCodeResponse.value == null) {
		isMasDisabled.value = true;
		mas.value = 0;
	}
}

const landUseCodeChange = debounce(async () => {
	if (landUseCodeFilter.value.length >= 3) {
		isLandUseCodeLoadingDataFilter.value = true;
		await applicationFormsStore.loadLandUseList(landUseCodeFilter.value);
		initLandUseList();
		isNextLandUseValid.value = applicationFormsStore.landUseList?.nextKey;
		isLandUseCodeLoadingDataFilter.value = false;
	} else {
		landUseList.value = [];
	}
}, 500);

function initLandUseList() {
	landUseList.value =
		landUseListResponse.value && landUseList && landUseList.value
			? landUseListResponse.value.records
			: [];
}

function onSearchChangeMunicipalityListCode(val: string) {
	municipalityCodeFilter.value = val;
}

function initMunicipalityList() {
	municipalityList.value =
		municipalityList.value && municipalityListResponse.value
			? municipalityListResponse.value.records
			: [];
}

const onKeyupMunicipalityCode = debounce(async () => {
	if (municipalityCodeFilter.value.length >= 3) {
		isMunicipalityListLoadingDataFilter.value = true;
		await applicationFormsStore.loadMunicipalityList(
			municipalityCodeFilter.value
		);
		initMunicipalityList();
		isNextMunicipalityValid.value =
			applicationFormsStore.municipalityList?.nextKey;
		isMunicipalityListLoadingDataFilter.value = false;
	} else {
		municipalityList.value = [];
	}
}, 500);
</script>

<template>
	<form
		id="ChemicalAndOrganicForm"
		@submit.stop.prevent="onSubmitPlotLand()"
		class="container col-12 px-3 mx-0">
		<div class="pt-3">
			<div class="col-12 mt-3">
				<h5 class="fw-bold mb-0" :class="getColor('text', 'primary')">
					{{ t(`${moduleId}.ChemicalAndOrganicForm.page.title`) }}
				</h5>
			</div>

			<div
				class="container-edit-element"
				v-if="plotLand?.ids?.[0] != null || idEditMassive != null">
				<div class="table-item" v-if="idEditMassive == null">
					<span class="table-item-head-grid">
						{{ t(`${moduleId}.ChemicalAndOrganicForm.table.municipality`) }}:
					</span>
					<span class="table-item-body-grid">
						{{ plotLand?.sectorDescription }}
					</span>
				</div>
				<div class="table-item" v-else>
					<span class="table-item-all-municipality-edit">
						{{
							t(
								`${moduleId}.ChemicalAndOrganicForm.table.editMassivePlotLand`
							) +
							idEditMassive.length +
							t(
								`${moduleId}.ChemicalAndOrganicForm.table.editMassivePlotLandElementsSelected`
							)
						}}
					</span>
				</div>
				<div class="table-item">
					<span class="table-item-head-grid">
						{{ t(`${moduleId}.ChemicalAndOrganicForm.table.plotLand`) }}:
					</span>
					<span class="table-item-body-grid">
						{{ plotLand?.plotDescription }}
					</span>
				</div>
				<div class="table-item">
					<span class="table-item-head-grid">
						{{ t(`${moduleId}.ChemicalAndOrganicForm.table.plantSpecies`) }}:
					</span>
					<span class="table-item-body-grid">
						{{ plotLand?.landUseDescription }}
					</span>
				</div>

				<div class="table-item" v-if="idEditMassive == null">
					<span class="table-item-head-grid">
						{{ t(`${moduleId}.ChemicalAndOrganicForm.table.surface`) }}:
					</span>
					<span class="table-item-body-grid">
						{{ plotLand?.areaSqm }}
					</span>
				</div>
			</div>

			<div class="row mb-5" v-if="plotLand?.ids?.[0] == null">
				<div class="row mb-3">
					<div class="col-9">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="municipalityCodeId"
							:id="'municipalityCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
							:items="municipalityList"
							:isAutocomplete="true"
							:loading="isMunicipalityListLoadingDataFilter"
							:showNoResults="!isMunicipalityListLoadingDataFilter"
							:errors="
								errorsPlotLand.sectorCode ? [errorsPlotLand.sectorCode] : []
							"
							v-model="sectorCode"
							@searchChange="onSearchChangeMunicipalityListCode"
							@keyup="onKeyupMunicipalityCode"
							:minSearchLenght="minSearchLenghtMunicipality"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${municipalityCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtMunicipality}`
							"
							:itemTitle="'description'"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextMunicipalityValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
					<div class="col-3">
						<BiInput
							name="areaSqmId"
							:id="'areaSqmId'"
							ref="areaSqmRef"
							type="text"
							@input="validateNumberOrNumberWithFourDecimalAreaSqm()"
							class="mb-4"
							:errors="errorsPlotLand.areaSqm ? [errorsPlotLand.areaSqm] : []"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.page.areaSqm`)"
							v-model="areaSqm" />
					</div>
				</div>

				<div class="row mb-3">
					<div class="col-9">
						<div>
							<BiAutocompleteNext
								name="landUseCodeId"
								:id="'landUseCodeId'"
								:label="t(`${moduleId}.graphicCropPlan.table.landUseCode`)"
								:items="landUseList"
								:isAutocomplete="true"
								:loading="isLandUseCodeLoadingDataFilter"
								:showNoResults="!isLandUseCodeLoadingDataFilter"
								:errors="
									errorsPlotLand.landUseCode ? [errorsPlotLand.landUseCode] : []
								"
								v-model="landUseCode"
								@close="onCloseLandUseCode()"
								@searchChange="onSearchChangeLandUseCode"
								@keyup="landUseCodeChange"
								:minSearchLenght="minCharFilterLandUse"
								:labelNoResult="
									t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
									` ${landUseCodeFilter}`
								"
								:labelMinCharachter="
									t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
								"
								:labelNoItems="
									t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
									` ${minCharFilterLandUse}`
								"
								:itemTitle="'description'"
								:disabled="isReadOnly">
								<template #afterList>
									<div
										class="autocomplete-after-search-template"
										v-if="isNextLandUseValid">
										{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
									</div>
								</template>
							</BiAutocompleteNext>
						</div>
					</div>

					<div class="col-3 mt-4">
						<BiCheckbox
							name="flZvnId"
							:id="'flZvnId'"
							class="mb-4"
							:errors="errorsPlotLand.flZvn ? [errorsPlotLand.flZvn] : []"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.page.flZvn`)"
							v-model="flZvn" />
					</div>
				</div>

				<div class="row mb-3">
					<div class="col-6">
						<BiInput
							name="cropDurationId"
							:id="'cropDurationId'"
							type="number"
							class="mb-4"
							:errors="
								errorsPlotLand.cropDuration ? [errorsPlotLand.cropDuration] : []
							"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.page.cropDuration`)"
							v-model="cropDuration" />
					</div>

					<div class="col-6">
						<BiInput
							name="masId"
							:id="'masId'"
							type="number"
							class="mb-4"
							:readonly="isMasDisabled"
							:errors="errorsPlotLand.mas ? [errorsPlotLand.mas] : []"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.page.mas`)"
							v-model="mas" />
					</div>
				</div>
			</div>

			<div class="row mb-5">
				<div class="col-4">
					<BiSelect
						name="loopId"
						:id="'loopId'"
						:isMultiple="false"
						:isAutocomplete="false"
						:label="t(`${moduleId}.ChemicalAndOrganicForm.page.loop`)"
						:items="cycleList ?? []"
						:errors="errorsPlotLand.cycle ? [errorsPlotLand.cycle] : []"
						v-model="cycle"></BiSelect>
				</div>

				<div class="col-4">
					<BiSelect
						name="typologyId"
						:id="'typologyId'"
						:isMultiple="false"
						:isAutocomplete="false"
						:disabled="isTypologyDisabled"
						:label="t(`${moduleId}.ChemicalAndOrganicForm.page.typology`)"
						:items="typologyList ?? []"
						v-model="typology"
						:errors="errorsPlotLand.typology ? [errorsPlotLand.typology] : []"
						@change="onTypologyChange()"></BiSelect>
				</div>

				<div class="col-4">
					<BiSelect
						name="precessionId"
						:id="'precessionId'"
						:isMultiple="false"
						:isAutocomplete="false"
						:label="t(`${moduleId}.ChemicalAndOrganicForm.page.precession`)"
						:items="precessionCodeList ?? []"
						:errors="
							errorsPlotLand.precessionCode
								? [errorsPlotLand.precessionCode]
								: []
						"
						v-model="precessionCode"></BiSelect>
				</div>
			</div>

			<div class="row mb-5">
				<div class="col-4">
					<BiInput
						name="yieldId"
						:id="'yieldId'"
						class="mb-4"
						type="number"
						:errors="errorsPlotLand.yield ? [errorsPlotLand.yield] : []"
						:label="t(`${moduleId}.ChemicalAndOrganicForm.page.resa`)"
						v-model="yieldField" />
				</div>
			</div>
		</div>

		<div class="container">
			<div class="row justify-content-start">
				<div class="col-12 my-3 row">
					<div class="col-12 d-flex justify-content-between">
						<div>
							<h5 class="fw-bold" :class="getColor('text', 'primary')">
								{{ t(`${moduleId}.ChemicalAndOrganicForm.table.title`) }}
							</h5>

							<!-- buttons final page -->
						</div>
					</div>
				</div>
			</div>

			<div class="d-flex justify-content-end">
				<BiButton
					v-if="
						(!isReadOnly && !applicationFormsStore.loading) ||
						(applicationFormsStore.loading && isAddEditModalOpen)
					"
					class="mx-1 mb-2 col-auto"
					:class="`${getColor('button', 'primary', 'outline')}`"
					@click.stop="toggleAddEditModal()">
					{{ t(`${moduleId}.ChemicalAndOrganicForm.button.add`) }}
				</BiButton>
				<BiProgressIndicator
					v-if="applicationFormsStore.loading && !isAddEditModalOpen"
					type="spinner"></BiProgressIndicator>
			</div>
			<BiTable
				class="table-responsive pb-5"
				extraTableClasses="table-head-bg"
				isResponsive>
				<template v-slot:head>
					<tr
						class="bg-light text-start"
						:class="getColor('text', 'secondary')">
						<th scope="col">
							{{ t(`${moduleId}.ChemicalAndOrganicForm.table.effluent`) }}
						</th>
						<th scope="col">
							{{
								t(`${moduleId}.ChemicalAndOrganicForm.table.measurementUnit`)
							}}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.ChemicalAndOrganicForm.table.qta`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.ChemicalAndOrganicForm.table.titleField`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.ChemicalAndOrganicForm.table.frequency`) }}
						</th>
						<th scope="col"></th>
					</tr>
				</template>
				<template
					v-slot:body
					v-if="
						previousManureListResponse &&
						previousManureListResponse.length > 0 &&
						isDataTableReady
					">
					<tr
						ref="trRef"
						class="align-middle"
						v-for="(element, index) in previousManureListResponse"
						:key="index">
						<td
							:data-label="
								t(`${moduleId}.ChemicalAndOrganicForm.table.effluent`)
							"
							class="text-start">
							{{ element?.effluentDescription }}
						</td>
						<td
							:data-label="
								t(`${moduleId}.ChemicalAndOrganicForm.table.measurementUnit`)
							"
							class="text-start">
							{{ element?.measurementUnit }}
						</td>

						<td
							:data-label="t(`${moduleId}.ChemicalAndOrganicForm.table.qta`)"
							class="text-end">
							{{ element?.quantity }}
						</td>
						<td
							:data-label="
								t(`${moduleId}.ChemicalAndOrganicForm.table.titleField`)
							"
							class="text-end">
							{{ element?.nitrogenContent }}
						</td>
						<td
							:data-label="
								t(`${moduleId}.ChemicalAndOrganicForm.table.frequency`)
							"
							class="text-end">
							{{ element?.frequencyDescription }}
						</td>
						<td class="text-end text-nowrap">
							<div>
								<BiTooltip
									:title="
										t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.edit`)
									"
									:aria-label="
										t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.edit`)
									">
									<BiButton
										:aria-label="
											t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.edit`)
										"
										:aria-labelledby="
											t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.edit`)
										"
										:alt="
											t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.edit`)
										"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="editPreviousManure(element, index)"
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'success', 'outline')}`">
										<span>
											<BiIcon icon="pencil" size="xl" icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
								<BiTooltip
									:title="
										t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`)
									"
									:aria-label="
										t(`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`)
									">
									<BiButton
										tabindex="0"
										role="button"
										aria-pressed="false"
										aria-disabled="false"
										:aria-label="
											t(
												`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`
											)
										"
										:aria-labelledby="
											t(
												`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`
											)
										"
										:alt="
											t(
												`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`
											)
										"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="
											toggleConfirmDeleteModal(element, index)
										"
										isPrimary
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'danger', 'outline')}`">
										<span
											:aria-label="
												t(
													`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`
												)
											">
											<BiIcon
												:aria-label="
													t(
														`${moduleId}.ChemicalAndOrganicForm.table.tooltip.delete`
													)
												"
												icon="trash"
												size="xl"
												icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
							</div>
						</td>
					</tr>
					<tr>
						<td :colspan="numberTotalTd">
							<div class="p-0 d-flex justify-content-end">
								{{
									t(`${moduleId}.ChemicalAndOrganicForm.table.totalNitrogen`)
								}}
								:
								{{ totalNitrogenCalculated }}
							</div>
						</td>
					</tr>
				</template>
				<template v-slot:body v-else>
					<tr>
						<td colspan="3" class="text-start">
							{{ t(`${moduleId}.general.noData`) }}
						</td>
					</tr>
				</template>
			</BiTable>

			<div class="mb-5 d-flex justify-content-end">
				<div class="container-calculate-fabbisogno">
					<div>
						<BiInput
							name="distributableNumId"
							:id="'distributableNumId'"
							type="number"
							class="mb-4"
							:readonly="true"
							:label="
								t(
									`${moduleId}.ChemicalAndOrganicForm.page.nitrogenDistributable`
								)
							"
							v-model="distributableNum" />
					</div>
					<div
						class="d-flex flex-wrap align-content-center justify-content-center ps-3">
						<BiTooltip
							:title="
								t(
									`${moduleId}.ChemicalAndOrganicForm.page.tooltip.calcolateDistributableneed`
								)
							"
							:aria-label="
								t(
									`${moduleId}.ChemicalAndOrganicForm.page.tooltip.calcolateDistributableneed`
								)
							">
							<BiButton
								:aria-label="
									t(
										`${moduleId}.ChemicalAndOrganicForm.page.tooltip.calcolateDistributableneed`
									)
								"
								:aria-labelledby="
									t(
										`${moduleId}.ChemicalAndOrganicForm.page.tooltip.calcolateDistributableneed`
									)
								"
								:alt="
									t(
										`${moduleId}.ChemicalAndOrganicForm.page.tooltip.calcolateDistributableneed`
									)
								"
								v-if="!isReadOnly"
								:disabled="
									applicationFormsStore.loading ||
									isFabbisgnoButtonDisabledIfMissingRequiredFields
								"
								@click.stop.prevent="calcolateDistributableneeded()"
								class="mx-1"
								:class="`${getColor('button', 'success', 'outline')}`">
								<BiIcon
									icon="calculator"
									size="1x"
									icon-style="regular"
									aria-hidden="true" />
								{{
									t(
										`${moduleId}.ChemicalAndOrganicForm.page.calcolateDistributableneed`
									)
								}}
							</BiButton>
						</BiTooltip>
					</div>
				</div>
			</div>
		</div>

		<div class="mb-0 mt-5 pt-3 d-flex justify-content-center">
			<BiButton
				v-if="!isReadOnly && !applicationFormsStore.loading"
				class="mx-1 mb-4"
				:class="getColor('button', 'primary')"
				:is-disabled="isSubmittingPlotLand"
				@click="cancelTab()">
				{{ t(`${moduleId}.general.cancel`) }}
			</BiButton>
			<BiButton
				v-if="!isReadOnly && !applicationFormsStore.loading"
				type="submit"
				form="ChemicalAndOrganicForm"
				class="mx-1 mb-4"
				:class="getColor('button', 'primary')"
				:is-disabled="isSubmittingPlotLand">
				{{ t(`${moduleId}.general.saveCard`) }}
			</BiButton>
			<BiProgressIndicator
				v-if="applicationFormsStore.loading"
				type="spinner"></BiProgressIndicator>
		</div>
	</form>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicForm.modal.delete.title`)
		"
		:title="t(`${moduleId}.ChemicalAndOrganicForm.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.ChemicalAndOrganicForm.modal.delete.body`) }}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmDeleteModal();
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deletePreviousManure(previousManureId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- add/edit previous manure -->
	<BiModal
		:disabled-teleport="true"
		:key="modalKey"
		:extra-footer-class="'justify-content-center'"
		v-model="isAddEditModalOpen"
		:aria-labelledby="
			isEditMode
				? t(`${moduleId}.ChemicalAndOrganicForm.modal.edit.title`)
				: t(`${moduleId}.ChemicalAndOrganicForm.modal.add.title`)
		"
		:title="
			isEditMode
				? t(`${moduleId}.ChemicalAndOrganicForm.modal.edit.title`)
				: t(`${moduleId}.ChemicalAndOrganicForm.modal.add.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="previousManureForm"
				class="needs-validation"
				@submit.stop.prevent="onSubmitPreviousManure()">
				<div class="row">
					<div class="col-12 mb-5">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="effluentId"
							:id="'effluentId'"
							:label="
								t(`${moduleId}.fertSpreadingDeclaration.modal.form.effluent`)
							"
							:items="effluentList"
							:isAutocomplete="true"
							:loading="isEffluentListLoadingDataFilter"
							:showNoResults="!isEffluentListLoadingDataFilter"
							v-model="effluent"
							@searchChange="onEffluentListCodeSearchChange"
							@close="onChangeEffluentGetFrequency()"
							@keyup="effluentCodeChange"
							:minSearchLenght="minCharFilterEffluent"
							:labelNoResult="
								t(`${moduleId}.fertSpreadingDeclaration.table.labelNoResult`) +
								` ${effluentFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`)
							"
							:labelNoItems="
								t(
									`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`
								) + ` ${minCharFilterEffluent}`
							"
							:itemTitle="'description'"
							:errors="
								errorsPreviousManure.effluent
									? [errorsPreviousManure.effluent]
									: []
							"
							:disabled="isReadOnly"></BiAutocompleteNext>
					</div>
				</div>

				<div class="row">
					<div class="col-6 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="measurementUnitId"
								:id="'measurementUnitId'"
								class="mb-4"
								:readonly="true"
								:errors="
									errorsPreviousManure.measurementUnit
										? [errorsPreviousManure.measurementUnit]
										: []
								"
								:label="
									t(`${moduleId}.ChemicalAndOrganicForm.table.measurementUnit`)
								"
								v-model="measurementUnit" />
						</div>
					</div>

					<div class="col-6 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="qtaId"
								:id="'qtaId'"
								class="mb-4"
								type="number"
								:min="0"
								:errors="
									errorsPreviousManure.quantity
										? [errorsPreviousManure.quantity]
										: []
								"
								:label="t(`${moduleId}.ChemicalAndOrganicForm.table.qta`)"
								@keyup="onChangeQuantityCalculateResidualNitrogen()"
								v-model="quantity" />
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-6 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="titleFieldId"
								:id="'titleFieldId'"
								class="mb-4"
								type="number"
								:min="0"
								:errors="
									errorsPreviousManure.nitrogenContent
										? [errorsPreviousManure.nitrogenContent]
										: []
								"
								:label="
									t(`${moduleId}.ChemicalAndOrganicForm.table.titleField`)
								"
								@keyup="onChangeQuantityCalculateResidualNitrogen()"
								v-model="nitrogenContent" />
						</div>
					</div>

					<div class="col-6 mb-5">
						<BiSelect
							class="mb-4"
							name="frequencyId"
							:id="'frequencyId'"
							:isMultiple="false"
							:isAutocomplete="false"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.table.frequency`)"
							:items="frequencyList ?? []"
							v-model="frequency"
							@change="onChangeFrequencyUpdateReductionAndNitrogenResiduo()"
							:errors="
								errorsPreviousManure.frequency
									? [errorsPreviousManure.frequency]
									: []
							"></BiSelect>
					</div>
				</div>

				<div class="row">
					<div class="col-6 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="reductionId"
								:id="'reductionId'"
								class="mb-4"
								type="number"
								:readonly="true"
								:min="0"
								:errors="
									errorsPreviousManure.reduction
										? [errorsPreviousManure.reduction]
										: []
								"
								:label="t(`${moduleId}.ChemicalAndOrganicForm.table.reduction`)"
								v-model="reduction" />
						</div>
					</div>

					<div class="col-6 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="remainingNumberId"
								:id="'remainingNumberId'"
								class="mb-4"
								type="number"
								:readonly="true"
								:min="0"
								:errors="
									errorsPreviousManure.residualNitrogen
										? [errorsPreviousManure.residualNitrogen]
										: []
								"
								:label="
									t(`${moduleId}.ChemicalAndOrganicForm.table.remainingNumber`)
								"
								v-model="residualNitrogen" />
						</div>
					</div>
				</div>

				<div class="mt-3 mb-5 d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="cancelTabPreviousManure()">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						form="previousManureForm"
						class="mx-1"
						isPrimary
						:is-disabled="isSubmittingPreviousManure"
						:class="getColor('button', 'success')">
						{{
							isEditMode
								? t(`${moduleId}.ChemicalAndOrganicForm.modal.edit.confirmEdit`)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
			</form>
		</template>
	</BiModal>
</template>

<style scoped lang="scss">
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}

.container-calculate-fabbisogno {
	display: flex;
}

.container-calculate-fabbisogno button i {
	margin-right: 10px;
}

.container-calculate-fabbisogno button:disabled {
	border: 2px solid rgba(0, 128, 0, 0.411);
	color: rgba(0, 128, 0, 0.411);
}

@media screen and (max-width: 600px) {
	.container-calculate-fabbisogno {
		display: block;
	}
}

.container-edit-element {
	width: 100%;
	padding: 50px 0;

	.table-item {
		display: flex;
		padding: 0 0 5px 0;

		.table-item-all-municipality-edit {
			font-weight: bold;
		}

		.table-item-head-grid {
			font-weight: bold;
			width: 150px;
		}

		.table-item-body-grid {
			width: calc(100% - 200px);
		}
	}
}

@media screen and (max-width: 1200px) {
	.container-edit-element .table-item {
		min-width: 90%;
	}
}
</style>
