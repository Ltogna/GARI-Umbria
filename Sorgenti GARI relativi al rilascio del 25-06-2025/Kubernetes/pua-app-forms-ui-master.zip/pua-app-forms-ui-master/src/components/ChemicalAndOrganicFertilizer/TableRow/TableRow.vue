<script setup lang="ts">
import type { getPlotLandResponse } from "@/models/applicationForms";

import { inject, ref } from "vue";
import { useI18n } from "vue-i18n";

// bootstrap
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// components
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import TransformationGroupTable from "./TransformationGroupRow.vue";

const props = defineProps<{
	toggleHandlerImportOrManualAdd: boolean | null;
	plotLand: getPlotLandResponse;
	firstLandUseCode: string | null;
	modelValue: boolean | null | undefined;
	isReadOnly: boolean;
}>();

const emit = defineEmits([
	"routeInAddOrEditPage",
	"deletePlotLand",
	"selectedPlotLand",
	"update:modelValue",
]);

// Vue
const isCollapsed = ref(false);
const isLoading = ref(false);

const { getColor } = useColors();

const { t } = useI18n();
const moduleId = inject("moduleId");

function routeInAddOrEditPage(plotLand: getPlotLandResponse) {
	emit("routeInAddOrEditPage", plotLand);
}

function deletePlotLand(plotLand: getPlotLandResponse) {
	emit("deletePlotLand", plotLand);
}

function selectedPlotLand(plotLand: getPlotLandResponse) {
	emit("selectedPlotLand", plotLand);
	emit("update:modelValue", !plotLand?.isSelected);
}
</script>

<template>
	<tr>
		<td
			v-if="
				toggleHandlerImportOrManualAdd == false &&
				props.plotLand?.isSelected != null
			"
			:data-label="t(`${moduleId}.ChemicalAndOrganicFertilizer.table.checkBox`)"
			class="text-start">
			<BiCheckbox
				:name="`isPlotLandSelectedId_${plotLand?.ids?.[0]}`"
				:id="`isPlotLandSelectedId_${plotLand?.ids?.[0]}`"
				class="mb-4"
				:isDisabled="
					firstLandUseCode !== null &&
					plotLand?.landUseCode !== firstLandUseCode
				"
				:modelValue="props.plotLand?.isSelected"
				@change="selectedPlotLand(plotLand)" />
		</td>
		<td
			:data-label="
				t(`${moduleId}.ChemicalAndOrganicFertilizer.table.municipality`)
			"
			class="text-start">
			{{ props.plotLand?.sectorDescription }}
		</td>
		<td
			:data-label="t(`${moduleId}.ChemicalAndOrganicFertilizer.table.plotLand`)"
			class="text-start">
			{{ props.plotLand?.plotDescription }}
		</td>
		<td
			:data-label="
				t(`${moduleId}.ChemicalAndOrganicFertilizer.table.plantSpecies`)
			"
			class="text-start">
			{{ props.plotLand?.landUseDescription }}
		</td>
		<td
			:data-label="t(`${moduleId}.ChemicalAndOrganicFertilizer.table.zvn`)"
			class="text-start">
			<div
				v-if="props.plotLand && props.plotLand.flZvn"
				:aria-label="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.yes`)
				"
				:aria-labelledby="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.yes`)
				"
				:alt="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.yes`)
				"
				isPrimary
				:width="40"
				class="mx-1 my-0">
				<BiIcon
					icon="check"
					size="xl"
					icon-style="regular"
					aria-hidden="true" />
			</div>
			<div
				v-else
				:aria-label="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.no`)
				"
				:aria-labelledby="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.no`)
				"
				:alt="
					t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.zvn.no`)
				"
				isPrimary
				:width="40"
				class="mx-1 my-0"></div>
		</td>
		<td
			:data-label="t(`${moduleId}.ChemicalAndOrganicFertilizer.table.surface`)"
			class="text-start">
			{{ props.plotLand?.areaSqm || "" }}
		</td>
		<td
			:data-label="
				t(
					`${moduleId}.ChemicalAndOrganicFertilizer.table.nitrogenDistributable`
				)
			"
			class="text-start">
			{{ props.plotLand?.distributableNitrogen }}
		</td>
		<td
			:data-label="
				t(`${moduleId}.ChemicalAndOrganicFertilizer.table.totalNitrogen`)
			"
			class="text-start">
			{{ props.plotLand?.totalNitrogen?.toFixed(4) }}
		</td>
		<td class="justify-content-end">
			<div class="d-flex flex-nowrap text-nowrap action-icons">
				<div class="d-flex text-end action-icons">
					<BiTooltip
						:title="
							t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.edit`)
						"
						:aria-label="
							t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.edit`)
						">
						<BiButton
							:aria-label="
								t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.edit`)
							"
							:aria-labelledby="
								t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.edit`)
							"
							:alt="
								t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.edit`)
							"
							v-if="!props.isReadOnly"
							@click.stop.prevent="routeInAddOrEditPage(props.plotLand)"
							:width="40"
							class="mx-1 my-0"
							:class="`${getColor('button', 'success', 'outline')}`">
							<span>
								<BiIcon icon="pencil" size="xl" icon-style="regular" />
							</span>
						</BiButton>
					</BiTooltip>

					<BiTooltip
						v-if="props.toggleHandlerImportOrManualAdd"
						:title="
							t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.delete`)
						"
						:aria-label="
							t(`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.delete`)
						">
						<BiButton
							:aria-label="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.delete`
								)
							"
							:aria-labelledby="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.delete`
								)
							"
							:alt="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.delete`
								)
							"
							v-if="!props.isReadOnly"
							@click.stop.prevent="deletePlotLand(props.plotLand)"
							:width="40"
							class="mx-1 my-0"
							:class="`${getColor('button', 'danger', 'outline')}`">
							<span>
								<BiIcon icon="trash" size="xl" icon-style="regular" />
							</span>
						</BiButton>
					</BiTooltip>

					<BiCollapse
						tag="span"
						:targetSelector="`#plotLand-${props.plotLand?.ids?.[0]}`"
						v-model="isCollapsed"
						class="accordion-collapse-icon">
						<BiIcon
							icon="chevron-down"
							style="cursor: pointer"
							:class="isCollapsed ? 'collapse-icon' : undefined"
							:aria-label="
								t(`${moduleId}.ChemicalAndOrganicFertilizer.page.details`)
							"
							tabindex="0" />
					</BiCollapse>

					<div
						class="circle-check-container"
						v-if="
							props.plotLand?.cycle != null &&
							props.plotLand.precessionCode != null &&
							props.plotLand.yield != null &&
							!props.toggleHandlerImportOrManualAdd
						">
						<span
							:aria-label="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.checked`
								)
							"
							:aria-labelledby="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.checked`
								)
							"
							:alt="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.table.tooltip.checked`
								)
							"
							isPrimary
							:width="40">
							<BiIcon icon="circle-check" size="xl" icon-style="regular" />
						</span>
					</div>
				</div>
			</div>
		</td>
	</tr>
	<tr>
		<td class="p-0" colspan="12">
			<div :id="`plotLand-${props.plotLand?.ids?.[0]}`">
				<div v-show="!isLoading" class="accordion-body">
					<TransformationGroupTable :plot-land="props.plotLand" />
				</div>
			</div>
		</td>
	</tr>
</template>

<style scoped lang="scss">
.collapse-icon {
	transform: rotate(-180deg);
}

.action-icons {
	align-items: center;
}

.action-icons a {
	margin-right: 10px;
}

.circle-check-container {
	display: flex;
	width: 40px;
	height: 20px;
	justify-content: end;
	flex-wrap: wrap;
	align-self: baseline;
	margin-top: -15px;
}

.circle-check-container span i {
	font-size: 18px;
	color: #008055;
}
</style>
