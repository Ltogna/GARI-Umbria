<script setup lang="ts">
import type { getPlotLandResponse } from "@/models/applicationForms";
import { defineProps, inject } from "vue";
import { useI18n } from "vue-i18n";

const props = defineProps<{
	plotLand: getPlotLandResponse;
}>();

const moduleId = inject("moduleId");
const { t } = useI18n();
</script>

<template>
	<div class="container">
		<div class="table-item">
			<strong>
				{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.cropDuration`) }}:
			</strong>
			<span>{{ props.plotLand?.cropDuration }}</span>
		</div>
		<div class="table-item">
			<strong>
				{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.typology`) }}:
			</strong>
			<span>{{ props.plotLand?.typologyDescription }}</span>
		</div>
		<div class="table-item">
			<strong>
				{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.precession`) }}:
			</strong>
			<span>{{ props.plotLand?.precessionCodeDescription }}</span>
		</div>

		<div class="table-item">
			<strong>
				{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.resa`) }}:
			</strong>
			<span>{{ props.plotLand?.yield }}</span>
		</div>

		<div class="table-item">
			<strong>
				{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.loop`) }}:
			</strong>
			<span>{{ props.plotLand?.cycleDescription }}</span>
		</div>
		<div class="table-item">
			<strong>
				{{
					t(
						`${moduleId}.ChemicalAndOrganicFertilizer.table.nitrogenPreviousFertilizations`
					)
				}}:
			</strong>
			<span>
				{{ props.plotLand?.totResidualNitrogen?.toFixed(4) }}
			</span>
		</div>
	</div>
</template>

<style scoped>
.container {
	width: 100%;
	display: flex;
	flex-wrap: wrap;
	row-gap: 15px;
	column-gap: 50px;
	justify-content: left;
}

.container .table-item {
	display: flex;
	justify-content: space-between;
	width: calc(50% - 25px);
}

@media screen and (max-width: 1200px) {
	.container .table-item {
		min-width: 90%;
	}
}
</style>
