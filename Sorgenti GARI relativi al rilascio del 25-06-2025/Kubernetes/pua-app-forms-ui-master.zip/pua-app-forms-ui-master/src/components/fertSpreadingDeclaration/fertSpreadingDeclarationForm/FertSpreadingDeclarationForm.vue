<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

// Boootstrap Italia components
import {
	type EffluentResponse,
	EffluentResponseSchema,
	type getDeclarationFromCropPlanResponse,
	type getPartyRegistryResponse,
	type MunicipalityListWithFertSpreadingResponse,
	MunicipalityRecordListWithFertSpreadingModelSchema,
	type MunicipalityWithFertSpreadingResponse,
	type SaveFertSpreadingDeclarationRequest,
	type SearchSubjectDescriptionResponse,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import searchSubjectFormHelper from "../../searchSubjectFormHelper/SearchSubjectFormHelper.vue";

import type { IListMap } from "@/components/ChemicalFertilizer/ChemicalFertilizer.vue";

import MapOpenLayer, {
	type IPolygonData,
} from "@/components/MapOpenLayer/MapOpenLayer.vue";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import { toTypedSchema } from "@vee-validate/zod";
import debounce from "lodash/debounce";
import { useField, useForm } from "vee-validate";
import { useRoute, useRouter } from "vue-router";
import { z } from "zod";

// const component
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();
const router = useRouter();
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);
const isSelectAllWithSameLandUseCode = ref<boolean>(false);

const minCharFilterEffluent = ref<number>(0);
const effluentList = ref<EffluentResponse[]>([]);
const effluentFilter = ref<string>("");
const isEffluentListLoadingDataFilter = ref<boolean>(false);
const effluentListResponse = computed(
	() => applicationFormsStore.getEffuentListResponse
);
const isNextEffluentValid = ref<string | null | undefined>(null);

const municipalityListWithFertSpreading =
	ref<MunicipalityListWithFertSpreadingResponse>(
		{} as MunicipalityListWithFertSpreadingResponse
	);

const municipalityCodeFilterWithFertSpreading = ref<string>("");
const isMunicipalityListWithFertSpreadingLoadingDataFilter =
	ref<boolean>(false);

const municipalityListWithFertSpreadingResponse = computed(
	() => applicationFormsStore.municipalityListWithFertSpreading
);
const municipalityListWithFertSpreadingResponseMap = ref<IListMap>({});
const isNextMunicipalityWithFertSpreadingValid = ref<string | null | undefined>(
	null
);

const isConfirmDeleteModalOpen = ref<boolean>(false);

const isMunicipalityDisabled = computed(() => {
	let isMunicipalityDisabledFn = true;
	if (
		!isExternalCompany.value ||
		(isExternalCompany.value &&
			(partyId.value || (selectedSubject.value && selectedSubject.value.id)))
	) {
		isMunicipalityDisabledFn = false;
	}
	return isMunicipalityDisabledFn;
});

const takeLandUseCodeFromFirstCheckBoxSelected = ref<string | null>(null);

function selectedPlotLandFromOpenLayerMap(plotLandId: string) {
	const plotLand = declarationUsedAsPlotList.value?.records.find(
		declarationUsedAsPlotListFn =>
			declarationUsedAsPlotListFn?.plotId == plotLandId
	);

	if (
		plotLand?.landuse?.code !== takeLandUseCodeFromFirstCheckBoxSelected.value
	) {
		declarationUsedAsPlotList.value?.records.map(declarationUsedAsPlot => {
			declarationUsedAsPlot.isSelected = false;
		});
	}

	if (plotLand != null && plotLand.isSelected != null) {
		plotLand.isSelected = !plotLand.isSelected;
		setTakeLandUseCodeFromFirstCheckBoxSelected(plotLand);
	}

	setPolygonsForOpenLayer();
}

function setTakeLandUseCodeFromFirstCheckBoxSelected(
	plotLand: getDeclarationFromCropPlanResponse
) {
	const isOnePLotLandSelected = declarationUsedAsPlotList.value.records.filter(
		(plotLand: getDeclarationFromCropPlanResponse) =>
			plotLand?.isSelected == true
	);

	if (isOnePLotLandSelected.length == 1 && plotLand?.landuse?.code != null) {
		takeLandUseCodeFromFirstCheckBoxSelected.value = plotLand.landuse.code;
	} else if (isOnePLotLandSelected.length == 0) {
		takeLandUseCodeFromFirstCheckBoxSelected.value = null;
		isSelectAllWithSameLandUseCode.value = false;
	}

	setPolygonsForOpenLayer();
}

const plotFilter = ref<string>("");
const isPlotListLoadingDataFilter = ref<boolean>(false);
const declarationUsedAsPlotList = computed(
	() => applicationFormsStore.getDeclarationUsedAsPlotListResponse
);

const livestockEffluentsQtyRef = ref();
let livestockEffluentsQtyOldValue: string | undefined;
const livestockEffluentsQtyId = "livestockEffluentsQtyId";

const plotLandWithAlmostOneElement = computed(() =>
	declarationUsedAsPlotList.value.records.filter(el => el?.isSelected == true)
);

const minDate = ref<string>("");
const isDataPresentInBackEnd = ref<boolean>(false);
const searchSubjectFormHelperRef = ref();

const cropPlanId = computed(
	() => applicationFormsStore.getCropPlanListResponse?.records[0]?.cropPlanId
);

const cropPlanVersion = computed(() => {
	if (
		applicationFormsStore.getCropPlanVersionListResponse &&
		applicationFormsStore.getCropPlanVersionListResponse.records &&
		applicationFormsStore.getCropPlanVersionListResponse.records[0]
	) {
		return applicationFormsStore.getCropPlanVersionListResponse.records[0]
			.version;
	}
	return "";
});

const fertSpreadingDeclarationId = computed(
	() =>
		applicationFormsStore.saveInStore?.FertSpreadingDeclaration?.editElement?.id
);

const partyIdSelf = computed(() => queryFieldsStore.getPartyId);
const partyIdSelected = ref<number | null>(null);

const fertSpreadingDeclaration = computed(
	() => applicationFormsStore.getFertSpreadingDeclarationResponse
);

const isExternalCompany = computed(() => {
	if (
		applicationFormsStore.saveInStore &&
		applicationFormsStore.saveInStore.FiveYearComunicationForm &&
		applicationFormsStore.saveInStore.FiveYearComunicationForm.isExternalCompany
	) {
		return applicationFormsStore.saveInStore.FiveYearComunicationForm
			.isExternalCompany;
	}
	if (
		fertSpreadingDeclaration.value &&
		fertSpreadingDeclaration.value?.partyId
	) {
		return fertSpreadingDeclaration.value?.partyId !== partyIdSelf.value;
	} else {
		return false;
	}
});

const selectedSubject = computed(() => {
	if (
		applicationFormsStore.selectedSubject &&
		!applicationFormsStore.selectedSubject.description
	) {
		applicationFormsStore.selectedSubject.description =
			applicationFormsStore.selectedSubject.lastName +
			" " +
			applicationFormsStore.selectedSubject.firstName;
	}

	return applicationFormsStore.selectedSubject;
});

const partyId = computed(() => {
	if (applicationFormsStore.selectedSubject) {
		return applicationFormsStore.selectedSubject?.id;
	} else {
		return applicationFormsStore.saveInStore?.FertSpreadingDeclaration
			?.editElement?.partyId;
	}
});

const saveFertSpreadingDeclarationResponse = computed(
	() => applicationFormsStore.saveFertSpreadingDeclarationResponse
);

const editFertSpreadingDeclarationResponse = computed(
	() => applicationFormsStore.editFertSpreadingDeclarationResponse
);

const getDeclarationType = computed(
	() => applicationFormsStore.getDeclarationYearResponse
);
const dateDeclarationType = computed(() => getDeclarationType.value?.year);
const datePointInTime = computed(() =>
	dateDeclarationType.value
		? `${dateDeclarationType.value - 1}-11-11`
		: undefined
);
const datePointInTimeTo = computed(() =>
	dateDeclarationType.value ? `${dateDeclarationType.value}-11-10` : undefined
);

const isNewMunicipality = ref<boolean>(false);

const effluentListResponseMap = ref<IListMap>({});
const polygonsForOpenLayer = ref<IPolygonData[]>([]);
const mapOpenLayerComponentRef = ref<InstanceType<typeof MapOpenLayer> | null>(
	null
);

function highlightTextAfterSearch() {
	if (plotFilter.value.length > 0) {
		const plotFilterFn = plotFilter.value.toUpperCase();
		declarationUsedAsPlotList.value.records =
			declarationUsedAsPlotList.value.records.map(plotLand => {
				if (plotLand != null && plotLand.landuse != null) {
					if (
						plotLand.landuse.code != null &&
						plotLand.landuse.code.includes(plotFilterFn) &&
						!plotLand.landuse.code.includes("span")
					) {
						plotLand.landuse.code = plotLand.landuse.code.replaceAll(
							`${plotFilterFn}`,
							`<span class="highlight-match-text">${plotFilterFn}</span>`
						);
					}

					if (
						plotLand.landuse.description != null &&
						plotLand.landuse.description.includes(plotFilterFn) &&
						!plotLand.landuse.description.includes("span")
					) {
						plotLand.landuse.description =
							plotLand.landuse.description.replaceAll(
								`${plotFilterFn}`,
								`<span class="highlight-match-text">${plotFilterFn}</span>`
							);
					}
				}

				return plotLand;
			});
	}
}
onMounted(async () => {
	queryFieldsStore.populateState();
	minDate.value = applicationFormsStore.addDate(null, 2, "day");

	clearPlotLandList();
	clearGetFertSpreadingDeclarationResponse();
	await initOrFilterEffluentCodeList();
	await initOrFilterMunicipalityList();
	await getfertSpreadingStoredInBackEndAndRequestType();
});

function clearPlotLandList() {
	applicationFormsStore.clearGetDeclarationUsedAsPlotListResponse();
}

function clearGetFertSpreadingDeclarationResponse() {
	applicationFormsStore.clearGetFertSpreadingDeclarationResponse();
}

function goInComunicazioneSpandimenti() {
	router.push({
		name: "comunicazioneSpandimenti",
		query: {
			...route.query,
		},
	});
}

async function cancelTab() {
	goInComunicazioneSpandimenti();
}

async function checkIfTabCompletedAndSaveDataAndGoInTableParentComponent() {
	if (
		expectedDate.value &&
		municipalityCodeWithFertSpreading.value &&
		plotLandWithAlmostOneElement.value &&
		plotLandWithAlmostOneElement.value.length > 0 &&
		livestockEffluents.value &&
		livestockEffluentsQty.value &&
		cropPlanVersion.value &&
		(!isExternalCompany.value ||
			(isExternalCompany.value &&
				(partyId.value || (selectedSubject.value && selectedSubject.value.id))))
	) {
		const saveData: SaveFertSpreadingDeclarationRequest = {
			partyId: partyId.value ?? null,
			expectedDate: expectedDate.value.replaceAll(/[-/]/gi, ""),
			sectorCode: municipalityCodeWithFertSpreading.value.code,
			landuses: plotLandWithAlmostOneElement.value,
			livestockEffluents: livestockEffluents.value.code,
			livestockEffluentsQty: (+String(livestockEffluentsQty.value).replace(
				",",
				"."
			)).toFixed(4),
			cropPlanVersion: cropPlanVersion.value,
		};

		await saveOrEditFertSpreadingDeclarationAndGoInTableParentComponent(
			saveData
		);
	}
}

async function saveOrEditFertSpreadingDeclarationAndGoInTableParentComponent(
	saveData: SaveFertSpreadingDeclarationRequest
) {
	if (dateDeclarationType.value == null) {
		return;
	}

	if (fertSpreadingDeclarationId.value) {
		await applicationFormsStore.editFertSpreadingDeclaration(
			saveData,
			fertSpreadingDeclarationId.value,
			dateDeclarationType.value
		);
	} else {
		await applicationFormsStore.saveFertSpreadingDeclaration(
			saveData,
			dateDeclarationType.value
		);
	}

	if (
		(saveFertSpreadingDeclarationResponse.value &&
			saveFertSpreadingDeclarationResponse.value.id) ||
		(editFertSpreadingDeclarationResponse.value &&
			editFertSpreadingDeclarationResponse.value.id)
	) {
		goInComunicazioneSpandimenti();
	}
}

function setValueInForm() {
	livestockEffluents.value = {} as EffluentResponse;
	municipalityCodeWithFertSpreading.value =
		{} as MunicipalityWithFertSpreadingResponse;

	if (
		fertSpreadingDeclaration.value &&
		livestockEffluents.value &&
		municipalityCodeWithFertSpreading.value &&
		effluentListResponseMap.value &&
		declarationUsedAsPlotList.value.records != null
	) {
		expectedDate.value = fertSpreadingDeclaration.value.expectedDate;

		createMapMunicipalityListWithFertSpreading();
		createMapEffluentList();

		municipalityCodeWithFertSpreading.value.code =
			fertSpreadingDeclaration.value.sectorCode;
		municipalityCodeWithFertSpreading.value.description =
			municipalityListWithFertSpreadingResponseMap.value[
				fertSpreadingDeclaration.value.sectorCode
			];

		livestockEffluents.value.code =
			fertSpreadingDeclaration.value.livestockEffluents;
		livestockEffluents.value.descriptionUom =
			fertSpreadingDeclaration.value.livestockEffluentsDescriptionUom;
		livestockEffluents.value.description =
			effluentListResponseMap.value[
				fertSpreadingDeclaration.value.livestockEffluents
			];

		livestockEffluentsQty.value = Number(
			fertSpreadingDeclaration.value.livestockEffluentsQty.toFixed(4)
		);
	}
}

function createMapEffluentList() {
	if (applicationFormsStore.getEffuentListResponse) {
		applicationFormsStore.getEffuentListResponse.map(el => {
			if (el.code && el.description) {
				effluentListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function onEffluentListCodeSearchChange(val: string) {
	effluentFilter.value = val;
}

const effluentCodeChange = debounce(async () => {
	await initOrFilterEffluentCodeList();
}, 500);

async function initOrFilterEffluentCodeList() {
	effluentList.value = [];
	isEffluentListLoadingDataFilter.value = true;
	const isFilterForFrequency = false;
	await applicationFormsStore.loadEffulentList(isFilterForFrequency);
	initOrUpdateEffulentList();

	isEffluentListLoadingDataFilter.value = false;
}

function initOrUpdateEffulentList() {
	if (effluentListResponse.value) {
		effluentList.value = effluentListResponse.value;
	}
}

async function getfertSpreadingStoredInBackEndAndRequestType() {
	if (fertSpreadingDeclarationId.value) {
		await applicationFormsStore.getFertSpreadingDeclaration(
			fertSpreadingDeclarationId.value
		);

		isDataPresentInBackEnd.value = true;

		await initItemObjectToPage();
		setValueInForm();
		await createRequestAfterSetValue();
	}
}

async function initItemObjectToPage() {
	if (fertSpreadingDeclaration.value) {
		fertSpreadingDeclaration.value.expectedDate =
			applicationFormsStore.addSeparatorInStringForDate(
				fertSpreadingDeclaration.value.expectedDate
			);
	}

	if (
		isExternalCompany.value &&
		fertSpreadingDeclaration.value &&
		fertSpreadingDeclaration.value.partyId
	) {
		const selectedSubject = {} as getPartyRegistryResponse;
		if (selectedSubject) {
			selectedSubject.description = fertSpreadingDeclaration.value.company;
			selectedSubject.id = fertSpreadingDeclaration.value.partyId;
			applicationFormsStore.setSelectedSubject(selectedSubject);
			await OnSeletSubjectAndPartyId(selectedSubject.id);
		}
	}
}

async function createRequestAfterSetValue() {
	await onChangeMunicipalitySelected(null);
	tableMappingIsSelectedForDataPresentInBackEnd();
}

const plotCodeChange = debounce(async () => {
	await loadPlotLandAndHighlightTextMatchWithFilter();
	tableMappingIsSelectedForDataPresentInBackEnd();
}, 500);

async function onPLotChangeWithNextKeyPagination() {
	if (
		cropPlanId.value &&
		cropPlanVersion.value &&
		municipalityCodeWithFertSpreading.value &&
		municipalityCodeWithFertSpreading.value.code != null &&
		municipalityCodeWithFertSpreading.value.code.length > 0
	) {
		isPlotListLoadingDataFilter.value = true;
		const pointInTime = createDateOrDateNow(datePointInTime.value).replaceAll(
			/[-/]/gi,
			""
		);
		const pointInTimeTo = createDateOrDateNow(
			datePointInTimeTo.value
		).replaceAll(/[-/]/gi, "");

		await applicationFormsStore.loadDeclarationsUsedAsPlotFromDeclCodeWithFertSpreading(
			partyIdSelected.value ? partyIdSelected.value : partyIdSelf.value,
			cropPlanId.value,
			cropPlanVersion.value,
			pointInTime,
			pointInTimeTo,
			municipalityCodeWithFertSpreading.value.code,
			plotFilter.value
		);

		isPlotListLoadingDataFilter.value = false;
	}
}

function calculatePlotTotalHectarWithFourDecimal(
	plotAreaSqm: number | null | undefined,
	plotAreaPerc: number | null | undefined
) {
	let plotTotalHectarFn = "0";
	const plotAreaSqmFn = Number(plotAreaSqm);
	const plotAreaPercFn = Number(plotAreaPerc);
	if (
		plotAreaSqm != null &&
		!Number.isNaN(plotAreaSqmFn) &&
		plotAreaPerc != null &&
		!Number.isNaN(plotAreaPercFn)
	) {
		plotTotalHectarFn = ((plotAreaSqm * plotAreaPerc) / 100 / 10000).toFixed(4);
	}
	return plotTotalHectarFn;
}

function createDateOrDateNow(date?: string) {
	const options: Intl.DateTimeFormatOptions = {
		year: "numeric",
		month: "2-digit",
		day: "2-digit",
	};

	const createDate = date ? new Date(date) : new Date();
	return createDate.toLocaleDateString("fr-CA", options);
}

function validateNumberOrNumberWithFourDecimalLivestockEffluentsQty() {
	if (livestockEffluentsQty.value != null) {
		livestockEffluentsQtyOldValue = livestockEffluentsQty.value.toString();
	}
	const result = applicationFormsStore.validateNumberOrNumberWithFourDecimal(
		livestockEffluentsQtyId,
		livestockEffluentsQty,
		livestockEffluentsQtyOldValue
	);

	if (result == false) {
		return false;
	} else {
		livestockEffluentsQtyOldValue = result;
	}
}

const { handleSubmit, setErrors, isSubmitting, errors } =
	useForm<SaveFertSpreadingDeclarationRequest>({
		initialValues: {
			expectedDate: null,
			landuses: undefined,
			sectorCode: null,
			livestockEffluents: undefined,
			livestockEffluentsQty: undefined,
		},
	});

const { value: expectedDate } = useField<string | null>(
	"expectedDate",
	toTypedSchema(z.string().nullish())
);

const { value: municipalityCodeWithFertSpreading } =
	useField<MunicipalityWithFertSpreadingResponse | null>(
		"sectorCode",
		toTypedSchema(MunicipalityRecordListWithFertSpreadingModelSchema.nullish())
	);

const { value: livestockEffluents } = useField<EffluentResponse | null>(
	"livestockEffluents",
	toTypedSchema(EffluentResponseSchema.nullish())
);

const { value: livestockEffluentsQty } = useField<string | number | null>(
	"livestockEffluentsQty",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const validateForm = (
	saveFertSpreadingDeclarationRequest: SaveFertSpreadingDeclarationRequest
) => {
	if (!saveFertSpreadingDeclarationRequest.expectedDate) {
		setErrors({
			expectedDate: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!saveFertSpreadingDeclarationRequest.sectorCode) {
		setErrors({
			sectorCode: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveFertSpreadingDeclarationRequest.livestockEffluents) {
		setErrors({
			livestockEffluents: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!saveFertSpreadingDeclarationRequest.livestockEffluentsQty) {
		setErrors({
			livestockEffluentsQty: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
};

const onSubmit = handleSubmit.withControlled(async values => {
	validateForm(values);
	const errorSearchSubjectComponent = ref<SearchSubjectDescriptionResponse>({});
	if (isExternalCompany.value) {
		errorSearchSubjectComponent.value = validateFormChildComponent();
	}

	applicationFormsStore.resetScrollToTop(window);

	if (
		(errorSearchSubjectComponent.value &&
			errorSearchSubjectComponent.value.description) ||
		errors.value.expectedDate ||
		errors.value.landuses ||
		errors.value.sectorCode ||
		errors.value.livestockEffluents ||
		errors.value.livestockEffluentsQty
	) {
		return;
	} else {
		await checkIfTabCompletedAndSaveDataAndGoInTableParentComponent();
	}

	return true;
});

function validateFormChildComponent() {
	if (searchSubjectFormHelperRef.value) {
		const errorSearchSubjectComponent =
			searchSubjectFormHelperRef.value.validateForm("");

		return errorSearchSubjectComponent;
	}
}

async function OnSeletSubjectAndPartyId(partyId: number | null | undefined) {
	if (partyId != null) {
		partyIdSelected.value = partyId;

		await applicationFormsStore.getCropPlanList(partyIdSelected.value);
		if (cropPlanId.value) {
			await applicationFormsStore.getCropPlanVersionList(
				partyIdSelected.value,
				cropPlanId.value
			);
		}

		await initOrFilterMunicipalityList();
	}
}

function onSearchChangeMunicipalityListCode(val: string) {
	municipalityCodeFilterWithFertSpreading.value = val;
}

function initMunicipalityList() {
	municipalityListWithFertSpreading.value.records =
		municipalityListWithFertSpreading.value &&
		municipalityListWithFertSpreadingResponse.value
			? municipalityListWithFertSpreadingResponse.value.records
			: [];
}

const onKeyupMunicipalityCode = debounce(async () => {
	await initOrFilterMunicipalityList();
}, 500);

async function initOrFilterMunicipalityList() {
	if (datePointInTime.value && cropPlanId.value) {
		const datePointInTimeToSearchMunicipalyListWithFertSpreadingFn =
			createDateOrDateNow(datePointInTimeTo.value).replaceAll(/[-/]/gi, "");

		isMunicipalityListWithFertSpreadingLoadingDataFilter.value = true;

		await applicationFormsStore.loadMunicipalityListWithFertSpreading(
			datePointInTimeToSearchMunicipalyListWithFertSpreadingFn,
			cropPlanId.value,
			partyIdSelected.value ? partyIdSelected.value : partyIdSelf.value
		);
		initMunicipalityList();
		isNextMunicipalityWithFertSpreadingValid.value =
			applicationFormsStore.municipalityList?.nextKey;
		isMunicipalityListWithFertSpreadingLoadingDataFilter.value = false;
	} else {
		municipalityListWithFertSpreading.value.records = [];
	}
}

async function filterDeclarationUsedAsPlotList() {
	takeLandUseCodeFromFirstCheckBoxSelected.value = null;
	await plotCodeChange();
}

async function loadPlotLandAndHighlightTextMatchWithFilter() {
	isSelectAllWithSameLandUseCode.value = false;
	await onPLotChangeWithNextKeyPagination();
	if (plotFilter.value.length > 0) {
		highlightTextAfterSearch();
	}
}

function setPolygonsForOpenLayer() {
	polygonsForOpenLayer.value = declarationUsedAsPlotList.value.records.reduce(
		(acc: IPolygonData[], el) => {
			if (
				el.geom != null &&
				el.plotId &&
				el.isSelected != null &&
				el.landuse != null
			) {
				const plotId = el.plotId.toString();
				const geometry = el.geom;
				const isSelected = el.isSelected;
				const landUseCode = el.landuse.code;

				acc.push({ plotId, geometry, isSelected, landUseCode });
			}

			return acc;
		},
		[]
	);

	if (mapOpenLayerComponentRef.value) {
		mapOpenLayerComponentRef.value.updatePolygonsInMapOpenLayer(
			polygonsForOpenLayer.value,
			takeLandUseCodeFromFirstCheckBoxSelected.value
		);
	}
}

function tableMappingIsSelectedForDataPresentInBackEnd() {
	declarationUsedAsPlotList.value?.records.map(declarationUsedAsPlot => {
		declarationUsedAsPlot.isSelected = false;
	});

	if (
		fertSpreadingDeclaration.value &&
		fertSpreadingDeclaration.value.landuses &&
		fertSpreadingDeclaration.value.landuses.length > 0
	) {
		fertSpreadingDeclaration.value.landuses.map(fertSpreadingDeclarationFn => {
			const searchElement = declarationUsedAsPlotList.value?.records.find(
				declarationUsedAsPlotListFn =>
					declarationUsedAsPlotListFn?.plotId ==
					fertSpreadingDeclarationFn?.plotId
			);

			if (searchElement != null && searchElement.plotId != null) {
				searchElement.isSelected = true;
				setTakeLandUseCodeFromFirstCheckBoxSelected(searchElement);
			}
		});
	}

	setPolygonsForOpenLayer();
}

function createMapMunicipalityListWithFertSpreading() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListWithFertSpreading.records.map(el => {
			if (el != null && el.code != null && el.description != null) {
				municipalityListWithFertSpreadingResponseMap.value[el.code] =
					el.description;
			}
		});
	}
}
async function onChangeMunicipalitySelected(
	municipalityCurrectSelection: MunicipalityWithFertSpreadingResponse | null
) {
	if (municipalityCurrectSelection != null) {
		municipalityNewValue.value = Object.assign(
			{},
			municipalityCodeWithFertSpreading.value
		);

		if (municipalityCurrectSelection.code != municipalityNewValue.value.code) {
			isNewMunicipality.value = true;
			toggleConfirmChangeMunicipality(municipalityCurrectSelection);
		}
	} else {
		await getRequestForPLotLand();
	}
}

function setFalseNewMunicipality() {
	isNewMunicipality.value = false;
}

const municipalityOldValue = ref<MunicipalityWithFertSpreadingResponse | null>(
	null
);
const municipalityNewValue = ref<MunicipalityWithFertSpreadingResponse | null>(
	null
);

function toggleConfirmChangeMunicipality(
	municipalityCurrectSelection: MunicipalityWithFertSpreadingResponse | null
) {
	if (municipalityCurrectSelection != null) {
		municipalityOldValue.value = municipalityCurrectSelection;

		municipalityCodeWithFertSpreading.value = Object.assign(
			{},
			municipalityOldValue.value
		);
	}

	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function confirmchangeMunicipality() {
	toggleConfirmChangeMunicipality(null);
	if (
		municipalityCodeWithFertSpreading.value != null &&
		municipalityNewValue.value != null &&
		municipalityCodeWithFertSpreading.value.code !=
			municipalityNewValue.value.code
	) {
		municipalityCodeWithFertSpreading.value = municipalityNewValue.value;
		await getRequestForPLotLand();
	}
}

async function getRequestForPLotLand() {
	takeLandUseCodeFromFirstCheckBoxSelected.value = null;
	await loadPlotLandAndHighlightTextMatchWithFilter();
	tableMappingIsSelectedForDataPresentInBackEnd();
}

function selectAllPlotLandWithSameLandUseCodeOrDeselectAll() {
	if (declarationUsedAsPlotList.value == null) return;

	if (isSelectAllWithSameLandUseCode.value == true) {
		declarationUsedAsPlotList.value.records
			.filter(
				(el: getDeclarationFromCropPlanResponse) =>
					el?.landuse?.code == takeLandUseCodeFromFirstCheckBoxSelected.value
			)
			.map((plotLand: getDeclarationFromCropPlanResponse) => {
				if (plotLand?.isSelected != null) {
					plotLand.isSelected = true;
				}
				return plotLand;
			});
	} else if (isSelectAllWithSameLandUseCode.value == false) {
		declarationUsedAsPlotList.value.records.map(
			(plotLand: getDeclarationFromCropPlanResponse) => {
				if (plotLand?.isSelected != null) {
					plotLand.isSelected = false;
				}
				return plotLand;
			}
		);
		takeLandUseCodeFromFirstCheckBoxSelected.value = null;
	}

	setPolygonsForOpenLayer();
}
</script>
<template>
	<div class="container col-12 px-3 mx-0">
		<div class="pb-3 pt-3">
			<form
				id="fertSPreadingDeclarationForm"
				class="needs-validation"
				@submit.prevent="cancelTab()">
				<div v-if="isExternalCompany">
					<div class="row">
						<searchSubjectFormHelper
							ref="searchSubjectFormHelperRef"
							@seletSubjectAndPartyId="
								OnSeletSubjectAndPartyId(partyId)
							"></searchSubjectFormHelper>
					</div>
				</div>
				<div class="row">
					<div class="col-12 mb-5">
						<BiDatepicker
							name="startDateOperationId"
							:id="'startDateOperationId'"
							:is-disabled="isReadOnly"
							v-model="expectedDate"
							:min="minDate"
							:label="
								t(
									`${moduleId}.fertSpreadingDeclaration.modal.form.expectedDate`
								)
							"
							:errors="
								errors.expectedDate ? [errors.expectedDate] : []
							"></BiDatepicker>
					</div>
				</div>
				<div class="row">
					<div class="col-12 mb-5">
						<div class="pt-4">
							<BiAutocompleteNext
								ref="autocompleteRef"
								name="municipalityCodeId"
								:id="'municipalityCodeId'"
								:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
								:items="municipalityListWithFertSpreading.records"
								:isAutocomplete="true"
								:loading="isMunicipalityListWithFertSpreadingLoadingDataFilter"
								:errors="errors.sectorCode ? [errors.sectorCode] : []"
								:showNoResults="
									!isMunicipalityListWithFertSpreadingLoadingDataFilter
								"
								v-model="municipalityCodeWithFertSpreading"
								@searchChange="onSearchChangeMunicipalityListCode"
								@close="onChangeMunicipalitySelected"
								@keyup="onKeyupMunicipalityCode"
								:labelNoResult="
									t(
										`${moduleId}.fertSpreadingDeclarationForm.table.labelNoResult`
									)
								"
								:labelNoItems="
									t(
										`${moduleId}.fertSpreadingDeclarationForm.table.labelNoResult`
									)
								"
								:itemTitle="'description'"
								:disabled="
									isReadOnly ||
									isMunicipalityDisabled ||
									isPlotListLoadingDataFilter
								">
								<template #afterList>
									<div
										class="autocomplete-after-search-template"
										v-if="isNextMunicipalityWithFertSpreadingValid">
										{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
									</div>
								</template>
							</BiAutocompleteNext>
						</div>
					</div>
				</div>

				<div class="row">
					<MapOpenLayer
						ref="mapOpenLayerComponentRef"
						:polygons="polygonsForOpenLayer"
						:isNewMunicipality="isNewMunicipality"
						:takeLandUseCodeFromFirstCheckBoxSelected="
							takeLandUseCodeFromFirstCheckBoxSelected
						"
						@selectedPlotLandFromOpenLayerMap="selectedPlotLandFromOpenLayerMap"
						@setFalseNewMunicipality="setFalseNewMunicipality"></MapOpenLayer>
				</div>

				<div class="row">
					<div class="row pt-2">
						<div class="col-6 mb-5">
							<div class="me-3 h-100">
								<BiInput
									name="inputFilterTableId"
									:id="'inputFilterTableId'"
									class="mb-4"
									type="search"
									:disabled="
										isReadOnly ||
										isPlotListLoadingDataFilter ||
										municipalityCodeWithFertSpreading == null ||
										municipalityCodeWithFertSpreading.code == null
									"
									:label="
										t(
											`${moduleId}.fertSpreadingDeclarationForm.table.inputFilterTable`
										)
									"
									v-model="plotFilter"
									@input="filterDeclarationUsedAsPlotList()" />
							</div>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-12 mb-5">
						<div
							v-if="applicationFormsStore.getLoading"
							class="d-flex row justify-content-center mb-3 cover-default-height-table-920">
							<div class="d-flex col-2 justify-content-center px-0">
								<BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
							</div>
						</div>

						<div class="table-and-loadMore-button" v-else>
							<div class="row justify-content-start">
								<div class="col-12 my-3 row">
									<div class="col-12 d-flex justify-content-between">
										<div>
											<h5 class="fw-bold" :class="getColor('text', 'primary')">
												{{
													t(
														`${moduleId}.fertSpreadingDeclarationForm.table.title`
													)
												}}
											</h5>
										</div>
									</div>
								</div>
							</div>
							<BiTable
								class="table-responsive"
								extraTableClasses="table-head-bg"
								isResponsive>
								<template v-slot:head>
									<tr
										class="bg-light text-start"
										:class="getColor('text', 'secondary')">
										<th scope="col">
											<div>
												<BiCheckbox
													:name="`selectAllWithSameLandUseCode`"
													:id="`selectAllWithSameLandUseCodes`"
													class="mb-4"
													:isDisabled="
														isReadOnly ||
														takeLandUseCodeFromFirstCheckBoxSelected == null
													"
													:title="
														t(
															`${moduleId}.ChemicalAndOrganicFertilizer.page.selectAllPlotLandWithSameLandUseCode`
														)
													"
													:alt="
														t(
															`${moduleId}.ChemicalAndOrganicFertilizer.page.selectAllPlotLandWithSameLandUseCode`
														)
													"
													v-model="isSelectAllWithSameLandUseCode"
													@change="
														selectAllPlotLandWithSameLandUseCodeOrDeselectAll()
													" />
											</div>
										</th>

										<th scope="col">
											{{
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.plotLand`
												)
											}}
										</th>

										<th scope="col">
											{{
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.plotLandDescription`
												)
											}}
										</th>

										<th scope="col">
											{{
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.Ha`
												)
											}}
										</th>
									</tr>
								</template>
								<template
									v-slot:body
									v-if="
										declarationUsedAsPlotList &&
										declarationUsedAsPlotList.records.length > 0
									">
									<tr
										class="align-middle"
										v-for="[
											index,
											element,
										] in declarationUsedAsPlotList.records.entries()"
										:key="element?.plotId!">
										<td
											:data-label="
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.selectCheckBox`
												)
											"
											class="text-start">
											<BiCheckbox
												:name="`plotLandCheckBoxId_${index}`"
												:id="`plotLandCheckBoxId_${index}`"
												class="mb-4"
												v-model="element.isSelected!"
												@change="
													setTakeLandUseCodeFromFirstCheckBoxSelected(element)
												"
												:isDisabled="
													isReadOnly ||
													(takeLandUseCodeFromFirstCheckBoxSelected !== null &&
														element?.landuse?.code !==
															takeLandUseCodeFromFirstCheckBoxSelected)
												" />
										</td>
										<td
											:data-label="
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.plotLand`
												)
											"
											class="text-start highlight-match-text-container">
											<div v-html="element?.landuse?.code"></div>
										</td>
										<td
											:data-label="
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.plotLandDescription`
												)
											"
											class="text-start highlight-match-text-container">
											<div v-html="element?.landuse?.description"></div>
										</td>
										<td
											:data-label="
												t(
													`${moduleId}.fertSpreadingDeclarationForm.table.headers.Ha`
												)
											"
											class="text-start highlight-match-text-container">
											{{
												calculatePlotTotalHectarWithFourDecimal(
													element?.areaPerc,
													element?.plotAreaSqm
												)
											}}
										</td>
									</tr>
								</template>
								<template v-slot:body v-else>
									<tr>
										<td colspan="3" class="text-start">
											{{ t(`${moduleId}.general.noData`) }}
										</td>
									</tr>
								</template>
							</BiTable>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-12 mb-5">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="effluentId"
							:id="'effluentId'"
							:label="
								t(`${moduleId}.fertSpreadingDeclaration.modal.form.effluent`)
							"
							:items="effluentList"
							:isAutocomplete="true"
							:loading="isEffluentListLoadingDataFilter"
							:showNoResults="!isEffluentListLoadingDataFilter"
							v-model="livestockEffluents"
							@searchChange="onEffluentListCodeSearchChange"
							@keyup="effluentCodeChange"
							:minSearchLenght="minCharFilterEffluent"
							:labelNoResult="
								t(`${moduleId}.fertSpreadingDeclaration.table.labelNoResult`) +
								` ${effluentFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`)
							"
							:labelNoItems="
								t(
									`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`
								) + ` ${minCharFilterEffluent}`
							"
							:itemTitle="'description'"
							:errors="
								errors.livestockEffluents ? [errors.livestockEffluents] : []
							"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextEffluentValid">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.select.refineSearch`
										)
									}}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="row pt-2">
					<div class="col-12 mb-5">
						<div class="me-3 h-100">
							<BiInput
								name="quantityId"
								ref="livestockEffluentsQtyRef"
								:id="'livestockEffluentsQtyId'"
								class="mb-4"
								type="text"
								:disabled="isReadOnly"
								@input="
									validateNumberOrNumberWithFourDecimalLivestockEffluentsQty()
								"
								:min="0"
								:label="
									t(
										`${moduleId}.fertSpreadingDeclaration.modal.form.quantity`
									) +
									(livestockEffluents?.descriptionUom
										? ` (${livestockEffluents?.descriptionUom || ''})`
										: ``)
								"
								:errors="
									errors.livestockEffluentsQty
										? [errors.livestockEffluentsQty]
										: []
								"
								v-model="livestockEffluentsQty" />
						</div>
					</div>
				</div>

				<div class="mt-3 mb-5 d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						:is-disabled="isReadOnly || isSubmitting"
						@click.stop="cancelTab()">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						form="fertSpreadingDeclarationForm"
						class="mx-1"
						isPrimary
						:is-disabled="
							isReadOnly ||
							isSubmitting ||
							plotLandWithAlmostOneElement.length == 0
						"
						@click="onSubmit()"
						:class="getColor('button', 'success')">
						{{
							fertSpreadingDeclarationId
								? t(
										`${moduleId}.fertSpreadingDeclaration.modal.edit.confirmEdit`
									)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
			</form>
		</div>

		<!-- confirm changeMunicipality modal -->
		<BiModal
			:disabled-teleport="true"
			:extra-footer-class="'justify-content-center'"
			v-model="isConfirmDeleteModalOpen"
			:aria-labelledby="
				t(
					`${moduleId}.fertSpreadingDeclarationForm.modal.changeMunicipality.title`
				)
			"
			:title="
				t(
					`${moduleId}.fertSpreadingDeclarationForm.modal.changeMunicipality.title`
				)
			"
			:prevent-dismiss="true">
			<template #body>
				<div class="col-12 mb-3">
					<BiAlert isWarn>
						<template #body>
							{{
								t(
									`${moduleId}.fertSpreadingDeclarationForm.modal.changeMunicipality.body`
								)
							}}
						</template>
					</BiAlert>
				</div>
			</template>
			<template #footer>
				<div class="d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop.prevent="toggleConfirmChangeMunicipality(null)">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						class="mx-1"
						isPrimary
						:class="getColor('button', 'success')"
						@click.stop="confirmchangeMunicipality()">
						{{ t(`${moduleId}.general.confirm`) }}
					</BiButton>
				</div>
				<div
					v-if="applicationFormsStore.getLoading"
					class="d-flex row justify-content-center mb-3">
					<div class="d-flex col-2 justify-content-center px-0">
						<BiProgressIndicator type="spinner"></BiProgressIndicator>
					</div>
				</div>
			</template>
		</BiModal>
	</div>
</template>

<style scoped lang="scss">
.cover-default-height-table-920 {
	padding-bottom: 920px;
}

::v-deep .highlight-match-text {
	color: #10225e;
	text-decoration: underline;
	font-weight: bold;
}
</style>
