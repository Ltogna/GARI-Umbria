<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

// Boootstrap Italia components
import type { SaveFertSpreadingDeclarationResponse } from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { getFormattedDate } from "@/utils/dateUtils.ts";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { useRoute, useRouter } from "vue-router";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";

// const component
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const route = useRoute();
const router = useRouter();
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();

export interface IEditElement {
	id: number | undefined;
	partyId: number | null;
	company: string;
}

const partyIdSelf = computed(() => queryFieldsStore.getPartyId);
const isVersionEmpty = ref<boolean>(true);
const cropPlanId = computed(
	() => applicationFormsStore.getCropPlanListResponse?.records[0]?.cropPlanId
);

const cropPlanVersion = computed(() => {
	if (
		applicationFormsStore.getCropPlanVersionListResponse &&
		applicationFormsStore.getCropPlanVersionListResponse.records &&
		applicationFormsStore.getCropPlanVersionListResponse.records[0]
	) {
		isVersionEmpty.value = false;

		return applicationFormsStore.getCropPlanVersionListResponse.records[0]
			.version;
	} else {
		isVersionEmpty.value = true;
	}
	return "";
});

const effluentListResponseMap = ref<IListMap>({});
const municipalityListResponseMap = ref<IListMap>({});
const isDataTableReady = ref<boolean>(false);
const fertSpreadingDeclarationId = ref<number>();
const isConfirmDeleteModalOpen = ref<boolean>(false);
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const fertSpreadingDeclarationList = computed(
	() => applicationFormsStore.getFertSpreadingDeclarationListResponse
);

const fertSpreadingDeclarationListSelf = computed(() =>
	applicationFormsStore.getFertSpreadingDeclarationListResponse.filter(
		el => el?.partyId == null
	)
);

const fertSpreadingDeclarationListExternal = computed(() =>
	applicationFormsStore.getFertSpreadingDeclarationListResponse.filter(
		el => el?.partyId !== null
	)
);

const isAddEditModalOpen = ref<boolean>(false);

onMounted(async () => {
	queryFieldsStore.populateState();
	const isFilterForFrequency = false;
	await applicationFormsStore.loadEffulentList(isFilterForFrequency);
	await loadFertSpreadingDeclaration();
});

function toggleAddEditModal(
	element: SaveFertSpreadingDeclarationResponse,
	isExternalCompany: boolean
) {
	if (element) {
		const { id, partyId, company } = element;
		const editElement: IEditElement = { id, partyId, company };

		applicationFormsStore.saveDataInStore(
			"FertSpreadingDeclaration",
			"editElement",
			editElement
		);

		if (!isExternalCompany) {
			applicationFormsStore.clearSelectedSubject();
			applicationFormsStore.clearDataInStore(
				"FiveYearComunicationForm",
				"isExternalCompany"
			);
		} else {
			applicationFormsStore.saveDataInStore(
				"FiveYearComunicationForm",
				"isExternalCompany",
				true
			);
		}

		changeRouteTofertSpreadingDeclarationForm();
		applicationFormsStore.resetBodyScroll();
	}
}

function toggleConfirmDeleteModal(elementId?: number | null) {
	if (elementId) {
		fertSpreadingDeclarationId.value = elementId;
	}
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function addSelfCadastralParticel() {
	applicationFormsStore.clearSelectedSubject();
	applicationFormsStore.clearDataInStore(
		"FertSpreadingDeclaration",
		"editElement"
	);

	applicationFormsStore.clearDataInStore(
		"FiveYearComunicationForm",
		"isExternalCompany"
	);
	changeRouteTofertSpreadingDeclarationForm();
}

function addExternalCadastralParticel() {
	applicationFormsStore.clearSelectedSubject();
	applicationFormsStore.clearDataInStore(
		"FertSpreadingDeclaration",
		"editElement"
	);
	applicationFormsStore.saveDataInStore(
		"FiveYearComunicationForm",
		"isExternalCompany",
		true
	);

	changeRouteTofertSpreadingDeclarationForm();
}

function changeRouteTofertSpreadingDeclarationForm() {
	router.push({
		name: "comunicazioneSpandimentiForm",
		query: {
			...route.query,
		},
	});
}

async function loadFertSpreadingDeclaration() {
	await applicationFormsStore.getFertSpreadingDeclarationList();
	await loadCropPlanAndVersionAndDeclarationYear();

	if (fertSpreadingDeclarationList.value.length > 0) {
		tableDataMappingDescriptionFromCodeForEffulentAndPlotDescription();
	}

	fertSpreadingDeclarationListSelf.value.map(
		(fertSpreadingDeclarationItem: SaveFertSpreadingDeclarationResponse) => {
			if (
				fertSpreadingDeclarationItem != null &&
				fertSpreadingDeclarationItem.expectedDate != null
			) {
				fertSpreadingDeclarationItem.expectedDate =
					applicationFormsStore.addSeparatorInStringForDate(
						fertSpreadingDeclarationItem.expectedDate
					);
				return fertSpreadingDeclarationItem;
			}
		}
	);

	fertSpreadingDeclarationListExternal.value.map(
		(fertSpreadingDeclarationItem: SaveFertSpreadingDeclarationResponse) => {
			if (
				fertSpreadingDeclarationItem != null &&
				fertSpreadingDeclarationItem.expectedDate != null
			) {
				fertSpreadingDeclarationItem.expectedDate =
					applicationFormsStore.addSeparatorInStringForDate(
						fertSpreadingDeclarationItem.expectedDate
					);

				return fertSpreadingDeclarationItem;
			}
		}
	);
}

async function loadCropPlanAndVersionAndDeclarationYear() {
	await applicationFormsStore.getCropPlanList(partyIdSelf.value);
	if (cropPlanId.value) {
		await applicationFormsStore.getCropPlanVersionList(
			partyIdSelf.value,
			cropPlanId.value
		);

		if (cropPlanVersion.value) {
			await applicationFormsStore.getDeclarationYear();
		}
	}
}

async function deleteFertSpreadingDeclaration() {
	if (fertSpreadingDeclarationId.value) {
		await applicationFormsStore.deleteFertSpreadingDeclaration(
			fertSpreadingDeclarationId.value
		);
		toggleConfirmDeleteModal();
		await loadFertSpreadingDeclaration();
	}
}

function createMapEffluentList() {
	if (applicationFormsStore.getEffuentListResponse) {
		applicationFormsStore.getEffuentListResponse.map(el => {
			if (el.code && el.description) {
				effluentListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

async function tableDataMappingDescriptionFromCodeForEffulentAndPlotDescription() {
	isDataTableReady.value = false;
	createMapEffluentList();

	await applicationFormsStore.loadMunicipalityListFromCode(
		municipalityCodeList.value
	);
	createMapMunicipalityList();

	if (cropPlanId.value && cropPlanVersion.value) {
		fertSpreadingDeclarationList.value.map(
			(
				fertSpreadingDeclarationItem: SaveFertSpreadingDeclarationResponse,
				index: number
			) => {
				if (
					fertSpreadingDeclarationItem &&
					fertSpreadingDeclarationItem.livestockEffluents
				) {
					fertSpreadingDeclarationItem.sectorDescription =
						municipalityListResponseMap.value[
							fertSpreadingDeclarationItem.sectorCode
						];

					let totalHectar = 0;
					if (fertSpreadingDeclarationItem.landuses) {
						totalHectar = fertSpreadingDeclarationItem.landuses.reduce(
							(acc, el) => (acc += el?.plotTotalHectar),
							totalHectar
						);
					}
					fertSpreadingDeclarationItem.plotDescription = `${fertSpreadingDeclarationItem.landuses?.[0].plotDescription.split("Ha:")[0]} Ha: ${totalHectar.toFixed(4)}`;

					fertSpreadingDeclarationItem.livestockEffluentsDescription =
						effluentListResponseMap.value[
							fertSpreadingDeclarationItem.livestockEffluents
						];

					fertSpreadingDeclarationList.value[index] =
						fertSpreadingDeclarationItem;
				}
				return fertSpreadingDeclarationList;
			}
		);
	}
	isDataTableReady.value = true;
}

const municipalityCodeList = computed(() =>
	applicationFormsStore.getFertSpreadingDeclarationListResponse.reduce(
		(acc: string[], el: SaveFertSpreadingDeclarationResponse) => {
			if (el && el.sectorCode && !acc.includes(el.sectorCode)) {
				acc.push(el.sectorCode);
			}
			return acc;
		},
		[]
	)
);
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-else class="pb-3 pt-3">
			<div v-if="isVersionEmpty">
				<BiAlert isError>
					<template #body>
						{{
							t(
								`${moduleId}.fertSpreadingDeclaration.errors.CROPPLAN_NOT_EXISTS`
							)
						}}
					</template>
				</BiAlert>
			</div>
			<div v-else>
				<div class="col-10">
					<h5 class="fw-bold" :class="getColor('text', 'primary')">
						{{ t(`${moduleId}.fertSpreadingDeclaration.page.title`) }}
					</h5>
				</div>
				<div class="row my-3 justify-content-start">
					<div class="d-flex justify-content-between">
						<div class="col-10">
							<h6 class="fw-bold" :class="getColor('text', 'primary')">
								<p>
									{{ t(`${moduleId}.fertSpreadingDeclaration.table.title_1`) }}
								</p>
							</h6>
						</div>
						<BiButton
							v-if="
								(!isReadOnly && !applicationFormsStore.loading) ||
								(applicationFormsStore.loading && isAddEditModalOpen)
							"
							type="submit"
							class="mx-1 mb-2 col-auto"
							:class="`${getColor('button', 'primary', 'outline')}`"
							@click.stop="addSelfCadastralParticel()">
							{{ t(`${moduleId}.fertSpreadingDeclaration.button.add`) }}
						</BiButton>
					</div>
					<BiTable
						class="table-responsive"
						extraTableClasses="table-head-bg"
						isResponsive>
						<template v-slot:head>
							<tr
								class="bg-light text-start"
								:class="getColor('text', 'secondary')">
								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.expectedDate`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.municipalityCode`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.plot`)
									}}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.effluent`
										)
									}}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.quantity`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.measurementUnit`
										)
									}}
								</th>
								<th scope="col"></th>
							</tr>
						</template>
						<template
							v-slot:body
							v-if="
								fertSpreadingDeclarationListSelf &&
								fertSpreadingDeclarationListSelf.length > 0 &&
								isDataTableReady
							">
							<tr
								class="align-middle"
								v-for="element in fertSpreadingDeclarationListSelf"
								:key="JSON.stringify(element)">
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.expectedDate`
										)
									"
									class="text-start">
									{{ getFormattedDate(element?.expectedDate!) }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.municipalityCode`
										)
									"
									class="text-start">
									{{ element?.sectorDescription }}
								</td>
								<td
									:data-label="
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.plot`)
									"
									class="text-start">
									{{ element?.plotDescription || "" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.effluent`
										)
									"
									class="text-start">
									{{ element?.livestockEffluentsDescription || "" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.quantity`
										)
									"
									class="text-start">
									{{ element?.livestockEffluentsQty || "" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.quantity`
										)
									"
									class="text-start">
									{{ element?.livestockEffluentsDescriptionUom || "" }}
								</td>
								<td class="text-end text-nowrap">
									<div>
										<BiTooltip
											:title="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
												)
											"
											:aria-label="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
												)
											">
											<BiButton
												:aria-label="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												:aria-labelledby="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												:alt="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												v-if="!isReadOnly"
												@click.stop.prevent="
													() => {
														toggleAddEditModal(element, false);
													}
												"
												:width="40"
												class="mx-1 my-0"
												:class="`${getColor('button', 'success', 'outline')}`">
												<span>
													<BiIcon
														icon="pencil"
														size="xl"
														icon-style="regular" />
												</span>
											</BiButton>
										</BiTooltip>
										<BiTooltip
											:title="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
												)
											"
											:aria-label="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
												)
											">
											<BiButton
												:aria-label="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												:aria-labelledby="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												:alt="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												v-if="!isReadOnly"
												@click.stop.prevent="
													toggleConfirmDeleteModal(element?.id)
												"
												isPrimary
												:width="40"
												class="mx-1 my-0"
												:class="`${getColor('button', 'danger', 'outline')}`">
												<span>
													<BiIcon icon="trash" size="xl" icon-style="regular" />
												</span>
											</BiButton>
										</BiTooltip>
									</div>
								</td>
							</tr>
						</template>
						<template v-slot:body v-else>
							<tr>
								<td colspan="3" class="text-start">
									{{ t(`${moduleId}.general.noData`) }}
								</td>
							</tr>
						</template>
					</BiTable>
				</div>
				<div class="row my-3 justify-content-start">
					<div class="d-flex justify-content-between">
						<div class="col-10">
							<h6 class="fw-bold" :class="getColor('text', 'primary')">
								<p>
									{{ t(`${moduleId}.fertSpreadingDeclaration.table.title_2`) }}
								</p>
							</h6>
						</div>

						<BiButton
							v-if="
								(!isReadOnly && !applicationFormsStore.loading) ||
								(applicationFormsStore.loading && isAddEditModalOpen)
							"
							type="submit"
							class="mx-1 mb-2 col-auto"
							:class="`${getColor('button', 'primary', 'outline')}`"
							@click.stop="addExternalCadastralParticel()">
							{{ t(`${moduleId}.fertSpreadingDeclaration.button.add`) }}
						</BiButton>
					</div>
					<BiTable
						class="table-responsive"
						extraTableClasses="table-head-bg"
						isResponsive>
						<template v-slot:head>
							<tr
								class="bg-light text-start"
								:class="getColor('text', 'secondary')">
								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.companyName`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.cuaa`)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.expectedDate`
										)
									}}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.municipalityCode`
										)
									}}
								</th>

								<th scope="col">
									{{
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.plot`)
									}}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.effluent`
										)
									}}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.quantity`
										)
									}}
								</th>
								<th scope="col"></th>
							</tr>
						</template>
						<template
							v-slot:body
							v-if="
								fertSpreadingDeclarationListExternal &&
								fertSpreadingDeclarationListExternal.length > 0 &&
								isDataTableReady
							">
							<tr
								class="align-middle"
								v-for="element in fertSpreadingDeclarationListExternal"
								:key="JSON.stringify(element)">
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.companyName`
										)
									"
									class="text-start">
									{{ element?.company || "" }}
								</td>
								<td
									:data-label="
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.cuaa`)
									"
									class="text-start">
									{{ element?.cuaa || "" + "cuaa" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.expectedDate`
										)
									"
									class="text-start">
									{{ getFormattedDate(element?.expectedDate!) }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.municipalityCode`
										)
									"
									class="text-start">
									{{ element?.sectorDescription }}
								</td>
								<td
									:data-label="
										t(`${moduleId}.fertSpreadingDeclaration.table.headers.plot`)
									"
									class="text-start">
									{{ element?.plotDescription || "" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.effluent`
										)
									"
									class="text-start">
									{{ element?.livestockEffluentsDescription || "" }}
								</td>
								<td
									:data-label="
										t(
											`${moduleId}.fertSpreadingDeclaration.table.headers.quantity`
										)
									"
									class="text-start">
									{{ element?.livestockEffluentsQty || "" }}
								</td>
								<td class="text-end text-nowrap">
									<div>
										<BiTooltip
											:title="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
												)
											"
											:aria-label="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
												)
											">
											<BiButton
												:aria-label="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												:aria-labelledby="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												:alt="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.edit`
													)
												"
												v-if="!isReadOnly"
												@click.stop.prevent="
													() => {
														toggleAddEditModal(element, true);
													}
												"
												:width="40"
												class="mx-1 my-0"
												:class="`${getColor('button', 'success', 'outline')}`">
												<span>
													<BiIcon
														icon="pencil"
														size="xl"
														icon-style="regular" />
												</span>
											</BiButton>
										</BiTooltip>
										<BiTooltip
											:title="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
												)
											"
											:aria-label="
												t(
													`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
												)
											">
											<BiButton
												:aria-label="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												:aria-labelledby="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												:alt="
													t(
														`${moduleId}.fertSpreadingDeclaration.table.tooltip.delete`
													)
												"
												v-if="!isReadOnly"
												@click.stop.prevent="
													toggleConfirmDeleteModal(element?.id)
												"
												isPrimary
												:width="40"
												class="mx-1 my-0"
												:class="`${getColor('button', 'danger', 'outline')}`">
												<span>
													<BiIcon icon="trash" size="xl" icon-style="regular" />
												</span>
											</BiButton>
										</BiTooltip>
									</div>
								</td>
							</tr>
						</template>
						<template v-slot:body v-else>
							<tr>
								<td colspan="3" class="text-start">
									{{ t(`${moduleId}.general.noData`) }}
								</td>
							</tr>
						</template>
					</BiTable>
				</div>

				<!-- confirm delete modal -->
				<BiModal
					:disabled-teleport="true"
					:extra-footer-class="'justify-content-center'"
					v-model="isConfirmDeleteModalOpen"
					:aria-labelledby="
						t(`${moduleId}.fertSpreadingDeclaration.modal.delete.title`)
					"
					:title="t(`${moduleId}.fertSpreadingDeclaration.modal.delete.title`)"
					:prevent-dismiss="true">
					<template #body>
						<div class="col-12 mb-3">
							<BiAlert isWarn>
								<template #body>
									{{
										t(`${moduleId}.fertSpreadingDeclaration.modal.delete.body`)
									}}
								</template>
							</BiAlert>
						</div>
					</template>
					<template #footer>
						<div class="d-flex justify-content-center w-100">
							<BiButton
								class="mx-1"
								:class="getColor('button', 'secondary', 'outline')"
								@click.stop="
									() => {
										toggleConfirmDeleteModal();
									}
								">
								{{ t(`${moduleId}.general.cancel`) }}
							</BiButton>
							<BiButton
								class="mx-1"
								isPrimary
								:class="getColor('button', 'success')"
								@click.stop="deleteFertSpreadingDeclaration()">
								{{ t(`${moduleId}.general.confirm`) }}
							</BiButton>
						</div>
						<div
							v-if="applicationFormsStore.getLoading"
							class="d-flex row justify-content-center mb-3">
							<div class="d-flex col-2 justify-content-center px-0">
								<BiProgressIndicator type="spinner"></BiProgressIndicator>
							</div>
						</div>
					</template>
				</BiModal>
			</div>
		</div>
	</div>
</template>

<style scoped lang="scss">
ul {
	list-style-type: none;
	padding-left: 0;
}

.change-color {
	background-color: #f6f8fa;
}

.title {
	font-weight: bold;
	font-size: 1.111em;
}

@media (max-width: 1200px) {
	div.form-check.form-check-inline {
		margin-right: 0.1rem !important;
	}
}
</style>
