<script setup lang="ts">
// Vue
import { computed, inject, onBeforeUnmount, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";

// Boootstrap Italia components
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiUpload from "@abaco/bootstrap-italia-components/src/components/BiUpload/BiUpload.vue";
import BiTextarea from "@abaco/bootstrap-italia-components/src/components/form/BiTextarea.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// Store
import type { ValidatedInput } from "@/models/form";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { checkMaxLength, verifyField } from "@/utils/formUtils";

// Model
import type { SaveAttachmentModel } from "@/models/applicationForms";

const props = defineProps<{
	isDigitalSignature?: boolean;
}>();

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const applicationFormsStore = useApplicationFormsStore();
const QueryFieldsStore = useQueryFieldsStore();

const isReadOnly = computed(() => QueryFieldsStore.getReadOnly === 1);
const compileStatusIdentifier = computed(
	() => QueryFieldsStore.getCompileStatusIdentifier
);

const attachmentTypeList = computed(
	() => applicationFormsStore.getAttachmentTypeList[0]
);

const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const isMaxSizeExceeded = ref<boolean>(false);
const isEditMode = ref<boolean>(false);
const attachmentId = ref<string>("");

const modalKey = ref<number>(0);

const formValue = ref({
	file: null,
	groupCode: "",
	notes: "",
});

const formError = ref<boolean>(true);

const uploadKey = ref<number>(0);

const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
	notes: {
		val: formValue.value.notes,
		errors: [],
	},
});

const attachmentList = computed(() => {
	return applicationFormsStore.getAttachmentList?.records || [];
});

watch(
	() => formValue.value,
	val => {
		if (!isEditMode.value && val.file === null) {
			formError.value = true;
		} else {
			formError.value = false;
		}
	},
	{
		deep: true,
	}
);

function resetForm() {
	formValue.value.file = null;
	formValue.value.notes = "";
	searchFormValidators.value.notes.errors = [];
	modalKey.value += 1;
}

async function fetchAttachmentList(resetPagination?: boolean) {
	await applicationFormsStore.loadAttachmentList(
		resetPagination ? true : false,
		attachmentTypeList.value.groupCode
	);
}

function checkInputLengthErrors(): boolean {
	searchFormValidators.value.notes.val = formValue.value.notes;

	const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
	const errors: boolean[] = [];
	errors.push(
		verifyField(
			[
				() =>
					checkMaxLength(
						searchFormValidators.value.notes,
						4000,
						maxLengthErrorMessage
					),
			],
			searchFormValidators.value.notes
		)
	);

	return errors.findIndex((x: boolean) => x) !== -1 ? false : true;
}

async function addAttachment(attachment: SaveAttachmentModel) {
	await applicationFormsStore.addAttachment(
		attachment,
		compileStatusIdentifier.value
	);
	await fetchAttachmentList(true);
}

async function editAttachment(attachment: SaveAttachmentModel) {
	await applicationFormsStore.editAttachment(
		attachmentId.value,
		attachment,
		compileStatusIdentifier.value
	);
	await fetchAttachmentList(true);
}

function toggleAddEditModal(isEdit?: boolean) {
	isEdit ? (isEditMode.value = true) : (isEditMode.value = false);
	isAddEditModalOpen.value = !isAddEditModalOpen.value;
	searchFormValidators.value.notes.errors = [];
	!isAddEditModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function toggleConfirmDeleteModal() {
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function loadMore() {
	await fetchAttachmentList();
}

async function downloadAttachment(attachmentId: string, fileName: string) {
	const fileUrl = await applicationFormsStore.downloadAttachment(attachmentId);

	const fileLink = document.createElement("a");
	fileLink.href = fileUrl ?? "unnamed.txt";
	fileLink.download = fileName;
	fileLink.click();
}

async function deleteAttachment(attachmentId: string) {
	await applicationFormsStore.deleteAttachment(
		attachmentId,
		compileStatusIdentifier.value
	);
	toggleConfirmDeleteModal();
	await fetchAttachmentList(true);
}

onMounted(async () => {
	QueryFieldsStore.populateState();
	await applicationFormsStore.loadAttachmentTypeList();
	await fetchAttachmentList(true);
});

onBeforeUnmount(async () => {
	applicationFormsStore.clearAttachmentListandTypeList();
});
</script>
<template>
	<div class="container">
		<div class="row my-3 justify-content-start">
			<div class="col-12 my-3">
				<h4 class="fw-bold" :class="getColor('text', 'primary')">
					<BiIcon
						:aria-label="
							t(`${moduleId}.attachmentsForm.table.tooltip.icon.file`)
						"
						class="mx-2"
						icon="file-lines"
						size="lg" />
					<p>
						{{
							props.isDigitalSignature
								? t(`${moduleId}.digitalSignature.title`)
								: t(`${moduleId}.attachmentsForm.title`)
						}}
					</p>
				</h4>
			</div>
		</div>
		<BiTable
			class="table-responsive"
			extraTableClasses="table-head-bg"
			isResponsive>
			<template v-slot:head>
				<tr class="bg-light text-start" :class="getColor('text', 'secondary')">
					<th scope="col">
						{{ t(`${moduleId}.attachmentsForm.table.fileName`) }}
					</th>
					<th scope="col" style="min-width: 190px">
						{{ t(`${moduleId}.attachmentsForm.table.attachmentType`) }}
					</th>
					<th scope="col">
						{{ t(`${moduleId}.attachmentsForm.table.notes`) }}
					</th>
					<th scope="col"></th>
				</tr>
			</template>
			<template v-slot:body v-if="attachmentList && attachmentList.length > 0">
				<tr
					class="align-middle"
					v-for="element in attachmentList"
					:key="JSON.stringify(element)">
					<td
						:data-label="t(`${moduleId}.attachmentsForm.table.fileName`)"
						class="text-start">
						{{ element?.fileName || element?.fileName || "" }}
					</td>
					<td
						:data-label="t(`${moduleId}.attachmentsForm.table.attachmentType`)"
						class="text-start"
						style="min-width: 190px">
						{{ element?.type.code || element?.type.typeCode || "" }}
					</td>
					<td
						:data-label="t(`${moduleId}.attachmentsForm.table.notes`)"
						class="text-start">
						{{ element?.notes || "" }}
					</td>
					<td class="text-end text-nowrap">
						<div>
							<BiTooltip
								:title="t(`${moduleId}.attachmentsForm.table.tooltip.download`)"
								:aria-label="
									t(`${moduleId}.attachmentsForm.table.tooltip.download`)
								">
								<BiButton
									:aria-label="
										t(`${moduleId}.attachmentsForm.table.tooltip.download`)
									"
									:aria-labelledby="
										t(`${moduleId}.attachmentsForm.table.tooltip.download`)
									"
									:alt="t(`${moduleId}.attachmentsForm.table.tooltip.download`)"
									@click.stop.prevent="
										() => {
											downloadAttachment(
												element?.attachmentId ?? '',
												element?.fileName ?? ''
											);
										}
									"
									:width="40"
									class="mx-1 my-0"
									:class="`${getColor('button', 'primary', 'outline')}`">
									<span>
										<BiIcon icon="download" size="xl" icon-style="regular" />
									</span>
								</BiButton>
							</BiTooltip>
							<BiTooltip
								:title="t(`${moduleId}.attachmentsForm.table.tooltip.edit`)"
								:aria-label="
									t(`${moduleId}.attachmentsForm.table.tooltip.edit`)
								">
								<BiButton
									:aria-label="
										t(`${moduleId}.attachmentsForm.table.tooltip.edit`)
									"
									:aria-labelledby="
										t(`${moduleId}.attachmentsForm.table.tooltip.edit`)
									"
									:alt="t(`${moduleId}.attachmentsForm.table.tooltip.edit`)"
									v-if="!isReadOnly"
									@click.stop.prevent="
										() => {
											formValue = {
												file: null,
												groupCode: element?.type.groupCode ?? '',
												notes: element?.notes ?? '',
											};
											attachmentId = element?.attachmentId ?? '';
											toggleAddEditModal(true);
										}
									"
									:width="40"
									class="mx-1 my-0"
									:class="`${getColor('button', 'success', 'outline')}`">
									<span>
										<BiIcon icon="pencil" size="xl" icon-style="regular" />
									</span>
								</BiButton>
							</BiTooltip>
							<BiTooltip
								:title="t(`${moduleId}.attachmentsForm.table.tooltip.delete`)"
								:aria-label="
									t(`${moduleId}.attachmentsForm.table.tooltip.delete`)
								">
								<BiButton
									:aria-label="
										t(`${moduleId}.attachmentsForm.table.tooltip.delete`)
									"
									:aria-labelledby="
										t(`${moduleId}.attachmentsForm.table.tooltip.delete`)
									"
									:alt="t(`${moduleId}.attachmentsForm.table.tooltip.delete`)"
									v-if="!isReadOnly"
									@click.stop.prevent="
										() => {
											attachmentId = element?.attachmentId ?? '';
											toggleConfirmDeleteModal();
										}
									"
									isPrimary
									:width="40"
									class="mx-1 my-0"
									:class="`${getColor('button', 'danger', 'outline')}`">
									<span>
										<BiIcon icon="trash" size="xl" icon-style="regular" />
									</span>
								</BiButton>
							</BiTooltip>
						</div>
					</td>
				</tr>
			</template>
			<template v-slot:body v-else>
				<tr>
					<td colspan="3" class="text-start">
						{{ t(`${moduleId}.general.noData`) }}
					</td>
				</tr>
			</template>
		</BiTable>
		<div
			v-if="
				applicationFormsStore.getLoading &&
				!isConfirmDeleteModalOpen &&
				!isAddEditModalOpen
			"
			class="d-flex row justify-content-center mb-3">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
			</div>
		</div>
		<div class="w-100 text-center mb-3">
			<BiButton
				v-if="
					applicationFormsStore?.getAttachmentList?.nextKey !== null &&
					!applicationFormsStore.getLoading
				"
				@click="loadMore()"
				:class="getColor('button', 'primary', 'outline')">
				{{ t(`${moduleId}.general.loadMore`) }}
			</BiButton>
		</div>
		<div class="w-100 text-center">
			<BiButton
				v-if="
					!isReadOnly &&
					!applicationFormsStore.getLoading &&
					(!isDigitalSignature ||
						(isDigitalSignature && attachmentList.length === 0))
				"
				@click.stop="toggleAddEditModal(false)"
				class="mx-1"
				:class="`${getColor('button', 'primary', 'outline')}`">
				{{ t(`${moduleId}.attachmentsForm.newAttachment`) }}
			</BiButton>
		</div>
	</div>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="t(`${moduleId}.attachmentsForm.deleteModal.title`)"
		:title="t(`${moduleId}.attachmentsForm.deleteModal.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.attachmentsForm.deleteModal.body`) }}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmDeleteModal();
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteAttachment(attachmentId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>
	<!-- -->

	<!-- add/edit attachment modal -->
	<BiModal
		:disabled-teleport="true"
		:key="modalKey"
		:extra-footer-class="'justify-content-center'"
		v-model="isAddEditModalOpen"
		:aria-labelledby="
			isEditMode
				? t(`${moduleId}.attachmentsForm.editModal.title`)
				: t(`${moduleId}.attachmentsForm.addModal.title`)
		"
		:title="
			isEditMode
				? t(`${moduleId}.attachmentsForm.editModal.title`)
				: t(`${moduleId}.attachmentsForm.addModal.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="attachmentForm"
				class="needs-validation"
				@submit.prevent="
					async () => {
						if (checkInputLengthErrors()) {
							if (isEditMode) {
								await editAttachment({
									typeCode: attachmentTypeList.typeCode,
									groupCode: attachmentTypeList.groupCode,
									notes: formValue.notes,
								});
							} else {
								await addAttachment({
									typeCode: attachmentTypeList.typeCode,
									groupCode: attachmentTypeList.groupCode,
									notes: formValue.notes,
									file: formValue.file,
								});
							}
							toggleAddEditModal();
							resetForm();
						}
					}
				">
				<div class="col-12 mb-5">
					<BiTextarea
						:label="
							isEditMode
								? t(`${moduleId}.attachmentsForm.editModal.form.notes`)
								: t(`${moduleId}.attachmentsForm.addModal.form.notes`)
						"
						v-model="formValue.notes"
						:isDisabled="applicationFormsStore.getLoading"
						:errors="searchFormValidators.notes.errors" />
				</div>
				<div class="col-12 mb-5" v-if="!isEditMode">
					<BiUpload
						:key="uploadKey"
						:isDisabled="applicationFormsStore.getLoading"
						state="success"
						:maxSizeInBytes="1073741824"
						@click="
							() => {
								isMaxSizeExceeded = false;
							}
						"
						@maxSizeExceeded="
							() => {
								isMaxSizeExceeded = true;
								uploadKey += 1;
							}
						"
						@fileChanged="
							file => {
								if (
									file === undefined ||
									file === null ||
									(file && Array.isArray(file) && file.length === 0)
								) {
									formValue.file = null;
								} else {
									formValue.file = file;
								}
							}
						"
						:label="
							t(`${moduleId}.attachmentsForm.addModal.form.uploadFile`)
						"></BiUpload>
				</div>
				<div
					v-if="!applicationFormsStore.getLoading"
					class="mt-3 mb-5 d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="
							() => {
								toggleAddEditModal();
								resetForm();
							}
						">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						:isDisabled="formError"
						class="mx-1"
						isPrimary
						:class="getColor('button', 'success')">
						{{
							isEditMode
								? t(`${moduleId}.attachmentsForm.editModal.confirmEdit`)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
				<div>
					<BiAlert v-if="isMaxSizeExceeded" isError>
						<template #body>
							{{ t(`${moduleId}.attachmentsForm.addModal.maxSizeExceeded`) }}
						</template>
					</BiAlert>
				</div>
				<div
					v-if="applicationFormsStore.getLoading"
					class="d-flex row justify-content-center mb-3">
					<div class="d-flex col-2 justify-content-center px-0">
						<BiProgressIndicator type="spinner"></BiProgressIndicator>
					</div>
				</div>
			</form>
		</template>
	</BiModal>
	<!-- -->
</template>
