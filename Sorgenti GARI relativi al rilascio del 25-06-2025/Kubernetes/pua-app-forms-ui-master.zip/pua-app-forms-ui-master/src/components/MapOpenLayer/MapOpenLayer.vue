<script setup lang="ts">
import { useMap } from "@/composables/useMap";
import type { Feature } from "ol";
import WKT from "ol/format/WKT";
import { Select } from "ol/interaction";
import { Tile as TileLayer, Vector as VectorLayer } from "ol/layer";
import "ol/ol.css";
import { get as getProjection } from "ol/proj";
import { register } from "ol/proj/proj4";
import { OSM } from "ol/source";
import VectorSource from "ol/source/Vector";
import { Fill, Stroke, Style } from "ol/style";
import View from "ol/View";
import proj4 from "proj4";
import { onMounted, onUnmounted, ref } from "vue";
import MapToolbar from "./MapToolbar/MapToolbar.vue";

// Definizione EPSG:3004
proj4.defs(
	"EPSG:3004",
	"+proj=tmerc +lat_0=0 +lon_0=15 +k=0.9996 +x_0=2520000 +y_0=0 +ellps=intl +units=m +no_defs"
);
register(proj4);
const projection = getProjection("EPSG:3004");

export interface IPolygonData {
	plotId: string;
	landUseCode: string;
	geometry: string;
	isSelected: boolean;
}

const { map, mapRef } = useMap();

const props = defineProps<{
	polygons: IPolygonData[];
	isNewMunicipality: boolean;
}>();

const emit = defineEmits([
	"selectedPlotLandFromOpenLayerMap",
	"setFalseNewMunicipality",
]);

// Espone la funzione al genitore
defineExpose({
	updatePolygonsInMapOpenLayer,
});

const vectorSource: VectorSource = new VectorSource();
const isFirstLoading = ref<boolean>(true);

onMounted(async () => {
	if (!projection || !mapRef.value) return;

	vectorSource.clear();

	const vectorLayer = new VectorLayer({
		source: vectorSource,
		style: new Style({
			stroke: new Stroke({ color: "blue", width: 2 }),
			fill: new Fill({ color: "rgba(0, 0, 255, 0.1)" }),
		}),
	});
	vectorLayer.setZIndex(10);

	const baseLayer = new TileLayer({
		source: new OSM(),
	});

	map.setTarget(mapRef.value);
	map.addLayer(baseLayer);
	map.addLayer(vectorLayer);
	map.setView(
		new View({
			projection,
			center: [2527500, 4567500],
			zoom: 14,
		})
	);

	const select = new Select();
	map.addInteraction(select);

	map.on("click", e => {
		const pixel = map.getPixelFromCoordinate(e.coordinate);
		const feature = map.forEachFeatureAtPixel(pixel, f => f as Feature);

		if (feature) {
			emit("selectedPlotLandFromOpenLayerMap", feature.get("plotId"));
		}
	});
});

function updatePolygonsInMapOpenLayer(
	polygons: IPolygonData[],
	takeLandUseCodeFromFirstCheckBoxSelected: string | null
) {
	const wkt = new WKT();

	let newPolygons: IPolygonData[] = [];

	if (polygons.length == 0) return;

	const findElementSelect = polygons.find(polygon => polygon.isSelected);

	if (takeLandUseCodeFromFirstCheckBoxSelected != null) {
		newPolygons = polygons.filter(
			polygon => polygon.landUseCode == takeLandUseCodeFromFirstCheckBoxSelected
		);
	} else if (findElementSelect != null) {
		newPolygons = polygons.filter(
			polygon => polygon.landUseCode == findElementSelect.landUseCode
		);
	} else if (!findElementSelect && !takeLandUseCodeFromFirstCheckBoxSelected) {
		newPolygons = polygons;
	}

	vectorSource.clear();
	newPolygons.forEach(polygon => {
		const feature = wkt.readFeature(polygon.geometry, {
			dataProjection: "EPSG:3004",
			featureProjection: "EPSG:3004",
		});
		feature.set("plotId", polygon.plotId);

		if (polygon.isSelected) {
			feature.setStyle(
				new Style({
					stroke: new Stroke({ color: "orange", width: 2 }),
					fill: new Fill({ color: "rgba(0, 0, 255, 0.1)" }),
				})
			);
		}
		vectorSource?.addFeature(feature);
	});

	if (isFirstLoading.value || props.isNewMunicipality) {
		centerMapGetExtent();
	}
}

function centerMapGetExtent() {
	if (
		vectorSource?.getFeatures()?.length != undefined &&
		vectorSource?.getFeatures()?.length > 0
	) {
		map.getView().fit(vectorSource.getExtent());
		isFirstLoading.value = false;
		emit("setFalseNewMunicipality");
	}
}

onUnmounted(async () => {
	vectorSource.clear();
});
</script>

<template>
	<div class="application-forms-module__map-viewer">
		<div ref="mapRef" class="map application-forms-module__map">
			<div
				class="position-absolute d-flex align-items-center flex-row primary-bg-b7 z-index-1 rounded top-and-right">
				<MapToolbar @centerMap="centerMapGetExtent" />
			</div>
		</div>
	</div>
</template>

<style scoped>
.map {
	width: 100%;
	height: 50vh;
}

.top-and-right {
	top: 0;
	right: 0;
}
</style>
