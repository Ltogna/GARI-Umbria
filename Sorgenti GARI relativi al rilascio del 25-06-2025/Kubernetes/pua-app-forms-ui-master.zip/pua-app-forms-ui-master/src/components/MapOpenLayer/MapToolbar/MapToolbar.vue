<script setup lang="ts">
import { useMap } from "@/composables/useMap";
import useModuleId from "@/composables/useModuleId";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import { useI18n } from "vue-i18n";

const moduleId = useModuleId();
const { t } = useI18n();
const { isFullscreen, zoomIn, zoomOut, toggleFullscreen } = useMap();

const emit = defineEmits(["centerMap"]);
</script>

<template>
	<!-- End of layer dropdown -->
	<BiButton
		class="shadow-none text-white"
		:width="40"
		is-icon
		:title="t(`${moduleId}.openLayer.zoomIn`)"
		@click="zoomIn">
		<BiIcon icon="magnifying-glass-plus" size="xl" />
	</BiButton>
	<BiButton
		class="shadow-none text-white"
		:width="40"
		is-icon
		:title="t(`${moduleId}.openLayer.zoomOut`)"
		@click="zoomOut">
		<BiIcon icon="magnifying-glass-minus" size="xl" />
	</BiButton>
	<BiButton
		class="shadow-none text-white"
		is-icon
		:width="40"
		@click="emit('centerMap')">
		<BiIcon icon="crosshairs" size="xl" />
	</BiButton>
	<BiButton
		class="shadow-none text-white"
		:width="40"
		is-icon
		:title="t(`${moduleId}.openLayer.fullscreen`)"
		@click="toggleFullscreen">
		<BiIcon :icon="isFullscreen ? 'compress' : 'expand'" size="xl" />
	</BiButton>
</template>
