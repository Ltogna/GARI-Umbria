<script setup lang="ts">
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { computed, inject, onMounted, reactive, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";
import type { balanceIndicesProgressInterface } from "./balanceIndicesProgressInterface";
import ProgressInput from "./ProgressInput.vue";

const router = useRouter();
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const applicationFormsStore = useApplicationFormsStore();
const balanceList = computed(() => {
	return applicationFormsStore.getBalanceIndicesListResponse.records;
});

const form = reactive<balanceIndicesProgressInterface>({
	superficie: {
		zonaZVN: 0,
		zonaZVN_Max: 0,
		zonaOrdinaria: 0,
		zonaOrdinaria_Max: 0,
		aziendale: 0,
		aziendale_Max: 0,
		cicloSecondarioZVN: 0,
		cicloSecondarioZVN_Max: 0,
		cicloSecondarioOrdinaria: 0,
		cicloSecondarioOrdinaria_Max: 0,
		cicloSecondarioAziendale: 0,
		cicloSecondarioAziendale_Max: 0,
		fertilizzataZVN: 0,
		fertilizzataZVN_Max: 0,
		fertilizzataOrdinaria: 0,
		fertilizzataOrdinaria_Max: 0,
		fertilizzataAziendale: 0,
		fertilizzataAziendale_Max: 0,
		effluentiZVN: 0,
		effluentiZVN_Max: 0,
		effluentiOrdinaria: 0,
		effluentiOrdinaria_Max: 0,
		effluentiAziendale: 0,
		effluentiAziendale_Max: 0,
	},
	azotoDistribuito: {
		zonaZVN: 0,
		zonaZVN_Max: 0,
		zonaOrdinaria: 0,
		zonaOrdinaria_Max: 0,
		totale: 0,
		totale_Max: 0,
		daLetamiZVN: 0,
		daLetamiZVN_Max: 0,
		daLetamiOrdinaria: 0,
		daLetamiOrdinaria_Max: 0,
		daLetamiTotale: 0,
		daLetamiTotale_Max: 0,
		daLiquamiZVN: 0,
		daLiquamiZVN_Max: 0,
		daLiquamiOrdinaria: 0,
		daLiquamiOrdinaria_Max: 0,
		daLiquamiTotale: 0,
		daLiquamiTotale_Max: 0,
	},
	medieApporto: {
		zootecnicoZVN: 0,
		zootecnicoZVN_Max: 0,
		zootecnicoOrdinaria: 0,
		zootecnicoOrdinaria_Max: 0,
		zootecnicoAziendale: 0,
		zootecnicoAziendale_Max: 0,
		daLetamiZVN: 0,
		daLetamiZVN_Max: 0,
		daLetamiOrdinaria: 0,
		daLetamiOrdinaria_Max: 0,
		daLetamiAziendale: 0,
		daLetamiAziendale_Max: 0,
		daLiquamiZVN: 0,
		daLiquamiZVN_Max: 0,
		daLiquamiOrdinaria: 0,
		daLiquamiOrdinaria_Max: 0,
		daLiquamiAziendale: 0,
		daLiquamiAziendale_Max: 0,
	},
});
const calculateGraphData = () => {
	calculateSuperfici();
	calculateAzoto();
	calculateMedieApportoAzoto();
};
function calculateSuperfici() {
	const totaleSuperficie = balanceList.value
		.filter(x => x.Ciclo_Principale === true)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);

	form.superficie.zonaZVN = balanceList.value
		.filter(x => x.ZVN === true && x.Ciclo_Principale === true)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.zonaZVN_Max = totaleSuperficie;

	form.superficie.zonaOrdinaria = balanceList.value
		.filter(x => x.ZVN === false && x.Ciclo_Principale === true)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.zonaOrdinaria_Max = totaleSuperficie;

	form.superficie.aziendale = totaleSuperficie;
	form.superficie.aziendale_Max = totaleSuperficie;

	//sp Row 2
	const totaleSuperFiciCS = balanceList.value
		.filter(x => x.Ciclo_Principale === false)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);

	form.superficie.cicloSecondarioZVN = balanceList.value
		.filter(x => x.ZVN === true && x.Ciclo_Principale === false)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.cicloSecondarioZVN_Max = totaleSuperFiciCS;

	form.superficie.cicloSecondarioOrdinaria = balanceList.value
		.filter(x => x.ZVN === false && x.Ciclo_Principale === false)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.cicloSecondarioOrdinaria_Max = totaleSuperFiciCS;

	form.superficie.cicloSecondarioAziendale = totaleSuperFiciCS;
	form.superficie.cicloSecondarioAziendale_Max = totaleSuperFiciCS;

	//sp Row 3
	const totaleSuperFiciFert = balanceList.value
		.filter(x => x.N_TotaleSoddisfatto > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);

	form.superficie.fertilizzataZVN = balanceList.value
		.filter(x => x.ZVN === true && x.N_TotaleSoddisfatto > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.fertilizzataZVN_Max = totaleSuperFiciFert;

	form.superficie.fertilizzataOrdinaria = balanceList.value
		.filter(x => x.ZVN === false && x.N_TotaleSoddisfatto > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.fertilizzataOrdinaria_Max = totaleSuperFiciFert;

	form.superficie.fertilizzataAziendale = totaleSuperFiciFert;
	form.superficie.fertilizzataAziendale_Max = totaleSuperFiciFert;
	//sp Row 4
	const totaleSuperFiciFertEFF = balanceList.value
		.filter(x => x.N_Zootecnico > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);

	form.superficie.effluentiZVN = balanceList.value
		.filter(x => x.ZVN === true && x.N_Zootecnico > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.effluentiZVN_Max = totaleSuperFiciFertEFF;

	form.superficie.effluentiOrdinaria = balanceList.value
		.filter(x => x.ZVN === false && x.N_Zootecnico > 0)
		.reduce((sum, item) => sum + (item.N_Superfice ?? 0), 0);
	form.superficie.effluentiOrdinaria_Max = totaleSuperFiciFertEFF;

	form.superficie.effluentiAziendale = totaleSuperFiciFertEFF;
	form.superficie.effluentiAziendale_Max = totaleSuperFiciFertEFF;
}

function calculateAzoto() {
	//row1
	const totaleSuperficie = balanceList.value.reduce(
		(sum, item) => sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico ?? 0),
		0
	);

	form.azotoDistribuito.zonaZVN = balanceList.value
		.filter(x => x.ZVN === true)
		.reduce(
			(sum, item) => sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico ?? 0),
			0
		);

	form.azotoDistribuito.zonaZVN_Max = totaleSuperficie;

	form.azotoDistribuito.zonaOrdinaria = balanceList.value
		.filter(x => x.ZVN === false)
		.reduce(
			(sum, item) => sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico ?? 0),
			0
		);
	form.azotoDistribuito.zonaOrdinaria_Max = totaleSuperficie;

	form.azotoDistribuito.totale = totaleSuperficie;
	form.azotoDistribuito.totale_Max = totaleSuperficie;

	//row2
	const totaleSuperfice_letami = balanceList.value.reduce(
		(sum, item) =>
			sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Letame ?? 0),
		0
	);

	form.azotoDistribuito.daLetamiZVN = balanceList.value
		.filter(x => x.ZVN === true)
		.reduce(
			(sum, item) =>
				sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Letame ?? 0),
			0
		);

	form.azotoDistribuito.daLetamiZVN_Max = totaleSuperfice_letami;

	form.azotoDistribuito.daLetamiOrdinaria = balanceList.value
		.filter(x => x.ZVN === false)
		.reduce(
			(sum, item) =>
				sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Letame ?? 0),
			0
		);
	form.azotoDistribuito.daLetamiOrdinaria_Max = totaleSuperfice_letami;

	form.azotoDistribuito.daLetamiTotale = totaleSuperfice_letami;
	form.azotoDistribuito.daLetamiTotale_Max = totaleSuperfice_letami;

	//row3
	const totaleSuperficie_liquami = balanceList.value.reduce(
		(sum, item) =>
			sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Liquame ?? 0),
		0
	);

	form.azotoDistribuito.daLiquamiZVN = balanceList.value
		.filter(x => x.ZVN === true)
		.reduce(
			(sum, item) =>
				sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Liquame ?? 0),
			0
		);

	form.azotoDistribuito.daLiquamiZVN_Max = totaleSuperficie_liquami;

	form.azotoDistribuito.daLiquamiOrdinaria = balanceList.value
		.filter(x => x.ZVN === false)
		.reduce(
			(sum, item) =>
				sum + (item.N_Superfice ?? 0) * (item.N_Zootecnico_Liquame ?? 0),
			0
		);
	form.azotoDistribuito.daLiquamiOrdinaria_Max = totaleSuperficie_liquami;

	form.azotoDistribuito.daLiquamiTotale = totaleSuperficie_liquami;
	form.azotoDistribuito.daLiquamiTotale_Max = totaleSuperficie_liquami;
}
function calculateMedieApportoAzoto() {
	form.medieApporto.zootecnicoZVN =
		!Number.isNaN(form.azotoDistribuito.zonaZVN / form.superficie.zonaZVN) &&
		form.superficie.zonaZVN != 0
			? form.azotoDistribuito.zonaZVN / form.superficie.zonaZVN
			: 0;
	form.medieApporto.zootecnicoZVN_Max = 170;

	form.medieApporto.zootecnicoOrdinaria =
		!Number.isNaN(
			form.azotoDistribuito.zonaOrdinaria / form.superficie.zonaOrdinaria
		) && form.superficie.zonaOrdinaria != 0
			? form.azotoDistribuito.zonaOrdinaria / form.superficie.zonaOrdinaria
			: 0;
	form.medieApporto.zootecnicoOrdinaria_Max = 340;

	form.medieApporto.zootecnicoAziendale =
		!Number.isNaN(form.azotoDistribuito.totale / form.superficie.aziendale) &&
		form.superficie.aziendale != 0
			? form.azotoDistribuito.totale / form.superficie.aziendale
			: 0;
	form.medieApporto.zootecnicoAziendale_Max =
		form.medieApporto.zootecnicoZVN + form.medieApporto.zootecnicoOrdinaria;

	// row 2
	form.medieApporto.daLetamiZVN =
		!Number.isNaN(
			form.azotoDistribuito.daLetamiZVN / form.superficie.zonaZVN
		) && form.superficie.zonaZVN != 0
			? form.azotoDistribuito.daLetamiZVN / form.superficie.zonaZVN
			: 0;
	form.medieApporto.daLetamiZVN_Max = 170;

	form.medieApporto.daLetamiOrdinaria =
		!Number.isNaN(
			form.azotoDistribuito.daLetamiOrdinaria / form.superficie.zonaOrdinaria
		) && form.superficie.zonaOrdinaria != 0
			? form.azotoDistribuito.daLetamiOrdinaria / form.superficie.zonaOrdinaria
			: 0;
	form.medieApporto.daLetamiOrdinaria_Max = 340;

	form.medieApporto.daLetamiAziendale =
		!Number.isNaN(
			form.azotoDistribuito.daLetamiTotale / form.superficie.aziendale
		) && form.superficie.aziendale != 0
			? form.azotoDistribuito.daLetamiTotale / form.superficie.aziendale
			: 0;
	form.medieApporto.daLetamiAziendale_Max =
		form.medieApporto.daLetamiZVN + form.medieApporto.daLetamiOrdinaria;

	// row 3
	form.medieApporto.daLiquamiZVN =
		!Number.isNaN(
			form.azotoDistribuito.daLiquamiZVN / form.superficie.zonaZVN
		) && form.superficie.zonaZVN != 0
			? form.azotoDistribuito.daLiquamiZVN / form.superficie.zonaZVN
			: 0;
	form.medieApporto.daLiquamiZVN_Max = 170;

	form.medieApporto.daLiquamiOrdinaria =
		!Number.isNaN(
			form.azotoDistribuito.daLiquamiOrdinaria / form.superficie.zonaOrdinaria
		) && form.superficie.zonaOrdinaria != 0
			? form.azotoDistribuito.daLiquamiOrdinaria / form.superficie.zonaOrdinaria
			: 0;
	form.medieApporto.daLiquamiOrdinaria_Max = 240;

	form.medieApporto.daLiquamiAziendale =
		!Number.isNaN(
			form.azotoDistribuito.daLiquamiTotale / form.superficie.aziendale
		) && form.superficie.aziendale != 0
			? form.azotoDistribuito.daLiquamiTotale / form.superficie.aziendale
			: 0;
	form.medieApporto.daLiquamiAziendale_Max =
		form.medieApporto.daLiquamiOrdinaria + form.medieApporto.daLiquamiZVN;
}

function goToBalanceIndices() {
	router.push({ name: "balanceIndices", query: { noReload: "true" } });
}
onMounted(async () => {
	calculateGraphData();
});
watch(balanceList, () => {
	calculateGraphData();
});
</script>
<template>
	<div>
		<div class="row pb-3 pt-3">
			<div class="col-8">
				<h5 class="fw-bold" :class="getColor('text', 'primary')">
					{{ t(`${moduleId}.balanceIndices.page.title`) }}
				</h5>
			</div>
		</div>
		<div class="row my-3 justify-content-start">
			<div class="d-flex justify-content-between">
				<div class="col-10">
					<h6 class="fw-bold" :class="getColor('text', 'primary')">
						<p>
							{{ t(`${moduleId}.balanceIndices.table.title`) }}
						</p>
					</h6>
				</div>
				<BiButton
					type="submit"
					class="mx-1 mb-2 col-auto"
					:class="`${getColor('button', 'primary', 'outline')}`"
					@click="goToBalanceIndices">
					{{ t(`${moduleId}.balanceIndices.button.balanceIndices`) }}
				</BiButton>
			</div>
		</div>

		<!-- Superfici -->
		<div class="section-box mb-4">
			<h5 class="section-title">
				{{ t(`${moduleId}.balanceIndices.progressBar.labels.superfici`) }}
			</h5>
			<div class="row d-flex align-items-end">
				<ProgressInput
					:label="t(`${moduleId}.balanceIndices.progressBar.labels.zonaZVN`)"
					:disable-bar-color="true"
					v-model="form.superficie.zonaZVN"
					:max="form.superficie.zonaZVN_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.zonaOrdinaria`)
					"
					:disable-bar-color="true"
					v-model="form.superficie.zonaOrdinaria"
					:max="form.superficie.zonaOrdinaria_Max" />
				<ProgressInput
					:label="t(`${moduleId}.balanceIndices.progressBar.labels.aziendale`)"
					:disable-bar-color="true"
					v-model="form.superficie.aziendale"
					:max="form.superficie.aziendale_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.cicloSecondarioZVN`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.cicloSecondarioZVN"
					:max="form.superficie.cicloSecondarioZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.cicloSecondarioOrdinaria`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.cicloSecondarioOrdinaria"
					:max="form.superficie.cicloSecondarioOrdinaria_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.cicloSecondarioAziendale`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.cicloSecondarioAziendale"
					:max="form.superficie.cicloSecondarioAziendale_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.fertilizzataZVN`)
					"
					:disable-bar-color="true"
					v-model="form.superficie.fertilizzataZVN"
					:max="form.superficie.fertilizzataZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.fertilizzataOrdinaria`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.fertilizzataOrdinaria"
					:max="form.superficie.fertilizzataOrdinaria_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.fertilizzataAziendale`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.fertilizzataAziendale"
					:max="form.superficie.fertilizzataAziendale_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.effluentiZVN`)
					"
					:disable-bar-color="true"
					v-model="form.superficie.effluentiZVN"
					:max="form.superficie.effluentiZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.effluentiOrdinaria`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.effluentiOrdinaria"
					:max="form.superficie.effluentiOrdinaria_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.effluentiAziendale`
						)
					"
					:disable-bar-color="true"
					v-model="form.superficie.effluentiAziendale"
					:max="form.superficie.effluentiAziendale_Max" />
			</div>
		</div>

		<!-- Azoto Zootecnico Distribuito -->
		<div class="section-box mb-4">
			<h5 class="section-title">
				{{ t(`${moduleId}.balanceIndices.progressBar.labels.azoto`) }}
			</h5>
			<div class="row d-flex align-items-end">
				<ProgressInput
					:label="t(`${moduleId}.balanceIndices.progressBar.labels.azotoZVN`)"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.zonaZVN"
					:max="form.azotoDistribuito.zonaZVN_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.azotoOrdinaria`)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.zonaOrdinaria"
					:max="form.azotoDistribuito.zonaOrdinaria_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.azotoTotale`)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.totale"
					:max="form.azotoDistribuito.totale_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.azotoLetamiZVN`)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLetamiZVN"
					:max="form.azotoDistribuito.daLetamiZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.azotoLetamiOrdinaria`
						)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLetamiOrdinaria"
					:max="form.azotoDistribuito.daLetamiOrdinaria_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.azotoLetamiTotale`)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLetamiTotale"
					:max="form.azotoDistribuito.daLetamiTotale_Max" />
				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.azotoLiquamiZVN`)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLiquamiZVN"
					:max="form.azotoDistribuito.daLiquamiZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.azotoLiquamiOrdinaria`
						)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLiquamiOrdinaria"
					:max="form.azotoDistribuito.daLiquamiOrdinaria_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.azotoLiquamiTotale`
						)
					"
					:disable-bar-color="true"
					v-model="form.azotoDistribuito.daLiquamiTotale"
					:max="form.azotoDistribuito.daLiquamiTotale_Max" />
			</div>
		</div>

		<!-- Medie Apporto Azoto -->
		<div class="section-box mb-4">
			<h5 class="section-title">
				{{
					t(`${moduleId}.balanceIndices.progressBar.labels.medieapportoazoto`)
				}}
			</h5>
			<div class="row d-flex align-items-end">
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.apportoZootecnicoZVN`
						)
					"
					v-model="form.medieApporto.zootecnicoZVN"
					:max="form.medieApporto.zootecnicoZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.apportoZootecnicoOrdinaria`
						)
					"
					v-model="form.medieApporto.zootecnicoOrdinaria"
					:max="form.medieApporto.zootecnicoOrdinaria_Max" />

				<div class="balanceindexes-value-container col-md-4 mb-3">
					<div class="balanceindexes-value-label fw-bold text-dark">
						{{
							t(
								`${moduleId}.balanceIndices.progressBar.labels.apportoZootecnicoAziendale`
							)
						}}
					</div>
					<div class="balanceindexes-value-content fw-bold text-dark">
						{{ form.medieApporto.zootecnicoAziendale.toFixed(4) }}
					</div>
				</div>

				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.apportoLetamiZVN`)
					"
					v-model="form.medieApporto.daLetamiZVN"
					:max="form.medieApporto.daLetamiZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.apportoLetamiOrdinaria`
						)
					"
					v-model="form.medieApporto.daLetamiOrdinaria"
					:max="form.medieApporto.daLetamiOrdinaria_Max" />

				<div class="balanceindexes-value-container col-md-4 mb-3">
					<div class="balanceindexes-value-label fw-bold text-dark">
						{{
							t(
								`${moduleId}.balanceIndices.progressBar.labels.apportoLetamiAziendale`
							)
						}}
					</div>
					<div class="balanceindexes-value-content fw-bold text-dark">
						{{ form.medieApporto.daLetamiAziendale.toFixed(4) }}
					</div>
				</div>

				<ProgressInput
					:label="
						t(`${moduleId}.balanceIndices.progressBar.labels.apportoLiquamiZVN`)
					"
					v-model="form.medieApporto.daLiquamiZVN"
					:max="form.medieApporto.daLiquamiZVN_Max" />
				<ProgressInput
					:label="
						t(
							`${moduleId}.balanceIndices.progressBar.labels.apportoLiquamiOrdinaria`
						)
					"
					v-model="form.medieApporto.daLiquamiOrdinaria"
					:max="form.medieApporto.daLiquamiOrdinaria_Max" />

				<div class="balanceindexes-value-container col-md-4 mb-3">
					<div class="balanceindexes-value-label fw-bold text-dark">
						{{
							t(
								`${moduleId}.balanceIndices.progressBar.labels.apportoLiquamiAziendale`
							)
						}}
					</div>
					<div class="balanceindexes-value-content fw-bold text-dark">
						{{ form.medieApporto.daLiquamiAziendale.toFixed(4) }}
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<style>
.section-box {
	border: 1px solid #b3d7ff;
	border-radius: 5px;
	padding: 15px 20px;
	background-color: #f4faff;
	box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
}

.section-title {
	font-weight: 600;
	font-size: 1rem;
	color: #003366;
	margin-bottom: 15px;
	text-transform: uppercase;
	letter-spacing: 0.5px;
}

input.form-control {
	height: 28px;
	font-size: 0.85rem;
}

.balanceindexes-value-container {
	align-self: start;
}

.balanceindexes-averages > div {
	align-self: start;
}
</style>
