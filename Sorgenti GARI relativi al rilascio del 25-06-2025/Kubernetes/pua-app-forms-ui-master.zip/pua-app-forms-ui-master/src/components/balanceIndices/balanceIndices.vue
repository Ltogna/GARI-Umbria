<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { useRouter } from "vue-router";

// Boootstrap Italia components
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

import type {
	IFilterChipChemicalAndOrganicaFertilizer,
	IFilterStoreChemicalAndOrganicaFertilizer,
} from "../ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizer.vue";

import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";

// others
import {
	MunicipalityRecordListResponseSchema,
	type AppezzamentoRequest,
	type BalanceIndicesRequest,
	type getBalanceIndicesResponse,
	type MunicipalityRecordListResponse,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";

import { toTypedSchema } from "@vee-validate/zod";
import { debounce } from "lodash";
import { useField } from "vee-validate";

// const component
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();
const router = useRouter();

export interface IEditElement {
	id: number | undefined;
	partyId: number | null;
	company: string;
}

const partyCodeSelf = computed(() => queryFieldsStore.getPartyCode);
const noData = ref(false);
const municipalityListResponseMap = ref<IListMap>({});
const landUseListResponseMap = ref<IListMap>({});

const getBalanceIndicesList = computed(
	() => applicationFormsStore.getBalanceIndicesListResponse
);

const getPlotLandListAndPreviousManure = computed(
	() => applicationFormsStore.getPlotLandListAndPreviousManureResponse
);

const municipalityCodeList = computed(() =>
	getBalanceIndicesList.value.records.reduce(
		(acc: string[], el: getBalanceIndicesResponse) => {
			if (el && el.sectorCode != null && !acc.includes(el.sectorCode)) {
				acc.push(el.sectorCode);
			}
			return acc;
		},
		[]
	)
);

const landUseCodeList = computed(() =>
	getBalanceIndicesList.value.records.reduce(
		(acc: string[], el: getBalanceIndicesResponse) => {
			if (el && el.landUseCode != null && !acc.includes(el.landUseCode)) {
				acc.push(el.landUseCode);
			}
			return acc;
		},
		[]
	)
);

const isFilterForSectorCodeVisible = ref<boolean>(false);

const showFilterForSearchModal = ref<boolean>(false);
const getPlotLandFilterObject = computed(() => {
	const getPlotLandFilterObjectFn =
		{} as IFilterStoreChemicalAndOrganicaFertilizer;

	if (sectorCode.value != null && sectorCode.value.sector_code != null) {
		getPlotLandFilterObjectFn.sectorCode = sectorCode.value;
	}

	return getPlotLandFilterObjectFn;
});

const { value: sectorCode } = useField<MunicipalityRecordListResponse>(
	"sectorCode",
	toTypedSchema(MunicipalityRecordListResponseSchema.nullish())
);
const municipalityList = ref<MunicipalityRecordListResponse[]>([]);
const municipalityCodeFilter = ref<string>("");
const isMunicipalityListLoadingDataFilter = ref<boolean>(false);
const minSearchLenghtMunicipality = ref<number>(3);

const municipalityListResponse = computed(
	() => applicationFormsStore.municipalityList
);
const isNextMunicipalityValid = ref<string | null | undefined>(null);

const chipFilterDescription = ref<IFilterChipChemicalAndOrganicaFertilizer>({
	sectorDescription: "",
	landUseDescription: "",
});

function findSuperfice(balance: getBalanceIndicesResponse) {
	const plotLandList =
		applicationFormsStore.getPlotLandListAndPreviousManureResponse || [];
	const area = plotLandList.find(
		x => x.declCode == balance.Chiave_Appezzamento
	)?.areaSqm;
	if (area != null) balance.N_Superfice = Number(area);
}

const balanceList = computed(() => {
	const records = applicationFormsStore.getBalanceIndicesListResponse.records;
	records.forEach(x => {
		findSuperfice(x);
	});
	applicationFormsStore.getBalanceIndicesListResponse.records = records;
	return applicationFormsStore.getBalanceIndicesListResponse.records;
});

onMounted(async () => {
	const shouldReload = router.currentRoute.value.query.noReload !== "true";
	if (shouldReload) {
		queryFieldsStore.populateState();
		await applicationFormsStore.getPlotsLandListAndPreviousManure(false);
		if (!noData.value) {
			const request = createRequestModel();
			await applicationFormsStore.getBalanceIndicesList(request);
			if (getBalanceIndicesList.value.records.length > 0) {
				await tableDataMappingDescriptionFromCodeForMunicipality();
			} else {
				isDataTableReady.value = true;
			}
		}
	}
});

async function tableDataMappingDescriptionFromCodeForMunicipality() {
	isDataTableReady.value = false;

	initItemListFiltersInEmptyArray();

	getBalanceIndicesList.value.records.map(balanceIndicesItem => {
		if (balanceIndicesItem != null && balanceIndicesItem.N_Superfice != null) {
			if (balanceIndicesItem.N_Superfice != null) {
				balanceIndicesItem.N_Superfice = balanceIndicesItem.N_Superfice / 10000;
			}

			balanceIndicesItem.sectorCode =
				getPlotLandListAndPreviousManure.value.find(
					x => x.declCode == balanceIndicesItem.Chiave_Appezzamento
				)?.sectorCode;

			balanceIndicesItem.landUseCode =
				getPlotLandListAndPreviousManure.value.find(
					x => x.declCode == balanceIndicesItem.Chiave_Appezzamento
				)?.landUseCode;
		}
		return balanceIndicesItem;
	});

	await applicationFormsStore.loadMunicipalityListFromCode(
		municipalityCodeList.value
	);
	createMapMunicipalityList();

	await applicationFormsStore.loadLandUseListFromCode(landUseCodeList.value);
	createMapLandUseListMap();

	getBalanceIndicesList.value.records.map(balanceIndicesItem => {
		if (balanceIndicesItem != null) {
			if (balanceIndicesItem.sectorCode != null) {
				balanceIndicesItem.sectorDescription =
					municipalityListResponseMap.value[balanceIndicesItem.sectorCode];

				municipalityList.value.push({
					description: balanceIndicesItem.sectorDescription,
					sector_code: balanceIndicesItem.sectorCode,
				});
			}

			if (balanceIndicesItem.landUseCode != null) {
				balanceIndicesItem.landUseDescription =
					landUseListResponseMap.value[balanceIndicesItem.landUseCode];
			}
		}
		return balanceIndicesItem;
	});

	const uniqueArrMunicipalityList: readonly MunicipalityRecordListResponse[] =
		Object.freeze(
			Array.from(
				municipalityList.value
					.reduce((map, obj) => {
						map.set(`${obj?.description}`, obj);
						return map;
					}, new Map<string, MunicipalityRecordListResponse>())
					.values()
			)
		);

	municipalityList.value = uniqueArrMunicipalityList.slice();

	isDataTableReady.value = true;
}

function initItemListFiltersInEmptyArray() {
	municipalityList.value = [];
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

function createMapLandUseListMap() {
	if (applicationFormsStore.landUseListFromCodeResponse) {
		applicationFormsStore.landUseListFromCodeResponse.land_uses_codes_list.map(
			el => {
				landUseListResponseMap.value[el.land_uses_code] = el.description;
			}
		);
	}
}

const createRequestModel = (): BalanceIndicesRequest => {
	const plotLandList =
		applicationFormsStore.getPlotLandListAndPreviousManureResponse || [];
	const elencoAppezzamenti: Array<AppezzamentoRequest> = [];
	if (plotLandList == null || plotLandList.length == 0) {
		noData.value = true;
	} else {
		noData.value = false;
	}
	for (const item of plotLandList) {
		elencoAppezzamenti.push({
			Chiave_Appezzamento: item.declCode ?? "",
			N_Mas: item.mas ?? 0,
			N_Fabbisogno: item.distributableNitrogen ?? 0,
			ZVN: item.flZvn,
			Ciclo_Principale: item.cycle == 0,
		});
	}
	const requestPayload: BalanceIndicesRequest = {
		Cuaa: partyCodeSelf.value,
		Regolamento_Cod: 125,
		ElencoAppezzamenti: elencoAppezzamenti,
	};
	return requestPayload;
};

function goToBalanceIndicesDetails() {
	router.push({ name: "balanceIndicesDetails" });
}
const isDataTableReady = ref<boolean>(false);

const getBalanceColor = (value: number, type: "utile" | "totale") => {
	if (type === "utile") {
		if (value <= 0) return "custom-green"; // green
		if (value <= 30) return "custom-orange"; // orange
		return "custom-red"; // red
	}
	if (type === "totale") {
		if (value <= 0) return "custom-green";
		if (value <= 50) return "custom-orange";
		return "custom-red";
	}
	return "";
};

const rowCollapseState = ref<Record<number, boolean>>({});
watch(
	() => balanceList.value, // 👈 unwrap computed here
	newList => {
		newList.forEach((_, index) => {
			if (!(index in rowCollapseState.value)) {
				rowCollapseState.value[index] = false;
			}
		});
	},
	{ immediate: true }
);

function toggleFilterSearch(toggleValue: boolean) {
	showFilterForSearchModal.value = toggleValue;
}

async function plotLandListFilterAndSaveFilterObjectInStore() {
	setChipFilterDescriptionForChipBeforeTable();
	toggleFilterSearch(false);

	applicationFormsStore.saveDataInStore(
		"ChemicalAndOrganic",
		"filterObject",
		getPlotLandFilterObject.value
	);

	getBalanceIndicesListFitlerFrontEnd();
}

function getBalanceIndicesListFitlerFrontEnd() {
	//  da aggiungere il passaggio dei filtri tra i componenti
	// per adesso non usato preparato per dopo da aggiungere la logica next key per adesso non usato
	const nextKey = 0;

	if (
		getBalanceIndicesList.value != null &&
		getBalanceIndicesList.value.records[0].sectorCode != null &&
		getBalanceIndicesList.value.records[0].sectorCode.length > 0
	) {
		let sectorCode = "";
		if (getBalanceIndicesList.value.records[0].sectorCode != null) {
			sectorCode = getBalanceIndicesList.value.records[0].sectorCode;
		}

		// filtroFrontEnd()
	} else {
		// ottinei i dati()
		applicationFormsStore.loadGraphicCropPlanList();
	}
}

function setChipFilterDescriptionForChipBeforeTable() {
	isFilterForSectorCodeVisible.value = false;

	if (sectorCode.value != null && sectorCode.value.sector_code != null) {
		isFilterForSectorCodeVisible.value = true;

		chipFilterDescription.value["sectorDescription"] =
			t(`${moduleId}.ChemicalAndOrganicFertilizer.table.municipality`) +
			` ${sectorCode.value.description}`;
	}
}

async function resetFilterValueAndClearFilterInStore() {
	toggleFilterSearch(false);

	if (sectorCode.value?.sector_code == null) {
		return;
	}
	sectorCode.value = null;

	applicationFormsStore.clearDataInStore("ChemicalAndOrganic", "filterObject");
	await plotLandListFilterAndSaveFilterObjectInStore();
}

function onSearchChangeMunicipalityListCode(val: string) {
	municipalityCodeFilter.value = val;
}

const onKeyupMunicipalityCode = debounce(async () => {
	const isMunicipalityFilterForAllDisabled = true;
	if (!isMunicipalityFilterForAllDisabled) {
		if (municipalityCodeFilter.value.length >= 3) {
			isMunicipalityListLoadingDataFilter.value = true;
			await applicationFormsStore.loadMunicipalityList(
				municipalityCodeFilter.value
			);
			initMunicipalityList();
			isNextMunicipalityValid.value =
				applicationFormsStore.municipalityList?.nextKey;
			isMunicipalityListLoadingDataFilter.value = false;
		} else {
			municipalityList.value = [];
		}
	}
}, 500);

function initMunicipalityList() {
	municipalityList.value =
		municipalityList.value && municipalityListResponse.value
			? municipalityListResponse.value.records
			: [];
}
</script>
<template>
	<div>
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-else class="pb-3 pt-3">
			<div v-if="noData">
				<div class="row my-3 justify-content-start">
					<div class="col-12 row">
						<BiAlert :isInfo="true" v-if="noData">
							<template #body>
								<div>
									{{ t(`${moduleId}.balanceIndices.page.noDeclarations`) }}
								</div>
							</template>
						</BiAlert>
					</div>
				</div>
			</div>
			<div v-else>
				<div class="row">
					<div class="col-8">
						<h5 class="fw-bold" :class="getColor('text', 'primary')">
							{{ t(`${moduleId}.balanceIndices.page.title`) }}
						</h5>
					</div>
					<div class="col-4" v-if="false">
						<div class="d-flex justify-content-end">
							<BiTooltip
								:title="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
									)
								"
								:aria-label="
									t(
										`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
									)
								">
								<BiButton
									v-if="!applicationFormsStore.loading"
									type="submit"
									class="mx-1 mb-2 col-auto"
									:class="`${getColor('button', 'primary', 'outline')}`"
									@click.stop.prevent="toggleFilterSearch(true)">
									<span>
										<BiIcon icon="plus" size="lg" icon-style="regular" />
										{{
											t(
												`${moduleId}.ChemicalAndOrganicFertilizer.button.filters`
											)
										}}
									</span>
								</BiButton>
							</BiTooltip>
						</div>
					</div>
				</div>
				<div class="row my-3 justify-content-start" v-if="!noData">
					<div class="d-flex justify-content-between">
						<div class="col-10">
							<h6 class="fw-bold" :class="getColor('text', 'primary')">
								<p>
									{{ t(`${moduleId}.balanceIndices.table.title`) }}
								</p>
							</h6>
						</div>
						<BiButton
							type="submit"
							class="mx-1 mb-2 col-auto"
							:class="`${getColor('button', 'primary', 'outline')}`"
							@click="goToBalanceIndicesDetails">
							{{ t(`${moduleId}.balanceIndices.button.companyAverage`) }}
						</BiButton>
					</div>

					<div>
						<BiChip
							v-model="isFilterForSectorCodeVisible"
							:label="chipFilterDescription.sectorDescription" />
					</div>

					<BiTable
						class="table-responsive custom-table-style"
						extraTableClasses="table-head-bg"
						isResponsive>
						<template v-slot:head>
							<tr
								class="bg-light text-start"
								:class="getColor('text', 'secondary')">
								<th scope="col">
									{{
										t(`${moduleId}.balanceIndices.table.headers.municipality`)
									}}
								</th>
								<th scope="col">
									{{ t(`${moduleId}.balanceIndices.table.headers.landUse`) }}
								</th>
								<th scope="col">
									{{ t(`${moduleId}.balanceIndices.table.headers.nMas`) }}
								</th>
								<th scope="col">
									{{
										t(`${moduleId}.balanceIndices.table.headers.nFabbisogno`)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.balanceIndices.table.headers.nFabbisognoSoddisfatto`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.balanceIndices.table.headers.nBilancioAzotatoUtile`
										)
									}}
								</th>

								<th scope="col" class="text-center">
									{{ t(`${moduleId}.balanceIndices.table.headers.nUtile`) }}
								</th>

								<th scope="col">
									{{
										t(
											`${moduleId}.balanceIndices.table.headers.nTotaleSoddisfatto`
										)
									}}
								</th>
								<th scope="col">
									{{
										t(
											`${moduleId}.balanceIndices.table.headers.nBilancioAzotatoTotale`
										)
									}}
								</th>
								<th scope="col" class="text-center">
									{{ t(`${moduleId}.balanceIndices.table.headers.nTotal`) }}
								</th>
								<th scope="col">
									{{
										t(`${moduleId}.balanceIndices.table.headers.nZootecnico`)
									}}
								</th>
							</tr>
						</template>

						<template v-slot:body v-if="isDataTableReady">
							<template
								v-for="element in balanceList"
								:key="JSON.stringify(element)">
								<tr class="align-middle">
									<!-- <td class="text-end text-nowrap">
										<div>
											<BiCollapse
												tag="span"
												:targetSelector="`#balanceDetail-${index + 1}`"
												v-model="rowCollapseState[index]"
												class="accordion-collapse-icon">
												<BiIcon
													icon="chevron-down"
													style="cursor: pointer"
													:class="
														rowCollapseState[index]
															? 'collapse-icon'
															: undefined
													"
													:aria-label="
														t(`${moduleId}.balanceIndices.page.details`)
													"
													tabindex="0" />
											</BiCollapse>
										</div>
									</td> -->
									<td class="text-start">{{ element?.sectorDescription }}</td>
									<td class="text-start">{{ element?.landUseDescription }}</td>
									<td class="text-start">
										{{ element?.N_Superfice?.toFixed(4) }}
									</td>
									<td class="text-start">
										{{ element?.N_Fabbisogno?.toFixed(2) }}
									</td>
									<td class="text-start">
										{{ element?.N_FabbisognoSoddisfatto?.toFixed(2) }}
									</td>
									<td class="text-start">
										{{ element?.N_BilancioAzotato_Utile?.toFixed(2) }}
									</td>

									<td class="text-center">
										<span
											class="d-inline-block rounded-circle"
											:class="[
												'mx-auto',
												getBalanceColor(
													element?.N_BilancioAzotato_Utile,
													'utile'
												),
											]"
											style="width: 25px; height: 25px"></span>
									</td>

									<td class="text-start">
										{{ element?.N_TotaleSoddisfatto?.toFixed(2) }}
									</td>
									<td class="text-start">
										{{ element?.N_BilancioAzotato_Totale?.toFixed(2) }}
									</td>
									<td class="text-center">
										<span
											class="d-inline-block rounded-circle"
											:class="[
												'mx-auto',
												getBalanceColor(
													element?.N_BilancioAzotato_Totale,
													'totale'
												),
											]"
											style="width: 25px; height: 25px"></span>
									</td>

									<td class="text-start">
										{{ element?.N_Zootecnico?.toFixed(2) }}
									</td>
								</tr>
								<!-- <tr>
									<td class="p-0" colspan="12">
										<div :id="`balanceDetail-${index + 1}`">
											<CollapseTransition
												:show="!isLoading && rowCollapseState[index]">
												<div class="accordion-body">
													<BalanceIndicesDetail :balance-detail="element" />
												</div>
											</CollapseTransition>
										</div>
									</td>
								</tr> -->
							</template>
						</template>

						<template v-slot:body v-else>
							<tr>
								<td colspan="13" class="text-start">
									{{ t(`${moduleId}.general.noData`) }}
								</td>
							</tr>
						</template>
					</BiTable>
				</div>
			</div>
		</div>
	</div>

	<!-- filter for search modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showFilterForSearchModal"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:title="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="filterChemicalAndOrganicFertilizer"
				class="needs-validation"
				@submit.stop.prevent="plotLandListFilterAndSaveFilterObjectInStore()">
				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="municipalityCodeId"
							:id="'municipalityCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
							:items="municipalityList"
							:isAutocomplete="true"
							:loading="isMunicipalityListLoadingDataFilter"
							:showNoResults="!isMunicipalityListLoadingDataFilter"
							v-model="sectorCode"
							@searchChange="onSearchChangeMunicipalityListCode"
							@keyup="onKeyupMunicipalityCode"
							:minSearchLenght="minSearchLenghtMunicipality"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${municipalityCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtMunicipality}`
							"
							:itemTitle="'description'">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextMunicipalityValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>
			</form>
		</template>
		<template #footer>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
			<div v-else class="mt-3 mb-5 d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop.prevent="resetFilterValueAndClearFilterInStore()">
					{{ t(`${moduleId}.general.delete`) }}
				</BiButton>
				<BiButton
					type="submit"
					form="filterChemicalAndOrganicFertilizer"
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')">
					{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.button.applyFilter`) }}
				</BiButton>
			</div>
		</template>
	</BiModal>
</template>
<style scoped lang="scss">
@import "node_modules/bootstrap/scss/functions";
@import "node_modules/bootstrap/scss/variables";

.custom-table-style thead th {
	text-align: center !important; /* Horizontal center */
	vertical-align: top !important; /* Vertical top */
}
.custom-table-style tbody td {
	text-align: center !important; /* Horizontal center */
	vertical-align: top !important; /* Vertical top */
}
.custom-orange {
	background-color: $orange-400;
}
.custom-green {
	background-color: $green-400;
}
.custom-red {
	background-color: $danger;
}
</style>
