<script setup lang="ts">
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import { computed, defineProps } from "vue";

const props = defineProps<{
	label: string;
	modelValue: number;
	max: number;
	disableBarColor?: boolean | undefined;
}>();

const percentage = computed(() => {
	if (props.max === 0) return 0;
	return (props.modelValue / props.max) * 100;
});

const barColor = computed(() => {
	if (percentage.value > 90) return "danger";
	if (percentage.value > 70) return "warning";
	return "success";
});
</script>

<template>
	<div class="col-md-4 mb-3">
		<BiProgressIndicator
			type="bar"
			:currentValue="percentage"
			:barColor="disableBarColor ? 'info' : barColor"
			:extraWrapperClasses="'mb-2'">
			<template #legend>
				<div class="d-flex justify-content-between mb-1 fw-bold text-dark">
					<span>{{ label }}</span>
					<span class="text-nowrap">
						{{ modelValue.toFixed(4) + " " }}({{ percentage.toFixed(2) }}%)
					</span>
				</div>
			</template>
		</BiProgressIndicator>
	</div>
</template>
