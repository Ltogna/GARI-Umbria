<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import { IS_DEV } from "@/main";
import type { SaveDeclarationYearResponse } from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

const applicationFormsStore = useApplicationFormsStore();
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const queryFieldsStore = useQueryFieldsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);
const fiveYears = computed(() => queryFieldsStore.fiveYears === 1);
const showOnlyYear = computed(() => queryFieldsStore.showOnlyYear === 1);
const applicationId = computed(() => queryFieldsStore.getApplicationId);

const getDeclarationType = computed(
	() => applicationFormsStore.getDeclarationYearResponse
);

export interface IYearsList {
	id: string;
	text: string;
}

const showRequirementsAlert = ref<boolean>(false);
const isDataPresentInBackEnd = ref<boolean>(false);
const flLivestockAnimals = ref<string>("");
const flOrganicFertilizersField = ref<string>("");

onMounted(async () => {
	queryFieldsStore.populateState();
	initYearList();
	getDeclarationStoredInBackEndAndRequestType();
});

async function getDeclarationStoredInBackEndAndRequestType() {
	await applicationFormsStore.getDeclarationYear();
	initPageWithDataStoredInBackEndAndSwitchRequestTypeSaveOrEdit();
}

function initPageWithDataStoredInBackEndAndSwitchRequestTypeSaveOrEdit() {
	if (getDeclarationType.value?.applicationId) {
		yearsTypeCode.value = getDeclarationType.value.year.toString();
		flLivestockAnimals.value = getDeclarationType.value.flLivestocks
			? "1"
			: "0";
		flOrganicFertilizersField.value = getDeclarationType.value.flOrganicFert
			? "1"
			: "0";
		isDataPresentInBackEnd.value = true;
	} else {
		isDataPresentInBackEnd.value = false;
	}
}

const isFlLivestockAnimalsDisabled = computed(() => {
	if (flOrganicFertilizersField.value == "0") {
		flLivestockAnimals.value = "";
		return true;
	}

	return false;
});

const yearsTypeList = ref<IYearsList[]>([]);
const yearsTypeCode = ref<string>("");

function initYearList() {
	let attualYearDefaultSelect = IS_DEV ? 2024 : new Date().getFullYear();
	let defaultMaxYear = 10;

	if (fiveYears.value == true) {
		attualYearDefaultSelect -= 5;
		defaultMaxYear += 5;
	}

	const maxYears = attualYearDefaultSelect + defaultMaxYear;

	for (
		let yearCaculated = attualYearDefaultSelect;
		yearCaculated <= maxYears;
		yearCaculated++
	) {
		yearsTypeList.value.push({
			id: yearCaculated.toString(),
			text: yearCaculated.toString(),
		});
	}

	if (
		Number(yearsTypeList.value[0].text) >= attualYearDefaultSelect &&
		attualYearDefaultSelect <= Number(yearsTypeList.value[10].text)
	) {
		yearsTypeCode.value = attualYearDefaultSelect.toString();
	} else {
		yearsTypeCode.value = yearsTypeList.value[0].text;
	}
}

async function checkIfTabCompleted() {
	if (!flOrganicFertilizersField.value && !showOnlyYear.value) {
		showRequirementsAlert.value = true;
	} else {
		showRequirementsAlert.value = false;
		saveDeclaratioYear();
	}
}

async function saveDeclaratioYear() {
	const saveData: SaveDeclarationYearResponse = {
		applicationId: applicationId.value,
		year: Number(yearsTypeCode.value),
		flOrganicFert:
			flOrganicFertilizersField.value === "1" && !showOnlyYear.value
				? true
				: false,
		flLivestocks: flLivestockAnimals.value === "1" ? true : false,
	};

	if (isDataPresentInBackEnd.value) {
		await applicationFormsStore.editDeclarationYear(saveData);
		return;
	} else {
		await applicationFormsStore.saveDeclarationYear(saveData);
	}
	getDeclarationStoredInBackEndAndRequestType();
}
</script>

<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<form
			v-else
			id="DeclarationYearForm"
			ref="declarationYearFormRef"
			@submit.prevent="() => {}">
			<div class="container col-12 px-3 mx-0">
				<div class="row pb-3 pt-3">
					<div class="col-12">
						<div class="ps-2">
							<h5 class="fw-bold" :class="getColor('text', 'primary')">
								{{
									t(`${moduleId}.declarationYearForm.YearSectionField.title`)
								}}
							</h5>
							{{ t(`${moduleId}.declarationYearForm.YearSectionField.label`) }}
						</div>
					</div>
					<div class="col-12 col-sm-4 col-md-2 col-lg-2 col-xl-2">
						<div class="pt-4">
							<BiSelect
								name="yearId"
								:id="'yearId'"
								:items="yearsTypeList"
								:isMultiple="false"
								:isAutocomplete="false"
								v-model="yearsTypeCode"
								:disabled="isReadOnly"></BiSelect>
						</div>
					</div>
				</div>
				<div v-if="!showOnlyYear">
					<div class="row pb-3 pt-3">
						<div class="col-12">
							<div class="ps-2">
								<h5 class="fw-bold" :class="getColor('text', 'primary')">
									{{
										t(
											`${moduleId}.declarationYearForm.organicFertilizersField.title`
										)
									}}
								</h5>
								<div class="ps-2">
									{{
										t(
											`${moduleId}.declarationYearForm.organicFertilizersField.label`
										)
									}}
								</div>
								<div class="ps-2">
									{{
										t(
											`${moduleId}.declarationYearForm.organicFertilizersField.labelLineTwo`
										)
									}}
								</div>
							</div>
						</div>
						<div class="col-12">
							<div
								class="ps-2 ps-md-0 col-4 offset-2 d-flex justify-content-around">
								<BiRadiobutton
									:label="t(`${moduleId}.general.yes`)"
									name="flOrganicFertilizersField"
									:value="'1'"
									:is-inline="true"
									v-model="flOrganicFertilizersField"
									:is-disabled="isReadOnly"></BiRadiobutton>
								<BiRadiobutton
									:label="t(`${moduleId}.general.no`)"
									name="flOrganicFertilizersField"
									:value="'0'"
									:is-inline="true"
									v-model="flOrganicFertilizersField"
									:is-disabled="isReadOnly"></BiRadiobutton>
							</div>
						</div>
					</div>
					<div class="row pb-3 pt-3">
						<div class="col-12">
							<div class="ps-2">
								<h5 class="fw-bold" :class="getColor('text', 'primary')">
									{{
										t(`${moduleId}.declarationYearForm.livestockAnimals.title`)
									}}
								</h5>

								<div class="ps-2">
									{{
										t(`${moduleId}.declarationYearForm.livestockAnimals.label`)
									}}
								</div>
								<div class="ps-2">
									{{
										t(
											`${moduleId}.declarationYearForm.livestockAnimals.labelLineTwo`
										)
									}}
								</div>
							</div>
						</div>
						<div class="col-12">
							<div
								class="ps-2 ps-md-0 col-4 offset-2 d-flex justify-content-around">
								<BiRadiobutton
									:label="t(`${moduleId}.general.yes`)"
									name="flLivestockAnimals"
									:value="'1'"
									:is-inline="true"
									v-model="flLivestockAnimals"
									:is-disabled="
										isFlLivestockAnimalsDisabled || isReadOnly
									"></BiRadiobutton>
								<BiRadiobutton
									:label="t(`${moduleId}.general.no`)"
									name="flLivestockAnimals"
									:value="'0'"
									:is-inline="true"
									v-model="flLivestockAnimals"
									:is-disabled="
										isFlLivestockAnimalsDisabled || isReadOnly
									"></BiRadiobutton>
							</div>
						</div>
					</div>
				</div>
				<!-- <div class="pt-5">
					<BiAlert v-if="showRequirementsAlert" isError>
						<template #body>
							{{
								t(
									`${moduleId}.declarationYearForm.requirements`
								)
							}}
						</template>
					</BiAlert>
				</div> -->

				<div class="mb-0 mt-5 pt-3 d-flex justify-content-center">
					<BiButton
						v-if="!isReadOnly && !applicationFormsStore.loading"
						type="submit"
						form="declarationYearForm"
						class="mx-1 mb-4"
						:class="getColor('button', 'primary')"
						@click="checkIfTabCompleted()">
						{{ t(`${moduleId}.general.saveCard`) }}
					</BiButton>
					<BiProgressIndicator
						v-if="applicationFormsStore.loading"
						type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</form>
	</div>
</template>
