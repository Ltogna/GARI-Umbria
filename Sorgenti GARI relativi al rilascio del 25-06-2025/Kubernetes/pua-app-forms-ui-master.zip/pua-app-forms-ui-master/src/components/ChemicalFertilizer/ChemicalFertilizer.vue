<script setup lang="ts">
// Vue
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import {
	MunicipalityRecordListResponseSchema,
	type getGraphicCropPlanResponse,
	type LandUseRecordListResponse,
	type MunicipalityRecordListResponse,
	type SaveGraphicCropPlanModel,
} from "@/models/applicationForms";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiChip from "@abaco/bootstrap-italia-components/src/components/BiChip/BiChip.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiCheckbox from "@abaco/bootstrap-italia-components/src/components/form/BiCheckbox.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// Store
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import { toTypedSchema } from "@vee-validate/zod";
import debounce from "lodash/debounce";
import { useField } from "vee-validate";
import type {
	IFilterChemicalAndOrganicaFertilizer,
	IFilterStoreChemicalAndOrganicaFertilizer,
} from "../ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizer.vue";
import ToggleImportOrManualAdd from "../ToggleImportOrManualAdd/ToggleImportOrManualAdd.vue";

export interface IListMap {
	[key: string]: string;
}

const applicationFormsStore = useApplicationFormsStore();
const QueryFieldsStore = useQueryFieldsStore();

const graphicCropPlanList = computed(
	() => applicationFormsStore.graphicCropPlanList
);

const municipalityCodeList = computed(() =>
	applicationFormsStore.graphicCropPlanList.reduce(
		(acc: string[], el: getGraphicCropPlanResponse) => {
			if (el && !acc.includes(el.sectorCode)) {
				acc.push(el.sectorCode);
			}
			return acc;
		},
		[]
	)
);

const landUseCodeList = computed(() =>
	applicationFormsStore.graphicCropPlanList.reduce(
		(acc: string[], el: getGraphicCropPlanResponse) => {
			if (el && !acc.includes(el.landUseCode)) {
				acc.push(el.landUseCode);
			}
			return acc;
		},
		[]
	)
);

const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const graphicCropPlanId = ref<number>(0);
const flZvn = ref<boolean>(false);

const isEditMode = ref<boolean>(false);
const modalKey = ref<number>(0);

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const loadingData = ref<boolean>(true);
const isReadOnly = computed(() => QueryFieldsStore.getReadOnly === 1);

const municipalityList = ref<MunicipalityRecordListResponse[]>([]);
const municipalityCode = ref<MunicipalityRecordListResponse>();
const municipalityCodeFilter = ref<string>("");
const isMunicipalityListLoadingDataFilter = ref<boolean>(false);
const minSearchLenghtMunicipality = ref<number>(3);

const municipalityListResponse = computed(
	() => applicationFormsStore.municipalityList
);
const municipalityListResponseMap = ref<IListMap>({});
const isNextMunicipalityValid = ref<string | null | undefined>(null);

const landUseList = ref<LandUseRecordListResponse[]>([]);
const landUseCodeFilter = ref<string>("");
const isLandUseCodeLoadingDataFilter = ref<boolean>(false);

const landUseCode = ref<LandUseRecordListResponse>();
const landUseCodeModalFilter = ref<LandUseRecordListResponse>();
const landUseListResponse = computed(() => applicationFormsStore.landUseList);
const landUseListResponseMap = ref<IListMap>({});
const minSearchLenghtLandUse = ref<number>(3);
const isNextLandUseValid = ref<string | null | undefined>(null);

const areaSqm = ref<string>();
const areaSqmId = "areaSqmId";
let areaSqmOldValue: string | undefined;
const areaSqmRef = ref();

const chipFilterDescription = ref<IFilterChemicalAndOrganicaFertilizer>({
	sectorCode: "",
	landUseCode: "",
});

const showFilterForSearchModal = ref<boolean>(false);
const isFilterForSectorCodeVisible = ref<boolean>(false);
const isFilterForLandUseCodeVisible = ref<boolean>(false);
const mas = ref<number>();
const showAlertIsGraphicCropPlanDuplicate = ref<boolean>(false);
const showAlertInTableIsPresentAlmostOneElement = ref<boolean>(false);
const isDataTableReady = ref<boolean>(false);
const isMasDisabled = ref<boolean>(false);
const toggleHandlerImportOrManualAdd = ref<boolean | null>(null);
const showAlertInTableIsPresentAlmostOneElementHandlerManualAdd =
	ref<boolean>(false);

const getChemicalFertilizerFilterObject = computed(() => {
	const getChemicalFertilizerFilterObjectFn =
		{} as IFilterStoreChemicalAndOrganicaFertilizer;

	if (
		sectorCodeModalFilter.value != null &&
		sectorCodeModalFilter.value.sector_code != null
	) {
		getChemicalFertilizerFilterObjectFn.sectorCode =
			sectorCodeModalFilter.value;
	}

	if (
		landUseCodeModalFilter.value != null &&
		landUseCodeModalFilter.value.land_uses_code != null
	) {
		getChemicalFertilizerFilterObjectFn.landUseCode =
			landUseCodeModalFilter.value;
	}

	return getChemicalFertilizerFilterObjectFn;
});

const getDeclarationYear = computed(
	() => applicationFormsStore.getDeclarationYearResponse
);

const getMasFromLandUseCodeResponse = computed(
	() => applicationFormsStore.getMasFromLandUseCodeResponse[0].nitrogenQt
);

async function tableDataMappingDescriptionFromCodeForMunicipalitysAndLandUse() {
	isDataTableReady.value = false;

	await applicationFormsStore.loadMunicipalityListFromCode(
		municipalityCodeList.value
	);
	createMapMunicipalityList();

	await applicationFormsStore.loadLandUseListFromCode(landUseCodeList.value);
	createMaplandUseListMap();

	initItemListFiltersInEmptyArray();
	graphicCropPlanList.value.map(
		(graphicCropPlanItem: getGraphicCropPlanResponse) => {
			if (
				graphicCropPlanItem &&
				graphicCropPlanItem.sectorCode &&
				graphicCropPlanItem.landUseCode
			) {
				graphicCropPlanItem.sectorDescription =
					municipalityListResponseMap.value[graphicCropPlanItem.sectorCode];
				graphicCropPlanItem.landUseDescription =
					landUseListResponseMap.value[graphicCropPlanItem.landUseCode];
				graphicCropPlanItem.areaSqm = (
					Number(graphicCropPlanItem.areaSqm) / 10000
				).toFixed(4);

				if (!toggleHandlerImportOrManualAdd.value) {
					municipalityList.value.push({
						description: graphicCropPlanItem.sectorDescription,
						sector_code: graphicCropPlanItem.sectorCode,
					});
					landUseList.value.push({
						description: graphicCropPlanItem.landUseDescription,
						land_uses_code: graphicCropPlanItem.landUseCode,
					});
				}
			}
			return graphicCropPlanItem;
		}
	);

	if (!toggleHandlerImportOrManualAdd.value) {
		const uniqueArrMunicipalityList: readonly MunicipalityRecordListResponse[] =
			Object.freeze(
				Array.from(
					municipalityList.value
						.reduce((map, obj) => {
							map.set(`${obj?.description}`, obj);
							return map;
						}, new Map<string, MunicipalityRecordListResponse>())
						.values()
				)
			);

		municipalityList.value = uniqueArrMunicipalityList.slice();

		const uniqueArrlandUseList: readonly LandUseRecordListResponse[] =
			Object.freeze(
				Array.from(
					landUseList.value
						.reduce((map, obj) => {
							map.set(`${obj?.description}`, obj);
							return map;
						}, new Map<string, LandUseRecordListResponse>())
						.values()
				)
			);

		landUseList.value = uniqueArrlandUseList.slice();
	}

	isDataTableReady.value = true;
}

function initItemListFiltersInEmptyArray() {
	municipalityList.value = [];
	landUseList.value = [];
}

function initMunicipalityList() {
	municipalityList.value =
		municipalityList.value && municipalityListResponse.value
			? municipalityListResponse.value.records
			: [];
}

function initLandUseList() {
	landUseList.value =
		landUseListResponse.value && landUseList && landUseList.value
			? landUseListResponse.value.records
			: [];
}

const formError = computed(() => {
	if (
		municipalityCode.value &&
		landUseCode.value &&
		areaSqm.value &&
		(mas.value || (!mas.value && isMasDisabled.value)) &&
		(!isInsertGraphicCropPlanMunicipalityAndLandUseCodeDuplicateInTableData() ||
			isEditMode.value)
	) {
		return false;
	}
	return true;
});

function isInsertGraphicCropPlanMunicipalityAndLandUseCodeDuplicateInTableData() {
	let isDuplicateFormError = false;
	const searchDuplicateItem = graphicCropPlanList.value.filter(
		graphicCropPlanItem => {
			if (
				graphicCropPlanItem &&
				municipalityCode &&
				municipalityCode.value &&
				landUseCode &&
				landUseCode.value &&
				graphicCropPlanItem.sectorCode === municipalityCode.value.sector_code &&
				graphicCropPlanItem.landUseCode === landUseCode.value.land_uses_code
			) {
				return graphicCropPlanItem;
			}
		}
	);
	if (searchDuplicateItem.length > 0) {
		isDuplicateFormError = true;
		showAlertIsGraphicCropPlanDuplicate.value = true;
	} else {
		showAlertIsGraphicCropPlanDuplicate.value = false;
	}
	return isDuplicateFormError;
}

function resetFormValue() {
	municipalityCode.value =
		landUseCode.value =
		areaSqm.value =
		mas.value =
			undefined;

	flZvn.value = false;

	showAlertIsGraphicCropPlanDuplicate.value = false;
	resetDynamicList();
}

function calculateNitrogen(areaSqm: number, mas: number) {
	return (areaSqm * mas).toFixed(4);
}

function resetDynamicList() {
	landUseList.value = [];
	municipalityList.value = [];
}

function toggleAddEditModal(isEdit?: boolean) {
	isEdit ? (isEditMode.value = true) : (isEditMode.value = false);
	isAddEditModalOpen.value = !isAddEditModalOpen.value;
	resetFormValue();
	!isAddEditModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function editGraphicCropPlanForm(element: getGraphicCropPlanResponse) {
	toggleAddEditModal(true);

	municipalityCode.value = {} as MunicipalityRecordListResponse;
	if (
		element?.sectorDescription &&
		element?.sectorCode &&
		municipalityCode.value
	) {
		municipalityCode.value.description = element?.sectorDescription;
		municipalityCode.value.sector_code = element?.sectorCode;
	}

	landUseCode.value = {} as LandUseRecordListResponse;
	if (
		element &&
		element.landUseDescription &&
		element.landUseCode &&
		element.flZvn != null &&
		element.ids != null &&
		landUseCode.value
	) {
		landUseCode.value.description = element.landUseDescription;
		landUseCode.value.land_uses_code = element.landUseCode;
		areaSqm.value = element?.areaSqm + "";
		mas.value = element?.mas ?? 0;
		flZvn.value = element.flZvn;
		graphicCropPlanId.value = element.ids[0] ?? 0;
	}
}

function toggleConfirmDeleteModal() {
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function deleteGraphicCropPlan(graphicCropPalnId: number) {
	await applicationFormsStore.deleteGraphicCropPlan(graphicCropPalnId);
	toggleConfirmDeleteModal();
	await loadChemicalFertilizerAndMapMunicipalityAndLandUse();
}

async function deleteAllGraphicCropPlanAndImportGraphicCropPlanAndSetToggleInImport() {
	if (
		getDeclarationYear.value != null &&
		getDeclarationYear.value.year != null
	) {
		toggleConfirmImportModal(false);
		await applicationFormsStore.importGraphicCropPlan(
			getDeclarationYear.value.year
		);
		await loadChemicalFertilizerAndMapMunicipalityAndLandUse();
		toggleHandlerImportOrManualAdd.value = false;
	}
}

function createMapMunicipalityList() {
	if (applicationFormsStore.municipalityListFromCodeResponse) {
		applicationFormsStore.municipalityListFromCodeResponse.records.map(el => {
			municipalityListResponseMap.value[el.sector_code] = el.description;
		});
	}
}

function createMaplandUseListMap() {
	if (applicationFormsStore.landUseListFromCodeResponse) {
		applicationFormsStore.landUseListFromCodeResponse.land_uses_codes_list.map(
			el => {
				landUseListResponseMap.value[el.land_uses_code] = el.description;
			}
		);
	}
}

const onKeyupMunicipalityCode = debounce(async () => {
	if (toggleHandlerImportOrManualAdd.value) {
		if (municipalityCodeFilter.value.length >= 3) {
			isMunicipalityListLoadingDataFilter.value = true;
			await applicationFormsStore.loadMunicipalityList(
				municipalityCodeFilter.value
			);
			initMunicipalityList();
			isNextMunicipalityValid.value =
				applicationFormsStore.municipalityList?.nextKey;
			isMunicipalityListLoadingDataFilter.value = false;
		} else {
			municipalityList.value = [];
		}
	}
}, 500);

const onKeyupLandUseCode = debounce(async () => {
	if (toggleHandlerImportOrManualAdd.value) {
		if (landUseCodeFilter.value.length >= 3) {
			isLandUseCodeLoadingDataFilter.value = true;
			await applicationFormsStore.loadLandUseList(landUseCodeFilter.value);
			initLandUseList();
			isNextLandUseValid.value = applicationFormsStore.landUseList?.nextKey;
			isLandUseCodeLoadingDataFilter.value = false;
		} else {
			landUseList.value = [];
		}
	}
}, 500);

onMounted(async () => {
	QueryFieldsStore.populateState();
	loadingData.value = false;

	await applicationFormsStore.getDeclarationYear();
	await loadChemicalFertilizerAndMapMunicipalityAndLandUse();

	if (graphicCropPlanList.value.length > 0) {
		if (graphicCropPlanList.value && graphicCropPlanList.value[0]) {
			toggleHandlerImportOrManualAdd.value =
				!graphicCropPlanList.value[0].flImported;
		}
	} else {
		isDataTableReady.value = true;
	}
});

function toggleConfirmHandlerManualAddModal(isOpen: boolean) {
	showAlertInTableIsPresentAlmostOneElementHandlerManualAdd.value = isOpen
		? true
		: false;
}

async function deleteAllGraphicCropPlanListAndHandlerManualAdd() {
	toggleConfirmHandlerManualAddModal(false);
	await applicationFormsStore.deleteAllGraphicCropPlanList();
	await getChemicalFertilizerOrChemicalFertilizerFilter();
	toggleHandlerImportOrManualAdd.value = true;
}

async function loadChemicalFertilizerAndMapMunicipalityAndLandUse() {
	await getChemicalFertilizerOrChemicalFertilizerFilter();
	if (graphicCropPlanList.value.length > 0) {
		await tableDataMappingDescriptionFromCodeForMunicipalitysAndLandUse();
	}
}

async function getChemicalFertilizerOrChemicalFertilizerFilter() {
	//  da aggiungere il passaggio dei filtri tra i componenti
	// per adesso non usato preparato per dopo da aggiungere la logica next key per adesso non usato
	const nextKey = 0;

	if (
		getChemicalFertilizerFilterObject.value != null &&
		((getChemicalFertilizerFilterObject.value.sectorCode != null &&
			getChemicalFertilizerFilterObject.value.sectorCode.sector_code &&
			getChemicalFertilizerFilterObject.value.sectorCode.sector_code.length >
				0) ||
			(getChemicalFertilizerFilterObject.value.landUseCode != null &&
				getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code &&
				getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code
					.length > 0))
	) {
		let sectorCode = "";
		if (
			getChemicalFertilizerFilterObject.value.sectorCode != null &&
			getChemicalFertilizerFilterObject.value.sectorCode.sector_code != null
		) {
			sectorCode =
				getChemicalFertilizerFilterObject.value.sectorCode.sector_code;
		}

		let landUseCode = "";
		if (
			getChemicalFertilizerFilterObject.value.landUseCode != null &&
			getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code != null
		) {
			landUseCode =
				getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code;
		}

		await applicationFormsStore.loadGraphicCropPlanListFilter(
			{ sectorCode, landUseCode },
			nextKey
		);
	} else {
		await applicationFormsStore.loadGraphicCropPlanList();
	}
}

function onSearchChangeMunicipalityListCode(val: string) {
	municipalityCodeFilter.value = val;
}

function onSearchChangeLandUseCode(val: string) {
	landUseCodeFilter.value = val;
}

function checkIfTabCompletedNewCropPlan() {
	if (
		municipalityCode.value &&
		municipalityCode.value.sector_code &&
		landUseCode &&
		landUseCode.value &&
		areaSqm &&
		areaSqm.value &&
		mas &&
		flZvn.value != null &&
		(mas.value || (!mas.value && isMasDisabled.value))
	) {
		const saveData: SaveGraphicCropPlanModel = {
			sectorCode: municipalityCode.value.sector_code,
			landUseCode: landUseCode.value.land_uses_code,
			flZvn: flZvn.value,
			areaSqm: +areaSqm.value.replaceAll(",", ".") * 10000,
			mas: mas.value,
		};
		saveOrEditGraphicCropPlan(saveData);
		resetFormValue();
	}
}

async function saveOrEditGraphicCropPlan(saveData: SaveGraphicCropPlanModel) {
	if (isEditMode.value) {
		saveData.ids = [graphicCropPlanId.value];
		await applicationFormsStore.editGraphicCropPlan(
			saveData,
			graphicCropPlanId.value
		);
	} else {
		await applicationFormsStore.saveGraphicCropPlan(saveData);
	}
	toggleAddEditModal(false);
	await loadChemicalFertilizerAndMapMunicipalityAndLandUse();
}
function validateNumberOrNumberWithFourDecimalAreaSqm() {
	if (areaSqm.value != null) {
		areaSqmOldValue = areaSqm.value.toString();
	}
	const result = applicationFormsStore.validateNumberOrNumberWithFourDecimal(
		areaSqmId,
		areaSqm,
		areaSqmOldValue
	);

	if (result == false) {
		return false;
	} else {
		areaSqmOldValue = result;
	}
}

async function showConfirmImportModalOrImportGraphicCropPlanAndSetToggleImport() {
	if (graphicCropPlanList.value.length > 0) {
		toggleConfirmImportModal(true);
	} else if (graphicCropPlanList.value.length == 0) {
		deleteAllGraphicCropPlanAndImportGraphicCropPlanAndSetToggleInImport();
	}
}

function toggleConfirmImportModal(isOpen: boolean) {
	showAlertInTableIsPresentAlmostOneElement.value = isOpen ? true : false;
}

async function showConfirmDeleteAllGraphicCropPlanListAndSetToggleManualAdd() {
	initItemListFiltersInEmptyArray();
	if (graphicCropPlanList.value.length > 0) {
		toggleConfirmHandlerManualAddModal(true);
	} else if (graphicCropPlanList.value.length == 0) {
		await deleteAllGraphicCropPlanListAndHandlerManualAdd();
	}
}

async function onCloseLandUseCode() {
	if (landUseCode.value && landUseCode.value.land_uses_code) {
		setMatFromLandUseCodeSelected(landUseCode.value.land_uses_code);
	}
}

async function setMatFromLandUseCodeSelected(landUseCode: string) {
	await applicationFormsStore.getMasFromLandUseCode(landUseCode);

	if (getMasFromLandUseCodeResponse.value != null) {
		mas.value = getMasFromLandUseCodeResponse.value;
		isMasDisabled.value = false;
	} else if (getMasFromLandUseCodeResponse.value == null) {
		isMasDisabled.value = true;
		mas.value = undefined;
	}
}

function toggleFilterSearch(toggleValue: boolean) {
	showFilterForSearchModal.value = toggleValue;
}

const { value: sectorCodeModalFilter } =
	useField<MunicipalityRecordListResponse>(
		"sectorCode",
		toTypedSchema(MunicipalityRecordListResponseSchema.nullish())
	);

async function resetFilterValue() {
	toggleFilterSearch(false);

	if (
		sectorCodeModalFilter.value?.sector_code == null &&
		landUseCodeModalFilter.value?.land_uses_code == null
	) {
		return;
	}
	sectorCodeModalFilter.value = null;
	landUseCodeModalFilter.value = null;
	await filterChemicalFertilizer();
}

async function filterChemicalFertilizer() {
	setFilterObjectFromStoreAndChipBeforeTable();
	await getChemicalFertilizerOrChemicalFertilizerFilter();
	toggleFilterSearch(false);
	if (graphicCropPlanList.value.length > 0) {
		await tableDataMappingDescriptionFromCodeForMunicipalitysAndLandUse();
	}
}

function setFilterObjectFromStoreAndChipBeforeTable() {
	if (getChemicalFertilizerFilterObject.value != null) {
		if (
			sectorCodeModalFilter.value != null &&
			getChemicalFertilizerFilterObject.value.sectorCode != null &&
			getChemicalFertilizerFilterObject.value.sectorCode.sector_code != null &&
			getChemicalFertilizerFilterObject.value.sectorCode.sector_code.length > 0
		) {
			sectorCodeModalFilter.value =
				getChemicalFertilizerFilterObject.value.sectorCode;
		}
		if (
			landUseCodeModalFilter.value != null &&
			getChemicalFertilizerFilterObject.value.landUseCode != null &&
			getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code !=
				null &&
			getChemicalFertilizerFilterObject.value.landUseCode.land_uses_code
				.length > 0
		) {
			landUseCodeModalFilter.value =
				getChemicalFertilizerFilterObject.value.landUseCode;
		}
	}

	setChipFilterDescriptionForChipBeforeTable();
}

function setChipFilterDescriptionForChipBeforeTable() {
	isFilterForSectorCodeVisible.value = false;
	isFilterForLandUseCodeVisible.value = false;

	if (
		sectorCodeModalFilter.value != null &&
		sectorCodeModalFilter.value.sector_code != null
	) {
		isFilterForSectorCodeVisible.value = true;

		chipFilterDescription.value["sectorCode"] =
			t(`${moduleId}.ChemicalAndOrganicFertilizer.table.municipality`) +
			` ${sectorCodeModalFilter.value.description}`;
	}

	if (
		landUseCodeModalFilter.value != null &&
		landUseCodeModalFilter.value.land_uses_code != null
	) {
		isFilterForLandUseCodeVisible.value = true;

		chipFilterDescription.value["landUseCode"] =
			t(`${moduleId}.ChemicalAndOrganicFertilizer.table.plantSpecies`) +
			` ${landUseCodeModalFilter.value.description}`;
	}
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading || !isDataTableReady"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-show="!(applicationFormsStore.getLoading || !isDataTableReady)">
			<div class="row my-3 justify-content-start">
				<div class="col-8 my-3">
					<h4 class="fw-bold" :class="getColor('text', 'primary')">
						<p>
							{{ t(`${moduleId}.graphicCropPlan.title`) }}
						</p>
					</h4>

					<div class="d-flex justify-content-start p-0">
						<div class="form-check form-check-inline">
							<ToggleImportOrManualAdd
								:toggleHandlerImportOrManualAdd="toggleHandlerImportOrManualAdd"
								:isReadOnly="isReadOnly"
								@showConfirmModalImportAndSetToggleImport="
									showConfirmImportModalOrImportGraphicCropPlanAndSetToggleImport()
								"
								@showConfirmModalDeleteAllAndSetToggleManualAdd="
									showConfirmDeleteAllGraphicCropPlanListAndSetToggleManualAdd()
								"></ToggleImportOrManualAdd>
						</div>
					</div>
				</div>
				<div class="col-4">
					<div class="d-flex justify-content-end">
						<BiTooltip
							:title="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
								)
							"
							:aria-label="
								t(
									`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`
								)
							">
							<BiButton
								v-if="!isReadOnly && !applicationFormsStore.loading"
								type="submit"
								class="mx-1 mb-2 col-auto"
								:class="`${getColor('button', 'primary', 'outline')}`"
								@click.stop.prevent="toggleFilterSearch(true)">
								<span>
									<BiIcon icon="plus" size="lg" icon-style="regular" />
									{{
										t(`${moduleId}.ChemicalAndOrganicFertilizer.button.filters`)
									}}
								</span>
							</BiButton>
						</BiTooltip>
					</div>
				</div>
			</div>
			<div class="d-flex justify-content-end">
				<BiButton
					v-if="
						((!isReadOnly && !applicationFormsStore.loading) ||
							(applicationFormsStore.loading && isAddEditModalOpen)) &&
						toggleHandlerImportOrManualAdd == true
					"
					type="submit"
					class="mx-1 mb-2 col-auto"
					:class="`${getColor('button', 'primary', 'outline')}`"
					@click.stop="toggleAddEditModal()">
					{{ t(`${moduleId}.graphicCropPlan.button.add`) }}
				</BiButton>
			</div>
			<div>
				<BiChip
					v-model="isFilterForSectorCodeVisible"
					:label="chipFilterDescription.sectorCode" />
				<BiChip
					v-model="isFilterForLandUseCodeVisible"
					:label="chipFilterDescription.landUseCode" />
			</div>
			<BiTable
				class="table-responsive"
				extraTableClasses="table-head-bg"
				isResponsive
				v-show="!loadingData">
				<template v-slot:head>
					<tr
						class="bg-light text-start"
						:class="getColor('text', 'secondary')">
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.municipalityCode`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.landUseCode`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.flZvn`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.areaSqm`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.mas`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.graphicCropPlan.table.totalNitrogen`) }}
						</th>
						<th scope="col"></th>
					</tr>
				</template>
				<template
					v-slot:body
					v-if="
						graphicCropPlanList &&
						graphicCropPlanList.length > 0 &&
						isDataTableReady
					">
					<tr
						class="align-middle"
						v-for="element in graphicCropPlanList"
						:key="element?.ids?.[0]">
						<td
							:data-label="
								t(`${moduleId}.graphicCropPlan.table.municipalityCode`)
							"
							class="text-start">
							{{ element?.sectorDescription }}
						</td>
						<td
							:data-label="t(`${moduleId}.graphicCropPlan.table.landUseCode`)"
							class="text-start">
							{{ element?.landUseDescription }}
						</td>

						<td
							:data-label="t(`${moduleId}.graphicCropPlan.table.flZvn`)"
							class="text-start">
							<div
								v-if="element && element.flZvn"
								:aria-label="
									t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.yes`)
								"
								:aria-labelledby="
									t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.yes`)
								"
								:alt="t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.yes`)"
								isPrimary
								:width="40"
								class="mx-1 my-0">
								<BiIcon
									icon="check"
									size="xl"
									icon-style="regular"
									aria-hidden="true" />
							</div>
							<div
								v-else
								:aria-label="
									t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.no`)
								"
								:aria-labelledby="
									t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.no`)
								"
								:alt="t(`${moduleId}.graphicCropPlan.table.tooltip.zvn.no`)"
								isPrimary
								:width="40"
								class="mx-1 my-0"></div>
						</td>

						<td
							:data-label="t(`${moduleId}.graphicCropPlan.table.areaSqm`)"
							class="text-end">
							{{ element?.areaSqm }}
						</td>
						<td
							:data-label="t(`${moduleId}.graphicCropPlan.table.mas`)"
							class="text-end">
							{{ element?.mas }}
						</td>
						<td
							:data-label="t(`${moduleId}.graphicCropPlan.table.totalNitrogen`)"
							class="text-end">
							{{ calculateNitrogen(Number(element?.areaSqm!), element?.mas!) }}
						</td>
						<td class="text-end text-nowrap">
							<div>
								<BiTooltip
									v-if="toggleHandlerImportOrManualAdd"
									:title="t(`${moduleId}.graphicCropPlan.table.tooltip.edit`)"
									:aria-label="
										t(`${moduleId}.graphicCropPlan.table.tooltip.edit`)
									">
									<BiButton
										:aria-label="
											t(`${moduleId}.graphicCropPlan.table.tooltip.edit`)
										"
										:aria-labelledby="
											t(`${moduleId}.graphicCropPlan.table.tooltip.edit`)
										"
										:alt="t(`${moduleId}.graphicCropPlan.table.tooltip.edit`)"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="
											() => {
												editGraphicCropPlanForm(element);
											}
										"
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'success', 'outline')}`">
										<span>
											<BiIcon icon="pencil" size="xl" icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
								<BiTooltip
									v-if="toggleHandlerImportOrManualAdd"
									:title="t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)"
									:aria-label="
										t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)
									">
									<BiButton
										tabindex="0"
										role="button"
										aria-pressed="false"
										aria-disabled="false"
										:aria-label="
											t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)
										"
										:aria-labelledby="
											t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)
										"
										:alt="t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="
											() => {
												graphicCropPlanId = element?.ids?.[0] ?? 0;
												toggleConfirmDeleteModal();
											}
										"
										isPrimary
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'danger', 'outline')}`">
										<span
											:aria-label="
												t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)
											">
											<BiIcon
												:aria-label="
													t(`${moduleId}.graphicCropPlan.table.tooltip.delete`)
												"
												icon="trash"
												size="xl"
												icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
							</div>
						</td>
					</tr>
				</template>
				<template v-slot:body v-else>
					<tr>
						<td colspan="3" class="text-start">
							{{ t(`${moduleId}.graphicCropPlan.noData`) }}
						</td>
					</tr>
				</template>
			</BiTable>
		</div>
		<!-- -->
	</div>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="t(`${moduleId}.graphicCropPlan.modal.delete.title`)"
		:title="t(`${moduleId}.graphicCropPlan.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.graphicCropPlan.modal.delete.body`) }}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmDeleteModal();
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteGraphicCropPlan(graphicCropPlanId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- add/edit graphic crop plan modal -->
	<BiModal
		:disabled-teleport="true"
		:key="modalKey"
		:extra-footer-class="'justify-content-center'"
		v-model="isAddEditModalOpen"
		:aria-labelledby="
			isEditMode
				? t(`${moduleId}.graphicCropPlan.modal.edit.title`)
				: t(`${moduleId}.graphicCropPlan.modal.add.title`)
		"
		:title="
			isEditMode
				? t(`${moduleId}.graphicCropPlan.modal.edit.title`)
				: t(`${moduleId}.graphicCropPlan.modal.add.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="newCropPlanForm"
				class="needs-validation"
				@submit.prevent="
					async () => {
						toggleAddEditModal();
					}
				">
				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="municipalityCodeId"
							:id="'municipalityCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
							:items="municipalityList"
							:isAutocomplete="true"
							:loading="isMunicipalityListLoadingDataFilter"
							:showNoResults="!isMunicipalityListLoadingDataFilter"
							v-model="municipalityCode"
							@searchChange="onSearchChangeMunicipalityListCode"
							@keyup="onKeyupMunicipalityCode"
							:minSearchLenght="minSearchLenghtMunicipality"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${municipalityCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtMunicipality}`
							"
							:itemTitle="'description'"
							:disabled="
								isReadOnly ||
								(isEditMode && toggleHandlerImportOrManualAdd == false)
							">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextMunicipalityValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							name="landUseCodeId"
							:id="'landUseCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.landUseCode`)"
							:items="landUseList"
							:isAutocomplete="true"
							:loading="isLandUseCodeLoadingDataFilter"
							:showNoResults="!isLandUseCodeLoadingDataFilter"
							v-model="landUseCode"
							@searchChange="onSearchChangeLandUseCode"
							@keyup="onKeyupLandUseCode"
							@close="onCloseLandUseCode()"
							:minSearchLenght="minSearchLenghtLandUse"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${landUseCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtLandUse}`
							"
							:itemTitle="'description'"
							:disabled="
								isReadOnly ||
								(isEditMode && toggleHandlerImportOrManualAdd == false)
							">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextLandUseValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="row">
					<div class="col-4 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="areaSqmId"
								:id="'areaSqmId'"
								@input="validateNumberOrNumberWithFourDecimalAreaSqm()"
								class="mb-4"
								type="text"
								:min="0"
								:label="t(`${moduleId}.graphicCropPlan.table.areaSqm`)"
								ref="areaSqmRef"
								v-model="areaSqm"
								:disabled="
									isReadOnly ||
									(isEditMode && toggleHandlerImportOrManualAdd == false)
								" />
						</div>
					</div>

					<div class="col-4 mb-5">
						<div class="d-flex me-3 h-100">
							<BiInput
								name="masId"
								:id="'masId'"
								class="mb-4"
								type="number"
								:readonly="isMasDisabled"
								:min="0"
								:label="t(`${moduleId}.graphicCropPlan.table.mas`)"
								v-model="mas"
								:disabled="isReadOnly" />
						</div>
					</div>

					<div class="col-4 mt-4">
						<BiCheckbox
							name="flZvnId"
							:id="'flZvnId'"
							class="mb-4"
							:label="t(`${moduleId}.ChemicalAndOrganicForm.page.flZvn`)"
							v-model="flZvn"
							:is-disabled="
								isReadOnly ||
								(isEditMode && toggleHandlerImportOrManualAdd == false)
							" />
					</div>
				</div>

				<BiAlert
					v-if="showAlertIsGraphicCropPlanDuplicate && !isEditMode"
					isError>
					<template #body>
						{{
							t(
								`${moduleId}.graphicCropPlan.error.isDuplicateMunicipalityAndLandUseCodeInTable`
							)
						}}
					</template>
				</BiAlert>

				<div class="mt-3 mb-5 d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="
							() => {
								toggleAddEditModal(false);
							}
						">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						form="newCropPlanForm"
						:isDisabled="formError"
						class="mx-1"
						isPrimary
						@click="checkIfTabCompletedNewCropPlan()"
						:class="getColor('button', 'success')">
						{{
							isEditMode
								? t(`${moduleId}.graphicCropPlan.modal.edit.confirmEdit`)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
			</form>
		</template>
	</BiModal>

	<!-- confirm delete tableData and import graphicCropPlan -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showAlertInTableIsPresentAlmostOneElement"
		:aria-labelledby="t(`${moduleId}.graphicCropPlan.modal.delete.title`)"
		:title="t(`${moduleId}.graphicCropPlan.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{
							t(
								`${moduleId}.graphicCropPlan.modal.import.importAndDeleteAllDataInTable`
							)
						}}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmImportModal(false);
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="
						deleteAllGraphicCropPlanAndImportGraphicCropPlanAndSetToggleInImport()
					">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- confirm delete tableData and handler manual add graphicCropPlan -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showAlertInTableIsPresentAlmostOneElementHandlerManualAdd"
		:aria-labelledby="t(`${moduleId}.graphicCropPlan.modal.import.title`)"
		:title="t(`${moduleId}.graphicCropPlan.modal.import.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{
							t(
								`${moduleId}.graphicCropPlan.modal.deleteAllDataInTableAndContinueWithHandlerManualAdd.title`
							)
						}}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmHandlerManualAddModal(false);
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteAllGraphicCropPlanListAndHandlerManualAdd()">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- filter for search modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="showFilterForSearchModal"
		:aria-labelledby="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:title="
			t(`${moduleId}.ChemicalAndOrganicFertilizer.modal.filterSearch.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="filterChemicalFertilizer"
				class="needs-validation"
				@submit.stop.prevent="filterChemicalFertilizer()">
				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="municipalityCodeId"
							:id="'municipalityCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.municipalityCode`)"
							:items="municipalityList"
							:isAutocomplete="true"
							:loading="isMunicipalityListLoadingDataFilter"
							:showNoResults="!isMunicipalityListLoadingDataFilter"
							v-model="sectorCodeModalFilter"
							@searchChange="onSearchChangeMunicipalityListCode"
							@keyup="onKeyupMunicipalityCode"
							:minSearchLenght="minSearchLenghtMunicipality"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${municipalityCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtMunicipality}`
							"
							:itemTitle="'description'"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextMunicipalityValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="col-12 mb-5">
					<div class="pt-4">
						<BiAutocompleteNext
							name="landUseCodeId"
							:id="'landUseCodeId'"
							:label="t(`${moduleId}.graphicCropPlan.table.landUseCode`)"
							:items="landUseList"
							:isAutocomplete="true"
							:loading="isLandUseCodeLoadingDataFilter"
							:showNoResults="!isLandUseCodeLoadingDataFilter"
							v-model="landUseCodeModalFilter"
							@searchChange="onSearchChangeLandUseCode"
							@keyup="onKeyupLandUseCode"
							:minSearchLenght="minSearchLenghtLandUse"
							:labelNoResult="
								t(`${moduleId}.graphicCropPlan.table.labelNoResult`) +
								` ${landUseCodeFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`)
							"
							:labelNoItems="
								t(`${moduleId}.graphicCropPlan.select.minSearchLength`) +
								` ${minSearchLenghtLandUse}`
							"
							:itemTitle="'description'"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextLandUseValid">
									{{ t(`${moduleId}.graphicCropPlan.select.refineSearch`) }}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>
			</form>
		</template>
		<template #footer>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
			<div v-else class="mt-3 mb-5 d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop.prevent="resetFilterValue()">
					{{ t(`${moduleId}.general.delete`) }}
				</BiButton>
				<BiButton
					type="submit"
					form="filterChemicalFertilizer"
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')">
					{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.button.applyFilter`) }}
				</BiButton>
			</div>
		</template>
	</BiModal>

	<!-- -->
</template>
<style scoped lang="scss">
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}
</style>
