<script setup lang="ts">
import type {
	getPartyRegistryResponse,
	SearchSubjectDescriptionResponse,
} from "@/models/applicationForms";
import type { ValidatedInput } from "@/models/form";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { checkMaxLength, verifyField } from "@/utils/formUtils";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiCollapse from "@abaco/bootstrap-italia-components/src/components/BiCollapse/BiCollapse.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { toTypedSchema } from "@vee-validate/zod";
import { useField, useForm } from "vee-validate";
import { computed, inject, ref, watch } from "vue";
import { useI18n } from "vue-i18n";
import { z } from "zod";

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});
const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();

const openSearchSubjectModal = ref<boolean>(false);
const showNoSubjectsAlert = ref<boolean>(false);
const showResult = ref<boolean>(false);

const emit = defineEmits(["seletSubjectAndPartyId"]);

interface subjectForm {
	cuaa: string;
	denomination: string;
}

const modalForm = ref<subjectForm>({
	cuaa: "",
	denomination: "",
});

const modalFormCuaaKey = ref<number>(0);
const modalFormDenominationKey = ref<number>(0);
const searchFormValidators = ref<Record<string, ValidatedInput<string>>>({
	cuaa: {
		val: modalForm.value.cuaa,
		errors: [],
	},
	denomination: {
		val: modalForm.value.denomination,
		errors: [],
	},
});

const partyId = computed(() => queryFieldsStore.getPartyId);

const resultSubjects = computed(() => {
	if (applicationFormsStore.getSubjectList) {
		applicationFormsStore.getSubjectList.map(
			(subjectItem: getPartyRegistryResponse, index: number) => {
				if (
					subjectItem &&
					!subjectItem.description &&
					applicationFormsStore.getSubjectList &&
					applicationFormsStore.getSubjectList[index]
				) {
					if (subjectItem.firstName && subjectItem.lastName) {
						subjectItem.description =
							subjectItem.lastName + " " + subjectItem.firstName;
					}
					if (!subjectItem.firstName && subjectItem.lastName) {
						subjectItem.description = subjectItem.lastName;
					}

					if (!subjectItem.lastName && subjectItem.firstName) {
						subjectItem.description = subjectItem.firstName;
					}

					applicationFormsStore.getSubjectList[index] = subjectItem;
				}
			}
		);
		if (partyId.value) {
			return applicationFormsStore.getSubjectList.filter(
				el => el?.id != partyId.value
			);
		} else {
			return applicationFormsStore.getSubjectList;
		}
	}

	return null;
});

const referenceSubject = computed(() => applicationFormsStore.selectedSubject);

async function searchSubjectList() {
	searchFormValidators.value.cuaa.val = modalForm.value.cuaa;
	searchFormValidators.value.denomination.val = modalForm.value.denomination;

	const maxLengthErrorMessage = t(`${moduleId}.general.maxLength`);
	const errors: boolean[] = [];
	errors.push(
		verifyField(
			[
				() =>
					checkMaxLength(
						searchFormValidators.value.cuaa,
						50,
						maxLengthErrorMessage
					),
			],
			searchFormValidators.value.cuaa
		)
	);

	errors.push(
		verifyField(
			[
				() =>
					checkMaxLength(
						searchFormValidators.value.denomination,
						150,
						maxLengthErrorMessage
					),
			],
			searchFormValidators.value.denomination
		)
	);

	if (errors.findIndex((x: boolean) => x) !== -1) return;

	showNoSubjectsAlert.value = false;
	applicationFormsStore.clearSubjectList();
	await callSearchSubject(true);
	if (
		(applicationFormsStore.hasError &&
			applicationFormsStore.getErrorResponse?.response?.status === 404) ||
		(applicationFormsStore.subjectList?.count || 0) === 0 ||
		(resultSubjects.value && resultSubjects.value.length == 0)
	) {
		applicationFormsStore.clearSubjectList();
		showNoSubjectsAlert.value = true;
	} else {
		showResult.value = true;
	}
}

async function callSearchSubject(resetList?: boolean) {
	await applicationFormsStore.searchSubjects(
		modalForm.value.cuaa,
		modalForm.value.denomination,
		resetList ?? false
	);
}

function onCloseModal() {
	openSearchSubjectModal.value = false;
	applicationFormsStore.clearSubjectList();
	modalForm.value.cuaa = "";
	modalForm.value.denomination = "";
	searchFormValidators.value.cuaa.errors = [];
	searchFormValidators.value.denomination.errors = [];
	showNoSubjectsAlert.value = false;
	modalFormCuaaKey.value += 1;
	modalFormDenominationKey.value += 1;
}

function onSelectSubject(subject: getPartyRegistryResponse) {
	applicationFormsStore.setSelectedSubject(subject);
	emit("seletSubjectAndPartyId", subject?.id);
	onCloseModal();
}

watch(
	() => modalForm.value.cuaa,
	() => {
		if (modalForm.value.cuaa == "") return;
		modalForm.value.denomination = "";
		modalFormDenominationKey.value += 1;
		searchFormValidators.value.denomination.errors = [];
	}
);

watch(
	() => modalForm.value.denomination,
	() => {
		if (modalForm.value.denomination == "") return;
		modalForm.value.cuaa = "";
		modalFormCuaaKey.value += 1;
		searchFormValidators.value.cuaa.errors = [];
	}
);

const { setErrors, errors } = useForm<SearchSubjectDescriptionResponse>({
	initialValues: {
		description: null,
	},
});

const { value: description } = useField<string | null>(
	"description",
	toTypedSchema(z.string().nullish())
);

watch(
	() => referenceSubject.value,
	() => {
		if (referenceSubject.value && referenceSubject.value.description) {
			description.value = referenceSubject.value.description;
		}
	}
);

defineExpose({
	validateForm: () => {
		if (!description.value) {
			setErrors({
				description: t(`${moduleId}.errors.FIELD_REQUIRED`),
			});
		}

		return errors;
	},
});
</script>
<template>
	<form
		id="taskSearchForm"
		class="needs-validation"
		ref="searchFormRef"
		@submit.prevent="() => {}">
		<div id="searchContainer" class="row justify-content-center">
			<div class="form-group col-8 col-md-8">
				<BiInput
					:label="
						t(`${moduleId}.confirmationForm.searchSubject.referenceSubject`)
					"
					:placeholder="
						t(`${moduleId}.confirmationForm.searchSubject.searchSubject`)
					"
					v-model="description"
					:errors="errors.description ? [errors.description] : []"
					:disabled="true"
					class="col-12" />
			</div>
			<div
				class="form-group col-4 col-md-4 d-flex align-items-end justify-content-center">
				<BiButton
					class="btn py-1 px-2"
					:class="getColor('button', 'primary', 'outline')"
					@click.stop="
						() => {
							openSearchSubjectModal = true;
						}
					">
					{{ t(`${moduleId}.confirmationForm.searchSubject.searchSubject`) }}
				</BiButton>
			</div>

			<BiModal
				:disabled-teleport="true"
				:modelValue="openSearchSubjectModal"
				:ariaLabelledby="
					t(`${moduleId}.confirmationForm.searchSubject.searchSubject`)
				"
				:title="t(`${moduleId}.confirmationForm.searchSubject.searchSubject`)"
				:size="'lg'"
				:preventDismiss="true"
				:extra-footer-class="'justify-content-center'">
				<template v-slot:body>
					<form
						id="subjectSearchForm"
						ref="subjectSearchFormRef"
						@submit.prevent="() => {}">
						<div class="form-group mt-5 w-100">
							<BiInput
								:key="modalFormCuaaKey"
								:label="
									t(`${moduleId}.confirmationForm.searchSubject.cuaaLabel`)
								"
								:placeholder="t(`${moduleId}.general.insertCode`)"
								v-model="modalForm.cuaa"
								class="mb-4"
								:errors="searchFormValidators.cuaa.errors" />
						</div>
						<div class="form-group w-100">
							<BiInput
								:key="modalFormDenominationKey"
								:label="
									t(
										`${moduleId}.confirmationForm.searchSubject.denominationLabel`
									)
								"
								:placeholder="t(`${moduleId}.general.textToSearch`)"
								v-model="modalForm.denomination"
								class="mb-4"
								:errors="searchFormValidators.denomination.errors" />
						</div>
					</form>
				</template>
				<template v-slot:footer>
					<div v-if="showNoSubjectsAlert" class="row w-100">
						<div class="col-3"></div>
						<div class="my-3">
							<BiAlert isWarn>
								<template #body>
									{{
										t(
											`${moduleId}.confirmationForm.searchSubject.errors.NO_PARTY_FOUND_EXCEPTION`
										)
									}}
								</template>
							</BiAlert>
						</div>
						<div class="col-3"></div>
					</div>

					<div
						v-if="!applicationFormsStore.loading"
						class="mt-0 mb-5 d-flex justify-content-center">
						<BiButton
							size="lg"
							class="btn"
							:class="getColor('button', 'secondary', 'outline')"
							@click.stop="onCloseModal">
							{{ t(`${moduleId}.general.cancel`) }}
						</BiButton>
						<BiButton
							:is-disabled="!modalForm.cuaa && !modalForm.denomination"
							type="submit"
							form="subjectSearchForm"
							isPrimary
							size="lg"
							class="ms-3 btn"
							:class="getColor('button', 'success')"
							@click.stop="searchSubjectList()">
							{{ t(`${moduleId}.general.search`) }}
						</BiButton>
					</div>

					<div v-else class="d-flex col-12 justify-content-center mb-5">
						<BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
					</div>
					<div id="table-collapse" class="w-100">
						<BiTable
							v-if="resultSubjects"
							isRowHover
							class="table-hover mb-4 table-responsive w-100"
							extraTableClasses="table-head-bg"
							isResponsive>
							<template v-slot:head>
								<tr class="bg-light" :class="getColor('text', 'secondary')">
									<th scope="col">
										{{
											t(
												`${moduleId}.confirmationForm.searchSubject.denominationLabel`
											)
										}}
									</th>
									<th scope="col">
										{{
											t(`${moduleId}.confirmationForm.searchSubject.cuaaLabel`)
										}}
									</th>
									<th scope="col"></th>
								</tr>
							</template>
							<template v-slot:body>
								<tr v-for="(subject, i) in resultSubjects" :key="i">
									<td
										:data-label="
											t(
												`${moduleId}.confirmationForm.searchSubject.denominationLabel`
											)
										">
										{{ subject?.description }}
									</td>
									<td
										:data-label="
											t(`${moduleId}.confirmationForm.searchSubject.cuaaLabel`)
										">
										{{ subject?.code }}
									</td>
									<td class="actions">
										<div class="d-flex justify-content-center">
											<BiButton
												:width="40"
												@click.stop="onSelectSubject(subject)"
												:class="`${getColor('button', 'info', 'outline')}`">
												<BiIcon icon="plus" color="primary" size="lg" />
											</BiButton>
										</div>
									</td>
								</tr>
							</template>
						</BiTable>
						<div class="d-flex col-12 justify-content-center mb-5" @click.stop>
							<BiButton
								v-if="
									!applicationFormsStore.loading &&
									!applicationFormsStore.hasError &&
									applicationFormsStore.subjectList?.nextKey &&
									parseInt(applicationFormsStore.subjectList?.nextKey) > 0
								"
								@click="callSearchSubject()"
								:class="getColor('button', 'primary', 'outline')">
								{{ t(`${moduleId}.confirmationForm.list.loadMore`) }}
							</BiButton>
							<BiProgressIndicator
								v-if="
									applicationFormsStore.loading &&
									applicationFormsStore.subjectList?.nextKey &&
									parseInt(applicationFormsStore.subjectList?.nextKey) > 0
								"
								:type="'spinner'"></BiProgressIndicator>
						</div>
					</div>
					<BiCollapse
						class="d-none"
						:model-value="showResult"
						:targetSelector="'#table-collapse'"></BiCollapse>
				</template>
			</BiModal>
		</div>
	</form>
</template>
