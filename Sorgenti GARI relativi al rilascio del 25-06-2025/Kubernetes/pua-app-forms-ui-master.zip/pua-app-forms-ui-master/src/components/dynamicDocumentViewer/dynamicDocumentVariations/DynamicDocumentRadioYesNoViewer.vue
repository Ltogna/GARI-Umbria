<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import type {
	DeclarationDocumentResponse,
	SaveDeclarationsModel,
} from "@/models/applicationForms";
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiRadiobutton from "@abaco/bootstrap-italia-components/src/components/form/BiRadiobutton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { getUserData } from "@abaco/safe-rest/src/sso2";

interface Declaration {
	declarationText: string;
	declarationCode: string;
	isTitle: boolean;
	decision: string;
	radioLabel: string[];
}

const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const queryFieldsStore = useQueryFieldsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);
const compileStatusIdentifier = computed(
	() => queryFieldsStore.getCompileStatusIdentifier
);

const DOCUMENT_CODE_PARAM_KEY = "document_code";

const documentCodeQuery = computed(() =>
	queryFieldsStore.getParamByKey(DOCUMENT_CODE_PARAM_KEY)
);

const applicationFormsStore = useApplicationFormsStore();

const formErrorAlert = ref<boolean>(false);

const documentList = computed(() => applicationFormsStore.getDeclarationList);
const documentCode = ref<string>();

const declarationsList = ref<Declaration[]>([]);

async function initComponent() {
	await applicationFormsStore.loadDeclarationList(documentCodeQuery.value);
	if (!applicationFormsStore.hasError) {
		getDynamicDocumentData();
	}
}

onMounted(async () => {
	queryFieldsStore.populateState();
	initComponent();
});

function getDynamicDocumentData() {
	if (documentList.value) {
		documentCode.value = documentList.value.documentDefinition.code;
		const fieldSet = documentList.value.documentDefinition.fieldSets[0];
		const document: DeclarationDocumentResponse | undefined =
			documentList.value.document ?? undefined;
		declarationsList.value = [];

		const getLanguage = getUserData()?.locale || "it";
		declarationsList.value.push({
			declarationText: fieldSet.label[getLanguage] || fieldSet.label.en,
			declarationCode: fieldSet.code,
			isTitle: true,
			decision: "",
			radioLabel: [t(`${moduleId}.general.yes`), t(`${moduleId}.general.no`)],
		});
		fieldSet.fields.forEach(element => {
			let decision = "";
			if (document?.fields) {
				if (document?.fields[element.code] === 0) {
					decision = t(`${moduleId}.general.no`);
				} else if (document?.fields[element.code] === 1) {
					decision = t(`${moduleId}.general.yes`);
				}
			}
			declarationsList.value.push({
				declarationText: element.label[getLanguage] || element.label.en,
				declarationCode: element.code,
				isTitle: false,
				decision: decision,
				radioLabel: [t(`${moduleId}.general.yes`), t(`${moduleId}.general.no`)],
			});
		});

		const allDecisionIsEqual = allRadioEqualDecision();
		declarationsList.value[0].decision = allDecisionIsEqual ?? "";
	}
}

function allRadioEqualDecision() {
	const document = declarationsList.value.slice(1);
	for (let i = 0; i < document.length - 1; i++) {
		if (document[i].decision !== document[i + 1].decision) {
			return null;
		}
	}
	return document[document.length - 1].decision;
}

function convertRadioDecision() {
	const saveDeclarations: SaveDeclarationsModel = {
		document: {
			fields: {},
			validTo: "9999-12-31T00:00:00Z",
			validFrom: new Date().toISOString(),
		},
	};
	const declarationsArray = declarationsList.value.slice(1);
	declarationsArray.forEach(element => {
		if (saveDeclarations.document) {
			if (element.decision === t(`${moduleId}.general.yes`)) {
				saveDeclarations.document.fields[element.declarationCode] = 1;
			} else if (element.decision === t(`${moduleId}.general.no`)) {
				saveDeclarations.document.fields[element.declarationCode] = 0;
			}
		}
	});
	return saveDeclarations;
}

function selectAllRadio(arg: Declaration) {
	if (arg.isTitle) {
		declarationsList.value.forEach(element => {
			if (!element.isTitle) element.decision = arg.decision;
		});
	}
}

async function saveForm() {
	const isDeclaration = true;
	const voidAnswerIndex = declarationsList.value.findIndex(
		el => !el.isTitle && el.decision === ""
	);
	if (voidAnswerIndex !== -1) {
		formErrorAlert.value = true;
	} else {
		//API Call
		await applicationFormsStore.saveDeclarations(
			documentCode.value as string,
			convertRadioDecision(),
			compileStatusIdentifier.value,
			isDeclaration
		);
		if (!applicationFormsStore.hasError) {
			formErrorAlert.value = false;
			await initComponent();
		}
	}
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<form
			v-else
			id="declarationsForm"
			ref="declarationsFormRef"
			@submit.prevent="() => {}">
			<div
				v-for="(declaration, index) in declarationsList"
				:key="index"
				:class="{ 'change-color': index % 2 !== 0 }">
				<div v-if="declaration.isTitle" class="row my-3 justify-content-start">
					<div class="col-12 col-md-6 col-lg-7 col-xl-7">
						<h4 class="mx-2 fw-bold" :class="getColor('text', 'primary')">
							<BiIcon class="mx-2" icon="file-lines" size="lg" />
							{{ declaration.declarationText }}
						</h4>
					</div>
					<div
						class="col-12 col-md-2 col-lg-2 col-xl-2 d-flex justify-content-end">
						<div>
							{{ t(`${moduleId}.declarationsForm.selectAll`) }}
						</div>
					</div>
					<div
						class="col-12 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-end">
						<div class="ps-2 ps-md-0">
							<BiRadiobutton
								v-for="(label, i) in declaration.radioLabel"
								:key="i"
								:id="`radio${index}${i}`"
								v-model="declaration.decision"
								@update:model-value="selectAllRadio(declaration)"
								:label="label"
								:name="`radio${index}`"
								:value="label"
								:is-inline="true"
								:is-disabled="isReadOnly" />
						</div>
					</div>
				</div>
				<div v-else class="row pb-3 pt-3 align-items-center">
					<div class="col-12 col-md-7 col-lg-8 col-xl-8">
						<div class="ps-2">
							{{ declaration.declarationText }}
						</div>
					</div>
					<div class="col-1"></div>
					<div
						class="col-12 col-md-4 col-lg-3 col-xl-3 d-flex justify-content-end">
						<div class="ps-2 ps-md-0">
							<BiRadiobutton
								v-for="(label, i) in declaration.radioLabel"
								:key="i"
								:id="`radio${index}${i}`"
								v-model="declaration.decision"
								:label="label"
								:name="`radio${index}`"
								:value="label"
								:is-inline="true"
								:is-disabled="isReadOnly"
								@update:modelValue="
									() => {
										declarationsList[0].decision =
											allRadioEqualDecision() ?? '';
									}
								" />
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12 col-md-12 my-3">
					<BiAlert v-if="formErrorAlert" isError>
						<template #body>
							{{ t(`${moduleId}.declarationsForm.declarationsErrorAlert`) }}
						</template>
					</BiAlert>
				</div>
			</div>
			<div class="mb-5 mt-0 pt-3 d-flex justify-content-center">
				<BiButton
					v-if="!isReadOnly"
					type="submit"
					form="declarationsForm"
					class="mx-1"
					:class="getColor('button', 'success')"
					@click="saveForm()">
					{{ t(`${moduleId}.general.saveCard`) }}
				</BiButton>
			</div>
		</form>
	</div>
</template>

<style scoped>
ul {
	list-style-type: none;
	padding-left: 0;
}
.change-color {
	background-color: #f6f8fa;
}
.title {
	font-weight: bold;
	font-size: 1.111em;
}

@media (max-width: 1200px) {
	div.form-check.form-check-inline {
		margin-right: 0.1rem !important;
	}
}
</style>
