<script setup lang="ts">
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { getFormattedMetadataDate } from "@/utils/dateUtils";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import DocumentBuilder from "@abaco/dynamic-documents/src";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

const props = withDefaults(
	defineProps<{
		formTitle?: string;
	}>(),
	{}
);

const queryFieldsStore = useQueryFieldsStore();
const applicationFormsStore = useApplicationFormsStore();

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const dynamicDocument = ref<any>(null);
const isValid = ref<boolean>(false);
const showErrors = ref<boolean>(false);
const mounted = ref<boolean>(false);
const documentCode = computed(() =>
	queryFieldsStore.getParamByKey("document_code")
);
const applicationId = computed(() => queryFieldsStore.getApplicationId);
const compileStatusIdentifier = computed(
	() => queryFieldsStore.getCompileStatusIdentifier
);
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const fileUploadConfig = computed(() => {
	return {
		readUrl: `/pua-application-forms/${getUserData()?.tenant}/v1/applications/${
			applicationId.value
		}/declarations/${documentCode.value}/files`,
		bucketName: "declarations",
		tenantId: getUserData()?.tenant as string,
	};
});

async function onSave() {
	const isDeclaration = false;
	showErrors.value = true;
	if (isValid.value) {
		//---------- TEMP PATCH ------------
		if (
			dynamicDocument.value &&
			dynamicDocument.value.document &&
			(!dynamicDocument.value.document.validFrom ||
				!dynamicDocument.value.document.validTo)
		) {
			dynamicDocument.value.document.validFrom = getFormattedMetadataDate(
				dynamicDocument.value.documentDefinition?.metadata?.startDateField
			);
			dynamicDocument.value.document.validTo = getFormattedMetadataDate(
				dynamicDocument.value.documentDefinition?.metadata?.endDateField
			);
		}
		//---------- TEMP PATCH ------------

		await applicationFormsStore.saveDeclarations(
			documentCode.value,
			{ document: dynamicDocument.value?.document },
			compileStatusIdentifier.value,
			isDeclaration
		);
	}
}

onMounted(async () => {
	queryFieldsStore.populateState();
	await useApplicationFormsStore().loadDeclarationList(documentCode.value);
	dynamicDocument.value = applicationFormsStore.declarationList;

	mounted.value = true;
});
</script>
<template>
	<div class="container">
		<div v-if="props.formTitle" class="row my-3 justify-content-start">
			<div class="col-12 my-3">
				<h4 class="fw-bold" :class="getColor('text', 'primary')">
					<BiIcon class="mx-2" icon="file-lines" size="lg" />
					{{ props.formTitle }}
				</h4>
			</div>
		</div>
		<div
			v-if="applicationFormsStore.getLoading"
			class="d-flex row justify-content-center mt-5">
			<div class="d-flex justify-content-center">
				<BiProgressIndicator :type="'spinner'"></BiProgressIndicator>
			</div>
		</div>
		<DocumentBuilder
			class="mt-3"
			v-if="
				mounted &&
				!applicationFormsStore.getLoading &&
				dynamicDocument &&
				dynamicDocument.documentDefinition
			"
			v-model="dynamicDocument.document"
			:show-errors="showErrors"
			:schema="dynamicDocument.documentDefinition"
			:file-upload-config="fileUploadConfig"
			:lang-prefix="dynamicDocument.documentDefinition.code"
			:readonly="isReadOnly"
			@update:valid="
				(value: boolean) => {
					isValid = value;
				}
			" />
		<div class="mb-5 mt-3 pt-3 d-flex justify-content-center">
			<BiButton
				v-if="!applicationFormsStore.loading && !isReadOnly && dynamicDocument"
				type="submit"
				class="mx-1"
				:class="getColor('button', 'success')"
				@click="onSave">
				{{ t(`${moduleId}.general.save`) }}
			</BiButton>
		</div>
	</div>
</template>
