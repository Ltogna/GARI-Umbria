<script setup lang="ts">
// Vue
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import {
	type EffluentResponse,
	EffluentResponseSchema,
	type getNoSpreadingPeriodResponse,
	type getNoSpreadingPeriodStoreResponse,
	type saveNoSpreadingPeriodResponse,
	type validationNoSpreadingPeriodResponse,
} from "@/models/applicationForms";
import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiDatepicker from "@abaco/bootstrap-italia-components/src/components/form/BiDatepicker.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import dayjs from "dayjs";

// Store
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { getFormattedDate } from "@/utils/dateUtils.ts";
import BiAutocompleteNext from "@abaco/bootstrap-italia-components/src/components/form/BiAutocompleteNext.vue";
import { toTypedSchema } from "@vee-validate/zod";
import { debounce } from "lodash";
import { useField, useForm } from "vee-validate";
import { z } from "zod";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";

const applicationFormsStore = useApplicationFormsStore();
const QueryFieldsStore = useQueryFieldsStore();

const noSpreadingPeriodList = computed(
	() => applicationFormsStore.getNoSpreadingPeriodListResponse
);

const getDeclarationYear = computed(
	() => applicationFormsStore.getDeclarationYearResponse
);

const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const noSpreadingPeriodId = ref<number>(0);

const isEditMode = ref<boolean>(false);
const modalKey = ref<number>(0);

const moduleId = inject("moduleId");
const { getColor } = useColors();
const { t } = useI18n({});

const loadingData = ref<boolean>(true);
const isReadOnly = computed(() => QueryFieldsStore.getReadOnly === 1);

const minCharFilterEffluent = ref<number>(0);
const effluentList = ref<EffluentResponse[]>([]);
const effluentFilter = ref<string>("");
const isEffluentListLoadingDataFilter = ref<boolean>(false);
const effluentListResponse = computed(
	() => applicationFormsStore.getEffuentListResponse
);
const isNextEffluentValid = ref<string | null | undefined>(null);
const effluentListResponseMap = ref<IListMap>({});

const minDiffDayFormTODayTo = ref<number>(90);
const diffDateType = ref<dayjs.ManipulateType>("day");
const firstOctober = computed(() => {
	let firstOctoberFn = "";

	if (getDeclarationYear.value != null) {
		firstOctoberFn = applicationFormsStore.createDateWithDayjs(
			getDeclarationYear.value?.year,
			10,
			1
		);
	}

	return firstOctoberFn;
});

const lastDayFebrary = computed(() => {
	let yearDate = new Date().getFullYear() + 1;

	if (getDeclarationYear.value != null) {
		yearDate = getDeclarationYear.value?.year + 1;
	}

	const lastDayInMoth = applicationFormsStore.getLastDayOfMonth(yearDate, 2, 1);
	const lastDayFebraryFn = applicationFormsStore.createDateWithDayjs(
		yearDate,
		2,
		lastDayInMoth
	);

	return lastDayFebraryFn;
});

const maxDateDayFrom = computed(() =>
	applicationFormsStore.subtractDate(
		dayTo.value != null && dayTo.value != ""
			? dayTo.value
			: lastDayFebrary.value,
		minDiffDayFormTODayTo.value,
		diffDateType.value
	)
);

const minDaySelectableForDayTO = computed(() => {
	return applicationFormsStore.addDate(
		dayFrom.value != null && dayFrom.value != ""
			? dayFrom.value
			: firstOctober.value,
		minDiffDayFormTODayTo.value,
		diffDateType.value
	);
});

const showEditButton = ref<boolean>(false);
const isDataTableReady = ref<boolean>(false);

async function tableDataMappingDescriptionFromCodeForEffluent() {
	isDataTableReady.value = false;

	createMapEffluentList();

	noSpreadingPeriodList.value.map(
		(noSpreadingPeriodsItem: getNoSpreadingPeriodResponse) => {
			noSpreadingPeriodsItem.effluentDescription =
				effluentListResponseMap.value[noSpreadingPeriodsItem.effluent];

			noSpreadingPeriodsItem.dayFrom =
				applicationFormsStore.addSeparatorInStringForDate(
					noSpreadingPeriodsItem.dayFrom
				);

			noSpreadingPeriodsItem.dayTo =
				applicationFormsStore.addSeparatorInStringForDate(
					noSpreadingPeriodsItem.dayTo
				);

			return noSpreadingPeriodsItem;
		}
	);

	isDataTableReady.value = true;
}

function createMapEffluentList() {
	if (applicationFormsStore.getEffuentListResponse) {
		applicationFormsStore.getEffuentListResponse.map(el => {
			if (el && el.code && el.description) {
				effluentListResponseMap.value[el.code] = el.description;
			}
		});
	}
}

function resetFormValue() {
	dayFrom.value = dayTo.value = effluent.value = null;
}

function toggleAddEditModal(isEdit?: boolean) {
	isEdit ? (isEditMode.value = true) : (isEditMode.value = false);
	isAddEditModalOpen.value = !isAddEditModalOpen.value;
	resetFormValue();
	!isAddEditModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function editNoSpreadingPeriodForm(element: getNoSpreadingPeriodResponse) {
	toggleAddEditModal(true);

	if (element && element.landUseDescription) {
		noSpreadingPeriodId.value = element.pkId ?? 0;
	}
}

function toggleConfirmDeleteModal(element?: getNoSpreadingPeriodStoreResponse) {
	noSpreadingPeriodId.value = element?.pkId ?? 0;
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function deleteNoSpreadingPeriod(noSpreadingPeriodId: number) {
	await applicationFormsStore.deleteNoSpreadingPeriod(noSpreadingPeriodId);
	toggleConfirmDeleteModal();
	await getNoSpreadingPeriodList();
}

onMounted(async () => {
	QueryFieldsStore.populateState();
	loadingData.value = false;

	await applicationFormsStore.getDeclarationYear();
	await initOrFilterEffluentCodeList();
	await getNoSpreadingPeriodList();
});

const { handleSubmit, setErrors, isSubmitting, errors } =
	useForm<validationNoSpreadingPeriodResponse>({
		initialValues: {
			effluent: null,
			dayFrom: null,
			dayTo: null,
		},
	});

const { value: effluent } = useField<EffluentResponse | null>(
	"effluent",
	toTypedSchema(EffluentResponseSchema.nullish())
);

const { value: dayFrom } = useField<string | null>(
	"dayFrom",
	toTypedSchema(z.string().nullish())
);

const { value: dayTo } = useField<string | null>(
	"dayTo",
	toTypedSchema(z.string().nullish())
);

const onSubmitNoSpreadingPeriod = handleSubmit.withControlled(async values => {
	validateFormTable(values);

	if (!errors.value.effluent && !errors.value.dayFrom && !errors.value.dayTo) {
		await checkIfTabCompletedAndSaveOrEditNoSpreadingPeriodForm();
	}
});

const validateFormTable = (
	noSpreadingPeriod: validationNoSpreadingPeriodResponse
) => {
	if (noSpreadingPeriod?.effluent == null) {
		setErrors({
			effluent: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!noSpreadingPeriod?.dayFrom) {
		setErrors({
			dayFrom: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!noSpreadingPeriod?.dayTo) {
		setErrors({
			dayTo: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
};

async function checkIfTabCompletedAndSaveOrEditNoSpreadingPeriodForm() {
	if (
		dayFrom.value != null &&
		dayTo.value != null &&
		effluent.value != null &&
		effluent.value.code != null
	) {
		const saveData: saveNoSpreadingPeriodResponse = {
			effluent: effluent.value.code,
			dayFrom: dayFrom.value.replaceAll(/[-/]/gi, ""),
			dayTo: dayTo.value.replaceAll(/[-/]/gi, ""),
		};

		await saveOrEditNoSpreadingPeriodAndToggleModal(saveData);
	}
}

async function saveOrEditNoSpreadingPeriodAndToggleModal(
	saveData: saveNoSpreadingPeriodResponse
) {
	if (noSpreadingPeriodId.value != null && isEditMode.value) {
		saveData.pkId = noSpreadingPeriodId.value;
		await applicationFormsStore.editNoSpreadingPeriod(saveData);
	} else {
		await applicationFormsStore.saveNoSpreadingPeriod(saveData);
	}

	resetFormValue();
	toggleAddEditModal(false);

	await getNoSpreadingPeriodList();
}

async function getNoSpreadingPeriodList() {
	await applicationFormsStore.getNoSpreadingPeriodList();

	if (noSpreadingPeriodList.value.length > 0) {
		await tableDataMappingDescriptionFromCodeForEffluent();
	}

	isDataTableReady.value = true;
}

function onEffluentListCodeSearchChange(val: string) {
	effluentFilter.value = val;
}

const effluentCodeChange = debounce(async () => {
	await initOrFilterEffluentCodeList();
}, 500);

async function initOrFilterEffluentCodeList() {
	effluentList.value = [];
	isEffluentListLoadingDataFilter.value = true;
	const isFilterForFrequency = false;
	await applicationFormsStore.loadEffulentList(isFilterForFrequency);
	initOrUpdateEffulentList();

	isEffluentListLoadingDataFilter.value = false;
}

function initOrUpdateEffulentList() {
	if (effluentListResponse.value) {
		effluentList.value = effluentListResponse.value;
	}
}
</script>
<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading || !isDataTableReady"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-show="!(applicationFormsStore.getLoading || !isDataTableReady)">
			<div class="row my-3 justify-content-start">
				<div class="col-8 my-3">
					<h4 class="fw-bold" :class="getColor('text', 'primary')">
						<p>
							{{ t(`${moduleId}.noSpreadingPeriods.page.title`) }}
						</p>
					</h4>
				</div>
				<div class="d-flex justify-content-end">
					<BiButton
						v-if="
							(!isReadOnly && !applicationFormsStore.loading) ||
							(applicationFormsStore.loading && isAddEditModalOpen)
						"
						type="submit"
						class="mx-1 mb-2 col-auto"
						:class="`${getColor('button', 'primary', 'outline')}`"
						@click.stop="toggleAddEditModal()">
						{{ t(`${moduleId}.noSpreadingPeriods.button.add`) }}
					</BiButton>
				</div>
			</div>

			<BiTable
				class="table-responsive"
				extraTableClasses="table-head-bg"
				isResponsive
				v-show="!loadingData">
				<template v-slot:head>
					<tr
						class="bg-light text-start"
						:class="getColor('text', 'secondary')">
						<th scope="col">
							{{ t(`${moduleId}.noSpreadingPeriods.table.effluent`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.noSpreadingPeriods.table.dayFrom`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.noSpreadingPeriods.table.dayTo`) }}
						</th>
						<th scope="col"></th>
					</tr>
				</template>
				<template
					v-slot:body
					v-if="
						noSpreadingPeriodList &&
						noSpreadingPeriodList.length > 0 &&
						isDataTableReady
					">
					<tr
						class="align-middle"
						v-for="element in noSpreadingPeriodList"
						:key="element?.pkId!">
						<td
							:data-label="t(`${moduleId}.noSpreadingPeriods.table.effluent`)"
							class="text-start">
							{{ element?.effluentDescription }}
						</td>
						<td
							:data-label="t(`${moduleId}.noSpreadingPeriods.table.dayFrom`)"
							class="text-start">
							{{ getFormattedDate(element?.dayFrom!) }}
						</td>

						<td
							:data-label="t(`${moduleId}.noSpreadingPeriods.table.dayTo`)"
							class="text-start">
							{{ getFormattedDate(element?.dayTo!) }}
						</td>

						<td class="text-end text-nowrap">
							<div>
								<BiTooltip
									:title="
										t(`${moduleId}.noSpreadingPeriods.table.tooltip.edit`)
									"
									:aria-label="
										t(`${moduleId}.noSpreadingPeriods.table.tooltip.edit`)
									">
									<BiButton
										:aria-label="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.edit`)
										"
										:aria-labelledby="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.edit`)
										"
										:alt="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.edit`)
										"
										v-if="!isReadOnly && showEditButton"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="editNoSpreadingPeriodForm(element)"
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'success', 'outline')}`">
										<span>
											<BiIcon icon="pencil" size="xl" icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
								<BiTooltip
									:title="
										t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
									"
									:aria-label="
										t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
									">
									<BiButton
										tabindex="0"
										role="button"
										aria-pressed="false"
										aria-disabled="false"
										:aria-label="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
										"
										:aria-labelledby="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
										"
										:alt="
											t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
										"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="toggleConfirmDeleteModal(element)"
										isPrimary
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'danger', 'outline')}`">
										<span
											:aria-label="
												t(`${moduleId}.noSpreadingPeriods.table.tooltip.delete`)
											">
											<BiIcon
												:aria-label="
													t(
														`${moduleId}.noSpreadingPeriods.table.tooltip.delete`
													)
												"
												icon="trash"
												size="xl"
												icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
							</div>
						</td>
					</tr>
				</template>
				<template v-slot:body v-else>
					<tr>
						<td colspan="3" class="text-start">
							{{ t(`${moduleId}.noSpreadingPeriods.noData`) }}
						</td>
					</tr>
				</template>
			</BiTable>
		</div>
		<!-- -->
	</div>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="t(`${moduleId}.noSpreadingPeriods.modal.delete.title`)"
		:title="t(`${moduleId}.noSpreadingPeriods.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.noSpreadingPeriods.modal.delete.body`) }}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop.prevent="toggleConfirmDeleteModal()">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteNoSpreadingPeriod(noSpreadingPeriodId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- add/edit noSpreadingPeriod crop plan modal -->
	<BiModal
		:disabled-teleport="true"
		:key="modalKey"
		:extra-footer-class="'justify-content-center'"
		v-model="isAddEditModalOpen"
		:aria-labelledby="
			isEditMode
				? t(`${moduleId}.noSpreadingPeriods.modal.edit.title`)
				: t(`${moduleId}.noSpreadingPeriods.modal.add.title`)
		"
		:title="
			isEditMode
				? t(`${moduleId}.noSpreadingPeriods.modal.edit.title`)
				: t(`${moduleId}.noSpreadingPeriods.modal.add.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="noSpreadingPeriodForm"
				class="needs-validation"
				@submit.stop.prevent="onSubmitNoSpreadingPeriod()">
				<div class="row">
					<div class="col-12 mb-5">
						<BiAutocompleteNext
							ref="autocompleteRef"
							name="effluentId"
							:id="'effluentId'"
							:label="
								t(`${moduleId}.fertSpreadingDeclaration.modal.form.effluent`)
							"
							:items="effluentList"
							:isAutocomplete="true"
							:loading="isEffluentListLoadingDataFilter"
							:showNoResults="!isEffluentListLoadingDataFilter"
							v-model="effluent"
							@searchChange="onEffluentListCodeSearchChange"
							@keyup="effluentCodeChange"
							:minSearchLenght="minCharFilterEffluent"
							:labelNoResult="
								t(`${moduleId}.fertSpreadingDeclaration.table.labelNoResult`) +
								` ${effluentFilter}`
							"
							:labelMinCharachter="
								t(`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`)
							"
							:labelNoItems="
								t(
									`${moduleId}.fertSpreadingDeclaration.select.minSearchLength`
								) + ` ${minCharFilterEffluent}`
							"
							:itemTitle="'description'"
							:errors="errors.effluent ? [errors.effluent] : []"
							:disabled="isReadOnly">
							<template #afterList>
								<div
									class="autocomplete-after-search-template"
									v-if="isNextEffluentValid">
									{{
										t(
											`${moduleId}.fertSpreadingDeclaration.select.refineSearch`
										)
									}}
								</div>
							</template>
						</BiAutocompleteNext>
					</div>
				</div>

				<div class="row">
					<div class="col-12 mb-5">
						<BiDatepicker
							name="dayFromOperationId"
							:id="'dayFromOperationId'"
							:is-disabled="isReadOnly"
							:min="firstOctober"
							:max="maxDateDayFrom"
							v-model="dayFrom"
							:label="
								t(
									`${moduleId}.fertSpreadingDeclaration.modal.form.expectedDate`
								)
							"
							:errors="errors.dayFrom ? [errors.dayFrom] : []"></BiDatepicker>
					</div>
				</div>

				<div class="row">
					<div class="col-12 mb-5">
						<BiDatepicker
							name="dayToOperationId"
							:id="'dayToOperationId'"
							:is-disabled="isReadOnly"
							v-model="dayTo"
							:min="minDaySelectableForDayTO"
							:max="lastDayFebrary"
							:label="
								t(
									`${moduleId}.fertSpreadingDeclaration.modal.form.expectedDate`
								)
							"
							:errors="errors.dayTo ? [errors.dayTo] : []"></BiDatepicker>
					</div>
				</div>
				<div
					v-if="applicationFormsStore.getLoading || !isDataTableReady"
					class="d-flex row justify-content-center mb-3 mt-5">
					<div class="d-flex col-2 justify-content-center px-0">
						<BiProgressIndicator type="spinner"></BiProgressIndicator>
					</div>
				</div>
				<div class="mt-3 mb-5 d-flex justify-content-center w-100" v-else>
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="
							() => {
								toggleAddEditModal(false);
							}
						">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						form="noSpreadingPeriodForm"
						:isDisabled="isReadOnly || isSubmitting"
						class="mx-1"
						isPrimary
						:class="getColor('button', 'success')">
						{{
							isEditMode
								? t(`${moduleId}.noSpreadingPeriods.modal.edit.confirmEdit`)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
			</form>
		</template>
	</BiModal>
</template>
<style scoped lang="scss">
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}
</style>
