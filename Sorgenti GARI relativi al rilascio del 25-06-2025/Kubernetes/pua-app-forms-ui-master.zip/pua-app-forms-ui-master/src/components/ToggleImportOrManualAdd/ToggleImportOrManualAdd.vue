<script setup lang="ts">
// Vue
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";
import { inject, ref, watch } from "vue";
import { useI18n } from "vue-i18n";

// const component
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const toggleHandlerImportOrManualAddHtmlField = ref<HTMLInputElement | null>(
	null
);

const props = defineProps<{
	toggleHandlerImportOrManualAdd: boolean | null;
	isReadOnly: boolean;
}>();

const emit = defineEmits([
	"showConfirmModalImportAndSetToggleImport",
	"showConfirmModalDeleteAllAndSetToggleManualAdd",
]);

watch(
	() => props.toggleHandlerImportOrManualAdd,
	() => {
		if (
			toggleHandlerImportOrManualAddHtmlField.value &&
			props.toggleHandlerImportOrManualAdd != null
		) {
			toggleHandlerImportOrManualAddHtmlField.value.checked =
				props.toggleHandlerImportOrManualAdd;
		}
	}
);

async function onCLickLabel(functionCaller: string) {
	if (
		functionCaller == t(`${moduleId}.ChemicalAndOrganicFertilizer.table.import`)
	) {
		emit("showConfirmModalImportAndSetToggleImport");
	} else if (
		functionCaller ==
		t(`${moduleId}.ChemicalAndOrganicFertilizer.table.manualManagement`)
	) {
		emit("showConfirmModalDeleteAllAndSetToggleManualAdd");
	}
}
</script>
<template>
	<div
		class="toggles"
		:class="{
			'bring-toggle-in-middle': props.toggleHandlerImportOrManualAdd === null,
			'not-bring-toggle-in-middle':
				props.toggleHandlerImportOrManualAdd != null,
		}">
		<div class="d-flex">
			<label class="d-flex" for="toggleHandleImportOrManualAdd">
				<BiButton
					class="toggle-label"
					:class="
						`${getColor('button', 'primary', 'outline')}` +
						`${props.toggleHandlerImportOrManualAdd == false && isReadOnly ? ' activeReadOnly' : ''}`
					"
					:disabled="
						props.toggleHandlerImportOrManualAdd == false || isReadOnly
					"
					@click.prevent.stop="
						onCLickLabel(
							t(`${moduleId}.ChemicalAndOrganicFertilizer.table.import`)
						)
					">
					{{ t(`${moduleId}.ChemicalAndOrganicFertilizer.table.import`) }}
				</BiButton>

				<input
					@click.prevent.stop="() => {}"
					:disabled="!isReadOnly"
					ref="toggleHandlerImportOrManualAddHtmlField"
					type="checkbox"
					id="toggleHandleImportOrManualAdd" />
				<span class="lever"></span>
			</label>
			<label for="toggleHandleImportOrManualAdd">
				<BiButton
					class="toggle-label"
					:class="
						`${getColor('button', 'primary', 'outline')}` +
						`${props.toggleHandlerImportOrManualAdd == true && isReadOnly ? ' activeReadOnly' : ''}`
					"
					:disabled="props.toggleHandlerImportOrManualAdd == true || isReadOnly"
					@click="
						onCLickLabel(
							t(
								`${moduleId}.ChemicalAndOrganicFertilizer.table.manualManagement`
							)
						)
					">
					{{
						t(`${moduleId}.ChemicalAndOrganicFertilizer.table.manualManagement`)
					}}
				</BiButton>
			</label>
		</div>
	</div>
</template>

<style scoped>
.toggles.bring-toggle-in-middle label input[type="checkbox"] + .lever:before,
.toggles.bring-toggle-in-middle label input[type="checkbox"] + .lever:after {
	left: 10px;
}

div.toggles label {
	cursor: default;
}

.toggles label input[type="checkbox"] + .lever:after {
	border: 2px solid #145999;
}

.toggles.not-bring-toggle-in-middle
	label
	input[type="checkbox"][disabled]
	+ .lever {
	background-color: #145999;
}

div.toggles label input[type="checkbox"] + .lever:before,
div.toggles label input[type="checkbox"] + .lever:after,
div.toggles label input[type="checkbox"][disabled]:checked + .lever:before,
div.toggles label input[type="checkbox"][disabled]:checked + .lever:after {
	background-image: none;
	background-color: #ffffff;
}

@media (max-width: 1200px) {
	div.form-check.form-check-inline {
		margin-right: 0.1rem !important;
	}
}

.activeReadOnly {
	--bs-text-opacity: 1;
	color: rgba(var(--bs-primary-rgb), var(--bs-text-opacity)) !important;
	opacity: 1 !important;
}
</style>
