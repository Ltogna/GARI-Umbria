<script setup lang="ts">
import DynamicDocumentViewer from "../dynamicDocumentViewer/DynamicDocumentViewer.vue";
</script>
<template>
	<DynamicDocumentViewer></DynamicDocumentViewer>
</template>
