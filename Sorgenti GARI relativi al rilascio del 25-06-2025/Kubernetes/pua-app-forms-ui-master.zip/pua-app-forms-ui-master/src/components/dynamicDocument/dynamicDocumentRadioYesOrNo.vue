<script setup lang="ts">
import DynamicDocumentRadioYesNoViewer from "../dynamicDocumentViewer/dynamicDocumentVariations/DynamicDocumentRadioYesNoViewer.vue";
</script>
<template>
	<DynamicDocumentRadioYesNoViewer></DynamicDocumentRadioYesNoViewer>
</template>
