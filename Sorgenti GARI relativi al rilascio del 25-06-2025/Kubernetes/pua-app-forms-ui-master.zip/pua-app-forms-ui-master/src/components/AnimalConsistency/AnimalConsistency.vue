<script setup lang="ts">
// Vue
import { computed, inject, onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import { useApplicationFormsStore } from "@/stores/applicationFormsStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import BiButton from "@abaco/bootstrap-italia-components/src/components/BiButton/BiButton.vue";
import BiProgressIndicator from "@abaco/bootstrap-italia-components/src/components/BiProgressIndicator/BiProgressIndicator.vue";

import BiAlert from "@abaco/bootstrap-italia-components/src/components/BiAlert/BiAlert.vue";
import BiIcon from "@abaco/bootstrap-italia-components/src/components/BiIcon/BiIcon.vue";
import BiModal from "@abaco/bootstrap-italia-components/src/components/BiModal/BiModal.vue";
import BiTable from "@abaco/bootstrap-italia-components/src/components/BiTable/BiTable.vue";
import BiTooltip from "@abaco/bootstrap-italia-components/src/components/BiTooltip/BiTooltip.vue";
import BiInput from "@abaco/bootstrap-italia-components/src/components/form/BiInput.vue";
import BiSelect from "@abaco/bootstrap-italia-components/src/components/form/BiSelect.vue";
import useColors from "@abaco/bootstrap-italia-components/src/composables/useColors";

// other
import {
	type getAnimalConsistencyResponse,
	type getAnimalConsistencyValidationResponse,
	type getCategoryFromSpecieResponse,
	type getCategoryResponse,
	type getHousingTypeFromCategoryResponse,
	type getHousingTypeResponse,
	type getSpecieResponse,
} from "@/models/applicationForms";
import { toTypedSchema } from "@vee-validate/zod";
import { useField, useForm } from "vee-validate";
import { z } from "zod";
import type { ISelectOptions } from "../ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizerForm/ChemicalAndOrganicFertilizerForm.vue";
import type { IListMap } from "../ChemicalFertilizer/ChemicalFertilizer.vue";

const applicationFormsStore = useApplicationFormsStore();
const moduleId = inject("moduleId");
const { t } = useI18n({});
const { getColor } = useColors();

const queryFieldsStore = useQueryFieldsStore();
const isReadOnly = computed(() => queryFieldsStore.getReadOnly === 1);

const isAddEditModalOpen = ref<boolean>(false);
const isConfirmDeleteModalOpen = ref<boolean>(false);
const animalConsistencyId = ref<number>(0);

const isEditMode = ref<boolean>(false);
const modalKey = ref<number>(0);
const isDataTableReady = ref<boolean>(false);

const getSpecieListMap = ref<IListMap>({});
const getCategoryListMap = ref<IListMap>({});
const getHousingTypeListMap = ref<IListMap>({});

const animalConsistencyListResponse = computed(
	() => applicationFormsStore.getAnimalConsistencyListResponse
);

const specieCodeList = computed(() => {
	const specieCodeWithDuplicate =
		applicationFormsStore.getAnimalConsistencyListResponse.records.reduce(
			(acc: getCategoryFromSpecieResponse[], el) => {
				if (el && el.species) {
					const specieGencodeAndCode = el.species.split("_");
					const specieFormatted: getCategoryFromSpecieResponse = {
						specieCode: specieGencodeAndCode[1],
						genreCode: specieGencodeAndCode[0],
					};

					acc.push(specieFormatted);
				}

				return acc;
			},
			[]
		);

	const uniqueArr: readonly getCategoryFromSpecieResponse[] = Object.freeze(
		Array.from(
			specieCodeWithDuplicate
				.reduce((map, obj) => {
					map.set(`${obj.specieCode}-${obj.genreCode}`, obj);
					return map;
				}, new Map<string, getCategoryFromSpecieResponse>())
				.values()
		)
	);

	return uniqueArr.slice();
});

const categoryCodeList = computed(() => {
	const categoryCodeWithDuplicate =
		applicationFormsStore.getCategoryListFromCodeResponse.reduce(
			(acc: getHousingTypeFromCategoryResponse[], el) => {
				if (
					el &&
					el.code &&
					el.productionCode &&
					el.genreCode &&
					el.specieCode
				) {
					const specieFormatted: getHousingTypeFromCategoryResponse = {
						specieCode: el.specieCode,
						genreCode: el.genreCode,
						categoryCode: el.code,
						productionCode: el.productionCode,
					};
					acc.push(specieFormatted);
				}

				return acc;
			},
			[]
		);

	const uniqueArr: readonly getHousingTypeFromCategoryResponse[] =
		Object.freeze(
			Array.from(
				categoryCodeWithDuplicate
					.reduce((map, obj) => {
						map.set(
							`${obj.specieCode}-${obj.genreCode}-${obj.categoryCode}-${obj.productionCode}`,
							obj
						);
						return map;
					}, new Map<string, getHousingTypeFromCategoryResponse>())
					.values()
			)
		);

	return uniqueArr.slice();
});

const specieSelected = ref<getSpecieResponse>({} as getSpecieResponse);

const categorySelected = ref<getCategoryResponse>({} as getCategoryResponse);

const housingTypeSelected = ref<getHousingTypeResponse>(
	{} as getHousingTypeResponse
);

const getSpecieList = computed(() => {
	const specieListFormatted = ref<ISelectOptions[]>([]);

	applicationFormsStore.getSpecieListResponse.map(el => {
		if (el && el.code && el.description) {
			specieListFormatted.value.push({
				id: `${el.genreCode}_${el.code}`,
				text: el.description,
			});
		}
	});

	return specieListFormatted.value;
});

const getCategoryList = computed(() => {
	const categoryListFormatted = ref<ISelectOptions[]>([]);

	applicationFormsStore.getCategoryListResponse.map(el => {
		if (el && el.code && el.description) {
			categoryListFormatted.value.push({
				id: `${el.genreCode}_${el.specieCode}_${el.code}_${el.productionCode}`,
				text: el.description,
			});
		}
	});

	return categoryListFormatted.value;
});

const getHousingTypeList = computed(() => {
	const housingTypeListFormatted = ref<ISelectOptions[]>([]);

	applicationFormsStore.getHousingTypeListResponse.map(el => {
		if (el && el.code && el.description) {
			housingTypeListFormatted.value.push({
				id: el.code,
				text: el.description,
			});
		}
	});

	return housingTypeListFormatted.value;
});

onMounted(async () => {
	queryFieldsStore.populateState();
	await applicationFormsStore.getAnimalConsistencyList();
	await applicationFormsStore.getSpecieList();
	await tableDataMappingSpecieAndCategoryAndHousingType();
});

async function tableDataMappingSpecieAndCategoryAndHousingType() {
	isDataTableReady.value = false;

	await getCategoryListFormSpecieCode();
	await getHousingTypeListFromCategoryCode();

	createMapSpecieListMap();
	createMapCategoryListMap();
	createMapHousingTypeListMap();

	applicationFormsStore.getAnimalConsistencyListResponse.records.reduce(
		(
			acc: any,
			animalConsistencyItem: getAnimalConsistencyResponse,
			index: number
		) => {
			if (
				animalConsistencyItem &&
				animalConsistencyItem.species &&
				animalConsistencyItem.category &&
				animalConsistencyItem.typeStabling
			) {
				animalConsistencyItem.specieDescription =
					getSpecieListMap.value[animalConsistencyItem.species];

				animalConsistencyItem.categoryDescription =
					getCategoryListMap.value[animalConsistencyItem.category];
				animalConsistencyItem.typeStablingDescription =
					getHousingTypeListMap.value[animalConsistencyItem.typeStabling];

				acc[index] = animalConsistencyItem;
				return acc;
			}
		},
		[]
	);
	resetFormTable();
	isDataTableReady.value = true;
}

function createMapSpecieListMap() {
	if (applicationFormsStore.getSpecieListResponse) {
		applicationFormsStore.getSpecieListResponse.map(el => {
			getSpecieListMap.value[`${el.genreCode}_${el.code}`] = el.description;
		});
	}
}

function createMapCategoryListMap() {
	if (applicationFormsStore.getCategoryListFromCodeResponse) {
		applicationFormsStore.getCategoryListFromCodeResponse.map(el => {
			getCategoryListMap.value[
				`${el.genreCode}_${el.specieCode}_${el.code}_${el.productionCode}`
			] = el.description;
		});
	}
}

function createMapHousingTypeListMap() {
	if (applicationFormsStore.getHousingTypeListFromCategoryCodeResponse) {
		applicationFormsStore.getHousingTypeListFromCategoryCodeResponse.map(el => {
			getHousingTypeListMap.value[el.code] = el.description;
		});
	}
}

async function onChangeAnimalSpeciesGetCategory(
	event: Event | null,
	isInitComponent: boolean,
	editValueForSetValueFunction: string | null
) {
	if (!isInitComponent) {
		typeStabling.value = null;
		category.value = null;
	}

	let newValueSpecies = "";
	if (event != null) {
		const target = event.target as HTMLSelectElement;
		newValueSpecies = target.value;
	} else if (editValueForSetValueFunction != null) {
		newValueSpecies = editValueForSetValueFunction;
	}

	specieSelected.value = applicationFormsStore.getSpecieListResponse.filter(
		el => `${el.genreCode}_${el.code}` == newValueSpecies
	)[0];

	await applicationFormsStore.getCategoryList(
		specieSelected.value?.code,
		specieSelected.value?.genreCode
	);
}

async function getCategoryListFormSpecieCode() {
	await applicationFormsStore.getCategoryListFromSpecieCode(
		specieCodeList.value
	);
}

async function onChangeCategoryGetHousingType(
	event: Event | null,
	isInitComponent: boolean,
	editValueForSetValueFunction: string | null
) {
	if (!isInitComponent) {
		typeStabling.value = null;
	}

	let newValueCategory = "";

	if (event != null) {
		const target = event.target as HTMLSelectElement;
		newValueCategory = target.value;
	} else if (editValueForSetValueFunction != null) {
		newValueCategory = editValueForSetValueFunction;
	}

	categorySelected.value = applicationFormsStore.getCategoryListResponse.filter(
		el => {
			const key = `${el.genreCode}_${el.specieCode}_${el.code}_${el.productionCode}`;
			return key == newValueCategory;
		}
	)[0];

	await applicationFormsStore.getHousingTypeList(
		specieSelected.value.code,
		specieSelected.value.genreCode,
		categorySelected.value.code,
		categorySelected.value.productionCode
	);

	averagePV.value = categorySelected.value.averageWeight.toFixed(1);
	numberField.value = categorySelected.value.nitrogenPV.toFixed(1);
}

async function getHousingTypeListFromCategoryCode() {
	await applicationFormsStore.getHousingTypeListFromCategoryCode(
		categoryCodeList.value
	);
}

async function onChangeHousingType(
	event: Event | null,
	editValueForSetHousingTypeFunction: string | null
) {
	let newValueHousingType = "";
	if (event != null) {
		const target = event.target as HTMLSelectElement;
		newValueHousingType = target.value;
	} else if (editValueForSetHousingTypeFunction != null) {
		newValueHousingType = editValueForSetHousingTypeFunction;
	}

	housingTypeSelected.value =
		applicationFormsStore.getHousingTypeListResponse.filter(
			el => el.code == newValueHousingType
		)[0];

	onChangeNumberHeadsRaised();
}

function onChangeNumberHeadsRaised() {
	setValueAsIntegerNumber();
	if (
		numberHeadsRaised.value != null &&
		+numberHeadsRaised.value != 0 &&
		!isNaN(+(+numberHeadsRaised.value).toFixed(0))
	) {
		sewageOutlet.value = (
			housingTypeSelected.value.sewageSludge * +numberHeadsRaised.value
		).toFixed(1);
		manureOrShovelableOutput.value = (
			housingTypeSelected.value.shovellableT * +numberHeadsRaised.value
		).toFixed(1);
	} else {
		sewageOutlet.value = housingTypeSelected.value.sewageSludge.toFixed(1);
		manureOrShovelableOutput.value =
			housingTypeSelected.value.shovellableT.toFixed(1);
	}
}

async function cancelTab() {
	toggleAddEditModal(false);
	resetFormTable();
}

async function checkIfTabCompletedAndSaveOrEditAnimalConsistencyAndToggleModal() {
	if (
		typeStabling.value &&
		species.value &&
		category.value &&
		numberHeadsRaised.value != null &&
		numberField.value != null &&
		averagePV.value != null &&
		sewageOutlet.value != null &&
		manureOrShovelableOutput.value != null
	) {
		const saveData: getAnimalConsistencyResponse = {
			id: animalConsistencyId.value ? animalConsistencyId.value : null,
			typeStabling: typeStabling.value,
			species: species.value,
			category: category.value,
			numberHeadsRaised: +numberHeadsRaised.value,
			numberField: +numberField.value,
			averagePV: +averagePV.value,
			sewageOutlet: +sewageOutlet.value.replaceAll(",", "."),
			manureOrShovelableOutput: +manureOrShovelableOutput.value.replaceAll(
				",",
				"."
			),
		};

		await SaveOrEditAnimalConsistencyAndToggleModal(saveData);
	}
}

function resetFormTable() {
	animalConsistencyId.value = 0;
	species.value =
		category.value =
		typeStabling.value =
		numberHeadsRaised.value =
		numberField.value =
		averagePV.value =
		sewageOutlet.value =
		manureOrShovelableOutput.value =
			null;
}

async function SaveOrEditAnimalConsistencyAndToggleModal(
	saveData: getAnimalConsistencyResponse
) {
	if (saveData && isEditMode.value) {
		await applicationFormsStore.editAnimalConsistency(saveData);
	} else {
		await applicationFormsStore.saveAnimalConsistency(saveData);
	}
}

const { handleSubmit, setErrors, isSubmitting, errors } =
	useForm<getAnimalConsistencyValidationResponse>({
		initialValues: {
			species: null,
			category: null,
			typeStabling: null,
			numberHeadsRaised: null,
			numberField: null,
			averagePV: null,
			sewageOutlet: null,
			manureOrShovelableOutput: null,
		},
	});

const { value: species } = useField<string | null>(
	"species",
	toTypedSchema(z.string().nullish())
);

const { value: category } = useField<string | null>(
	"category",
	toTypedSchema(z.string().nullish())
);

const { value: typeStabling } = useField<string | null>(
	"typeStabling",
	toTypedSchema(z.string().nullish())
);

const { value: numberHeadsRaised } = useField<number | string | null>(
	"numberHeadsRaised",
	toTypedSchema(z.number().or(z.string()).nullish())
);

const { value: numberField } = useField<string | null>(
	"numberField",
	toTypedSchema(z.string().nullish())
);

const { value: averagePV } = useField<string | null>(
	"averagePV",
	toTypedSchema(z.string().nullish())
);

const { value: sewageOutlet } = useField<string | null>(
	"sewageOutlet",
	toTypedSchema(z.string().nullish())
);

const { value: manureOrShovelableOutput } = useField<string | null>(
	"manureOrShovelableOutput",
	toTypedSchema(z.string().nullish())
);

const validateForm = (animalConsistency: getAnimalConsistencyResponse) => {
	if (!animalConsistency?.species) {
		setErrors({
			species: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
	if (!animalConsistency?.category) {
		setErrors({
			category: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.typeStabling) {
		setErrors({
			typeStabling: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.numberHeadsRaised) {
		setErrors({
			numberHeadsRaised: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.numberField) {
		setErrors({
			numberField: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.averagePV) {
		setErrors({
			averagePV: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.sewageOutlet) {
		setErrors({
			sewageOutlet: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}

	if (!animalConsistency?.manureOrShovelableOutput) {
		setErrors({
			manureOrShovelableOutput: t(`${moduleId}.errors.FIELD_REQUIRED`),
		});
	}
};

const onSubmit = handleSubmit.withControlled(async values => {
	validateForm(values);

	if (
		!errors.value.species &&
		!errors.value.category &&
		!errors.value.typeStabling &&
		!errors.value.numberHeadsRaised &&
		!errors.value.numberField &&
		!errors.value.averagePV &&
		!errors.value.sewageOutlet &&
		!errors.value.manureOrShovelableOutput
	) {
		await checkIfTabCompletedAndSaveOrEditAnimalConsistencyAndToggleModal();
		toggleAddEditModal(false);
		resetFormTable();
		await applicationFormsStore.getAnimalConsistencyList();
		await tableDataMappingSpecieAndCategoryAndHousingType();
	}
});

function toggleAddEditModal(isEdit?: boolean) {
	isEdit ? (isEditMode.value = true) : (isEditMode.value = false);
	isAddEditModalOpen.value = !isAddEditModalOpen.value;
	!isAddEditModalOpen.value && applicationFormsStore.resetBodyScroll();
}

function toggleModalAndSetId(element: getAnimalConsistencyResponse) {
	animalConsistencyId.value = element?.id ?? 0;
	toggleConfirmDeleteModal();
}

async function setValueEditAnimalConsistency(
	element: getAnimalConsistencyResponse
) {
	const isInitComponent = true;
	toggleAddEditModal(true);

	if (
		element &&
		element.id != null &&
		element.species &&
		element.category &&
		element.typeStabling &&
		element.numberHeadsRaised != null &&
		element.numberField != null &&
		element.averagePV != null &&
		element.sewageOutlet != null &&
		element.manureOrShovelableOutput != null
	) {
		animalConsistencyId.value = element.id;
		species.value = element.species;
		category.value = element.category;
		typeStabling.value = element.typeStabling;
		numberHeadsRaised.value = element.numberHeadsRaised;
		numberField.value = String(element.numberField);
		averagePV.value = String(element.averagePV);

		const eventNull = null;

		await onChangeAnimalSpeciesGetCategory(
			eventNull,
			isInitComponent,
			element.species
		);
		await onChangeCategoryGetHousingType(
			eventNull,
			isInitComponent,
			element.category
		);
		await onChangeHousingType(eventNull, element.typeStabling);

		sewageOutlet.value = String(element.sewageOutlet);
		manureOrShovelableOutput.value = String(element.manureOrShovelableOutput);
	}
}

function toggleConfirmDeleteModal() {
	isConfirmDeleteModalOpen.value = !isConfirmDeleteModalOpen.value;
	!isConfirmDeleteModalOpen.value && applicationFormsStore.resetBodyScroll();
}

async function deleteAnimalConsistency(animalConsistencyId: number) {
	await applicationFormsStore.deleteAnimalConsistency(animalConsistencyId);
	toggleConfirmDeleteModal();
	await applicationFormsStore.getAnimalConsistencyList();
	await tableDataMappingSpecieAndCategoryAndHousingType();
}

function setValueAsIntegerNumber() {
	if (numberHeadsRaised.value != null) {
		numberHeadsRaised.value = (+numberHeadsRaised.value).toFixed(0);
	}
}
</script>

<template>
	<div class="container">
		<div
			v-if="applicationFormsStore.getLoading || !isDataTableReady"
			class="d-flex row justify-content-center mb-3 mt-5">
			<div class="d-flex col-2 justify-content-center px-0">
				<BiProgressIndicator type="spinner"></BiProgressIndicator>
			</div>
		</div>
		<div v-else>
			<div class="row my-3 justify-content-start">
				<div class="col-12 my-3 row">
					<div class="col-12 d-flex justify-content-between">
						<div>
							<h4 class="fw-bold" :class="getColor('text', 'primary')">
								<p>
									{{ t(`${moduleId}.graphicCropPlan.title`) }}
								</p>
							</h4>
						</div>
					</div>
				</div>
			</div>

			<div class="d-flex justify-content-end">
				<BiButton
					v-if="
						(!isReadOnly && !applicationFormsStore.loading) ||
						(applicationFormsStore.loading && isAddEditModalOpen)
					"
					class="mx-1 mb-4"
					:class="`${getColor('button', 'primary', 'outline')}`"
					@click.stop="toggleAddEditModal()">
					{{ t(`${moduleId}.animalConsistency.button.add`) }}
				</BiButton>
				<BiProgressIndicator
					v-if="applicationFormsStore.loading && !isAddEditModalOpen"
					type="spinner"></BiProgressIndicator>
			</div>
			<BiTable
				class="table-responsive"
				extraTableClasses="table-head-bg"
				isResponsive>
				<template v-slot:head>
					<tr
						class="bg-light text-start"
						:class="getColor('text', 'secondary')">
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.species`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.category`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.housingType`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.numberHeadsRaised`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.numberField`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.averagePV`) }}
						</th>
						<th scope="col">
							{{ t(`${moduleId}.animalConsistency.table.sewageOutlet`) }}
						</th>
						<th scope="col">
							{{
								t(
									`${moduleId}.animalConsistency.table.manureOrShovelableOutput`
								)
							}}
						</th>
						<th scope="col"></th>
					</tr>
				</template>
				<template
					v-slot:body
					v-if="
						animalConsistencyListResponse &&
						animalConsistencyListResponse.records.length > 0
					">
					<tr
						class="align-middle"
						v-for="element in animalConsistencyListResponse.records"
						:key="element?.id!">
						<td
							:data-label="t(`${moduleId}.animalConsistency.page.species`)"
							class="text-start">
							{{ element?.specieDescription }}
						</td>
						<td
							:data-label="t(`${moduleId}.animalConsistency.page.category`)"
							class="text-start">
							{{ element?.categoryDescription }}
						</td>

						<td
							:data-label="t(`${moduleId}.animalConsistency.table.housingType`)"
							class="text-end">
							{{ element?.typeStablingDescription }}
						</td>
						<td
							:data-label="
								t(`${moduleId}.animalConsistency.table.numberHeadsRaised`)
							"
							class="text-end">
							{{ element?.numberHeadsRaised }}
						</td>
						<td
							:data-label="t(`${moduleId}.animalConsistency.table.numberField`)"
							class="text-end">
							{{ element?.numberField }}
						</td>
						<td
							:data-label="t(`${moduleId}.animalConsistency.table.averagePV`)"
							class="text-end">
							{{ element?.averagePV }}
						</td>
						<td
							:data-label="t(`${moduleId}.animalConsistency.page.sewageOutlet`)"
							class="text-end">
							{{ element?.sewageOutlet }}
						</td>
						<td
							:data-label="
								t(`${moduleId}.animalConsistency.page.manureOrShovelableOutput`)
							"
							class="text-end">
							{{ element?.manureOrShovelableOutput }}
						</td>
						<td class="text-end text-nowrap">
							<div>
								<BiTooltip
									:title="t(`${moduleId}.animalConsistency.table.tooltip.edit`)"
									:aria-label="
										t(`${moduleId}.animalConsistency.table.tooltip.edit`)
									">
									<BiButton
										:aria-label="
											t(`${moduleId}.animalConsistency.table.tooltip.edit`)
										"
										:aria-labelledby="
											t(`${moduleId}.animalConsistency.table.tooltip.edit`)
										"
										:alt="t(`${moduleId}.animalConsistency.table.tooltip.edit`)"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="setValueEditAnimalConsistency(element)"
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'success', 'outline')}`">
										<span>
											<BiIcon icon="pencil" size="xl" icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
								<BiTooltip
									:title="
										t(`${moduleId}.animalConsistency.table.tooltip.delete`)
									"
									:aria-label="
										t(`${moduleId}.animalConsistency.table.tooltip.delete`)
									">
									<BiButton
										tabindex="0"
										role="button"
										aria-pressed="false"
										aria-disabled="false"
										:aria-label="
											t(`${moduleId}.animalConsistency.table.tooltip.delete`)
										"
										:aria-labelledby="
											t(`${moduleId}.animalConsistency.table.tooltip.delete`)
										"
										:alt="
											t(`${moduleId}.animalConsistency.table.tooltip.delete`)
										"
										v-if="!isReadOnly"
										:disabled="applicationFormsStore.loading"
										@click.stop.prevent="toggleModalAndSetId(element)"
										isPrimary
										:width="40"
										class="mx-1 my-0"
										:class="`${getColor('button', 'danger', 'outline')}`">
										<span
											:aria-label="
												t(`${moduleId}.animalConsistency.table.tooltip.delete`)
											">
											<BiIcon
												:aria-label="
													t(
														`${moduleId}.animalConsistency.table.tooltip.delete`
													)
												"
												icon="trash"
												size="xl"
												icon-style="regular" />
										</span>
									</BiButton>
								</BiTooltip>
							</div>
						</td>
					</tr>
				</template>
				<template v-slot:body v-else>
					<tr>
						<td colspan="3" class="text-start">
							{{ t(`${moduleId}.general.noData`) }}
						</td>
					</tr>
				</template>
			</BiTable>
		</div>
	</div>

	<!-- confirm delete modal -->
	<BiModal
		:disabled-teleport="true"
		:extra-footer-class="'justify-content-center'"
		v-model="isConfirmDeleteModalOpen"
		:aria-labelledby="t(`${moduleId}.animalConsistency.modal.delete.title`)"
		:title="t(`${moduleId}.animalConsistency.modal.delete.title`)"
		:prevent-dismiss="true">
		<template #body>
			<div class="col-12 mb-3">
				<BiAlert isWarn>
					<template #body>
						{{ t(`${moduleId}.animalConsistency.modal.delete.body`) }}
					</template>
				</BiAlert>
			</div>
		</template>
		<template #footer>
			<div class="d-flex justify-content-center w-100">
				<BiButton
					class="mx-1"
					:class="getColor('button', 'secondary', 'outline')"
					@click.stop="
						() => {
							toggleConfirmDeleteModal();
						}
					">
					{{ t(`${moduleId}.general.cancel`) }}
				</BiButton>
				<BiButton
					class="mx-1"
					isPrimary
					:class="getColor('button', 'success')"
					@click.stop="deleteAnimalConsistency(animalConsistencyId)">
					{{ t(`${moduleId}.general.confirm`) }}
				</BiButton>
			</div>
			<div
				v-if="applicationFormsStore.getLoading"
				class="d-flex row justify-content-center mb-3">
				<div class="d-flex col-2 justify-content-center px-0">
					<BiProgressIndicator type="spinner"></BiProgressIndicator>
				</div>
			</div>
		</template>
	</BiModal>

	<!-- add/edit animal consistency -->
	<BiModal
		:disabled-teleport="true"
		:key="modalKey"
		class="animal-consistency-modal-container"
		:extra-footer-class="'justify-content-center'"
		v-model="isAddEditModalOpen"
		:aria-labelledby="
			isEditMode
				? t(`${moduleId}.animalConsistency.modal.edit.title`)
				: t(`${moduleId}.animalConsistency.modal.add.title`)
		"
		:title="
			isEditMode
				? t(`${moduleId}.animalConsistency.modal.edit.title`)
				: t(`${moduleId}.animalConsistency.modal.add.title`)
		"
		:prevent-dismiss="true">
		<template #body>
			<form
				id="animalConsistencyForm"
				class="needs-validation"
				@submit.stop.prevent="onSubmit()">
				<div class="row mb-3">
					<div class="col-12">
						<BiSelect
							class="mb-4"
							name="speciesId"
							:id="'speciesId'"
							:isMultiple="false"
							:isAutocomplete="false"
							:label="t(`${moduleId}.animalConsistency.page.species`)"
							:items="getSpecieList ?? []"
							v-model="species"
							:errors="errors.species ? [errors.species] : []"
							@change="
								onChangeAnimalSpeciesGetCategory($event, false, null)
							"></BiSelect>
					</div>
				</div>
				<div class="row mb-3">
					<div class="col-12">
						<BiSelect
							name="categoryId"
							:id="'categoryId'"
							class="mb-4"
							:isMultiple="false"
							:isAutocomplete="false"
							:label="t(`${moduleId}.animalConsistency.page.category`)"
							:items="getCategoryList ?? []"
							:errors="errors.category ? [errors.category] : []"
							v-model="category"
							@change="
								onChangeCategoryGetHousingType($event, false, null)
							"></BiSelect>
					</div>
				</div>

				<div class="row mb-3">
					<div class="col-12">
						<BiSelect
							class="mb-4"
							name="typeStablingId"
							:id="'typeStablingId'"
							:isMultiple="false"
							:isAutocomplete="false"
							:errors="errors.typeStabling ? [errors.typeStabling] : []"
							:label="t(`${moduleId}.animalConsistency.page.housingType`)"
							:items="getHousingTypeList ?? []"
							v-model="typeStabling"
							@change="onChangeHousingType($event, null)"></BiSelect>
					</div>
				</div>

				<div class="row mb-3">
					<div class="col-12">
						<BiInput
							class="mb-4"
							name="numberHeadsRaisedId"
							:id="'numberHeadsRaisedId'"
							type="number"
							@keyup="onChangeNumberHeadsRaised()"
							:min="0"
							:errors="
								errors.numberHeadsRaised ? [errors.numberHeadsRaised] : []
							"
							:label="
								t(`${moduleId}.animalConsistency.table.numberHeadsRaised`)
							"
							v-model="numberHeadsRaised" />
					</div>
				</div>

				<div class="row mb-5">
					<div class="col-6">
						<BiInput
							name="averagePVId"
							:id="'averagePVId'"
							type="number"
							:min="0"
							:readonly="true"
							:errors="errors.averagePV ? [errors.averagePV] : []"
							:label="t(`${moduleId}.animalConsistency.table.averagePV`)"
							v-model="averagePV" />
					</div>

					<div class="col-6">
						<BiInput
							name="numberFieldId"
							:id="'numberFieldId'"
							type="number"
							:min="0"
							:readonly="true"
							:errors="errors.numberField ? [errors.numberField] : []"
							:label="t(`${moduleId}.animalConsistency.table.numberField`)"
							v-model="numberField" />
					</div>
				</div>

				<div class="row mb-5">
					<div class="col-12">
						<BiInput
							name="sewageOutletId"
							:id="'sewageOutletId'"
							:errors="errors.sewageOutlet ? [errors.sewageOutlet] : []"
							:label="t(`${moduleId}.animalConsistency.page.sewageOutlet`)"
							v-model="sewageOutlet" />
					</div>
				</div>

				<div class="row mb-5">
					<div class="col-12">
						<BiInput
							name="manureOrShovelableOutputId"
							:id="'manureOrShovelableOutputId'"
							:errors="
								errors.manureOrShovelableOutput
									? [errors.manureOrShovelableOutput]
									: []
							"
							:label="
								t(`${moduleId}.animalConsistency.page.manureOrShovelableOutput`)
							"
							v-model="manureOrShovelableOutput" />
					</div>
				</div>

				<div class="mt-3 mb-5 d-flex justify-content-center w-100">
					<BiButton
						class="mx-1"
						:class="getColor('button', 'secondary', 'outline')"
						@click.stop="cancelTab()">
						{{ t(`${moduleId}.general.cancel`) }}
					</BiButton>
					<BiButton
						type="submit"
						form="animalConsistencyForm"
						class="mx-1"
						isPrimary
						:is-disabled="isSubmitting"
						:class="getColor('button', 'success')">
						{{
							isEditMode
								? t(`${moduleId}.animalConsistency.modal.edit.confirmEdit`)
								: t(`${moduleId}.general.save`)
						}}
					</BiButton>
				</div>
			</form>
		</template>
	</BiModal>
</template>

<style scoped>
.autocomplete-after-search-template {
	padding: 5px 10px;
	font-size: 15px;
	font-weight: normal;
}
</style>
<style>
.animal-consistency-modal-container .modal-dialog {
	width: 90%;
	max-width: 1200px;
}
</style>
