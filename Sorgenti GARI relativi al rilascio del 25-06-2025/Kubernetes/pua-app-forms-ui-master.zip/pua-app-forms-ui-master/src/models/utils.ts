/* eslint-disable @typescript-eslint/no-explicit-any */
import { useAlertsStore } from "@abaco/bootstrap-italia-components/src/stores/alertsStore";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import type { ErrorModel } from "@abaco/bootstrap-italia-components/src/models/index";
import { z } from "zod";
import i18n from "@/i18n/index.js";
import { MODULE_ID } from "@/main";
import type { LocationQuery } from "vue-router";

export enum GeometryType {
	POLYGON = "Polygon",
	MULTI_POLYGON = "MultiPolygon",
	LINE_STRING = "LineString",
	POINT = "Point",
	LINEAR_RING = "LinearRing",
	MULTI_POINT = "MultiPoint",
	MULTI_LINE_STRING = "MultiLineString",
	GEOMETRY_COLLECTION = "GeometryCollection",
	CIRCLE = "Circle",
}

export const GeometryTypeKeySchema = z.nativeEnum(GeometryType);

const geoJsonPointSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.POINT),
	coordinates: z.tuple([z.number(), z.number()]),
});

const geoJsonLineStringSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.LINE_STRING),
	coordinates: z.array(z.tuple([z.number(), z.number()])),
});

const geoJsonPolygonSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.POLYGON),
	coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
});

const geoJsonMultiPointSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.MULTI_POINT),
	coordinates: z.array(z.tuple([z.number(), z.number()])),
});

const geoJsonMultiLineStringSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.MULTI_LINE_STRING),
	coordinates: z.array(z.array(z.tuple([z.number(), z.number()]))),
});

const geoJsonMultiPolygonSchema = z.object({
	type: z.literal(GeometryTypeKeySchema.enum.MULTI_POLYGON),
	coordinates: z.array(z.array(z.array(z.tuple([z.number(), z.number()])))),
});

export const geoJsonSchema = z.discriminatedUnion("type", [
	geoJsonPointSchema,
	geoJsonLineStringSchema,
	geoJsonPolygonSchema,

	geoJsonMultiPointSchema,
	geoJsonMultiLineStringSchema,
	geoJsonMultiPolygonSchema,
]);

export type GeoJsonGeometryModel = z.infer<typeof geoJsonSchema>;

const t = i18n.global.t;

export const ResponseSchema = z.object({
	status: z.number(),
});

export type ResponseModel = z.infer<typeof ResponseSchema>;

export function removeNullsOrBlanksFromObject(obj: any) {
	if (obj) {
		Object.keys(obj).forEach(k => {
			if (obj && (obj[k] === "" || obj[k] == null)) {
				delete obj[k];
			}
		});
	}
}

export const DATE_SERVER_FORMAT = "yyyyMMdd";

export const stringToDate = z.preprocess(arg => {
	if (typeof arg === "string") {
		// eslint-disable-next-line @typescript-eslint/ban-ts-comment
		// @ts-ignore
		const match = arg.match(DATE_PATTERN)?.groups;
		if (!match) {
			return new Date();
		}
		const date = new Date(+match.year, +match.month - 1, +match.day);
		if (isNaN(date.getTime())) {
			return new Date();
		}
		return date;
	}
}, z.date());

export const PaginateListSchema = z.object({
	count: z.number(),
	records: z.array(z.any()),
	nextKey: z.string().nullable(),
});

export function handleApiErrorAndShowAlert(response: any, exposeAlert = true) {
	const alertsStore = useAlertsStore();
	if (response.errorType === ErrorType.HTTP_STATUS) {
		if (
			response.response.status === 403 &&
			response.response.statusText === "Forbidden"
		) {
			console.error(response.response.statusText);
			if (exposeAlert) {
				alertsStore.setError({
					errorCode: t(`${MODULE_ID}.errors.USER_HAS_NO_ACCESS`),
				});
			}
		} else {
			response.response
				.json()
				.then((errMsg: ErrorModel) => {
					const e: ErrorModel = {
						errorCode: "GENERIC_ERROR",
					};
					if (errMsg.errorCode) {
						e.errorCode = t(`${MODULE_ID}.errors.${errMsg.errorCode}`);
						e.message = errMsg.message;
					}
					console.error(e);
					e.message = undefined;
					if (exposeAlert) {
						alertsStore.setError(e);
					}
				})
				.catch((err: any) => {
					alertsStore.setGenericError();
					console.error("generic error", err);
				});
		}
	} else {
		console.error(response?.err ?? response);
		alertsStore.setGenericError();
	}
}

export function sendCompiledEvent() {
	window.dispatchEvent(new Event("form-compiled"));
}

export function redirectToGraphicalApplication(
	queryParamsObj: LocationQuery,
	applicationId: number,
	selectedOptionCode: string,
	takeoverId?: number
) {
	const queryParamsObjCloned: Record<string, string | number> = {
		...queryParamsObj,
		applicationId,
		selectedOptionCode,
	};
	delete queryParamsObjCloned["partyCode"];

	queryParamsObjCloned["option_codes"] = selectedOptionCode; //TKT 151775

	if (takeoverId !== undefined) queryParamsObjCloned.takeoverId = takeoverId;
	let queryParams = "";
	Object.keys(queryParamsObjCloned).forEach((key: string) => {
		if (queryParams.length !== 0) queryParams += "&";
		const camelCaseKey = snakeToCamel(key);
		queryParams += `${camelCaseKey}=${queryParamsObjCloned[key]}`;
	});

	window.location.assign(`/portal/gsaa?${queryParams}`);
}

function snakeToCamel(value: string) {
	return value.replace(/[^a-zA-Z0-9]+(.)/g, (sub, chr) => chr.toUpperCase());
}
