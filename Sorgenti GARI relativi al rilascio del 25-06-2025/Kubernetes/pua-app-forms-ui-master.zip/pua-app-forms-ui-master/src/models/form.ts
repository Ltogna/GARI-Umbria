export interface BaseInput {
	id: string;
	text: string;
}

export interface SelectItem extends BaseInput {
	selected?: boolean;
	disabled?: boolean;
}

export interface SelectItemsGroup {
	name: string;
	list: SelectItem[];
}

export type InputType =
	| "text"
	| "email"
	| "password"
	| "number"
	| "date"
	| "time";

export interface ValidatedInput<T> {
	val?: T;
	errors: string[];
}
