import { z } from "zod";
import { OptionDetailsSchema } from "./unificataForms";

export enum OptionType {
	ZOOTECHNIC = "ZOOTECHNIC",
	SURFACE = "SURFACE",
}

export const InvestigationSurfacePrizeSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string().nullable(),
	engagedArea: z.number(),
});
export const InvestigationSurfacesPrizesListSchema = z.array(
	InvestigationSurfacePrizeSchema
);

export const InvestigationSurfacesPrizesDetailsSchema =
	OptionDetailsSchema.extend({
		id: z.number(),
		flBiologicalCrop: z.number(),
		flDerogaBcaa8: z.number(),
		declarationGeomList: z.optional(
			z.nullable(
				z.array(
					z.object({
						code: z.number(),
						flEngaged: z.number(),
						geom: z.string(),
						engagedArea: z.number(),
						requestableArea: z.number(),
						flEligible: z.number(),
					})
				)
			)
		),
		eligibilityGeomList: z.optional(
			z.nullable(
				z.array(
					z.object({
						flEligible: z.number(),
						geom: z.nullable(z.string()),
					})
				)
			)
		),
		monitoringData: z.any(),
		waivedAreaWithoutVariation: z.number(),
		finalEngagedArea: z.number(),
		requestableAreaFound: z.number(),
		waivedAreaWithVariationSanctioned: z.number(),
		waivedAreaWithVariationNotSanctioned: z.number(),
		notes: z.optional(z.nullable(z.string())),
	});

export const InvestigationSurfacesPrizesDetailsListSchema = z.array(
	InvestigationSurfacesPrizesDetailsSchema
);

export const InvestigationSurfacesPrizesDetailsInfiniteListSchema = z.object({
	records: z.nullable(InvestigationSurfacesPrizesDetailsListSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const SaveInvestigationSurfacesPrizesDetailsSchema = z.array(
	z.object({
		declarationCode: z.string(),
		notes: z.optional(z.nullable(z.string())),
	})
);

export const SaveInvestigationSurfacesPrizesDetailsResponseSchema = z.array(
	z.object({
		declarationId: z.number(),
		notes: z.optional(z.nullable(z.string())),
	})
);

export const InvestigationYoungFarmerSchema = z.object({
	investigationOutcome: z.boolean().nullable(),
	isOptionWithdrawn: z.boolean().nullable(),
	code: z.string(),
	penalty: z.boolean().nullable(),
	educationCompetenceRequirement: z.boolean().nullable(),
	firstPositiveInvestigationYear: z.number().nullable(),
	firstSettlementDate: z.string(),
	vatnumberOpeningDate: z.string().nullable(),
	cciasubscription: z.boolean(),
	cciasubscriptionState: z.string().nullable(),
	firstSettlementYear: z.number(),
	campaignYear: z.number(),
	lastRequestableYear: z.number().nullable(),
	notes: z.string().nullable(),
});

export const InvestigationOutcomeCaseABSchema = z.object({
	registryRequirement: z.boolean(),
	missingSupSurfaces: z.boolean(),
	relationSupDarBps: z.boolean(),
	ageaAnomalies: z.boolean(),
	farmerActive: z.boolean(),
	missingMultipleRequestAB: z.boolean(),
	requestYoungFarmerPrizeDu: z.boolean(),
	assignmentYoungFarmerPrizeDu: z.boolean(),
	investigationOutcome: z.boolean(),
	investigationDate: z.string(),
});

export const InvestigationOutcomeCaseCDFSchema = z.object({
	registryRequirement: z.boolean(),
	missingSupSurfaces: z.boolean(),
	relationSupDarBps: z.boolean(),
	ageaAnomalies: z.boolean(),
	farmerActive: z.boolean(),
	investigationOutcome: z.boolean(),
	investigationDate: z.string(),
});

export const InvestigationDARCaseASchema = z.object({
	darInvestigationDTO: z.object({
		caseRequested: z.boolean(),
		requestedArea: z.number(),
		fcYoungFarmer: z.string().nullable().optional(),
		ageDar: z.number().nullish(),
		datePhysicalPersonVatCreation: z.string().nullable().optional(),
		dateJuridicalEntityInitialCheck: z.string().nullable().optional(),
		dateFirstSubmission: z.string(),
		inducedArea: z.number().nullable().optional(),
		inducedAreaEqOrMoreThanOne: z.boolean(),
		educationalAndProficiencyRequirement: z.boolean(),
		cciaRegistered: z.boolean(),
		notes: z.string().nullable(),
		externalDarRegistry: z.boolean().optional(),
	}),
	investigationOutcomeDTO: InvestigationOutcomeCaseABSchema,
});

export const InvestigationDARCaseBSchema = z.object({
	darInvestigationDTO: z.object({
		caseRequested: z.boolean(),
		requestedArea: z.number(),
		fcNewFarmer: z.string().nullable().optional(),
		ageDar: z.number().nullish(),
		agriActivityPrevFiveYears: z.boolean(),
		datePhysicalPersonVatCreation: z.string().nullable().optional(),
		dateJuridicalEntityInitialCheck: z.string().nullable().optional(),
		dateFirstSubmission: z.string().nullable(),
		inducedArea: z.number().nullable().optional(),
		inducedAreaEqOrMoreThanOne: z.boolean(),
		educationalAndProficiencyRequirement: z.boolean(),
		cciaRegistered: z.boolean(),
		notes: z.string().nullable(),
		externalDarRegistry: z.boolean().optional(),
	}),
	investigationOutcomeDTO: InvestigationOutcomeCaseABSchema,
});

export const InvestigationDARCaseCSchema = z.object({
	darInvestigationDTO: z.object({
		caseC1Requested: z.boolean(),
		caseC2Requested: z.boolean(),
		requestedArea: z.number(),
		inducedAreaC1: z.number().nullable().optional(),
		inducedAreaC2: z.number().nullable().optional(),
		c1SurfacesInPsr: z.boolean(),
		inducedAreaEqOrMoreThan1: z.boolean(),
		notes: z.string().nullable(),
	}),
	investigationOutcomeDTO: InvestigationOutcomeCaseCDFSchema,
});

export const InvestigationDARCaseDSchema = z.object({
	darInvestigationDTO: z.object({
		caseRequested: z.boolean(),
		requestedArea: z.number(),
		inducedArea: z.number().nullable().optional(),
		inducedAreaEqOrMoreThanOne: z.boolean(),
		notes: z.string().nullable(),
	}),
	investigationOutcomeDTO: InvestigationOutcomeCaseCDFSchema,
});

export const InvestigationDARCaseFSchema = z.object({
	darInvestigationDTO: z.object({
		caseRequested: z.boolean(),
		requestedArea: z.number(),
		attachmentsValidity: z.boolean(),
		notes: z.string().nullable(),
	}),
	investigationOutcomeDTO: InvestigationOutcomeCaseCDFSchema,
});

export const InvestigationDARSchema = z.object({
	darCaseInPointA: InvestigationDARCaseASchema.nullable().optional(),
	darCaseInPointB: InvestigationDARCaseBSchema.nullable().optional(),
	darCaseInPointC: InvestigationDARCaseCSchema.nullable().optional(),
	darCaseInPointD: InvestigationDARCaseDSchema.nullable().optional(),
	darCaseInPointF: InvestigationDARCaseFSchema.nullable().optional(),
});

export const SaveInvestigationDarCaseInPointSchema = z.object({
	notes: z.string().nullable(),
	attachmentsValidity: z.optional(z.boolean()),
});

export const SaveInvestigationOutcomeSchema = z.object({
	ageaAnomalies: z.boolean(),
	farmerActive: z.boolean(),
	investigationOutcome: z.boolean(),
	investigationDate: z.string(),
});

export const SaveInvestigationDARCaseSchema = z.object({
	createOrUpdateDarCaseInPointDTO: SaveInvestigationDarCaseInPointSchema,
	outcomeInvestigationDTO: SaveInvestigationOutcomeSchema,
});

export const SaveInvestigationDARSchema = z.object({
	createOrUpdateDarCaseInPointA:
		SaveInvestigationDARCaseSchema.nullable().optional(),
	createOrUpdateDarCaseInPointB:
		SaveInvestigationDARCaseSchema.nullable().optional(),
	createOrUpdateDarCaseInPointC:
		SaveInvestigationDARCaseSchema.nullable().optional(),
	createOrUpdateDarCaseInPointD:
		SaveInvestigationDARCaseSchema.nullable().optional(),
	createOrUpdateDarCaseInPointF:
		SaveInvestigationDARCaseSchema.nullable().optional(),
});

export const InvestigationModulationSchema = z.array(
	z.object({
		process: z.string(),
		listId: z.number(),
		totalAmountRequested: z.nullable(z.number()),
		dateTotalAmountRequested: z.nullable(z.string()),
		sentToSoc: z.string(),
		additionalFields: z.record(z.any()),
	})
);

export const CorrectionSurfacePrizeSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string().nullable(),
	engagedArea: z.number(),
});
export const CorrectionSurfacesPrizesListSchema = z.array(
	CorrectionSurfacePrizeSchema
);

export const CorrectionSurfacesPrizesDetailsSchema = OptionDetailsSchema.extend(
	{
		declarationId: z.number(),
		flBiologicalCrop: z.number(),
		flDerogaBcaa8: z.number(),
		declarationGeomList: z.optional(
			z.nullable(
				z.array(
					z.object({
						code: z.number(),
						flEngaged: z.number(),
						geom: z.string(),
						engagedArea: z.number(),
						requestableArea: z.number(),
						flEligible: z.number(),
					})
				)
			)
		),
		eligibilityGeomList: z.optional(
			z.nullable(
				z.array(
					z.object({
						flEligible: z.number(),
						geom: z.nullable(z.string()),
					})
				)
			)
		),
		monitoringData: z.any(),
		waivedArea: z.number(),
		notes: z.optional(z.nullable(z.string())),
	}
);

export const CorrectionSurfacesPrizesDetailsListSchema = z.array(
	CorrectionSurfacesPrizesDetailsSchema
);

export const CorrectionSurfacesPrizesDetailsInfiniteListSchema = z.object({
	records: z.nullable(CorrectionSurfacesPrizesDetailsListSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const SaveCorrectionSurfacesPrizesDetailsSchema = z.array(
	z.object({
		declarationCode: z.string(),
		notes: z.string().nullable(),
		waivedArea: z.number(),
	})
);

export const OptionsPaymentSchema = z.object({
	id: z.number(),
	paymentCode: z.string(),
	paymentDescription: z.string(),
	optionCode: z.string(),
	optionDescription: z.string(),
	selected: z.boolean(),
});

export const SaveOptionsPaymentSchema = z.array(
	z.object({
		paymentCode: z.string(),
		selected: z.boolean(),
	})
);

export const OptionsPaymentListSchema = z.array(OptionsPaymentSchema);

export const InvestigationCoupledSchema = z.object({
	coupledInvestigationCode: z.string(),
	coupledInvestigationDescription: z.string(),
	measurementUnit: z.string(),
	optionCode: z.string(),
	optionDescription: z.string(),
	groupCode: z.string(),
	groupDescription: z.string(),
	engagedArea: z.number().nullable(),
	value: z.number().nullable(),
	sortOrder: z.number(),
});

export const InvestigationCoupledArraySchema = z.array(
	InvestigationCoupledSchema
);
export const InvestigationCoupledListSchema = z.object({
	records: z.array(InvestigationCoupledSchema).nullable(),
	notes: z.string().nullable(),
});

export const SaveInvestigationCoupledSchema = z.object({
	coupledCode: z.string(),
	value: z.number().optional().nullable(),
});

export const SaveInvestigationCoupledListSchema = z.object({
	records: z.array(SaveInvestigationCoupledSchema),
	notes: z.string(),
});

export const InvestigationDataSchema = z.object({
	flSurfaceNotDeclared: z.number(),
	surfaceNotDeclaredNotes: z.string().nullable().optional(),
	flDelayExemption: z.number(),
	delayExemptionNotes: z.string().nullable().optional(),
});

export const InvestigationSurfaceEcoschemasCheckListSchema = z.object({
	code: z.string(),
	description: z.string(),
	flValue: z.number(),
	sortOrder: z.number(),
});

export const saveInvestigationSurfaceEcoschemasCheckListSchema = z.object({
	code: z.string(),
	flValue: z.number(),
});

export const InvestigationSurfaceEcoschemasCheckListArraySchema = z.array(
	InvestigationSurfaceEcoschemasCheckListSchema
);

export const saveInvestigationSurfaceEcoschemasCheckListArraySchema = z.array(
	saveInvestigationSurfaceEcoschemasCheckListSchema
);

export const InvestigationSurfaceEcoschemasRecordSchema = z.object({
	referenceSchema: z.string(),
	checkList: InvestigationSurfaceEcoschemasCheckListArraySchema,
	sanctionPerc: z.number().nullable(),
});

export const saveInvestigationSurfaceEcoschemasRecordSchema = z.object({
	referenceSchema: z.string(),
	checkList: saveInvestigationSurfaceEcoschemasCheckListArraySchema,
	sanctionPerc: z.number().nullable(),
});

export const InvestigationSurfaceEcoschemasRecordArraySchema = z.array(
	InvestigationSurfaceEcoschemasRecordSchema
);

export const saveInvestigationSurfaceEcoschemasRecordArraySchema = z.array(
	saveInvestigationSurfaceEcoschemasRecordSchema
);

export const InvestigationSurfaceEcoschemasSchema = z.object({
	notes: z.string().nullish(),
	records: InvestigationSurfaceEcoschemasRecordArraySchema,
});

export const saveInvestigationSurfaceEcoschemasSchema = z.object({
	notes: z.string().nullish(),
	records: saveInvestigationSurfaceEcoschemasRecordArraySchema,
});

export const InvestigationOverdeclarationSchema = z.object({
	optionCode: z.string(),
	optionDescription: z.string(),
	flOverdeclaration: z.boolean(),
	overdeclarationReductionArea: z.number().nullish(),
	notes: z.string().nullish(),
});

export const InvestigationOverdeclarationListSchema = z.array(
	InvestigationOverdeclarationSchema
);

export const SaveInvestigationOverdeclarationSchema = z.object({
	optionCode: z.string(),
	flOverdeclaration: z.boolean(),
	overdeclarationReductionArea: z.number().nullish(),
	notes: z.string().nullish(),
});

export const SaveInvestigationOverdeclarationListSchema = z.array(
	SaveInvestigationOverdeclarationSchema
);

export type InvestigationSurfacesPrizesModel = z.infer<
	typeof InvestigationSurfacePrizeSchema
>;
export type InvestigationSurfacesPrizesListModel = z.infer<
	typeof InvestigationSurfacesPrizesListSchema
>;

export type InvestigationSurfacesPrizesDetailsModel = z.infer<
	typeof InvestigationSurfacesPrizesDetailsSchema
>;
export type InvestigationSurfacesPrizesDetailsListModel = z.infer<
	typeof InvestigationSurfacesPrizesDetailsListSchema
>;
export type InvestigationSurfacesPrizesDetailsInfiniteListModel = z.infer<
	typeof InvestigationSurfacesPrizesDetailsInfiniteListSchema
>;
export type SaveInvestigationSurfacesPrizesDetailsModel = z.infer<
	typeof SaveInvestigationSurfacesPrizesDetailsSchema
>;
export type SaveInvestigationSurfacesPrizesDetailsResponseModel = z.infer<
	typeof SaveInvestigationSurfacesPrizesDetailsResponseSchema
>;
export type InvestigationYoungFarmerModel = z.infer<
	typeof InvestigationYoungFarmerSchema
>;
export type InvestigationDARModel = z.infer<typeof InvestigationDARSchema>;
export type InvestigationDARCaseAModel = z.infer<
	typeof InvestigationDARCaseASchema
>;
export type InvestigationDARCaseBModel = z.infer<
	typeof InvestigationDARCaseBSchema
>;
export type InvestigationDARCaseCModel = z.infer<
	typeof InvestigationDARCaseCSchema
>;
export type InvestigationDARCaseDModel = z.infer<
	typeof InvestigationDARCaseDSchema
>;
export type InvestigationDARCaseFModel = z.infer<
	typeof InvestigationDARCaseFSchema
>;
export type SaveInvestigationDARModel = z.infer<
	typeof SaveInvestigationDARSchema
>;
export type SaveInvestigationDARCaseModel = z.infer<
	typeof SaveInvestigationDARCaseSchema
>;
export type CorrectionSurfacesPrizesModel = z.infer<
	typeof CorrectionSurfacePrizeSchema
>;
export type CorrectionSurfacesPrizesListModel = z.infer<
	typeof CorrectionSurfacesPrizesListSchema
>;
export type CorrectionSurfacesPrizesDetailsModel = z.infer<
	typeof CorrectionSurfacesPrizesDetailsSchema
>;
export type CorrectionSurfacesPrizesDetailsListModel = z.infer<
	typeof CorrectionSurfacesPrizesDetailsListSchema
>;
export type CorrectionSurfacesPrizesDetailsInfiniteListModel = z.infer<
	typeof CorrectionSurfacesPrizesDetailsInfiniteListSchema
>;
export type SaveCorrectionSurfacesPrizesDetailsModel = z.infer<
	typeof SaveCorrectionSurfacesPrizesDetailsSchema
>;
export type InvestigationOutcomeCaseABModel = z.infer<
	typeof InvestigationOutcomeCaseABSchema
>;
export type InvestigationOutcomeCaseCDFModel = z.infer<
	typeof InvestigationOutcomeCaseCDFSchema
>;
export type SaveInvestigationOutcomeModel = z.infer<
	typeof SaveInvestigationOutcomeSchema
>;
export type SaveInvestigationDarCaseInPointModel = z.infer<
	typeof SaveInvestigationDarCaseInPointSchema
>;
export type InvestigationModulationModel = z.infer<
	typeof InvestigationModulationSchema
>;
export type OptionsPaymentListModel = z.infer<typeof OptionsPaymentListSchema>;
export type OptionsPaymentModel = z.infer<typeof OptionsPaymentSchema>;
export type SaveOptionsPaymentModel = z.infer<typeof SaveOptionsPaymentSchema>;
export type InvestigationCoupledListModel = z.infer<
	typeof InvestigationCoupledListSchema
>;
export type InvestigationCoupledModel = z.infer<
	typeof InvestigationCoupledSchema
>;
export type InvestigationCoupledArrayModel = z.infer<
	typeof InvestigationCoupledArraySchema
>;
export type SaveInvestigationCoupledModel = z.infer<
	typeof SaveInvestigationCoupledSchema
>;
export type SaveInvestigationCoupledListModel = z.infer<
	typeof SaveInvestigationCoupledListSchema
>;
export type InvestigationDataModel = z.infer<typeof InvestigationDataSchema>;
export type InvestigationSurfaceEcoschemasModel = z.infer<
	typeof InvestigationSurfaceEcoschemasSchema
>;
export type saveInvestigationSurfaceEcoschemasModel = z.infer<
	typeof saveInvestigationSurfaceEcoschemasSchema
>;
export type InvestigationSurfaceEcoschemasRecordArrayModel = z.infer<
	typeof InvestigationSurfaceEcoschemasRecordArraySchema
>;
export type InvestigationOverDeclarationModel = z.infer<
	typeof InvestigationOverdeclarationSchema
>;
export type InvestigationOverDeclarationListModel = z.infer<
	typeof InvestigationOverdeclarationListSchema
>;
export type SaveInvestigationOverDeclarationModel = z.infer<
	typeof SaveInvestigationOverdeclarationSchema
>;
export type SaveInvestigationOverDeclarationListModel = z.infer<
	typeof SaveInvestigationOverdeclarationListSchema
>;
