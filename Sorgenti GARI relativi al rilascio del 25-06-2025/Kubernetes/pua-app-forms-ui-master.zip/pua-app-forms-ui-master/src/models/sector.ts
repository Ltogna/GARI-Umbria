import { z } from "zod";
import { PaginateListSchema } from "./utils";

export const SectorSchema = z.object({
	sector_code: z.string().nullish(),
	sector_description: z.string(),
	sector_short_descr: z.string(),
	total_area_sqm: z.number(),
	total_parcels: z.number(),
	world_geom: z.string(),
});
export type SectorModel = z.infer<typeof SectorSchema>;

export const SectorDataSchema = z.object({
	description: z.string(),
	id: z.number().optional(),
	sector_code: z.string(),
	short_descr: z.string(),
});
export type SectorDataModel = z.infer<typeof SectorDataSchema>;

export const SectorsListSchema = PaginateListSchema.extend({
	records: z.array(SectorSchema),
});
export type SectorsListModel = z.infer<typeof SectorsListSchema>;
