import { z } from "zod";

export const SaveAttachmentModelSchema = z.object({
	file: z.nullable(z.any()),
	typeCode: z.string(),
	groupCode: z.string(),
	notes: z.nullable(z.string()),
});
export type SaveAttachmentModel = z.infer<typeof SaveAttachmentModelSchema>;

export const AttachmentModelSchema = z.object({
	applicationId: z.number(),
	attachmentId: z.string(),
	fileName: z.string(),
	notes: z.nullable(z.string()),
	type: z.object({
		code: z.nullable(z.string()),
		groupCode: z.nullable(z.string()),
		typeCode: z.nullable(z.string()),
	}),
});

export type AttachmentModel = z.infer<typeof AttachmentModelSchema>;

export const AttachmentListResponseSchema = z.object({
	records: z.nullable(z.array(z.nullable(AttachmentModelSchema))),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export type AttachmentListResponse = z.infer<
	typeof AttachmentListResponseSchema
>;

export const AttachmentTypeModelSchema = z.object({
	code: z.nullable(z.string()),
	groupCode: z.string(),
	typeCode: z.string(),
});

export type AttachmentTypeModel = z.infer<typeof AttachmentTypeModelSchema>;

export const AttachmentTypeResponseSchema = z.nullable(
	z.object({
		records: z.nullable(z.array(AttachmentTypeModelSchema)),
		nextKey: z.nullable(z.string()),
		count: z.number(),
	})
);

export type AttachmentTypeResponse = z.infer<
	typeof AttachmentTypeResponseSchema
>;

export const DeclarationModelSchema = z.object({
	code: z.string(),
	required: z.boolean(),
	minOccurs: z.number().optional(),
	maxOccurs: z.number().optional(),
	label: z.record(z.string()),
	type: z.string(),
	style: z.nullable(z.string()).optional(),
	help: z.nullable(z.string()).optional(),
	format: z.nullable(z.string()).optional(),
	readonly: z.nullable(z.boolean()).optional(),
	lookupCode: z.nullable(z.string()).optional(),
	validation: z.nullable(z.string()).optional(),
});

export const DeclarationDocumentSchema = z.object({
	fields: z.record(z.nullable(z.number().or(z.string()))),
	validTo: z.string().or(z.number()),
	validFrom: z.string().or(z.number()),
});

export type DeclarationDocumentResponse = z.infer<
	typeof DeclarationDocumentSchema
>;

export const DeclarationListResponseSchema = z.nullable(
	z
		.object({
			document: z.nullable(DeclarationDocumentSchema),
			documentDefinition: z.object({
				code: z.string(),
				version: z.string(),
				description: z.string(),
				title: z.record(z.string()),
				metadata: z.object({
					maxOccurs: z.number(),
					timeOverlap: z.boolean(),
					defaultLocale: z.string(),
					startDateField: z.nullable(z.string()),
					endDateField: z.nullable(z.string()),
					summaryFields: z.nullable(z.string()).optional(),
				}),
				fieldSets: z.array(
					z.object({
						code: z.string(),
						minOccurs: z.number(),
						maxOccurs: z.number(),
						label: z.record(z.string()),
						fields: z.array(DeclarationModelSchema),
					})
				),
				lookups: z.nullable(z.string()).optional(),
				restLookups: z.nullable(z.string()).optional(),
				onSaveApiCalls: z.nullable(z.string()).optional(),
			}),
		})
		.passthrough()
);

export type DeclarationListResponse = z.infer<
	typeof DeclarationListResponseSchema
>;

export const SaveDeclarationsSchema = z.nullable(
	z.object({
		document: z.nullable(DeclarationDocumentSchema),
	})
);
/// Bilance
// export const BalanceIndicesModelSchema = z.object({
// 	Chiave_Appezzamento: z.string(),
// 	Ciclo_Principale: z.boolean(),
// 	ZVN: z.boolean(),
// 	N_Mas: z.number(),
// 	N_Fabbisogno: z.number(),
// 	N_FabbisognoSoddisfatto: z.number(),
// 	N_Zootecnico: z.number(),
// 	N_Zootecnico_Letame: z.number(),
// 	N_Zootecnico_Liquame: z.number(),
// 	N_BilancioAzotato_Utile: z.number(),
// 	N_TotaleSoddisfatto: z.number(),
// 	N_BilancioAzotato_Totale: z.number(),
// });

export const SaveBalanceIndicesSchema = z.object({
	ids: z.array(z.number()).optional(),
	sectorCode: z.string(),
	landUseCode: z.string(),
	flZvn: z.boolean(),
	areaSqm: z.number(),
	mas: z.number().optional(),
});

export type SaveBalanceIndicesModel = z.infer<typeof SaveBalanceIndicesSchema>;

export const BalanceIndicesListResponseSchema = z.nullable(
	SaveBalanceIndicesSchema
);

export const getBalanceIndicesResponseSchema = z.object({
	Chiave_Appezzamento: z.string(),
	Ciclo_Principale: z.boolean(),
	ZVN: z.boolean(),
	N_Mas: z.number(),
	N_Superfice: z.number().nullable().optional(),
	N_Fabbisogno: z.number(),
	N_FabbisognoSoddisfatto: z.number(),
	N_Zootecnico: z.number(),
	N_Zootecnico_Letame: z.number(),
	N_Zootecnico_Liquame: z.number(),
	N_BilancioAzotato_Utile: z.number(),
	N_TotaleSoddisfatto: z.number(),
	N_BilancioAzotato_Totale: z.number(),
	sectorCode: z.string().nullish(),
	sectorDescription: z.string().optional(),
	landUseCode: z.string().nullish(),
	landUseDescription: z.string().optional(),
});

export type getBalanceIndicesListResponse = z.infer<
	typeof getBalanceIndicesListResponseSchema
>;

export const getBalanceIndicesListResponseSchema = z.object({
	records: z.array(getBalanceIndicesResponseSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});
export type getBalanceIndicesResponse = z.infer<
	typeof getBalanceIndicesResponseSchema
>;

export const SaveBalanceIndicesResponseSchema = z.nullable(
	z.object({
		ids: z.array(z.number()),
		applicationId: z.number(),
		sectorCode: z.string(),
		landUseCode: z.string(),
		areaSqm: z.number(),
		mas: z.number(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export type SaveBalanceIndicesResponse = z.infer<
	typeof SaveBalanceIndicesResponseSchema
>;
// Appezzamento entry schema
export const AppezzamentoRequestSchema = z.object({
	Chiave_Appezzamento: z.string(),
	N_Mas: z.number(),
	N_Fabbisogno: z.number(),
	ZVN: z.boolean().nullish(),
	Ciclo_Principale: z.boolean().nullish(),
});
// Full request schema
export const BalanceIndicesRequestSchema = z.object({
	Cuaa: z.string(),
	Regolamento_Cod: z.number(),
	ElencoAppezzamenti: z.array(AppezzamentoRequestSchema),
});
// Export the TypeScript type
export type BalanceIndicesRequest = z.infer<typeof BalanceIndicesRequestSchema>;
export type AppezzamentoRequest = z.infer<typeof AppezzamentoRequestSchema>;

////

export type SaveDeclarationsModel = z.infer<typeof SaveDeclarationsSchema>;

export const MunicipalityRecordListModelSchema = z
	.object({
		id: z.number().nullish(),
		description: z.string().nullish(),
		short_descr: z.string().nullish(),
		sector_code: z.string().nullish(),
	})
	.passthrough();

export const MunicipalityRecordListResponseSchema = z.nullable(
	MunicipalityRecordListModelSchema
);

export type MunicipalityRecordListResponse = z.infer<
	typeof MunicipalityRecordListResponseSchema
>;

export const MunicipalityListModelSchema = z.object({
	nextKey: z.nullable(z.string()),
	records: z.array(MunicipalityRecordListModelSchema),
	count: z.number(),
});

export const MunicipalityListResponseSchema = MunicipalityListModelSchema;

export type MunicipalityListResponse = z.infer<
	typeof MunicipalityListResponseSchema
>;

export const MunicipalityRecordListMbRModelSchema = z.object({
	xmin: z.number(),
	ymin: z.number(),
	xmax: z.number(),
	ymax: z.number(),
});

export const MunicipalityRecordListholdingAreaModelSchema = z.object({
	areaSqm: z.number(),
});

export const MunicipalityRecordListWithFertSpreadingModelSchema = z.object({
	domainZoneId: z.string().nullish(),
	code: z.string().nullish(),
	description: z.string().nullish(),
	srs: z.string().nullish(),
	mbr: MunicipalityRecordListMbRModelSchema.nullish(),
	holdingArea: MunicipalityRecordListholdingAreaModelSchema.nullish(),
	bigDomainZone: z.boolean().nullish(),
});

export const MunicipalityListWithFertSpreadingModelSchema = z.object({
	nextKey: z.nullable(z.string()),
	records: z.array(MunicipalityRecordListWithFertSpreadingModelSchema),
	count: z.number(),
});

export const MunicipalityListWithFertSpreadingResponseSchema =
	MunicipalityListWithFertSpreadingModelSchema;

export type MunicipalityListWithFertSpreadingResponse = z.infer<
	typeof MunicipalityListWithFertSpreadingResponseSchema
>;
export type MunicipalityWithFertSpreadingResponse = z.infer<
	typeof MunicipalityRecordListWithFertSpreadingModelSchema
>;

export const MunicipalityListFromCodeSubModelSchema = z
	.object({
		id: z.number(),
		description: z.string(),
		short_descr: z.string(),
		sector_code: z.string(),
		srs: z.nullable(z.string()),
		geom: z.nullable(z.string()),
		world_geom: z.nullable(z.string()),
	})
	.passthrough();

export const MunicipalityRecordListFromCodeSubResponseSchema = z.nullable(
	MunicipalityListFromCodeSubModelSchema
);

export type MunicipalityRecordListFromCodeSubResponse = z.infer<
	typeof MunicipalityRecordListFromCodeSubResponseSchema
>;

export const MunicipalityListFromCodeModelSchema = z.object({
	nextKey: z.nullable(z.string()),
	records: z.array(MunicipalityListFromCodeSubModelSchema),
	count: z.number(),
});

export const MunicipalityListFromCodeResponseSchema =
	MunicipalityListFromCodeModelSchema;

export type MunicipalityRecordListFromCodeResponse = z.infer<
	typeof MunicipalityListFromCodeResponseSchema
>;

export type MunicipalityListFromCodeResponse = z.infer<
	typeof MunicipalityListFromCodeResponseSchema
>;

export const LandUseCodesListModelSchema = z
	.object({
		land_uses_code: z.string(),
		description: z.string(),
	})
	.passthrough();

export const LandUseCodesListResponseSchema = z.nullable(
	LandUseCodesListModelSchema
);

export const LandUseListFromCodeSchema = z
	.object({
		land_uses_codes_list: z.array(LandUseCodesListModelSchema),
	})
	.passthrough();

export const LandUseListFromCodeResponseSchema = z.nullable(
	LandUseListFromCodeSchema
);

export type LandUseListFromCodeResponse = z.infer<
	typeof LandUseListFromCodeResponseSchema
>;

export const LandUseRecordListModelSchema = z
	.object({
		land_uses_code: z.string(),
		description: z.string(),
	})
	.passthrough();

export const LandUseRecordListResponseSchema = z.nullable(
	LandUseRecordListModelSchema
);

export type LandUseRecordListResponse = z.infer<
	typeof LandUseRecordListResponseSchema
>;

export const LandUseListModelSchema = z.object({
	nextKey: z.nullable(z.string()),
	records: z.array(LandUseRecordListModelSchema),
	count: z.number(),
});

export const LandUseListResponseSchema = LandUseListModelSchema;

export type LandUseListResponse = z.infer<typeof LandUseListResponseSchema>;

export const SaveDeclarationYearModelSchema = z
	.object({
		applicationId: z.number(),
		year: z.number(),
		flOrganicFert: z.boolean(),
		flLivestocks: z.nullable(z.boolean()),
	})
	.passthrough();

export const SaveDeclarationYearResponseSchema = z.nullable(
	SaveDeclarationYearModelSchema
);

export type SaveDeclarationYearResponse = z.infer<
	typeof SaveDeclarationYearResponseSchema
>;

export const SaveGraphicCropPlanSchema = z.object({
	ids: z.array(z.number()).optional(),
	sectorCode: z.string(),
	landUseCode: z.string(),
	flZvn: z.boolean(),
	areaSqm: z.number(),
	mas: z.number().optional(),
});

export type SaveGraphicCropPlanModel = z.infer<
	typeof SaveGraphicCropPlanSchema
>;

export const GraphicCropPlanListResponseSchema = z.nullable(
	SaveGraphicCropPlanSchema
);

export const getGraphicCropPlanResponseSchema = z.nullable(
	z.object({
		ids: z.array(z.number()),
		applicationId: z.number(),
		sectorCode: z.string(),
		sectorDescription: z.string().nullish(),
		flZvn: z.boolean().nullish(),
		landUseCode: z.string(),
		landUseDescription: z.string().nullish(),
		areaSqm: z.string().or(z.number()),
		mas: z.number(),
		flImported: z.boolean(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export type getGraphicCropPlanResponse = z.infer<
	typeof getGraphicCropPlanResponseSchema
>;

export const getGraphicCropPlanListResponseSchema = z.array(
	getGraphicCropPlanResponseSchema
);

export const SaveGraphicCropPlanResponseSchema = z.nullable(
	z.object({
		ids: z.array(z.number()),
		applicationId: z.number(),
		sectorCode: z.string(),
		landUseCode: z.string(),
		areaSqm: z.number(),
		mas: z.number(),
		dtInsert: z.string(),
		dtDelete: z.string(),
		userIdInsert: z.string(),
		userIdDelete: z.nullable(z.string()),
	})
);

export type SaveGraphicCropPlanResponse = z.infer<
	typeof SaveGraphicCropPlanResponseSchema
>;

export const GeneratedPrintSchema = z.object({
	processStatus: z.string(),
	printCode: z.string(),
	printDescription: z.string(),
	printDate: z.number().or(z.string()),
	printJobUuid: z.nullable(z.string()),
	fileId: z.nullable(z.string()),
	username: z.string(),
});

export type PrintHistoryResponseModel = z.infer<
	typeof PrintHistoryResponseSchema
>;

export const PrintHistoryResponseSchema = z.array(GeneratedPrintSchema);

export const SaveCadastralParticelModelSchema = z.object({
	id: z.number().optional(),
	partyId: z.nullable(z.number()),
	sectorCode: z.string().nullish(),
	sectorDescription: z.string().nullish(),
	blockCode: z.number(),
	parcelCode: z.number(),
	subParcelCode: z.string().nullish(),
	cadastralAreaSqm: z.number().or(z.string()),
	dayFrom: z.string().nullish(),
	dayTo: z.string().nullish(),
	usedAreaSqm: z.number().or(z.string()),
});

export const SaveCadastralParticelResponseSchema = z.nullable(
	SaveCadastralParticelModelSchema
);

export type SaveCadastralParticelModel = z.infer<
	typeof SaveCadastralParticelModelSchema
>;

export type SaveCadastralParticelResponse = z.infer<
	typeof SaveCadastralParticelResponseSchema
>;

export const getCadastralParticelModelSchema = z.object({
	id: z.number().optional(),
	partyId: z.nullable(z.number()),
	sectorCode: z.string(),
	sectorDescription: z.string().optional(),
	blockCode: z.number(),
	parcelCode: z.number(),
	subParcelCode: z.string(),
	cadastralAreaSqm: z.number(),
	dayFrom: z.string(),
	dayTo: z.string(),
	usedAreaSqm: z.number(),
	cuaa: z.string(),
	company: z.string(),
});

export const getAllCadastralParticelResponseSchema = z.array(
	getCadastralParticelModelSchema
);

export const getCadastralParticelResponseSchema = z.nullable(
	getCadastralParticelModelSchema
);

export type getCadastralParticelResponse = z.infer<
	typeof getCadastralParticelResponseSchema
>;

export const getPartyRegistryModelSchema = z
	.object({
		id: z.number(),
		partyType: z.string(),
		gender: z.string().optional(),
		lastName: z.string(),
		firstName: z.nullable(z.string()),
		taxCode: z.string(),
		vatNumber: z.nullable(z.string()),
		code: z.string(),
		legalStatus: z.string(),
		birthDate: z.nullable(z.string()),
		deathDate: z.nullable(z.string()),
		birthMunicipality: z.nullable(z.string()),
		nationality: z.nullable(z.string()),
		archived: z.boolean(),
		description: z.string().optional(),
	})
	.passthrough();

export const getPartyRegistryResponseSchema = z.nullable(
	getPartyRegistryModelSchema
);

export type getPartyRegistryResponse = z.infer<
	typeof getPartyRegistryResponseSchema
>;

export const EffluentModelSchema = z
	.object({
		code: z.string().nullish(),
		description: z.string().nullish(),
		nitrogen: z.number().nullish(),
		codeUom: z.string().nullish(),
		descriptionUom: z.string().nullish(),
	})
	.passthrough();

export const EffluentResponseSchema = z.nullable(EffluentModelSchema);

export type EffluentResponse = z.infer<typeof EffluentResponseSchema>;

export const EffluentListFromCodeResponseSchema = z.array(EffluentModelSchema);

export type EffluentListFromCodeResponse = z.infer<
	typeof EffluentListFromCodeResponseSchema
>;

export const EffluentListModelSchema = z.array(EffluentModelSchema);

export const EffluentListResponseSchema = z.nullable(EffluentListModelSchema);

export type EffluentListResponse = z.infer<typeof EffluentListResponseSchema>;

export const cropPlanPrintsModelSchema = z.object({
	code: z.string(),
	description: z.string(),
});

export const cropPlanPrintsResponseSchema = z.array(cropPlanPrintsModelSchema);

export const getCropPlanModelSchema = z.object({
	cropPlanId: z.number(),
	cropPlanTypeCode: z.string(),
	cropPlanTypeDescription: z.string(),
	description: z.string(),
	changesPending: z.boolean(),
	readOnly: z.boolean(),
	locked: z.boolean(),
	lockedErrorCode: z.nullable(z.string()),
	canAddPlots: z.boolean(),
	cropPlanPrints: cropPlanPrintsResponseSchema,
});

export const getCropPlanResponseSchema = z.nullable(getCropPlanModelSchema);

export type getCropPlanResponse = z.infer<typeof getCropPlanResponseSchema>;

export const getCropPlanListModelSchema = z.object({
	records: z.array(getCropPlanResponseSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});

export const getCropPlanListResponseSchema = z.nullable(
	getCropPlanListModelSchema
);

export type getCropPlanListResponse = z.infer<
	typeof getCropPlanListResponseSchema
>;

export const getCropPlanVersionModelSchema = z.object({
	version: z.string(),
	versionDate: z.string(),
	versionReferenceDate: z.string(),
	message: z.string(),
	userId: z.string(),
	flPublished: z.boolean(),
});

export const getCropPlanVersionResponseSchema = z.nullable(
	getCropPlanVersionModelSchema
);

export type getCropPlanVersionResponse = z.infer<
	typeof getCropPlanVersionResponseSchema
>;

export const getCropPlanVersionListModelSchema = z.object({
	records: z.array(getCropPlanVersionModelSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});
export const getCropPlanVersionListResponseSchema =
	getCropPlanVersionListModelSchema;

export type getCropPlanVersionListResponse = z.infer<
	typeof getCropPlanVersionListResponseSchema
>;

export const landUseModelSchema = z.object({
	code: z.string(),
	description: z.string(),
});

export const landUseResponseSchema = z.nullable(landUseModelSchema);

export const getDeclarationFromCropPlanModelSchema = z
	.object({
		declarationCode: z.string().nullish(),
		landuse: landUseResponseSchema.nullish(),
		areaPerc: z.number().nullish(),
		geom: z.string().nullish(),
		fromDate: z.string().nullish(),
		fromDatePrecision: z.string().nullish(),
		toDate: z.string().nullish(),
		plotId: z.number().or(z.string()).nullish(),
		plotCode: z.string().nullish(),
		plotDescription: z.string().nullish(),
		plotAreaSqm: z.number().nullish(),
		domainZoneDescription: z.string().nullish(),
		domainZoneCode: z.string().nullish(),
		isSelected: z.boolean().nullish(),
	})
	.strip();

export const getDeclarationFromCropPlanResponseSchema = z.nullable(
	getDeclarationFromCropPlanModelSchema
);

export type getDeclarationFromCropPlanResponse = z.infer<
	typeof getDeclarationFromCropPlanResponseSchema
>;

export const declarationLandUseModelSchema = z.object({
	plotId: z.string(),
	declarationCode: z.string(),
	plotDescription: z.string(),
	landUseCode: z.string(),
	landUseDescription: z.string(),
	plotAreaSqm: z.number(),
	plotAreaPerc: z.number(),
	plotTotalHectar: z.number(),
	dtInsert: z.string(),
	dtDelete: z.string(),
	userIdInsert: z.string(),
	userIdDelete: z.nullable(z.string()),
});

export const declarationLandUseResponseSchema = z.nullable(
	declarationLandUseModelSchema
);

export const SaveFertSpreadingDeclarationModelSchema = z.object({
	id: z.number(),
	cuaa: z.string(),
	company: z.string(),
	partyId: z.nullable(z.number()),
	expectedDate: z.string(),
	landuses: z.array(declarationLandUseModelSchema).nullable(),
	plotDescription: z.string().nullish(),
	sectorCode: z.string(),
	sectorDescription: z.string().optional(),
	livestockEffluents: z.string(),
	livestockEffluentsDescription: z.string().optional(),
	livestockEffluentsDescriptionUom: z.string(),
	livestockEffluentsQty: z.number(),
	cropPlanVersion: z.string(),
	dtInsert: z.string(),
	dtDelete: z.string(),
	userIdInsert: z.string(),
	userIdDelete: z.nullable(z.string()),
});

export const SaveFertSpreadingDeclarationResponseSchema = z.nullable(
	SaveFertSpreadingDeclarationModelSchema
);

export const getFertSpreadingDeclarationResponseSchema = z.array(
	SaveFertSpreadingDeclarationModelSchema
);

export type SaveFertSpreadingDeclarationResponse = z.infer<
	typeof SaveFertSpreadingDeclarationResponseSchema
>;

export const SaveFertSpreadingDeclarationRequestSchema = z.object({
	partyId: z.number().nullish(),
	expectedDate: z.string().nullish(),
	sectorCode: z.string().nullish(),
	landuses: z.array(getDeclarationFromCropPlanResponseSchema).nullish(),
	livestockEffluents: z.string().nullish(),
	livestockEffluentsQty: z.number().or(z.string()).nullish(),
	cropPlanVersion: z.string(),
});

export type SaveFertSpreadingDeclarationRequest = z.infer<
	typeof SaveFertSpreadingDeclarationRequestSchema
>;

export const getDeclarationListFromCropPlanModelSchema = z.object({
	records: z.array(getDeclarationFromCropPlanModelSchema),
	nextKey: z.nullable(z.string()),
	count: z.number(),
});
export const getDeclarationListFromCropPlanResponseSchema =
	getDeclarationListFromCropPlanModelSchema;

export type getDeclarationListFromCropPlanResponse = z.infer<
	typeof getDeclarationListFromCropPlanResponseSchema
>;

export const searchSubjectDescriptionModelSchema = z.object({
	description: z.string().nullish(),
});

export type SearchSubjectDescriptionResponse = z.infer<
	typeof searchSubjectDescriptionModelSchema
>;

export const getPreviousManureModelSchema = z.object({
	id: z.number().nullish(),
	parentId: z.number().nullish(),
	effluent: z.string().nullish(),
	effluentDescription: z.string().optional(),
	measurementUnit: z.string().nullish(),
	quantity: z.number().nullish(),
	frequency: z.string().nullish(),
	frequencyDescription: z.string().nullish(),
	nitrogenContent: z.number().nullish(),
	reduction: z.number().nullish(),
	residualNitrogen: z.number().nullish(),
});

export const getPreviousManureResponseSchema = z.nullable(
	getPreviousManureModelSchema
);

export type getPreviousManureResponse = z.infer<
	typeof getPreviousManureResponseSchema
>;

export type getPreviousManureValidationResponse = z.infer<
	typeof getPreviousManureModelSchema
>;

export const savePreviousManureModelSchema = z
	.object({
		id: z.nullable(z.number()),
		parentId: z.nullable(z.number()),
		effluent: z.string(),
		descrizioneEffluente: z.string().optional(),
		measurementUnit: z.string(),
		quantity: z.number(),
		frequency: z.string(),
		nitrogenContent: z.number(),
		reduction: z.number(),
		residualNitrogen: z.number(),
	})
	.passthrough();

export type savePreviousManureResponse = z.infer<
	typeof savePreviousManureModelSchema
>;

export const getPlotLandModelSchema = z.object({
	ids: z.array(z.number()).optional(),
	planId: z.number().nullish(),
	plotCode: z.string().nullish(),
	plotDescription: z.string().nullish(),
	declCode: z.string().nullish(),
	declarationVersion: z.string().nullish(),
	sectorCode: z.string().nullish(),
	sectorDescription: z.string().nullish(),
	landUseCode: z.string().nullish(),
	landUseDescription: z.string().nullish(),
	flZvn: z.boolean().nullish(),
	areaSqm: z.number().or(z.string()).nullish(),
	cropDuration: z.string().nullish(),
	yield: z.number().nullish(),
	yieldReference: z.number().nullish(),
	mas: z.number().nullish(),
	precessionCode: z.number().nullish(),
	precessionCodeDescription: z.string().nullish(),
	typology: z.string().nullish(),
	typologyDescription: z.string().nullish(),
	cycle: z.number().nullish(),
	cycleDescription: z.string().nullish(),
	totResidualNitrogen: z.number().nullish(),
	distributableNitrogen: z.number().nullish(),
	totalNitrogen: z.number().nullish(),
	previousEffluents: z.array(getPreviousManureModelSchema),
	isSelected: z.boolean().nullish(),
});

export const getPlotLandListResponseSchema = z.array(getPlotLandModelSchema);

export type getPlotLandListResponse = z.infer<
	typeof getPlotLandListResponseSchema
>;

export const getPlotLandResponseSchema = z.nullable(getPlotLandModelSchema);

export type getPlotLandValidationResponse = z.infer<
	typeof getPlotLandModelSchema
>;

export type getPlotLandResponse = z.infer<typeof getPlotLandResponseSchema>;

export const getPlotLandRequestModelSchema = z.object({
	id: z.array(z.number()).optional(),
	landUseCode: z.string().nullish(),
	flZvn: z.boolean().nullish(),
	areaSqm: z.number().nullish(),
	cropDuration: z.number().nullish(),
	cycle: z.number().nullish(),
	typology: z.string().nullish(),
	yield: z.number().nullish(),
	mas: z.number().nullish(),
	precessionCode: z.number().nullish(),
	totResidualNitrogen: z.number().nullish(),
	distributableNitrogen: z.number().nullish(),
	totalNitrogen: z.number().nullish(),
});

export type getPlotLandRequestResponse = z.infer<
	typeof getPlotLandRequestModelSchema
>;

export const editPlotLandRequestModelSchema = z.object({
	ids: z.array(z.number()),
	cycle: z.number(),
	typology: z.nullable(z.string()),
	yield: z.number(),
	precessionCode: z.number(),
	previousEffluents: z.array(getPreviousManureModelSchema).nullish(),
});

export type editPlotLandRequestResponse = z.infer<
	typeof editPlotLandRequestModelSchema
>;

export const savePlotLandRequestModelSchema =
	editPlotLandRequestModelSchema.extend({
		ids: z.array(z.number()).optional(),
		sectorCode: z.string(),
		landUseCode: z.string(),
		flZvn: z.boolean(),
		areaSqm: z.number(),
		cropDuration: z.string(),
		mas: z.number(),
		totResidualNitrogen: z.number(),
		distributableNitrogen: z.number(),
		totalNitrogen: z.nullable(z.number()),
	});

export const savePlotLandRequestResponseSchema = z.nullable(
	savePlotLandRequestModelSchema
);

export type savePlotLandRequestResponse = z.infer<
	typeof savePlotLandRequestResponseSchema
>;

export const getFrequencyFromEffluentCodeModelSchema = z.object({
	code: z.string(),
	description: z.string(),
	nitrogen: z.number(),
});

export const getFrequencyFromEffluentCodeResponseSchema = z.array(
	getFrequencyFromEffluentCodeModelSchema
);

export type getFrequencyFromEffluentCodeResponse = z.infer<
	typeof getFrequencyFromEffluentCodeResponseSchema
>;

export const getAnimalConsistencyModelSchema = z.object({
	id: z.number().nullish(),
	species: z.string().nullish(),
	specieDescription: z.string().optional(),
	category: z.string().nullish(),
	categoryDescription: z.string().optional(),
	typeStabling: z.string().nullish(),
	typeStablingDescription: z.string().optional(),
	numberHeadsRaised: z.number().nullish(),
	numberField: z.number().nullish(),
	averagePV: z.number().nullish(),
	sewageOutlet: z.number().nullish(),
	manureOrShovelableOutput: z.number().nullish(),
});

export const getAnimalConsistencyResponseSchema = z.nullable(
	getAnimalConsistencyModelSchema
);

export type getAnimalConsistencyResponse = z.infer<
	typeof getAnimalConsistencyResponseSchema
>;

export type getAnimalConsistencyValidationResponse = z.infer<
	typeof getAnimalConsistencyModelSchema
>;

export const getAnimalConsistencyListModelSchema = z.object({
	count: z.nullable(z.number()),
	nextKey: z.nullable(z.number()),
	records: z.array(getAnimalConsistencyModelSchema),
});

export type getAnimalConsistencyListResponse = z.infer<
	typeof getAnimalConsistencyListModelSchema
>;

export const getDistributedNeedsModelSchema = z
	.object({
		ListaFabbisogni: z.array(
			z.object({
				Chiave_Appezzamneto: z.string().nullish(),
				N_Fabbisogno: z.number().nullish(),
			})
		),
	})
	.nullish();

export type getDistributedNeedsResponse = z.infer<
	typeof getDistributedNeedsModelSchema
>;

export const getDistributedNeedsResponseSchema = getDistributedNeedsModelSchema;

export const getPrecessionModelSchema = z
	.object({
		code: z.string().nullish(),
		description: z.string().nullish(),
		resudualNitrogen: z.number().nullish(),
	})
	.nullish();

export type getPrecessionResponse = z.infer<typeof getPrecessionModelSchema>;

export const getPrecessionResponseSchema = z.array(getPrecessionModelSchema);

export const getTypologyModelSchema = z.object({
	cropCode: z.string(),
	nitrogenCorrectionFactor: z.number(),
	nitrogenQt: z.number().nullish(),
	productTypeCode: z.string().nullish(),
	productTypeDescr: z.string().nullish(),
	yield: z.number().nullish(),
});

export type getTypologyResponse = z.infer<typeof getTypologyModelSchema>;

export const getTypologyListResponseSchema = z.array(getTypologyModelSchema);

export type getMasListFromLandUseCodeResponse = z.infer<
	typeof getTypologyListResponseSchema
>;

export const getCycleModelSchema = z.object({
	Ciclo_Cod: z.number(),
	Ciclo_Des: z.string(),
});

export type getCycleResponse = z.infer<typeof getCycleModelSchema>;

export const getCycleResponseSchema = z.array(getCycleModelSchema);

export const getSpecieModelSchema = z.object({
	id: z.number().nullish(),
	genreCode: z.string(),
	code: z.string(),
	description: z.string(),
});

export type getSpecieResponse = z.infer<typeof getSpecieModelSchema>;

export const getSpecieResponseSchema = z.array(getSpecieModelSchema);

export const getCategoryFromSpecieModelSchema = z.object({
	genreCode: z.string(),
	specieCode: z.string(),
});
export type getCategoryFromSpecieResponse = z.infer<
	typeof getCategoryFromSpecieModelSchema
>;

export const getCategoryModelSchema = z.object({
	genreCode: z.string(),
	specieCode: z.string(),
	code: z.string(),
	productionCode: z.string(),
	description: z.string(),
	averageWeight: z.number(),
	nitrogenPV: z.number(),
});

export type getCategoryResponse = z.infer<typeof getCategoryModelSchema>;

export const getCategoryResponseSchema = z.array(getCategoryModelSchema);

export const getHousingTypeFromCategoryModelSchema = z.object({
	genreCode: z.string(),
	specieCode: z.string(),
	categoryCode: z.string(),
	productionCode: z.string(),
});
export type getHousingTypeFromCategoryResponse = z.infer<
	typeof getHousingTypeFromCategoryModelSchema
>;

export const getHousingTypeModelSchema = z.object({
	genreCode: z.string(),
	specieCode: z.string(),
	categoryCode: z.string(),
	productionCode: z.string(),
	code: z.string(),
	description: z.string(),
	sewageSludge: z.number(),
	sewageSludgePct: z.number(),
	nitrogenSewage: z.number(),
	nitrogenShovellable: z.number(),
	hay: z.number(),
	shovellableMc: z.number(),
	shovellableT: z.number(),
});

export type getHousingTypeResponse = z.infer<typeof getHousingTypeModelSchema>;

export const getHousingTypeResponseSchema = z.array(getHousingTypeModelSchema);

export const GenericLayerSchema = z.object({
	name: z.string(),
	text: z.string(),
	visible: z.boolean(),
});

export type GenericLayerModel = z.infer<typeof GenericLayerSchema>;

export const getNoSpreadingPeriod = z
	.object({
		pkId: z.number().nullish(),
		effluent: z.string(),
		effluentDescription: z.string().optional(),
		dayFrom: z.string(),
		dayTo: z.string(),
	})
	.passthrough();

export type getNoSpreadingPeriodResponse = z.infer<typeof getNoSpreadingPeriod>;

export const saveNoSpreadingPeriod = z.object({
	pkId: z.number().nullish(),
	effluent: z.string(),
	dayFrom: z.string(),
	dayTo: z.string(),
});

export type saveNoSpreadingPeriodResponse = z.infer<
	typeof saveNoSpreadingPeriod
>;

export const validationNoSpreadingPeriod = z.object({
	pkId: z.number().nullish(),
	effluent: EffluentResponseSchema.nullish(),
	dayFrom: z.string().nullish(),
	dayTo: z.string().nullish(),
});

export type validationNoSpreadingPeriodResponse = z.infer<
	typeof validationNoSpreadingPeriod
>;

export const getNoSpreadingPeriodResponseSchema =
	z.nullable(getNoSpreadingPeriod);

export type getNoSpreadingPeriodStoreResponse = z.infer<
	typeof getNoSpreadingPeriodResponseSchema
>;

export const getNoSpreadingPeriodListResponseSchema =
	z.array(getNoSpreadingPeriod);

export type getNoSpreadingPeriodListResponse = z.infer<
	typeof getNoSpreadingPeriodListResponseSchema
>;
