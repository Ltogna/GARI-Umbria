import { DateSchema } from "@abaco/safe-rest/src/Schemas";
import { z } from "zod";
import { PaginateListSchema, stringToDate } from "./utils";

export const AreaSectorLevelSchema = z.object({
	code: z.string(),
	description: z.string().nullish(),
});

export const AreaSectorSchemaBase = {
	area_id: z.number().nullish(),
	level: AreaSectorLevelSchema.nullish(),
	acronym: z.string().nullish(),
	description: z.string().nullish(),
	day_from: stringToDate.nullish(),
	day_to: stringToDate.nullish(),
	world_geom: z.string().nullish(),
};

export const AreaSectorSchema = z.object({
	...AreaSectorSchemaBase,
	parent: z.object(AreaSectorSchemaBase),
});

export const AreaSectorResponseSchema = z.object({
	records: z.array(AreaSectorSchema),
	count: z.number(),
	nextKey: z.string().nullish(),
});

export const LayerStyleSchema = z.object({
	fill_rgba: z.string(),
	line_rgba: z.string(),
	line_thick: z.number(),
});

export const LandCoverDetailSchema = z.object({
	land_cover_code: z.string(),
	description: z.string().nullable(),
	world_geom: z.string(),
	layer_style: LayerStyleSchema.nullish(),
});

export const ParcelSchema = z.object({
	area_sau: z.number().nullable().default(0),
	area_sqm: z.number(),
	day_from: stringToDate,
	day_to: z.string(),
	landcover_details_list: z.array(LandCoverDetailSchema),
	block_code: z.string(),
	parcel_code: z.string(),
	parcel_id: z.number(),
	world_geom: z.string(),
});

export const ParcelsListSchema = PaginateListSchema.extend({
	records: z.array(ParcelSchema),
});

export const SummarySchema = z.object({
	total_area_sqm: z.number(),
	total_parcels: z.number(),
});

export const LandCoverSummarySchema = z.object({
	description: z.string().nullable(),
	land_cover_code: z.string(),
	total_area_sqm: z.number(),
});

export const LandCoversSummarySchema = z.object({
	total_land_covers_list: z.array(LandCoverSummarySchema),
});

export type SummaryModel = z.infer<typeof SummarySchema>;
export type LandCoverSummaryModel = z.infer<typeof LandCoverSummarySchema>;
export type ParcelModel = z.infer<typeof ParcelSchema>;
export type ParcelsListModel = z.infer<typeof ParcelsListSchema>;
export type LandCoversSummaryModel = z.infer<typeof LandCoversSummarySchema>;
export type LandCoverDetailModel = z.infer<typeof LandCoverDetailSchema>;
export type LayerStyleModel = z.infer<typeof LayerStyleSchema>;

// #region ----parcelData

/* Parcel Data Schema and Model */
const ParcelDataSectorSchema = z.object({
	id: z.number(),
	description: z.string(),
	short_descr: z.string(),
	sector_code: z.string(),
});

const ParcelDataBlockSchema = z.object({
	id: z.number(),
	sector_id: z.number(),
	description: z.string(),
	short_descr: z.string(),
	block_code: z.string().nullish(),
});

const ParcelDataInfoGisSchema = z.object({
	average_altitude: z.number().nullish(),
	average_slope: z.number().nullish(),
	average_direction: z.number().nullish(),
});

const ParcelDataLandCoverSchema = z.object({
	id: z.number(),
	code: z.string(),
	description: z.string().nullable(),
	parcel_id: z.number(),
	day_from: stringToDate,
	day_to: stringToDate,
	last_update: DateSchema,
	area_sqm: z.number(),
	world_geom: z.string(),
	layer_style: LayerStyleSchema,
	info_gis: ParcelDataInfoGisSchema,
});

export const ParcelDataSchema = z.object({
	id: z.number(),
	parcel: z.string(),
	day_from: stringToDate,
	day_to: stringToDate,
	area_sqm: z.number(),
	world_geom: z.string(),
	sector: ParcelDataSectorSchema,
	block: ParcelDataBlockSchema,
	land_covers: z.array(ParcelDataLandCoverSchema),
	info_gis: ParcelDataInfoGisSchema,
});

export type ParcelDataLandCoverModel = z.infer<
	typeof ParcelDataLandCoverSchema
>;
export type ParcelDataInfoGisModel = z.infer<typeof ParcelDataInfoGisSchema>;
export type ParacelDataModel = z.infer<typeof ParcelDataSchema>;

// #endregion ----parcelData

export type AreaSectorLevelModel = z.infer<typeof AreaSectorLevelSchema>;
export type AreaSectorModel = z.infer<typeof AreaSectorSchema>;
export type AreaSectorResponseModel = z.infer<typeof AreaSectorResponseSchema>;

// #region ----monitoringData

export const MonitoringResultFlagColorCodes = z.enum([
	"WHITE",
	"GREEN",
	"RED",
	"CHECKERED_BLUE",
	"CHECKERED_YELLOW",
	"YELLOW",
]);

// #endregion ----monitoringData
