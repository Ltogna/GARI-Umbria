import { z } from "zod";
import type { ListItem2 } from "@abaco/bootstrap-italia-components/src/models";

export enum LayerTypeEnum {
	WMS = "WMS",
	WMTS = "WMTS",
	VECTOR = "VECTOR",
}

export enum StaticLayerEnum {
	ORTHOPHOTO = "orthophoto",
	FOREGROUND_LAYER = "foregroundLayer",
	VECTOR = "vector",
}

export const SEPARATOR = "->";

function refine(data: BaseLayerModel) {
	const [group, layer] = data.description.split(SEPARATOR);
	data.description = layer ?? group;
	data.group = layer ? group : null;
}

export const BaseLayerSchema = z.object({
	layer_id: z.string(),
	layer: z.string(),
	description: z.string(),
	snapElementType: z.string().nullable(),
	minResolution: z.number().nullable(),
	maxResolution: z.number().nullable(),
	on: z.boolean(),
	enabledInOverview: z.boolean(),
	foregroundLevel: z.number(),
	group: z.string().nullish(),
});

// BaseLayerSchema.superRefine(refine);

export type BaseLayerModel = z.infer<typeof BaseLayerSchema>;

export const WmsLayerSchema = BaseLayerSchema.extend({
	url: z.string(),
	layers: z.string(),
	styles: z.string(),
	bgcolor: z.string(),
	transparent: z.boolean(),
	version: z.string(),
	srs: z.string(),
	format: z.string(),
	publicLayerType: z.literal(LayerTypeEnum.WMS),
	optionalParams: z.record(z.string(), z.any()),
	options: z.any(),
});

// WmsLayerSchema.superRefine(refine);

export type WmsLayerModel = z.infer<typeof WmsLayerSchema>;

export const WmtsLayerSchema = BaseLayerSchema.extend({
	style: z
		.string()
		.nullable()
		// eslint-disable-next-line @typescript-eslint/no-unused-vars
		.transform((value, _ctx): string => value ?? "raster"),
	version: z.string(),
	format: z.string(),
	tileMatrixSet: z.string(),
	tileMatrix: z.string(),
	url: z.string(),
	publicLayerType: z.literal(LayerTypeEnum.WMTS),
	options: z.any(),
});

// WmtsLayerSchema.superRefine(refine);

export type WmtsLayerModel = z.infer<typeof WmtsLayerSchema>;

export const VectorLayerSchema = BaseLayerSchema.extend({
	style: z.string().nullable(),
	version: z.string(),
	format: z.string(),
	tileMatrixSet: z.string(),
	tileMatrix: z.string(),
	publicLayerType: z.literal(LayerTypeEnum.VECTOR),
});

// VectorLayerSchema.superRefine(refine);

export type VectorLayerModel = z.infer<typeof VectorLayerSchema>;

export const AdditionalLayerSchema = z
	.discriminatedUnion("publicLayerType", [
		WmsLayerSchema,
		WmtsLayerSchema,
		VectorLayerSchema,
	])
	.superRefine(refine);

export type AdditionalLayerModel = z.infer<typeof AdditionalLayerSchema>;

export const AdditionalLayerListSchema = z.object({
	additional_layers: z.array(AdditionalLayerSchema),
});

export type AdditionalLayerListModel = z.infer<
	typeof AdditionalLayerListSchema
>;

export type ListItemWithLayer = ListItem2 & {
	id: string;
	ref: StaticLayerEnum;
};

export const GenericLayerSchema = z.object({
	name: z.string(),
	text: z.string(),
	visible: z.boolean(),
});

export type GenericLayerModel = z.infer<typeof GenericLayerSchema>;
