export const BASE = "/ui/pua-app-forms/";

export enum SanctionPercOptions {
	PERC_30 = "30",
	PERC_50 = "50",
	PERC_100 = "100",
}

export const NOTES_MAX_LENGTH = 4000;
