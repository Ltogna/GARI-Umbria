import createBootstrapItaliaPlugin from "@abaco/bootstrap-italia-components/src/components/BootstrapItaliaComponentPlugin";
import { onModuleLoaded } from "@abaco/micro-frontend/src/Application";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { getUserData } from "@abaco/safe-rest/src/sso2";
// HACK: fix dayjs import
import "dayjs";
import "dayjs/plugin/customParseFormat";
import "dayjs/plugin/utc";
// HACK: end fix dayjs import
import mitt from "mitt";
import { createPinia } from "pinia";
import type { App as VueApp } from "vue";
import { createApp } from "vue";
import { createRouter, createWebHistory } from "vue-router";
import App from "./App.vue";
import i18n, { loadLocaleMessages } from "./i18n";
import routes from "./routes";
import { getIsDirty } from "./stores/formDirtyStore";
import { isStandalone } from "./utils/isStandalone";

export const MODULE_ID = "pua-app-forms";
export const IS_DEV = import.meta.env.DEV;

import("@/assets/applicationFormsModule.scss");

async function initApplication(isStandalone: boolean, basePath?: string) {
	const router = isStandalone
		? createRouter({
				history: createWebHistory(import.meta.env.BASE_URL),
				routes,
			})
		: createAbcRouter(routes, basePath);
	const bootstrapItaliaComponentPlugin = await createBootstrapItaliaPlugin({
		includeGlobalComponent: false,
		includeFontAwesome: isStandalone ? true : false,
	});
	const app = createApp(App);
	const emitter = mitt();
	const lang = getUserData()?.locale ?? window.navigator.language;
	await loadLocaleMessages(lang);
	app.use(i18n);
	app.use(bootstrapItaliaComponentPlugin);
	app.use(createPinia());
	app.use(router);
	app.provide("moduleId", MODULE_ID);
	app.provide("emitter", emitter);
	app.provide("isDev", IS_DEV);
	app.provide("basePath", basePath);

	return app;
}

if (isStandalone) {
	window.bootstrap.loadFonts(
		import.meta.env.BASE_URL + "bootstrap-italia/dist/fonts"
	);
	await import("@/assets/index.scss");
	initApplication(
		isStandalone,
		"https://iacs-dev.fe.abacogroup.eu/portal"
	).then(app => {
		app.mount("#app");
	});
} else {
	let appModule: VueApp<Element> | null;

	onModuleLoaded(MODULE_ID, {
		async start(node, basePath?: string) {
			const app = await initApplication(isStandalone, basePath);
			app.mount(node);
			appModule = app;
		},
		async canStop() {
			if (getIsDirty()) {
				return {
					title: i18n.global.t(`${MODULE_ID}.micro.askForExitTitle`),
					message: i18n.global.t(`${MODULE_ID}.micro.askForExitMessage`),
				};
			} else {
				return true;
			}
		},

		async stop() {
			appModule?.unmount();
		},
	});
}
