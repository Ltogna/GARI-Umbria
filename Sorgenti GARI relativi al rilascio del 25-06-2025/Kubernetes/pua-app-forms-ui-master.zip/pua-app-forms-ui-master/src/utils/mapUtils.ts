import WMTS, { optionsFromCapabilities } from "ol/source/WMTS";
import WMTSCapabilities from "ol/format/WMTSCapabilities";
import {
	StaticLayerEnum,
	type WmsLayerModel,
	type WmtsLayerModel,
} from "@/models/layer";
import { httpPlus as http } from "@/resources/api/http";
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { addProjection, Projection } from "ol/proj";
import BaseLayer from "ol/layer/Base";
import ImageLayer from "ol/layer/Image";
import TileLayer from "ol/layer/Tile";
import TileState from "ol/TileState";
import ImageWMS from "ol/source/ImageWMS";
import { Tile } from "ol";
import ImageWrapper from "ol/Image";

export function olLoadFunction(image: Tile | ImageWrapper, src: string) {
	http.get(src).then(async resp => {
		if (resp.errorType === ErrorType.NONE) {
			resp.response
				.blob()
				.then(data => {
					/**
					 * Do not use this
					 * ```typescript
					 * URL.createObjectURL(data);
					 * // result example: blob:http://127.0.0.1:5174/11d2fa9b-bd9b-4b27-9b2c-a63a94090040
					 * ```
					 * because the **content policy** on prodution **not allow** blob protocol
					 */
					const reader = new FileReader();
					reader.onloadend = () => {
						// eslint-disable-next-line @typescript-eslint/no-explicit-any
						(image as any).getImage().src = reader.result;
					};
					reader.readAsDataURL(data);
				})
				.catch(() => {
					if (image instanceof Tile) {
						image.setState(TileState.ERROR);
					}
				});
		} else {
			if (image instanceof Tile) {
				image.setState(TileState.ERROR);
			}
		}
	});
}

export async function buildWmtsLayer(layer: WmtsLayerModel) {
	if (!layer.options) {
		try {
			addProjection(
				new Projection({
					code: layer.tileMatrixSet,
					units: "m",
				})
			);
			const resp = await http.get(layer.url, {
				params: {
					REQUEST: "GetCapabilities",
					SERVICE: "WMTS",
				},
			});
			if (resp.errorType === ErrorType.NONE) {
				const parser = new WMTSCapabilities();
				const data = await resp.response.text();
				const capabilities = parser.read(data);

				const options = optionsFromCapabilities(capabilities, {
					layer: layer.layer,
					matrixSet: layer.tileMatrixSet,
					crossOrigin:
						layer.url.startsWith(window.origin) ||
						window.origin.includes("localhost")
							? null
							: "Anonymous",
				});

				if (options && options.requestEncoding === "KVP") {
					// workaround for mapproxy returning wrong urls
					if (options.urls) {
						for (let i = 0; i < options.urls?.length; i++) {
							options.urls[i] = layer.url;
						}
					}
					if (options.url) {
						options.url = layer.url;
					}
				}
				layer.options = options;
			} else {
				throw resp;
			}
		} catch (err) {
			console.error(err);
		}
	}
	// if (layer.layerType === "WMS") {
	//   if (!layer.options) {
	//     const sourceParams: ImageWMSOptions = {
	//       url: layer.url,
	//       ratio: 1,
	//       params: {
	//         LAYERS: layer.layers,
	//         STYLES: layer.styles,
	//         VERSION: layer.version,
	//         TRANSPARENT: layer.transparent,
	//         BGCOLOR: layer.bgcolor,
	//         FORMAT: layer.format,
	//         SRS: layer.srs,
	//         ...layer.optionalParams,
	//       },
	//       crossOrigin:
	//         layer.url.startsWith(window.origin) ||
	//         window.origin.includes("localhost")
	//           ? null
	//           : "Anonymous",
	//     };

	//     const layerParams: ImageWMSLayerOptions<ImageWMSSource> = {
	//       minResolution: layer.minResolution || undefined,
	//       maxResolution: layer.maxResolution || undefined,
	//       // visible: layer.on,
	//     };

	//     layer.options = { sourceParams, layerParams };
	//     layer;
	//   }
	// }
}

export async function createLayer(
	actLayer: WmtsLayerModel | WmsLayerModel,
	layerType: StaticLayerEnum,
	zIndex: number
): Promise<BaseLayer | null> {
	if (actLayer.publicLayerType === "WMTS") {
		const source = new WMTS({
			...actLayer.options,
			tileLoadFunction: olLoadFunction,
		});
		const orthophotoLayer = new TileLayer({
			source,
			properties: {
				ref: layerType,
				id: actLayer.layer_id,
			},
			zIndex,
			visible: actLayer.on,
		});
		return orthophotoLayer;
	} else if (actLayer.publicLayerType === "WMS") {
		const orthophotoLayer = new ImageLayer({
			...actLayer.options.layerParams,
			source: new ImageWMS({
				...actLayer.options.sourceParams,
				imageLoadFunction: olLoadFunction,
			}),
			zIndex,
			properties: {
				ref: layerType,
				id: actLayer.layer_id,
			},
			visible: actLayer.on,
		});
		return orthophotoLayer;
	} else {
		console.error("Error in utils>mapUtils! layer is not WMTS or WMS");
		return null;
	}
}
