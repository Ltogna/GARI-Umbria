<template>
	<div ref="wrapper" :style="style">
		<slot />
	</div>
</template>

<script setup lang="ts">
import { nextTick, ref, watch } from "vue";

/**
 * Props:
 * - show: Boolean to control visibility (true = expand, false = collapse)
 */
const props = defineProps<{
	show: boolean;
}>();

// DOM reference to the wrapping div
const wrapper = ref<HTMLElement | null>(null);

// Reactive inline style
const style = ref({
	maxHeight: "0px",
	overflow: "hidden",
	transition: "max-height 0.3s ease",
});

/**
 * Watch for changes in `show` to expand/collapse smoothly
 */
watch(
	() => props.show,
	async isVisible => {
		if (!wrapper.value) return;

		if (isVisible) {
			await nextTick(); // wait for DOM update
			const fullHeight = wrapper.value.scrollHeight;
			style.value = {
				maxHeight: fullHeight + "px",
				overflow: "hidden",
				transition: "max-height 0.3s ease",
			};
		} else {
			style.value = {
				maxHeight: "0px",
				overflow: "hidden",
				transition: "max-height 0.3s ease",
			};
		}
	},
	{ immediate: true }
);
</script>

<style scoped>
/* Optional: smoother ending state for open content */
div {
	will-change: max-height;
}
</style>
