import { type ValidatedInput } from "@/models/form";
import { resetDirtyState, setDirtyState } from "@/stores/formDirtyStore";
import { useQueryFieldsStore } from "@/stores/queryFieldsStore";
import { resetValidationStore } from "@/stores/validationStore";
import type { GlobalConfigInterface } from "just-validate/dist/modules/interfaces";

const QueryFieldsStore = useQueryFieldsStore();

export const justValidateConfig: Partial<GlobalConfigInterface> = {
	errorFieldCssClass: "is-invalid",
	errorLabelCssClass: "form-feedback",
	errorLabelStyle: "",
	focusInvalidField: true,
};

export const elementIdPrefix = import.meta.env.VITE_MODULE_ID;

export function getFieldSelector(formId: string, fieldName: string): string {
	return `#${formId} [name='${fieldName}']`;
}

export function extendDOMInputFieldsOnChange(document: Document) {
	const inputsList: HTMLElement[] = [
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		...((document.getElementsByTagName("input") as any) ?? []),
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		...((document.getElementsByTagName("select") as any) ?? []),
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		...((document.getElementsByTagName("textarea") as any) ?? []),
	];
	const elementsToExtend = inputsList.filter(
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		(el: any) => el.name !== "filter-name-to-avoid-dirty-state"
	);
	elementsToExtend.forEach(el => {
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		if (!(el as any).hasAlreadyBeenExtended) {
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			(el as any).hasAlreadyBeenExtended = true;
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			el.onchange = ((onchange: any) => {
				return function (evt: Event) {
					// if an existing event already existed then execute it.
					if (onchange) {
						onchange(evt);
					}

					// inject new code
					setDirtyState(QueryFieldsStore.getFormCode);
				};
			})(el.onchange);
		}
	});
}

export function isMandatory(
	field: ValidatedInput<string | null>,
	errorMessage: string
) {
	if (!field.val) {
		field.errors.push(errorMessage);
		return true;
	}
	return false;
}

export function verifyField(
	validatingFunctions: (() => boolean)[],
	field: ValidatedInput<string | null>,
	flush = true
): boolean {
	if (flush) {
		field.errors = [];
	}
	for (const valFunc of validatingFunctions) {
		const res = valFunc();
		if (res) {
			return res;
		}
	}
	return false;
}

export function validateField(
	value: string | undefined,
	field: ValidatedInput<string>
) {
	if (value !== "") {
		field.errors = [];
	}
}

export function checkMaxLength(
	field: ValidatedInput<string | null>,
	maxLength: number,
	errorMessage: string
) {
	if (field.val && field.val.length > maxLength) {
		field.errors.push(errorMessage);
		return true;
	}
	return false;
}

export function resetStates() {
	resetDirtyState();
	resetValidationStore();
}
