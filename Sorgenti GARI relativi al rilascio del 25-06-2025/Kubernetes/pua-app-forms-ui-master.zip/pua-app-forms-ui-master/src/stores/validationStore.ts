import { computed, ref } from "vue";

const validationStore = ref<Record<string, boolean>>({});

export const validationStoreIsNotValid = computed(
	() => !Object.values(validationStore.value).every(x => x)
);

export function resetValidationStore() {
	validationStore.value = {};
}

export function setValidationRecord(uuid: string, valid: boolean) {
	validationStore.value[uuid] = valid;
}
