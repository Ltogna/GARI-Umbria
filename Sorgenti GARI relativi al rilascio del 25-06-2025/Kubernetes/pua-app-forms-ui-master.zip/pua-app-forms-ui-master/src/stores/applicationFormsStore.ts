/* eslint-disable @typescript-eslint/no-unused-vars */
import type {
	IFilterChemicalAndOrganicaFertilizer,
	IFilterStoreChemicalAndOrganicaFertilizer,
} from "@/components/ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizer.vue";
import type { IEditElement } from "@/components/fertSpreadingDeclaration/FertSpreadingDeclaration.vue";
import type {
	AttachmentListResponse,
	AttachmentTypeModel,
	AttachmentTypeResponse,
	BalanceIndicesRequest,
	DeclarationListResponse,
	editPlotLandRequestResponse,
	EffluentListFromCodeResponse,
	EffluentListResponse,
	GenericLayerModel,
	getAnimalConsistencyListResponse,
	getAnimalConsistencyResponse,
	getBalanceIndicesListResponse,
	getCadastralParticelResponse,
	getCategoryFromSpecieResponse,
	getCategoryResponse,
	getCropPlanListResponse,
	getCropPlanVersionListResponse,
	getCycleResponse,
	getDeclarationListFromCropPlanResponse,
	getDistributedNeedsResponse,
	getFrequencyFromEffluentCodeResponse,
	getGraphicCropPlanResponse,
	getHousingTypeFromCategoryResponse,
	getHousingTypeResponse,
	getMasListFromLandUseCodeResponse,
	getNoSpreadingPeriodResponse,
	getNoSpreadingPeriodStoreResponse,
	getPartyRegistryResponse,
	getPlotLandListResponse,
	getPlotLandResponse,
	getPrecessionResponse,
	getPreviousManureResponse,
	getSpecieResponse,
	getTypologyResponse,
	LandUseListFromCodeResponse,
	LandUseListResponse,
	MunicipalityListFromCodeResponse,
	MunicipalityListResponse,
	MunicipalityListWithFertSpreadingResponse,
	SaveAttachmentModel,
	SaveCadastralParticelModel,
	SaveCadastralParticelResponse,
	SaveDeclarationsModel,
	SaveDeclarationYearResponse,
	SaveFertSpreadingDeclarationRequest,
	SaveFertSpreadingDeclarationResponse,
	SaveGraphicCropPlanModel,
	SaveGraphicCropPlanResponse,
	saveNoSpreadingPeriodResponse,
	savePlotLandRequestResponse,
	savePreviousManureResponse,
} from "@/models/applicationForms";
import type {
	AdditionalLayersModel,
	partyRegistryResponse,
} from "@/models/unificataForms";
import { handleApiErrorAndShowAlert, sendCompiledEvent } from "@/models/utils";
import {
	addAttachment,
	deleteAllGraphicCropPlanList,
	deleteAllPlotsLandList,
	deleteAnimalConsistency,
	deleteAttachment,
	deleteCadastralParcel,
	deleteFertSpreadingDeclaration,
	deleteGraphicCropPlan,
	deleteNoSpreadingPeriod,
	deletePlotLand,
	deletePreviousManure,
	downloadAttachment,
	editAnimalConsistency,
	editAttachment,
	editCadastralParcel,
	editDeclarationYear,
	editFertSpreadingDeclaration,
	editGraphicCropPlan,
	editMassivePlotLand,
	editNoSpreadingPeriod,
	editPlotLand,
	editPreviousManure,
	getAnimalConsistencyList,
	getAttachmentList,
	getAttachmentTypeList,
	getBalanceIndicesList,
	getCadastralParticel,
	getCadastralParticelList,
	getCategoryList,
	getCategoryListFromCode,
	getCropPlanList,
	getCropPlanVersionList,
	getCycle,
	getDeclarationList,
	getDeclarationListFromCropPlan,
	getDeclarationYear,
	getDistributedNeeds,
	getEffluentList,
	getEffluentListFromCode,
	getFertSpreadingDeclaration,
	getFertSpreadingDeclarationList,
	getFrequencyFromEffluentCode,
	getFrequencyFromEffluentCodeList,
	getGraphicCropPlanList,
	getGraphicCropPlanListFilter,
	getHousingTypeList,
	getHousingTypeListFromCode,
	getLandUseChoiceList,
	getMasFromLandUseCode,
	getMunicipalityList,
	getMunicipalityListWithFertSpreading,
	getNoSpreadingPeriodList,
	getPlotList,
	getPlotListFormCode,
	getPlotListWithFertSpreading,
	getPlotsLand,
	getPlotsLandListAndPreviousManure,
	getPlotsLandListFilter,
	getPrecession,
	getSpecieList,
	getTypology,
	getTypologyFromLandUseCodeList,
	importGraphicCropPlanList,
	importPlotsLandList,
	loadLandUseListFromCode,
	loadMunicipalityListFromCode,
	loadPartiesV2,
	saveAnimalConsistency,
	saveCadastralParticel,
	saveDeclarations,
	saveDeclarationYear,
	saveFertSpreadingDeclaration,
	saveGraphicCropPlan,
	saveNoSpreadingPeriod,
	savePlotLand,
	savePreviousManure,
} from "@/resources/api/applicationFormsApi";
import { loadAdditionalLayersAPI } from "@/resources/api/unificataFormsApi";
import { resetDirtyState } from "@/stores/formDirtyStore";
import {
	ErrorType,
	type HttpJsonResult,
	type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import dayjs from "dayjs";
import { defineStore } from "pinia";
import type { Ref } from "vue";

export type TComponentSaveStore =
	| "FiveYearComunicationForm"
	| "FertSpreadingDeclaration"
	| "ChemicalAndOrganic";

export type TDataKey = keyof ISaveInStoreSubObject;

export interface ISaveInStoreSubObject {
	editElementDetailsPage?: getPlotLandResponse | null;
	editElement?: IEditElement | null;
	editMassive: number[] | null;
	isExternalCompany?: boolean | null;
	filterObject: IFilterStoreChemicalAndOrganicaFertilizer | null;
}

interface State {
	/* initStore*/
	loading: boolean;
	hasError: boolean;
	errorResponse?: HttpResponseError;
	/* saveInStore for component comunication*/
	saveInStore: Record<TComponentSaveStore, ISaveInStoreSubObject> | null;
	/* attachment*/
	attachmentList: AttachmentListResponse;
	attachmentTypeList: AttachmentTypeResponse;
	/* dynamic documents*/

	declarationList: DeclarationListResponse;
	/* declarationYear */
	declarationYear: SaveDeclarationYearResponse;
	getDeclarationYearResponse: SaveDeclarationYearResponse;
	saveDeclarationYearResponse: SaveDeclarationYearResponse;
	editDeclarationYearResponse: SaveDeclarationYearResponse;
	/* graphic CropPlan*/
	municipalityList: MunicipalityListResponse;
	municipalityListWithFertSpreading: MunicipalityListWithFertSpreadingResponse;
	municipalityListFromCodeResponse: MunicipalityListFromCodeResponse;
	landUseListFromCodeResponse: LandUseListFromCodeResponse;
	landUseList: LandUseListResponse;
	graphicCropPlanList: getGraphicCropPlanResponse[];
	saveGraphicCropPlanResponse: SaveGraphicCropPlanResponse;
	editGraphicCropPlanResponse: SaveGraphicCropPlanResponse;
	getMasFromLandUseCodeResponse: getMasListFromLandUseCodeResponse;

	/* fiveYearDeclaration and cadastralParcelForm */
	getCadastralParticelResponse: SaveCadastralParticelResponse;
	getCadastralParticelListResponse: getCadastralParticelResponse[];
	saveCadastralParticelResponse: SaveCadastralParticelResponse;
	editCadastralParcelResponse: SaveCadastralParticelResponse;
	/* fertSPreading and fertSpreadingForm */
	getFertSpreadingDeclarationListResponse: SaveFertSpreadingDeclarationResponse[];
	getFertSpreadingDeclarationResponse: SaveFertSpreadingDeclarationResponse;
	saveFertSpreadingDeclarationResponse: SaveFertSpreadingDeclarationResponse;
	editFertSpreadingDeclarationResponse: SaveFertSpreadingDeclarationResponse;
	getEffuentListResponse: EffluentListResponse;
	effluentListFromCodeResponse: EffluentListFromCodeResponse;
	getCropPlanListResponse: getCropPlanListResponse;
	getBalanceIndicesListResponse: getBalanceIndicesListResponse;
	getCropPlanVersionListResponse: getCropPlanVersionListResponse;
	getDeclarationListResponse: getDeclarationListFromCropPlanResponse;
	getDeclarationUsedAsPlotListResponse: getDeclarationListFromCropPlanResponse;
	getDeclarationUsedAsPlotListFromCodeResponse: getDeclarationListFromCropPlanResponse;

	// searchSubject
	subjectList: partyRegistryResponse;
	selectedSubject: getPartyRegistryResponse;

	// ChemicalAndOrganic
	getPlotLandListAndPreviousManureResponse: getPlotLandListResponse;
	getPlotLandResponse: getPlotLandResponse;
	getFrequencyFromEffluentCodeResponse: getFrequencyFromEffluentCodeResponse;
	getFrequencyFromEffluentCodeListResponse: getFrequencyFromEffluentCodeResponse;
	editPlotLandResponse: getPlotLandResponse;
	editMassivePlotLandResponse: getPlotLandListResponse;
	savePlotLandResponse: savePlotLandRequestResponse;
	getDistributedNeedsResponse: getDistributedNeedsResponse;
	getPrecessionResponse: getPrecessionResponse[];
	getTypologyResponse: getTypologyResponse[];
	getTypologyFromCodeResponse: getTypologyResponse[];
	getCycleResponse: getCycleResponse[];

	// previousmanure
	editPreviousManureResponse: getPreviousManureResponse;
	savePreviousManureResponse: getPreviousManureResponse;

	// animal consistency
	getAnimalConsistencyListResponse: getAnimalConsistencyListResponse;
	getAnimalConsistencyResponse: getAnimalConsistencyResponse;
	editAnimalConsistencyResponse: getAnimalConsistencyResponse;
	saveAnimalConsistencyResponse: getAnimalConsistencyResponse;
	getSpecieListResponse: getSpecieResponse[];
	getCategoryListResponse: getCategoryResponse[];
	getCategoryListFromCodeResponse: getCategoryResponse[];
	getHousingTypeListResponse: getHousingTypeResponse[];
	getHousingTypeListFromCategoryCodeResponse: getHousingTypeResponse[];

	// openLayer components
	layerList: GenericLayerModel[];
	additionalLayers: AdditionalLayersModel;

	// no spreading
	getNoSpreadingPeriodListResponse: getNoSpreadingPeriodResponse[];
	editNoSpreadingPeriodResponse: getNoSpreadingPeriodStoreResponse;
	saveNoSpreadingPeriodResponse: getNoSpreadingPeriodStoreResponse;
}

export const useApplicationFormsStore = defineStore("applicationFormsStore", {
	state: () =>
		({
			/* initStore*/
			loading: false,
			hasError: false,
			errorResponse: undefined,
			/* saveInStore for component comunicatuion*/
			saveInStore: null,
			/* attachment*/
			attachmentList: {
				records: [],
				nextKey: null,
				count: 0,
			},
			attachmentTypeList: null,
			/* dynamic documents*/
			declarationList: null,
			/* declarationYear */
			declarationYear: null,
			getDeclarationYearResponse: null,
			saveDeclarationYearResponse: null,
			editDeclarationYearResponse: null,
			/* graphic CropPlan*/
			municipalityList: {
				records: [],
				nextKey: null,
				count: 0,
			},
			municipalityListWithFertSpreading: {
				records: [],
				nextKey: null,
				count: 0,
			},
			municipalityListFromCodeResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			landUseListFromCodeResponse: null,
			landUseList: {
				records: [],
				nextKey: null,
				count: 0,
			},
			graphicCropPlanList: [],
			saveGraphicCropPlanResponse: null,
			editGraphicCropPlanResponse: null,
			getMasFromLandUseCodeResponse: [],

			/* fiveYearDeclaration and cadastralParcelForm */
			getCadastralParticelResponse: null,
			getCadastralParticelListResponse: [],
			saveCadastralParticelResponse: null,
			editCadastralParcelResponse: null,
			/* fertSPreading and fertSpreadingForm */
			getFertSpreadingDeclarationListResponse: [],
			getFertSpreadingDeclarationResponse: null,
			saveFertSpreadingDeclarationResponse: null,
			editFertSpreadingDeclarationResponse: null,
			getEffuentListResponse: null,
			effluentListFromCodeResponse: [],
			getCropPlanListResponse: null,

			getCropPlanVersionListResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			getDeclarationListResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			getDeclarationUsedAsPlotListResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			getDeclarationUsedAsPlotListFromCodeResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},

			// search subject
			subjectList: null,
			selectedSubject: null,

			// ChemicalAndOrganic
			getPlotLandListAndPreviousManureResponse: [],
			getPlotLandResponse: null,
			getFrequencyFromEffluentCodeResponse: [],
			getFrequencyFromEffluentCodeListResponse: [],
			editPlotLandResponse: null,
			editMassivePlotLandResponse: [],
			savePlotLandResponse: null,
			getDistributedNeedsResponse: null,
			getPrecessionResponse: [],
			getTypologyResponse: [],
			getTypologyFromCodeResponse: [],
			getCycleResponse: [],

			// previousManure
			editPreviousManureResponse: null,
			savePreviousManureResponse: null,

			// animal consistency
			getAnimalConsistencyListResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			getAnimalConsistencyResponse: null,
			editAnimalConsistencyResponse: null,
			saveAnimalConsistencyResponse: null,
			getSpecieListResponse: [],
			getCategoryListResponse: [],
			getCategoryListFromCodeResponse: [],
			getHousingTypeListResponse: [],
			getHousingTypeListFromCategoryCodeResponse: [],
			getBalanceIndicesListResponse: {
				records: [],
				nextKey: null,
				count: 0,
			},
			BalanceIndicesRequest: null,

			// openLayer components
			layerList: [],
			additionalLayers: null,

			// no spreading
			getNoSpreadingPeriodListResponse: [],
			editNoSpreadingPeriodResponse: null,
			saveNoSpreadingPeriodResponse: null,
		}) as State,
	getters: {
		getLoading: (state: State) => {
			return state.loading;
		},
		getDeclarationList: (state: State) => {
			return state.declarationList;
		},
		getAttachmentList: (state: State) => {
			return state.attachmentList;
		},
		getAttachmentTypeList: (state: State) => {
			return state.attachmentTypeList?.records ?? [];
		},
		getErrorResponse: (state: State) => {
			return state.errorResponse;
		},
		getSubjectList: (state: State) => {
			return state.subjectList?.records;
		},
		getSelectedSubject: (state: State) => {
			return state.selectedSubject;
		},
		getLayerList: (state: State) => {
			return state.layerList;
		},
		getAdditionalLayers: (state: State) => {
			return state.additionalLayers;
		},
	},
	actions: {
		validateNumberOrNumberWithFourDecimal(
			inputId: string,
			input: Ref,
			inputOldValue: string | undefined
		) {
			const regexValidator = new RegExp("^\\d+(\\.|,)\\d{1,4}$", "gi");
			const regexValidator2 = new RegExp("^\\d+(\\.|,)$", "gi");
			const regexValidator3 = new RegExp("^\\d*$", "gi");
			const inputRef: HTMLInputElement = document.getElementById(
				inputId
			) as HTMLInputElement;
			const inputValue = inputRef.value;
			if (
				!(inputValue + "").match(regexValidator) &&
				!(inputValue + "").match(regexValidator2) &&
				!(inputValue + "").match(regexValidator3)
			) {
				if (input) {
					input.value = inputOldValue;
				}
				setTimeout(function () {
					input.value = inputOldValue;
					inputRef.focus();
				}, 0);
				return false;
			} else {
				inputOldValue = inputValue;

				setTimeout(function () {
					inputRef.focus();
				}, 0);
				return inputOldValue;
			}
		},
		resetScrollToTop(window: Window) {
			return window.scrollTo(0, 0);
		},
		saveDataInStore(
			componentSaveStore: TComponentSaveStore,
			dataKey: TDataKey,
			dataToSave:
				| IEditElement
				| getPlotLandResponse
				| boolean
				| savePlotLandRequestResponse
				| editPlotLandRequestResponse
				| number[]
				| IFilterStoreChemicalAndOrganicaFertilizer
		) {
			this.loading = true;
			this.hasError = false;
			if (!this.saveInStore) {
				this.saveInStore = {} as Record<
					TComponentSaveStore,
					ISaveInStoreSubObject
				>;
			}
			if (!this.saveInStore[componentSaveStore]) {
				this.saveInStore[componentSaveStore] = {} as ISaveInStoreSubObject;
			}

			if (
				dataKey === "editElement" &&
				dataToSave &&
				typeof dataToSave === "object" &&
				!Array.isArray(dataToSave) &&
				isDataToSaveTypeSafeIEditElement(dataToSave)
			) {
				this.saveInStore[componentSaveStore][dataKey] = dataToSave;
			} else if (
				dataKey === "isExternalCompany" &&
				dataToSave &&
				typeof dataToSave === "boolean"
			) {
				this.saveInStore[componentSaveStore][dataKey] = dataToSave;
			} else if (
				dataKey === "editMassive" &&
				dataToSave &&
				typeof dataToSave === "object" &&
				Array.isArray(dataToSave)
			) {
				this.saveInStore[componentSaveStore][dataKey] = dataToSave;
			} else if (
				dataKey === "editElementDetailsPage" &&
				dataToSave &&
				typeof dataToSave === "object" &&
				!Array.isArray(dataToSave) &&
				!isDataToSaveTypeSafeIEditElement(dataToSave) &&
				isDataToSaveTypeSafeGetPlotLandResponse(dataToSave)
			) {
				this.saveInStore[componentSaveStore][dataKey] = dataToSave;
			} else if (
				dataKey === "filterObject" &&
				dataToSave &&
				typeof dataToSave === "object" &&
				!Array.isArray(dataToSave) &&
				!isDataToSaveTypeSafeIEditElement(dataToSave) &&
				!isDataToSaveTypeSafeGetPlotLandResponse(dataToSave) &&
				isDataToSaveTypeSafeFilterObject(dataToSave)
			) {
				this.saveInStore[componentSaveStore][dataKey] = dataToSave;
			}

			this.loading = false;

			function isDataToSaveTypeSafeIEditElement(
				dataToSave:
					| IEditElement
					| getPlotLandResponse
					| boolean
					| savePlotLandRequestResponse
					| editPlotLandRequestResponse
					| IFilterStoreChemicalAndOrganicaFertilizer
			): dataToSave is IEditElement {
				return (
					typeof dataToSave != "boolean" &&
					dataToSave != null &&
					(dataToSave as IEditElement).id != null &&
					(dataToSave as getPlotLandResponse)?.previousEffluents == null
				);
			}

			function isDataToSaveTypeSafeGetPlotLandResponse(
				dataToSave:
					| IEditElement
					| getPlotLandResponse
					| boolean
					| savePlotLandRequestResponse
					| editPlotLandRequestResponse
					| IFilterStoreChemicalAndOrganicaFertilizer
			): dataToSave is getPlotLandResponse {
				return (
					typeof dataToSave != "boolean" &&
					dataToSave != null &&
					(dataToSave as getPlotLandResponse)?.ids != null
				);
			}

			function isDataToSaveTypeSafeFilterObject(
				dataToSave:
					| IEditElement
					| getPlotLandResponse
					| boolean
					| savePlotLandRequestResponse
					| editPlotLandRequestResponse
					| IFilterStoreChemicalAndOrganicaFertilizer
			): dataToSave is IFilterStoreChemicalAndOrganicaFertilizer {
				return (
					(typeof dataToSave != "boolean" &&
						dataToSave != null &&
						(dataToSave as IFilterStoreChemicalAndOrganicaFertilizer)
							?.sectorCode !== null) ||
					(dataToSave as IFilterStoreChemicalAndOrganicaFertilizer)
						?.landUseCode !== null
				);
			}
		},
		clearDataInStore(
			componentSaveStore: TComponentSaveStore,
			dataKey: TDataKey
		) {
			this.loading = true;
			this.hasError = false;
			if (!this.saveInStore) {
				this.saveInStore = {} as Record<
					TComponentSaveStore,
					ISaveInStoreSubObject
				>;
			}
			if (!this.saveInStore[componentSaveStore]) {
				this.saveInStore[componentSaveStore] = {} as ISaveInStoreSubObject;
			}
			this.saveInStore[componentSaveStore][dataKey] = null;
			this.loading = false;
		},
		clearGetDeclarationUsedAsPlotListResponse() {
			this.getDeclarationUsedAsPlotListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
		},
		clearGetCadastralParticelResponse() {
			this.getCadastralParticelResponse = null;
		},
		clearGetFertSpreadingDeclarationResponse() {
			this.getFertSpreadingDeclarationResponse = null;
		},
		clearPLotLandResponseForChemicalAndOrganicFertilizerForm() {
			this.editMassivePlotLandResponse = [];
			this.editPlotLandResponse = null;
			this.savePlotLandResponse = null;
		},
		resetBodyScroll() {
			document.body.classList.remove("modal-open");
			document.body.style.removeProperty("overflow");
			document.body.style.removeProperty("padding-right");
		},
		addDate(
			date: string | null,
			addNumber: number,
			addType: dayjs.ManipulateType
		) {
			return dayjs(date ?? dayjs())
				.add(addNumber, addType)
				.format("YYYY-MM-DD")
				.toString();
		},
		subtractDate(
			date: string,
			subtrackNumber: number,
			subtraackType: dayjs.ManipulateType
		) {
			return dayjs(date)
				.subtract(subtrackNumber, subtraackType)
				.format("YYYY-MM-DD")
				.toString();
		},

		addSeparatorInStringForDate(date: string) {
			return dayjs(date).format("YYYY/MM/DD").toString();
		},
		createDateWithDayjs(year: number, mouth: number, day: number) {
			return dayjs(`${year}-${mouth}-${day}`).format("YYYY-MM-DD").toString();
		},
		getLastDayOfMonth(year: number, mouth: number, day: number) {
			return dayjs(`${year}-${mouth}-${day}`).daysInMonth();
		},

		async loadAttachmentList(resetList: boolean, attachmentGroup: string) {
			if (resetList) {
				this.attachmentList = {
					records: [],
					nextKey: null,
					count: 0,
				};
			}
			this.loading = true;
			this.hasError = false;
			const actualNextKey = this.attachmentList?.nextKey;
			const response = await getAttachmentList(actualNextKey, attachmentGroup);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				if (
					!resetList &&
					this.attachmentList &&
					this.attachmentList.records &&
					response.data &&
					response.data.records
				) {
					this.attachmentList.records.push(...(response.data.records || []));
					this.attachmentList.nextKey = response.data.nextKey;
					this.attachmentList.count = response.data.count;
				} else {
					this.attachmentList = response.data;
				}
			}
			this.loading = false;
		},
		async getBalanceIndicesList(request: BalanceIndicesRequest) {
			this.getBalanceIndicesListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getBalanceIndicesList(request);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getBalanceIndicesListResponse = response.data;
			}
			this.loading = false;
		},
		async addAttachment(
			attachmentObj: SaveAttachmentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await addAttachment(
				attachmentObj,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async editAttachment(
			attachmentId: string,
			attachmentObj: SaveAttachmentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await editAttachment(
				attachmentId,
				attachmentObj,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			}
			this.loading = false;
		},
		async deleteAttachment(
			attachmentId: string,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteAttachment(
				attachmentId,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadAttachmentTypeList() {
			this.attachmentTypeList = null;
			this.loading = true;
			this.hasError = false;
			let _tmpNextKey: string | null = "";
			const _tmpTypeArray: AttachmentTypeModel[] = [];
			let _tmpCount = 0;
			while (_tmpNextKey !== null && _tmpNextKey !== undefined) {
				const response: HttpJsonResult<AttachmentTypeResponse> =
					await getAttachmentTypeList(_tmpNextKey);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response);
					return;
				} else if (response.data && response.data.records) {
					_tmpNextKey = response.data.nextKey;
					_tmpCount = response.data.count;
					_tmpTypeArray.push(...response.data.records);
				}
			}
			this.attachmentTypeList = {
				records: _tmpTypeArray,
				count: _tmpCount,
				nextKey: _tmpNextKey,
			};
			this.loading = false;
		},
		async downloadAttachment(attachmentId: string) {
			this.hasError = false;
			const response = await downloadAttachment(attachmentId);

			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				const _blob = await response.response.blob();
				return URL.createObjectURL(_blob);
			}
		},
		async clearAttachmentListandTypeList() {
			this.attachmentTypeList = null;
			this.attachmentList = {
				records: [],
				nextKey: null,
				count: 0,
			};
		},

		async loadMunicipalityList(filter: string) {
			this.municipalityList = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getMunicipalityList(filter);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.municipalityList = response.data;
			}
			this.loading = false;
		},
		async loadMunicipalityListWithFertSpreading(
			pointInTime: string,
			cropPlanId: number,
			businessId: number
		) {
			this.municipalityListWithFertSpreading = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			let currentNextKey: string | null = "";

			while (currentNextKey !== null) {
				const response = await getMunicipalityListWithFertSpreading(
					pointInTime,
					cropPlanId,
					businessId,
					currentNextKey
				);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response, false);
				} else if (response.data && response.data.records) {
					currentNextKey = this.municipalityListWithFertSpreading.nextKey =
						response.data.nextKey;
					this.municipalityListWithFertSpreading.count = response.data.count;
					this.municipalityListWithFertSpreading.records.push(
						...response.data.records
					);
				}
				this.loading = false;
			}
		},
		async loadLandUseList(filter: string) {
			this.landUseList = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getLandUseChoiceList(filter);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				let records = [] as Array<any>;
				if (response.data.records != null && response.data.records.length > 0) {
					records =
						response.data.records.filter(
							item =>
								item.land_uses_code != null &&
								item.land_uses_code.split("-").length === 5
						) ?? [];
				}
				this.landUseList = {
					records: records,
					nextKey: response.data.nextKey,
					count: records.length,
				};
			}
			this.loading = false;
		},
		async deleteGraphicCropPlan(graphicCropPlan: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteGraphicCropPlan(graphicCropPlan);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteAllGraphicCropPlanList() {
			this.loading = true;
			this.hasError = false;
			const response = await deleteAllGraphicCropPlanList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadGraphicCropPlanList() {
			this.graphicCropPlanList = [];
			this.loading = true;
			this.hasError = false;
			const response = await getGraphicCropPlanList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanList = response.data;
			}
			this.loading = false;
		},

		async loadGraphicCropPlanListFilter(
			getChemicalFertilizerFilterObject: IFilterChemicalAndOrganicaFertilizer,
			nextKey: undefined | number
		) {
			this.graphicCropPlanList = [];
			this.loading = true;
			this.hasError = false;
			const response = await getGraphicCropPlanListFilter(
				getChemicalFertilizerFilterObject,
				nextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanList = response.data;
			}
			this.loading = false;
		},
		async importGraphicCropPlan(campaignYear: number) {
			this.loading = true;
			this.hasError = false;
			this.graphicCropPlanList = [];
			const response = await importGraphicCropPlanList(campaignYear);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.graphicCropPlanList = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async saveGraphicCropPlan(graphicCropPlan: SaveGraphicCropPlanModel) {
			this.saveGraphicCropPlanResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await saveGraphicCropPlan(graphicCropPlan);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveGraphicCropPlanResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async editGraphicCropPlan(
			graphicCropPlan: SaveGraphicCropPlanModel,
			graphicCropPlanId: number
		) {
			this.editGraphicCropPlanResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editGraphicCropPlan(
				graphicCropPlan,
				graphicCropPlanId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editGraphicCropPlanResponse = response.data;
			}
			this.loading = false;
		},

		async getMasFromLandUseCode(landUseCode: string) {
			this.getMasFromLandUseCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getMasFromLandUseCode(landUseCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getMasFromLandUseCodeResponse = response.data;
			}
			this.loading = false;
		},
		async loadLandUseListFromCode(landUseCodeList: string[]) {
			this.landUseListFromCodeResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await loadLandUseListFromCode(landUseCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.landUseListFromCodeResponse = response.data;
			}
			this.loading = false;
		},
		async loadMunicipalityListFromCode(municipalityCodeList: string[]) {
			this.municipalityListFromCodeResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await loadMunicipalityListFromCode(municipalityCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.municipalityListFromCodeResponse = response.data;
			}
			this.loading = false;
		},

		async getCadastralParticel(CadastralParcelId: string) {
			this.getCadastralParticelResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await getCadastralParticel(CadastralParcelId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getCadastralParticelResponse = response.data;
			}
			this.loading = false;
		},
		async editCadastralParcel(cadastralParcel: SaveCadastralParticelModel) {
			this.editCadastralParcelResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editCadastralParcel(cadastralParcel);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				this.editCadastralParcelResponse = response.data;
			}
			this.loading = false;
		},
		async saveCadastralParticel(cadastralParticel: SaveCadastralParticelModel) {
			this.saveCadastralParticelResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await saveCadastralParticel(cadastralParticel);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveCadastralParticelResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async getCadastralParticelList() {
			this.getCadastralParticelListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getCadastralParticelList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getCadastralParticelListResponse = response.data;
			}
			this.loading = false;
		},

		async deleteCadastralParcel(graphicCropPlan: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteCadastralParcel(graphicCropPlan);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async loadDeclarationList(documentCode: string) {
			this.declarationList = null;
			this.loading = true;
			this.hasError = false;
			const response = await getDeclarationList(documentCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.hasError = false;
				this.declarationList = response.data;
			}
			this.loading = false;
		},
		async saveDeclarations(
			document_code: string,
			declarations: SaveDeclarationsModel,
			compileStatusIdentifier: string,
			isDeclaration: boolean
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveDeclarations(
				document_code,
				declarations,
				compileStatusIdentifier,
				isDeclaration
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async getDeclarationYear() {
			this.getDeclarationYearResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await getDeclarationYear();
			if (response.errorType !== ErrorType.NONE) {
				if (response.errorType === ErrorType.HTTP_STATUS) {
					if (response.response.status !== 404) {
						//if not found create new one
						this.hasError = true;
						this.errorResponse = response as HttpResponseError;
						handleApiErrorAndShowAlert(response);
					}
				}
			} else {
				this.getDeclarationYearResponse = response.data;
			}
			this.loading = false;
		},
		async saveDeclarationYear(declarationYear: SaveDeclarationYearResponse) {
			this.loading = true;
			this.hasError = false;
			this.saveDeclarationYearResponse = null;
			const response = await saveDeclarationYear(declarationYear);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveDeclarationYearResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async editDeclarationYear(declarationsYear: SaveDeclarationYearResponse) {
			this.loading = true;
			this.hasError = false;
			this.editDeclarationYearResponse = null;
			const response = await editDeclarationYear(declarationsYear);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editDeclarationYearResponse = response.data;
			}
			this.loading = false;
		},

		async saveFertSpreadingDeclaration(
			fertSpreadingDeclaration: SaveFertSpreadingDeclarationRequest,
			campaignYear: number
		) {
			this.loading = true;
			this.hasError = false;
			this.saveFertSpreadingDeclarationResponse = null;
			const response = await saveFertSpreadingDeclaration(
				fertSpreadingDeclaration,
				campaignYear
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.saveFertSpreadingDeclarationResponse = response.data;
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async editFertSpreadingDeclaration(
			fertSpreadingDeclaration: SaveFertSpreadingDeclarationRequest,
			fertSpreadingDeclarationId: number,
			campaignYear: number
		) {
			this.loading = true;
			this.hasError = false;
			this.editFertSpreadingDeclarationResponse = null;
			const response = await editFertSpreadingDeclaration(
				fertSpreadingDeclaration,
				fertSpreadingDeclarationId,
				campaignYear
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editFertSpreadingDeclarationResponse = response.data;
			}
			this.loading = false;
		},
		async getFertSpreadingDeclarationList() {
			this.getFertSpreadingDeclarationListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getFertSpreadingDeclarationList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getFertSpreadingDeclarationListResponse = response.data;
			}
			this.loading = false;
		},
		async getFertSpreadingDeclaration(fertSpreadingDeclarationId: number) {
			this.getFertSpreadingDeclarationResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await getFertSpreadingDeclaration(
				fertSpreadingDeclarationId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getFertSpreadingDeclarationResponse = response.data;
			}
			this.loading = false;
		},
		async deleteFertSpreadingDeclaration(fertSpreadingDeclarationId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteFertSpreadingDeclaration(
				fertSpreadingDeclarationId
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async loadEffulentList(isFilterForFrequency: boolean) {
			this.getEffuentListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getEffluentList(isFilterForFrequency);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getEffuentListResponse = response.data;
			}
			this.loading = false;
		},
		async getPrecession() {
			this.getPrecessionResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getPrecession();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getPrecessionResponse = response.data;
			}
			this.loading = false;
		},
		async getTipology(landUseCode: string) {
			this.getTypologyResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getTypology(landUseCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getTypologyResponse = response.data;
			}
			this.loading = false;
		},
		async getTypologyFromLandUseCodeList(landUseCodeList: string[]) {
			this.getTypologyFromCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getTypologyFromLandUseCodeList(landUseCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getTypologyFromCodeResponse = response.data;
			}
			this.loading = false;
		},
		async getCycle() {
			this.getCycleResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getCycle();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getCycleResponse = response.data;
			}
			this.loading = false;
		},
		async loadEffulentListFromCode(codes: string[]) {
			this.effluentListFromCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getEffluentListFromCode(codes);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.effluentListFromCodeResponse = response.data;
			}
			this.loading = false;
		},
		async getCropPlanList(businessId: number) {
			this.getCropPlanListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getCropPlanList(businessId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getCropPlanListResponse = response.data;
			}
			this.loading = false;
		},
		async getCropPlanVersionList(businessId: number, cropPlanId: number) {
			this.getCropPlanVersionListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getCropPlanVersionList(businessId, cropPlanId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getCropPlanVersionListResponse = response.data;
			}
			this.loading = false;
		},
		async getDeclarationListFromCropPlan(
			businessId: number,
			cropPlanId: number,
			version: string,
			pointInTime: string,
			pointInTimeTo: string
		) {
			this.getDeclarationListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			let currentNextKey: string | null = "";

			while (currentNextKey !== null) {
				const response = await getDeclarationListFromCropPlan(
					businessId,
					cropPlanId,
					version,
					pointInTime,
					pointInTimeTo,
					currentNextKey
				);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response, false);
				} else if (response.data && response.data.records) {
					currentNextKey = this.getDeclarationListResponse.nextKey =
						response.data.nextKey;
					this.getDeclarationListResponse.count = response.data.count;
					this.getDeclarationListResponse.records.push(
						...response.data.records
					);
				}
			}
			this.loading = false;
		},
		async loadDeclarationsUsedAsPlotFromDeclCodeWithFertSpreading(
			businessId: number,
			cropPlanId: number,
			version: string,
			pointInTime: string,
			pointInTimeTo: string,
			municipality: string,
			filter: string
		) {
			this.getDeclarationUsedAsPlotListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;

			let currentNextKey: string | null = "";
			while (currentNextKey !== null) {
				const response = await getPlotListWithFertSpreading(
					currentNextKey,
					businessId,
					cropPlanId,
					version,
					pointInTime,
					pointInTimeTo,
					municipality,
					filter
				);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response, false);
				} else if (response.data && response.data.records) {
					currentNextKey = this.getDeclarationUsedAsPlotListResponse.nextKey =
						response.data.nextKey;
					this.getDeclarationUsedAsPlotListResponse.count = response.data.count;
					this.getDeclarationUsedAsPlotListResponse.records.push(
						...(response.data.records || [])
					);
				}
			}
			this.loading = false;
		},
		async loadDeclarationsUsedAsPlotFromDeclCode(
			resetList: boolean,
			businessId: number,
			cropPlanId: number,
			version: string,
			pointInTime: string,
			pointInTimeTo: string,
			filter: string
		) {
			if (resetList) {
				this.getDeclarationUsedAsPlotListResponse = {
					records: [],
					nextKey: null,
					count: 0,
				};
			}
			this.loading = true;
			this.hasError = false;
			const actualNextKey = this.getDeclarationUsedAsPlotListResponse.nextKey;
			const response = await getPlotList(
				actualNextKey,
				businessId,
				cropPlanId,
				version,
				pointInTime,
				pointInTimeTo,
				filter
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				if (!resetList && response.data && response.data.records) {
					this.getDeclarationUsedAsPlotListResponse.records.push(
						...(response.data.records || [])
					);
					this.getDeclarationUsedAsPlotListResponse.nextKey =
						response.data.nextKey;
					this.getDeclarationUsedAsPlotListResponse.count = response.data.count;
				} else {
					this.getDeclarationUsedAsPlotListResponse = response.data;
				}
			}
			this.loading = false;
		},
		async loadDeclarationAsPlotListFromCode(
			businessId: number,
			cropPlanId: number,
			version: string,
			pointInTime: string,
			pointInTimeTo: string
		) {
			this.getDeclarationUsedAsPlotListFromCodeResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			let currentNextKey: string | null = "";

			while (currentNextKey !== null) {
				const response: HttpJsonResult<getDeclarationListFromCropPlanResponse> =
					await getPlotListFormCode(
						businessId,
						cropPlanId,
						version,
						pointInTime,
						pointInTimeTo,
						currentNextKey
					);
				if (response.errorType !== ErrorType.NONE) {
					this.hasError = true;
					this.errorResponse = response as HttpResponseError;
					handleApiErrorAndShowAlert(response);
					return;
				} else if (response.data && response.data.records) {
					currentNextKey =
						this.getDeclarationUsedAsPlotListFromCodeResponse.nextKey =
							response.data.nextKey;
					this.getDeclarationUsedAsPlotListFromCodeResponse.count =
						response.data.count;
					this.getDeclarationUsedAsPlotListFromCodeResponse.records.push(
						...response.data.records
					);
				}
			}
			this.loading = false;
		},

		async searchSubjects(
			cuaa?: string | null,
			partyDesc?: string | null,
			resetList?: boolean
		) {
			this.loading = true;
			this.hasError = false;
			const useCuaa = cuaa?.trimEnd();
			const usePartyDesc = partyDesc?.trimEnd();
			const actualNextKey = this.subjectList?.nextKey;
			const response = await loadPartiesV2(
				useCuaa,
				usePartyDesc,
				actualNextKey
			);
			if (response.errorType !== ErrorType.NONE) {
				handleApiErrorAndShowAlert(response, false);
			} else {
				if (!resetList && this.subjectList && response.data) {
					this.subjectList.records.push(...response.data.records);
					this.subjectList.nextKey = response.data.nextKey;
					this.subjectList.count = response.data.count;
				} else {
					this.subjectList = response.data;
				}
			}
			this.loading = false;
		},
		clearSubjectList() {
			this.subjectList = null;
		},
		clearSelectedSubject() {
			this.selectedSubject = null;
		},
		setSelectedSubject(subject: getPartyRegistryResponse) {
			this.selectedSubject = subject;
		},

		async getFrequencyFromEffluentCode(effluentCode: string) {
			this.getFrequencyFromEffluentCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getFrequencyFromEffluentCode(effluentCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getFrequencyFromEffluentCodeResponse = response.data;
			}
			this.loading = false;
		},
		async getFrequencyFromEffluentCodeList(effluentCodeList: string[]) {
			this.getFrequencyFromEffluentCodeListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getFrequencyFromEffluentCodeList(effluentCodeList);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getFrequencyFromEffluentCodeListResponse = response.data;
			}
			this.loading = false;
		},
		async getPlotLand(plotLandId: number) {
			this.getPlotLandResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await getPlotsLand(plotLandId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getPlotLandResponse = response.data;
			}
			this.loading = false;
		},
		async savePlotLand(plotLand: savePlotLandRequestResponse) {
			this.savePlotLandResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await savePlotLand(plotLand);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.savePlotLandResponse = response.data;
			}
			this.loading = false;
		},
		async editMassivePlotLand(plotLand: editPlotLandRequestResponse) {
			this.editMassivePlotLandResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await editMassivePlotLand(plotLand);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.editMassivePlotLandResponse = response.data;
			}
			this.loading = false;
		},
		async editPlotLand(
			plotLandId: number,
			plotLand: editPlotLandRequestResponse
		) {
			this.editPlotLandResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editPlotLand(plotLandId, plotLand);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.editPlotLandResponse = response.data;
			}
			this.loading = false;
		},
		async getPlotsLandListAndPreviousManure(showError = true) {
			this.getPlotLandListAndPreviousManureResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getPlotsLandListAndPreviousManure();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, showError);
			} else {
				this.getPlotLandListAndPreviousManureResponse = response.data;
			}
			this.loading = false;
		},
		async getPlotLandListFilter(
			getPlotLandFilter: IFilterChemicalAndOrganicaFertilizer,
			nextKey: undefined | number
		) {
			this.getPlotLandListAndPreviousManureResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getPlotsLandListFilter(getPlotLandFilter, nextKey);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getPlotLandListAndPreviousManureResponse = response.data;
			}
			this.loading = false;
		},
		async importPlotsLandList(campaignYear: number) {
			this.getPlotLandListAndPreviousManureResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await importPlotsLandList(campaignYear);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.getPlotLandListAndPreviousManureResponse = response.data;
			}
			this.loading = false;
		},
		async deletePlotLand(plotLandId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deletePlotLand(plotLandId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async deleteAllPlotsLandList() {
			this.loading = true;
			this.hasError = false;
			const response = await deleteAllPlotsLandList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},

		async getDistributedNeeds(
			cropCode: string,
			chiaveAppezzamento: string,
			tipologiaCod: number,
			resa: number,
			precessioneCod: number,
			nFertilizzazioniPrecedenti: string
		) {
			this.getDistributedNeedsResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await getDistributedNeeds(
				cropCode,
				chiaveAppezzamento,
				tipologiaCod,
				resa,
				precessioneCod,
				nFertilizzazioniPrecedenti
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getDistributedNeedsResponse = response.data;
			}
			this.loading = false;
		},

		async editPreviousManure(previousManure: savePreviousManureResponse) {
			this.editPreviousManureResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editPreviousManure(previousManure);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editPreviousManureResponse = response.data;
			}
			this.loading = false;
		},
		async savePreviousManure(previousManure: savePreviousManureResponse) {
			this.savePreviousManureResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await savePreviousManure(previousManure);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.savePreviousManureResponse = response.data;
			}
			this.loading = false;
		},
		async deletePreviousManure(previousManureId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deletePreviousManure(previousManureId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			}
			this.loading = false;
		},

		async getAnimalConsistencyList() {
			this.getAnimalConsistencyListResponse = {
				records: [],
				nextKey: null,
				count: 0,
			};
			this.loading = true;
			this.hasError = false;
			const response = await getAnimalConsistencyList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getAnimalConsistencyListResponse = response.data;
			}
			this.loading = false;
		},

		async getSpecieList() {
			this.getSpecieListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getSpecieList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getSpecieListResponse = response.data;
			}
			this.loading = false;
		},
		async getCategoryList(specieCode: string, genreCode: string) {
			this.getCategoryListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getCategoryList(specieCode, genreCode);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getCategoryListResponse = response.data;
			}
			this.loading = false;
		},
		async getCategoryListFromSpecieCode(
			codes: getCategoryFromSpecieResponse[]
		) {
			this.getCategoryListFromCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getCategoryListFromCode(codes);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getCategoryListFromCodeResponse = response.data;
			}
			this.loading = false;
		},
		async getHousingTypeList(
			specieCode: string,
			genreCode: string,
			categoryCode: string,
			productionCode: string
		) {
			this.getHousingTypeListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getHousingTypeList(
				specieCode,
				genreCode,
				categoryCode,
				productionCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getHousingTypeListResponse = response.data;
			}
			this.loading = false;
		},
		async getHousingTypeListFromCategoryCode(
			codes: getHousingTypeFromCategoryResponse[]
		) {
			this.getHousingTypeListFromCategoryCodeResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getHousingTypeListFromCode(codes);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.getHousingTypeListFromCategoryCodeResponse = response.data;
			}
			this.loading = false;
		},

		async editAnimalConsistency(
			animalConsistency: getAnimalConsistencyResponse
		) {
			this.editAnimalConsistencyResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editAnimalConsistency(animalConsistency);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editAnimalConsistencyResponse = response.data;
			}
			this.loading = false;
		},

		async saveAnimalConsistency(
			animalConsistency: getAnimalConsistencyResponse
		) {
			this.saveAnimalConsistencyResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await saveAnimalConsistency(animalConsistency);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.saveAnimalConsistencyResponse = response.data;
			}
			this.loading = false;
		},
		async deleteAnimalConsistency(animalConsistencyId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteAnimalConsistency(animalConsistencyId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		async getNoSpreadingPeriodList() {
			this.getNoSpreadingPeriodListResponse = [];
			this.loading = true;
			this.hasError = false;
			const response = await getNoSpreadingPeriodList();
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response, false);
			} else {
				this.getNoSpreadingPeriodListResponse = response.data;
			}
			this.loading = false;
		},
		async editNoSpreadingPeriod(
			noSpreadingPeriod: saveNoSpreadingPeriodResponse
		) {
			this.editNoSpreadingPeriodResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await editNoSpreadingPeriod(noSpreadingPeriod);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				this.editNoSpreadingPeriodResponse = response.data;
			}
			this.loading = false;
		},

		async saveNoSpreadingPeriod(
			noSpreadingPeriod: saveNoSpreadingPeriodResponse
		) {
			this.saveNoSpreadingPeriodResponse = null;
			this.loading = true;
			this.hasError = false;
			const response = await saveNoSpreadingPeriod(noSpreadingPeriod);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
				this.saveNoSpreadingPeriodResponse = response.data;
			}
			this.loading = false;
		},
		async deleteNoSpreadingPeriod(noSpreadingPeriodId: number) {
			this.loading = true;
			this.hasError = false;
			const response = await deleteNoSpreadingPeriod(noSpreadingPeriodId);
			if (response.errorType !== ErrorType.NONE) {
				this.hasError = true;
				this.errorResponse = response as HttpResponseError;
				handleApiErrorAndShowAlert(response);
			} else {
				resetDirtyState();
				sendCompiledEvent();
			}
			this.loading = false;
		},
		clearLayerList() {
			this.layerList = [];
		},
		setLayerVisibility(layer: GenericLayerModel, value: boolean) {
			if (
				this.layerList &&
				Array.isArray(this.layerList) &&
				this.layerList.length > 0
			) {
				const _currLay = this.layerList.find(l => l.name === layer.name);
				_currLay && (_currLay.visible = value);
			}
		},
		pushToLayerList(layer: GenericLayerModel) {
			if (Array.isArray(this.layerList) && layer) {
				this.layerList.push(layer);
			}
		},
		async loadAdditionalLayers(moduleId: string, srs: string) {
			this.loading = true;
			this.hasError = false;
			const response = await loadAdditionalLayersAPI(moduleId, srs);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.additionalLayers = response.data;
			}
			this.loading = false;
		},
		handleError(response: unknown, showAlert: boolean) {
			this.hasError = true;
			this.errorResponse = response as HttpResponseError;
			if (showAlert) handleApiErrorAndShowAlert(response);
		},
	},
});
