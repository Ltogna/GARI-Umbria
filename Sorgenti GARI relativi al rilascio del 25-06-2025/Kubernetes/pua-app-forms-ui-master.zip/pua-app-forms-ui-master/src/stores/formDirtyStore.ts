interface DirtyStore {
	isDirty: boolean;
	formCode?: string | null;
}

const dirtyStore: DirtyStore = {
	isDirty: false,
};

export function getIsDirty() {
	return dirtyStore.isDirty;
}

export function resetDirtyState() {
	dirtyStore.isDirty = false;
	dirtyStore.formCode = undefined;
	dispatchDirtyStateEvent(false);
}

export function setDirtyState(formCode?: string | null) {
	dirtyStore.isDirty = true;
	dirtyStore.formCode = formCode;
	dispatchDirtyStateEvent(true);
}

function dispatchDirtyStateEvent(value: boolean) {
	const event = new CustomEvent("forms-dirty-state", {
		detail: { formDirtyState: value },
	});
	window.dispatchEvent(event);
}
