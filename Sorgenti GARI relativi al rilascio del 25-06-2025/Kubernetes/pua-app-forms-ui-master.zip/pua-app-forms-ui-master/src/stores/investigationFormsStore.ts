import type { TerritoryFiltersModel } from "@/models/unificataForms";
import type {
	CorrectionSurfacesPrizesDetailsInfiniteListModel,
	CorrectionSurfacesPrizesListModel,
	InvestigationCoupledListModel,
	InvestigationDARModel,
	InvestigationDataModel,
	InvestigationModulationModel,
	InvestigationOverDeclarationListModel,
	InvestigationSurfaceEcoschemasModel,
	InvestigationSurfacesPrizesDetailsInfiniteListModel,
	InvestigationSurfacesPrizesListModel,
	InvestigationYoungFarmerModel,
	OptionsPaymentListModel,
	SaveCorrectionSurfacesPrizesDetailsModel,
	SaveInvestigationCoupledListModel,
	SaveInvestigationDARModel,
	SaveInvestigationOverDeclarationListModel,
	saveInvestigationSurfaceEcoschemasModel,
	SaveInvestigationSurfacesPrizesDetailsModel,
	SaveOptionsPaymentModel,
} from "@/models/investigationForms";
import { handleApiErrorAndShowAlert } from "@/models/utils";
import {
	loadCorrectionSurfacesPrizesAPI,
	loadCorrectionSurfacesPrizesDetailsAPI,
	loadInvestigationCoupledAPI,
	loadInvestigationDARAPI,
	loadInvestigationDataAPI,
	loadInvestigationModulationAPI,
	loadInvestigationOverdeclarationAPI,
	loadInvestigationSurfaceEcoschemesAPI,
	loadInvestigationSurfacesFiltersAPI,
	loadInvestigationSurfacesPrizesAPI,
	loadInvestigationSurfacesPrizesDetailsAPI,
	loadInvestigationYoungFarmerAPI,
	loadOptionsPaymentAPI,
	saveCorrectionSurfacesPrizesDetailsAPI,
	saveInvestigationCoupledAPI,
	saveInvestigationDARAPI,
	saveInvestigationDataAPI,
	saveInvestigationOverdeclarationAPI,
	saveInvestigationSurfaceEcoschemesAPI,
	saveInvestigationSurfacesPrizesDetailsAPI,
	saveInvestigationYoungFarmerAPI,
	saveOptionsPaymentAPI,
	updateInvestigationDARAPI,
} from "@/resources/api/investigationFormsApi";
import {
	ErrorType,
	type HttpResponseError,
} from "@abaco/safe-rest/src/HTTPClient";
import { defineStore } from "pinia";

interface State {
	loading: boolean;
	hasError: boolean;
	errorResponse?: HttpResponseError;
	standardSurfaceFilters?: TerritoryFiltersModel;
	investigationSurfacesPrizesList?: InvestigationSurfacesPrizesListModel;
	investigationSurfacesPrizesDetailsList: InvestigationSurfacesPrizesDetailsInfiniteListModel;
	investigationYoungFarmer?: InvestigationYoungFarmerModel;
	investigationDAR?: InvestigationDARModel;
	correctionSurfacesPrizesList?: CorrectionSurfacesPrizesListModel;
	correctionSurfacesPrizesDetailsList: CorrectionSurfacesPrizesDetailsInfiniteListModel;
	investigationModulation?: InvestigationModulationModel;
	optionsPaymentList: OptionsPaymentListModel;
	investigationCoupledList: InvestigationCoupledListModel;
	investigationData?: InvestigationDataModel;
	investigationSurfaceEcoschemas?: InvestigationSurfaceEcoschemasModel;
	investigationOverdeclarationList?: InvestigationOverDeclarationListModel;
}

export const useInvestigationFormsStore = defineStore({
	id: "investigationFormsStore",
	state: () =>
		({
			loading: false,
			hasError: false,
			errorResponse: undefined,
			standardSurfaceFilters: undefined,
			investigationSurfacesPrizesList: undefined,
			investigationSurfacesPrizesDetailsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			investigationYoungFarmer: undefined,
			investigationDAR: undefined,
			correctionSurfacesPrizesList: undefined,
			correctionSurfacesPrizesDetailsList: {
				count: 0,
				nextKey: null,
				records: null,
			},
			investigationModulation: undefined,
			optionsPaymentList: [],
			investigationCoupledList: {
				records: null,
				notes: null,
			},
			investigationData: undefined,
			investigationSurfaceEcoschemas: undefined,
			investigationOverdeclarationList: undefined,
		}) as State,
	getters: {
		getLoading: (state: State) => {
			return state.loading;
		},
		getError: (state: State) => {
			return state.hasError;
		},
		getErrorResponse: (state: State) => {
			return state.errorResponse;
		},
		getStandardSurfaceFilters: (state: State) => {
			return state.standardSurfaceFilters;
		},
		getInvestigationSurfacesPrizes: (state: State) => {
			return state.investigationSurfacesPrizesList;
		},
		getInvestigationSurfacesPrizesDetailsList: (state: State) => {
			return state.investigationSurfacesPrizesDetailsList;
		},
		getInvestigationYoungFarmer: (state: State) => {
			return state.investigationYoungFarmer;
		},
		getInvestigationDAR: (state: State) => {
			return state.investigationDAR;
		},
		getCorrectionSurfacesPrizes: (state: State) => {
			return state.correctionSurfacesPrizesList;
		},
		getCorrectionSurfacesPrizesDetailsList: (state: State) => {
			return state.correctionSurfacesPrizesDetailsList;
		},
		getInvestigationModulation: (state: State) => {
			return state.investigationModulation;
		},
		getOptionsPayment: (state: State) => {
			return state.optionsPaymentList;
		},
		getInvestigationCoupled: (state: State) => {
			return state.investigationCoupledList;
		},
		getInvestigationData: (state: State) => {
			return state.investigationData;
		},
		getInvestigationSurfaceEcoschemas: (state: State) => {
			return state.investigationSurfaceEcoschemas;
		},
		getInvestigationOverdeclaration: (state: State) => {
			return state.investigationOverdeclarationList;
		},
	},
	actions: {
		clearInvestigationSurfacesPrizesDetailsList() {
			this.investigationSurfacesPrizesDetailsList = {
				count: 0,
				nextKey: null,
				records: null,
			};
		},
		clearCorrectionSurfacesPrizesDetailsList() {
			this.investigationSurfacesPrizesDetailsList = {
				count: 0,
				nextKey: null,
				records: null,
			};
		},
		async loadInvestigationSurfacesPrizes() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationSurfacesPrizesAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.investigationSurfacesPrizesList = response.data;
			}
			this.loading = false;
		},
		async loadInvestigationSurfacesPrizesDetails(
			optionCode: string,
			nextKey?: string | null,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.clearInvestigationSurfacesPrizesDetailsList();
			const response = await loadInvestigationSurfacesPrizesDetailsAPI(
				optionCode,
				nextKey,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.investigationSurfacesPrizesDetailsList = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationSurfacesPrizesDetails(
			optionCode: string,
			investigationSurfacesPrizesDetailsList: SaveInvestigationSurfacesPrizesDetailsModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationSurfacesPrizesDetailsAPI(
				optionCode,
				investigationSurfacesPrizesDetailsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationSurfacesFilters(
			optionCode: string,
			path: string,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.standardSurfaceFilters = undefined;
			const response = await loadInvestigationSurfacesFiltersAPI(
				optionCode,
				path,
				councilCode,
				sheet,
				parcelCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.standardSurfaceFilters = response.data;
			}
			this.loading = false;
		},
		async loadInvestigationYoungFarmer() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationYoungFarmerAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.investigationYoungFarmer = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationYoungFarmer(
			investigationYoungFarmerData: InvestigationYoungFarmerModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationYoungFarmerAPI(
				investigationYoungFarmerData,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationDAR() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationDARAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.investigationDAR = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationDAR(
			investigationDARData: SaveInvestigationDARModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationDARAPI(
				investigationDARData,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async updateInvestigationDAR() {
			this.loading = true;
			this.hasError = false;
			const response = await updateInvestigationDARAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadCorrectionSurfacesPrizes() {
			this.loading = true;
			this.hasError = false;
			const response = await loadCorrectionSurfacesPrizesAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.correctionSurfacesPrizesList = response.data;
			}
			this.loading = false;
		},
		async loadCorrectionSurfacesPrizesDetails(
			optionCode: string,
			nextKey?: string | null,
			councilCode?: string,
			sheet?: string,
			parcelCode?: string,
			engagement?: string,
			cropCode?: string
		) {
			this.loading = true;
			this.hasError = false;
			this.clearCorrectionSurfacesPrizesDetailsList();
			const response = await loadCorrectionSurfacesPrizesDetailsAPI(
				optionCode,
				nextKey,
				councilCode,
				sheet,
				parcelCode,
				engagement,
				cropCode
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.correctionSurfacesPrizesDetailsList = response.data;
			}
			this.loading = false;
		},
		async saveCorrectionSurfacesPrizesDetails(
			optionCode: string,
			correctionSurfacesPrizesDetailsList: SaveCorrectionSurfacesPrizesDetailsModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveCorrectionSurfacesPrizesDetailsAPI(
				optionCode,
				correctionSurfacesPrizesDetailsList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationModulation() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationModulationAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.investigationModulation = response.data;
			}
			this.loading = false;
		},
		async loadOptionsPayment() {
			this.optionsPaymentList = [];
			this.loading = true;
			this.hasError = false;
			const response = await loadOptionsPaymentAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.optionsPaymentList = response.data;
			}
			this.loading = false;
		},
		async saveOptionsPayment(
			choices: SaveOptionsPaymentModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveOptionsPaymentAPI(
				choices,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationCoupled() {
			this.optionsPaymentList = [];
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationCoupledAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.investigationCoupledList = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationCoupled(
			investigationCoupledList: SaveInvestigationCoupledListModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationCoupledAPI(
				investigationCoupledList,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationData() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationDataAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.investigationData = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationData(
			investigationData: InvestigationDataModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationDataAPI(
				investigationData,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationSurfaceEcoschemas() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationSurfaceEcoschemesAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.investigationSurfaceEcoschemas = response.data;
			}
			this.loading = false;
		},
		async saveInvestigationSurfaceEcoschemas(
			investigationSurfaceEcoschemas: saveInvestigationSurfaceEcoschemasModel
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationSurfaceEcoschemesAPI(
				investigationSurfaceEcoschemas
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		async loadInvestigationOverdeclaration() {
			this.loading = true;
			this.hasError = false;
			const response = await loadInvestigationOverdeclarationAPI();
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
				this.investigationOverdeclarationList = response.data;
			}
			this.loading = false;
		},
		async saveInvestigatioOverdeclarationData(
			investigationOverdeclarationData: SaveInvestigationOverDeclarationListModel,
			compileStatusIdentifier: string
		) {
			this.loading = true;
			this.hasError = false;
			const response = await saveInvestigationOverdeclarationAPI(
				investigationOverdeclarationData,
				compileStatusIdentifier
			);
			if (response.errorType !== ErrorType.NONE) {
				this.handleError(response, true);
			} else {
				this.hasError = false;
			}
			this.loading = false;
		},
		handleError(response: unknown, showAlert: boolean) {
			this.hasError = true;
			this.errorResponse = response as HttpResponseError;
			if (showAlert) handleApiErrorAndShowAlert(response);
		},
	},
});
