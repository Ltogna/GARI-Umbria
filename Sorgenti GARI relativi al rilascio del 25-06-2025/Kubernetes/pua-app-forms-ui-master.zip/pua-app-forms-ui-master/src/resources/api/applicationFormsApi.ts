import {
	AttachmentListResponseSchema,
	AttachmentTypeResponseSchema,
	DeclarationListResponseSchema,
	EffluentListFromCodeResponseSchema,
	EffluentListResponseSchema,
	getAllCadastralParticelResponseSchema,
	getAnimalConsistencyListModelSchema,
	getAnimalConsistencyModelSchema,
	getBalanceIndicesListResponseSchema,
	getCategoryResponseSchema,
	getCropPlanListResponseSchema,
	getCropPlanVersionListResponseSchema,
	getCycleResponseSchema,
	getDeclarationListFromCropPlanResponseSchema,
	getDistributedNeedsResponseSchema,
	getFertSpreadingDeclarationResponseSchema,
	getFrequencyFromEffluentCodeResponseSchema,
	getGraphicCropPlanListResponseSchema,
	getHousingTypeResponseSchema,
	getNoSpreadingPeriod,
	getNoSpreadingPeriodListResponseSchema,
	getNoSpreadingPeriodResponseSchema,
	getPlotLandListResponseSchema,
	getPlotLandResponseSchema,
	getPrecessionResponseSchema,
	getPreviousManureModelSchema,
	getSpecieResponseSchema,
	getTypologyListResponseSchema,
	LandUseListFromCodeResponseSchema,
	LandUseListResponseSchema,
	MunicipalityListFromCodeResponseSchema,
	MunicipalityListResponseSchema,
	MunicipalityListWithFertSpreadingResponseSchema,
	PrintHistoryResponseSchema,
	SaveCadastralParticelResponseSchema,
	SaveDeclarationsSchema,
	SaveDeclarationYearResponseSchema,
	SaveFertSpreadingDeclarationResponseSchema,
	SaveGraphicCropPlanResponseSchema,
	savePlotLandRequestResponseSchema,
	type AttachmentListResponse,
	type AttachmentTypeResponse,
	type BalanceIndicesRequest,
	type DeclarationListResponse,
	type editPlotLandRequestResponse,
	type EffluentListFromCodeResponse,
	type EffluentListResponse,
	type getAnimalConsistencyListResponse,
	type getAnimalConsistencyResponse,
	type getBalanceIndicesListResponse,
	type getCadastralParticelResponse,
	type getCategoryFromSpecieResponse,
	type getCategoryResponse,
	type getCropPlanListResponse,
	type getCropPlanVersionListResponse,
	type getCycleResponse,
	type getDeclarationListFromCropPlanResponse,
	type getDistributedNeedsResponse,
	type getFrequencyFromEffluentCodeResponse,
	type getGraphicCropPlanResponse,
	type getHousingTypeFromCategoryResponse,
	type getHousingTypeResponse,
	type getMasListFromLandUseCodeResponse,
	type getNoSpreadingPeriodListResponse,
	type getNoSpreadingPeriodResponse,
	type getNoSpreadingPeriodStoreResponse,
	type getPlotLandListResponse,
	type getPlotLandResponse,
	type getPrecessionResponse,
	type getPreviousManureResponse,
	type getSpecieResponse,
	type getTypologyResponse,
	type LandUseListFromCodeResponse,
	type LandUseListResponse,
	type MunicipalityListFromCodeResponse,
	type MunicipalityListResponse,
	type MunicipalityListWithFertSpreadingResponse,
	type PrintHistoryResponseModel,
	type SaveAttachmentModel,
	type SaveCadastralParticelModel,
	type SaveCadastralParticelResponse,
	type SaveDeclarationsModel,
	type SaveDeclarationYearResponse,
	type SaveFertSpreadingDeclarationRequest,
	type SaveFertSpreadingDeclarationResponse,
	type SaveGraphicCropPlanModel,
	type SaveGraphicCropPlanResponse,
	type saveNoSpreadingPeriodResponse,
	type savePlotLandRequestResponse,
	type savePreviousManureResponse,
} from "@/models/applicationForms";
import { removeNullsOrBlanksFromObject } from "@/models/utils";
import {
	type HttpJsonResult,
	type HttpResult,
	type RequestConfig,
} from "@abaco/safe-rest/src/HTTPClient";

import type { IFilterChemicalAndOrganicaFertilizer } from "@/components/ChemicalAndOrganicFertilizer/ChemicalAndOrganicFertilizer.vue";
import {
	partyRegistryResponseSchema,
	type partyRegistryResponse,
} from "@/models/unificataForms";
import { httpPlus as http } from "./http";

export const getAttachmentList = async (
	nextKey: string | undefined | null,
	attachmentGroup: string
): Promise<HttpJsonResult<AttachmentListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		AttachmentListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachments/groups/${attachmentGroup}`,
		requestConfig
	);
};
export const addAttachment = async (
	newAttachmentObj: SaveAttachmentModel,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	const form = new FormData();

	form.append(
		"file",
		new Blob([newAttachmentObj.file]),
		newAttachmentObj.file.name
	);
	form.append(
		"payload",
		JSON.stringify({
			notes: newAttachmentObj.notes,
			typeCode: newAttachmentObj.typeCode,
			groupCode: newAttachmentObj.groupCode,
		})
	);

	return http.post(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachments`,
		form,
		requestConfig
	);
};
export const editAttachment = async (
	attachmentId: string,
	editAttachmentObj: SaveAttachmentModel,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.headers = {
		"Content-Type": "application/json",
	};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return http.patch(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`,
		JSON.stringify(editAttachmentObj),
		requestConfig
	);
};
export const deleteAttachment = async (
	attachmentId: string,
	compileStatusIdentifier: string
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
	};

	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`,
		requestConfig
	);
};
export const getAttachmentTypeList = async (
	nextKey?: string | undefined | null
): Promise<HttpJsonResult<AttachmentTypeResponse>> => {
	const attachmentGroupInitStatic = "PUA_ATTACHMENTS";

	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		nextKey: nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.getJson(
		AttachmentTypeResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachment-types/${attachmentGroupInitStatic}`,
		requestConfig
	);
};
export const downloadAttachment = async (
	attachmentId: string
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
): Promise<any> => {
	return http.get(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/attachments/${attachmentId}`
	);
};

export const getDeclarationList = async (
	documentCode: string
): Promise<HttpJsonResult<DeclarationListResponse>> => {
	return http.getJson(
		DeclarationListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations/${documentCode}`
	);
};

export const saveDeclarations = async (
	document_code: string,
	declarations: SaveDeclarationsModel,
	compileStatusIdentifier: string,
	isDeclaration: boolean
): Promise<HttpJsonResult<SaveDeclarationsModel>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		compileStatusIdentifier,
		compileStatus: "COMPLETED",
	};

	if (!isDeclaration) {
		requestConfig.params.isDeclaration = isDeclaration;
	}

	removeNullsOrBlanksFromObject(requestConfig.params);
	return http.postJson(
		SaveDeclarationsSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations/${document_code}`,
		declarations,
		requestConfig
	);
};

export const loadMunicipalityListFromCode = async (
	municipalityCodeList: string[]
): Promise<HttpJsonResult<MunicipalityListFromCodeResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		include_geometries: false,
	};
	return http.postJson(
		MunicipalityListFromCodeResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/sectors`,
		{ codes: municipalityCodeList },
		requestConfig
	);
};
export const getMunicipalityList = async (
	filter: string
): Promise<HttpJsonResult<MunicipalityListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		domainZones: "comuni",
		include_geometries: false,
		filter,
	};

	return http.getJson(
		MunicipalityListResponseSchema,
		`/lpis-server-api/{TENANT}/api-priv/v1/lpis/sectors`,
		requestConfig
	);
};
export const getMunicipalityListWithFertSpreading = async (
	pointInTime: string,
	cropPlanId: number,
	businessId: number,
	nextKey: string | null | undefined
): Promise<HttpJsonResult<MunicipalityListWithFertSpreadingResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		filterByBusiness: true,
		pointInTime,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		MunicipalityListWithFertSpreadingResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/domains/${businessId}/plans/${cropPlanId}/zones`,
		requestConfig
	);
};
export const loadLandUseListFromCode = async (
	landUseCodeList: string[]
): Promise<HttpJsonResult<LandUseListFromCodeResponse>> => {
	return http.postJson(
		LandUseListFromCodeResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/support/landuses-codes`,
		{ landuse_codes: landUseCodeList }
	);
};
export const getLandUseChoiceList = async (
	filter: string
): Promise<HttpJsonResult<LandUseListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		filter,
	};
	return http.getJson(
		LandUseListResponseSchema,
		`/lpis-server-api/{TENANT}/public/v1/lpis/support/landuses-codes`,
		requestConfig
	);
};
export const saveGraphicCropPlan = async (
	graphicCropPlan: SaveGraphicCropPlanModel
): Promise<HttpJsonResult<SaveGraphicCropPlanResponse>> => {
	return http.postJson(
		SaveGraphicCropPlanResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-sectors`,
		graphicCropPlan
	);
};
export const editGraphicCropPlan = async (
	graphicCropPlan: SaveGraphicCropPlanModel,
	graphicCropPlanId: number
): Promise<HttpJsonResult<SaveGraphicCropPlanResponse>> => {
	return http.putJson(
		SaveGraphicCropPlanResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-sector/${graphicCropPlanId}`,
		graphicCropPlan
	);
};
export const getMasFromLandUseCode = async (
	cropCode: string
): Promise<HttpJsonResult<getMasListFromLandUseCodeResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cropCode,
	};
	return http.getJson(
		getTypologyListResponseSchema,
		`/banche-dati/{TENANT}/public/v1/nitrogen/max-to-add-by-crop`,
		requestConfig
	);
};
export const deleteGraphicCropPlan = async (
	graphicCropPlanId: number
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};

	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-sector/${graphicCropPlanId}`,
		requestConfig
	);
};
export const deleteAllGraphicCropPlanList = async (): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};

	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-sector`,
		requestConfig
	);
};
export const getGraphicCropPlanList = async (): Promise<
	HttpJsonResult<getGraphicCropPlanResponse[]>
> => {
	return http.getJson(
		getGraphicCropPlanListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-sectors`
	);
};
export const getGraphicCropPlanListFilter = async (
	getChemicalFertilizerFilterObject: IFilterChemicalAndOrganicaFertilizer,
	nextKey: undefined | number
): Promise<HttpJsonResult<getGraphicCropPlanResponse[]>> => {
	const requestConfig: RequestConfig = {};
	const { sectorCode: sectorCode, landUseCode: landUseCode } =
		getChemicalFertilizerFilterObject;
	requestConfig.params = {
		sectorCode,
		landUseCode,
		nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getGraphicCropPlanListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-sectors`,
		requestConfig
	);
};

export const importGraphicCropPlanList = async (
	campaignYear: number
): Promise<HttpJsonResult<getGraphicCropPlanResponse[]>> => {
	return http.getJson(
		getGraphicCropPlanListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-sectors/${campaignYear}/import`
	);
};

export const getDeclarationYear = async (): Promise<
	HttpJsonResult<SaveDeclarationYearResponse>
> => {
	return http.getJson(
		SaveDeclarationYearResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/tipologia-dichiarazione`
	);
};
export const saveDeclarationYear = async (
	declarationsYear: SaveDeclarationYearResponse
): Promise<HttpJsonResult<SaveDeclarationYearResponse>> => {
	return http.postJson(
		SaveDeclarationYearResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/tipologie-dichiarazione`,
		declarationsYear
	);
};
export const editDeclarationYear = async (
	declarationYear: SaveDeclarationYearResponse
): Promise<HttpJsonResult<SaveDeclarationYearResponse>> => {
	return http.putJson(
		SaveDeclarationYearResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/tipologia-dichiarazione`,
		declarationYear
	);
};

export const getCadastralParticelList = async (): Promise<
	HttpJsonResult<getCadastralParticelResponse[]>
> => {
	return http.getJson(
		getAllCadastralParticelResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/five-year-declarations`
	);
};
export const getCadastralParticel = async (
	CadastralParcelId: string
): Promise<HttpJsonResult<SaveCadastralParticelResponse>> => {
	return http.getJson(
		SaveCadastralParticelResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/five-year-declaration/${CadastralParcelId}`
	);
};

export const editCadastralParcel = async (
	cadastralParcel: SaveCadastralParticelModel
): Promise<HttpJsonResult<SaveCadastralParticelResponse>> => {
	return http.putJson(
		SaveCadastralParticelResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/five-year-declaration/${cadastralParcel.id}`,
		cadastralParcel
	);
};
export const saveCadastralParticel = async (
	cadastralParticel: SaveCadastralParticelModel
): Promise<HttpJsonResult<SaveCadastralParticelResponse>> => {
	return http.postJson(
		SaveCadastralParticelResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/five-year-declaration`,
		cadastralParticel
	);
};
export const deleteCadastralParcel = async (
	cadastralId: number
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};

	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/five-year-declaration/${cadastralId}`,
		requestConfig
	);
};

export const getApplicationPrintHistory = async (): Promise<
	HttpJsonResult<PrintHistoryResponseModel>
> => {
	return http.getJson(
		PrintHistoryResponseSchema,
		`/applications/{TENANT}/api-priv/v1/applications/{APPLICATION_ID}/print-history`
	);
};

export const getFertSpreadingDeclarationList = async (): Promise<
	HttpJsonResult<SaveFertSpreadingDeclarationResponse[]>
> => {
	return http.getJson(
		getFertSpreadingDeclarationResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declarations`
	);
};
export const getFertSpreadingDeclaration = async (
	fertSpreadingDeclarationId: number
): Promise<HttpJsonResult<SaveFertSpreadingDeclarationResponse>> => {
	return http.getJson(
		SaveFertSpreadingDeclarationResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declaration/${fertSpreadingDeclarationId}`
	);
};
export const saveFertSpreadingDeclaration = async (
	fertSpreadingDeclaration: SaveFertSpreadingDeclarationRequest,
	campaignYear: number
): Promise<HttpJsonResult<SaveFertSpreadingDeclarationResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		campaignYear,
	};

	return http.postJson(
		SaveFertSpreadingDeclarationResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declaration`,
		fertSpreadingDeclaration,
		requestConfig
	);
};
export const editFertSpreadingDeclaration = async (
	fertSpreadingDeclaration: SaveFertSpreadingDeclarationRequest,
	fertSpreadingDeclarationId: number,
	campaignYear: number
): Promise<HttpJsonResult<SaveFertSpreadingDeclarationResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		campaignYear,
	};
	return http.putJson(
		SaveFertSpreadingDeclarationResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declaration/${fertSpreadingDeclarationId}`,
		fertSpreadingDeclaration,
		requestConfig
	);
};
export const deleteFertSpreadingDeclaration = async (
	fertSpreadingDeclarationId: number
): Promise<HttpResult> => {
	const requestConfig: RequestConfig = {};

	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/fert-spreading-declaration/${fertSpreadingDeclarationId}`,
		requestConfig
	);
};
export const getEffluentList = async (
	filterOnceWithFrequency: boolean
): Promise<HttpJsonResult<EffluentListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		filterOnceWithFrequency,
	};

	return http.getJson(
		EffluentListResponseSchema,
		`/banche-dati/{TENANT}/public/v1/effluents`,
		requestConfig
	);
};
export const getPrecession = async (): Promise<
	HttpJsonResult<getPrecessionResponse[]>
> => {
	const requestConfig: RequestConfig = {};

	return http.getJson(
		getPrecessionResponseSchema,
		`/banche-dati/{TENANT}/public/v1/preceding-crops/types`,
		requestConfig
	);
};
export const getTypology = async (
	landUseCode: string
): Promise<HttpJsonResult<getTypologyResponse[]>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cropCode: landUseCode,
	};

	return http.getJson(
		getTypologyListResponseSchema,
		`/banche-dati/{TENANT}/public/v1/nitrogen/product-types-by-crop`,
		requestConfig
	);
};
export const getTypologyFromLandUseCodeList = async (
	landUseCode: string[]
): Promise<HttpJsonResult<getTypologyResponse[]>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {};

	return http.postJson(
		getTypologyListResponseSchema,
		`/banche-dati/{TENANT}/public/v1/nitrogen/product-types-by-crop`,
		landUseCode,
		requestConfig
	);
};
export const getCycle = async (): Promise<
	HttpJsonResult<getCycleResponse[]>
> => {
	const requestConfig: RequestConfig = {};

	return http.getJson(
		getCycleResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/cycle-types`,
		requestConfig
	);
};
export const getEffluentListFromCode = async (
	codes: string[]
): Promise<HttpJsonResult<EffluentListFromCodeResponse>> => {
	return http.postJson(
		EffluentListFromCodeResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/effluents/search/type-codes`,
		{ codes }
	);
};
export const getCropPlanList = async (
	businessId: number
): Promise<HttpJsonResult<getCropPlanListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cropPlanTypeCode: "CROPPLAN",
	};
	return http.getJson(
		getCropPlanListResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans`,
		requestConfig
	);
};
export const getCropPlanVersionList = async (
	businessId: number,
	cropPlanId: number
): Promise<HttpJsonResult<getCropPlanVersionListResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cropPlanTypeCode: "CROPPLAN",
	};
	return http.getJson(
		getCropPlanVersionListResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans/${cropPlanId}/versions`,
		requestConfig
	);
};

export const getBalanceIndicesList = async (
	requestBody: BalanceIndicesRequest
): Promise<HttpJsonResult<getBalanceIndicesListResponse>> => {
	const requestConfig: RequestConfig = {};
	return http.postJson(
		getBalanceIndicesListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/balance-indicates`,
		requestBody,
		requestConfig
	);
};

export const loadPartiesV2 = async (
	cuaa?: string | boolean | null,
	partyDesc?: string | boolean | null,
	nextKey?: string | null
): Promise<HttpJsonResult<partyRegistryResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		hasCode: true,
		nextKey,
	};

	if (cuaa && typeof cuaa == "string") {
		cuaa = cuaa.replace(/-/g, "");
		requestConfig.params.code = cuaa;
	} else if (partyDesc && typeof partyDesc == "string") {
		requestConfig.params.fullName = partyDesc;
	}

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		partyRegistryResponseSchema,
		"/party-registry/{TENANT}/public/v1/parties/",
		requestConfig
	);
};

export const getDeclarationListFromCropPlan = async (
	businessId: number,
	cropPlanId: number,
	version: string,
	pointInTime: string,
	pointInTimeTo: string,
	nextKey: string | null | undefined
): Promise<HttpJsonResult<getDeclarationListFromCropPlanResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		pointInTime,
		pointInTimeTo,
		version,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getDeclarationListFromCropPlanResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans/${cropPlanId}/declarations`,
		requestConfig
	);
};
export const getPlotListWithFertSpreading = async (
	nextKey: string | undefined | null,
	businessId: number,
	cropPlanId: number,
	version: string,
	pointInTime: string,
	pointInTimeTo: string,
	domainZoneCode: string,
	search: string
): Promise<HttpJsonResult<getDeclarationListFromCropPlanResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		pointInTime,
		pointInTimeTo,
		version,
		search,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getDeclarationListFromCropPlanResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans/${cropPlanId}/domains/${domainZoneCode}/declarations`,
		requestConfig
	);
};
export const getPlotList = async (
	nextKey: string | undefined | null,
	businessId: number,
	cropPlanId: number,
	version: string,
	pointInTime: string,
	pointInTimeTo: string,
	search: string
): Promise<HttpJsonResult<getDeclarationListFromCropPlanResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		pointInTime,
		pointInTimeTo,
		version,
		search,
		nextKey,
	};

	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getDeclarationListFromCropPlanResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans/${cropPlanId}/declarations`,
		requestConfig
	);
};
export const getPlotListFormCode = async (
	businessId: number,
	cropPlanId: number,
	version: string,
	pointInTime: string,
	pointInTimeTo: string,
	nextKey: string | null | undefined
): Promise<HttpJsonResult<getDeclarationListFromCropPlanResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		pointInTime,
		pointInTimeTo,
		version,
		nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getDeclarationListFromCropPlanResponseSchema,
		`/crop-plan-api/{TENANT}/public/v1/crop-plans/${businessId}/plans/${cropPlanId}/declarations`,
		requestConfig
	);
};

export const getPlotsLandListAndPreviousManure = async (): Promise<
	HttpJsonResult<getPlotLandListResponse>
> => {
	return http.getJson(
		getPlotLandListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops`
	);
};
export const getPlotsLandListFilter = async (
	plotLandFilterObject: IFilterChemicalAndOrganicaFertilizer,
	nextKey: undefined | number
): Promise<HttpJsonResult<getPlotLandListResponse>> => {
	const requestConfig: RequestConfig = {};
	const { sectorCode: sectorCode, landUseCode: landUseCode } =
		plotLandFilterObject;
	requestConfig.params = {
		sectorCode,
		landUseCode,
		nextKey,
	};
	removeNullsOrBlanksFromObject(requestConfig.params);

	return http.getJson(
		getPlotLandListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops`,
		requestConfig
	);
};
export const getFrequencyFromEffluentCode = async (
	effluentCode: string
): Promise<HttpJsonResult<getFrequencyFromEffluentCodeResponse>> => {
	return http.getJson(
		getFrequencyFromEffluentCodeResponseSchema,
		`/banche-dati/{TENANT}/public/v1/effluents/${effluentCode}/frequencies`
	);
};

export const getFrequencyFromEffluentCodeList = async (
	effluentCodes: string[]
): Promise<HttpJsonResult<getFrequencyFromEffluentCodeResponse>> => {
	return http.postJson(
		getFrequencyFromEffluentCodeResponseSchema,
		`/banche-dati/{TENANT}/public/v1/effluents/frequencies`,
		{ effluentCodes }
	);
};
export const getPlotsLand = async (
	plotLandId: number
): Promise<HttpJsonResult<getPlotLandResponse>> => {
	return http.getJson(
		getPlotLandResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-crop/${plotLandId}`
	);
};
export const savePlotLand = async (
	plotLand: savePlotLandRequestResponse
): Promise<HttpJsonResult<savePlotLandRequestResponse>> => {
	return http.postJson(
		savePlotLandRequestResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-crop`,
		plotLand
	);
};

export const editMassivePlotLand = async (
	plotLand: editPlotLandRequestResponse
): Promise<HttpJsonResult<getPlotLandListResponse>> => {
	return http.putJson(
		getPlotLandListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crop`,
		plotLand
	);
};
export const editPlotLand = async (
	plotLandId: number,
	plotLand: editPlotLandRequestResponse
): Promise<HttpJsonResult<getPlotLandResponse>> => {
	return http.putJson(
		getPlotLandResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-crop/${plotLandId}`,
		plotLand
	);
};

export const getDistributedNeeds = async (
	cropCode: string,
	chiaveAppezzamento: string,
	tipologiaCod: number,
	resa: number,
	precessioneCod: number,
	nFertilizzazioniPrecedenti: string
): Promise<HttpJsonResult<getDistributedNeedsResponse>> => {
	const requestConfig: RequestConfig = {};
	requestConfig.params = {
		cropCode,
		chiaveAppezzamento,
		tipologiaCod,
		resa,
		precessioneCod,
		nFertilizzazioniPrecedenti,
	};

	return http.getJson(
		getDistributedNeedsResponseSchema,
		`/banche-dati/{TENANT}/public/v1/nitrogen/calculate-fabbisogno`,
		requestConfig
	);
};

export const importPlotsLandList = async (
	campaignYear: number
): Promise<HttpJsonResult<getPlotLandListResponse>> => {
	return http.getJson(
		getPlotLandListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops/${campaignYear}/import`
	);
};

export const deleteAllPlotsLandList = async (): Promise<HttpResult> => {
	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-crop`
	);
};

export const deletePlotLand = async (
	plotLandId: number
): Promise<HttpResult> => {
	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declaration-on-crop/${plotLandId}`
	);
};

export const editPreviousManure = async (
	previousManure: savePreviousManureResponse
): Promise<HttpJsonResult<getPreviousManureResponse>> => {
	return http.putJson(
		getPreviousManureModelSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-prev-effluent/${previousManure.id}`,
		previousManure
	);
};

export const savePreviousManure = async (
	previousManure: savePreviousManureResponse
): Promise<HttpJsonResult<getPreviousManureResponse>> => {
	return http.postJson(
		getPreviousManureModelSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-prev-effluent`,
		previousManure
	);
};

export const deletePreviousManure = async (
	previousManureId: number
): Promise<HttpResult> => {
	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-prev-effluent/${previousManureId}`
	);
};

export const getAnimalConsistencyList = async (): Promise<
	HttpJsonResult<getAnimalConsistencyListResponse>
> => {
	return http.getJson(
		getAnimalConsistencyListModelSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-livestock-consist`
	);
};

export const getSpecieList = async (): Promise<
	HttpJsonResult<getSpecieResponse[]>
> => {
	return http.getJson(
		getSpecieResponseSchema,
		`/banche-dati/{TENANT}/public/v1/animals/species`
	);
};

export const getCategoryList = async (
	specieCode: string,
	genreCode: string
): Promise<HttpJsonResult<getCategoryResponse[]>> => {
	return http.getJson(
		getCategoryResponseSchema,
		`/banche-dati/{TENANT}/public/v1/animals/species/${genreCode}/${specieCode}/categories`
	);
};
export const getCategoryListFromCode = async (
	codes: getCategoryFromSpecieResponse[]
): Promise<HttpJsonResult<getCategoryResponse[]>> => {
	return http.postJson(
		getCategoryResponseSchema,
		`/banche-dati/{TENANT}/public/v1/animals/species/categories`,
		codes
	);
};
export const getHousingTypeList = async (
	specieCode: string,
	genreCode: string,
	categoryCode: string,
	productionCode: string
): Promise<HttpJsonResult<getHousingTypeResponse[]>> => {
	return http.getJson(
		getHousingTypeResponseSchema,
		`/banche-dati/{TENANT}/public/v1/animals/species/${genreCode}/${specieCode}/${categoryCode}/${productionCode}/housing`
	);
};

export const getHousingTypeListFromCode = async (
	codes: getHousingTypeFromCategoryResponse[]
): Promise<HttpJsonResult<getHousingTypeResponse[]>> => {
	return http.postJson(
		getHousingTypeResponseSchema,
		`/banche-dati/{TENANT}/public/v1/animals/species/housing`,
		codes
	);
};

export const editAnimalConsistency = async (
	previousManure: getAnimalConsistencyResponse
): Promise<HttpJsonResult<getAnimalConsistencyResponse>> => {
	return http.putJson(
		getAnimalConsistencyModelSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-livestock-consist/${previousManure?.id}`,
		previousManure
	);
};

export const saveAnimalConsistency = async (
	previousManure: getAnimalConsistencyResponse
): Promise<HttpJsonResult<getAnimalConsistencyResponse>> => {
	return http.postJson(
		getAnimalConsistencyModelSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-livestock-consist`,
		previousManure
	);
};

export const deleteAnimalConsistency = async (
	previousManureId: number
): Promise<HttpResult> => {
	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/declarations-on-crops-livestock-consist/${previousManureId}`
	);
};

export const getNoSpreadingPeriodList = async (): Promise<
	HttpJsonResult<getNoSpreadingPeriodListResponse>
> => {
	return http.getJson(
		getNoSpreadingPeriodListResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/no-spreading-periods`
	);
};

export const saveNoSpreadingPeriod = async (
	noSpreadingPeriod: saveNoSpreadingPeriodResponse
): Promise<HttpJsonResult<getNoSpreadingPeriodStoreResponse>> => {
	return http.postJson(
		getNoSpreadingPeriodResponseSchema,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/no-spreading-periods`,
		noSpreadingPeriod
	);
};

export const editNoSpreadingPeriod = async (
	noSpreadingPeriod: saveNoSpreadingPeriodResponse
): Promise<HttpJsonResult<getNoSpreadingPeriodResponse>> => {
	return http.putJson(
		getNoSpreadingPeriod,
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/no-spreading-periods/${noSpreadingPeriod.pkId}`,
		noSpreadingPeriod
	);
};

export const deleteNoSpreadingPeriod = async (
	noSpreadingPeriodListId: number
): Promise<HttpResult> => {
	return await http.delete(
		`/pua-application-forms/{TENANT}/v1/applications/{APPLICATION_ID}/no-spreading-periods/${noSpreadingPeriodListId}`
	);
};
