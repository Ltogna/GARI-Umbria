import {
	ErrorType,
	HTTPClient,
	type HttpJsonResult,
} from "@abaco/safe-rest/src/HTTPClient";
import { z } from "zod";
import { storeAuth } from "@abaco/safe-rest/src/sso2";

const LoginResponseSchema = z.object({
	user_id: z.string(),
	isParentUser: z.boolean(),
	auth_token: z.string(),
	username: z.string(),
	tenant: z.string(),
	refresh_token: z.string(),
	description: z.string(),
	locale: z.string(),
	dateFormat: z.string(),
	warnings: z.array(z.string()),
	errors: z.array(z.string()),
});
export type LoginResponse = z.infer<typeof LoginResponseSchema>;

export interface LoginData {
	tenant: string;
	username: string;
	password: string;
}

export async function login(
	data: LoginData
): Promise<HttpJsonResult<LoginResponse>> {
	const { tenant, username, password } = data;
	const res = await new HTTPClient().postJson(
		LoginResponseSchema,
		`/sso2/${tenant}/public/v1/login`,
		{
			username,
			password,
		}
	);

	if (res.errorType !== ErrorType.NONE) {
		return res;
	}

	const auth = {
		authToken: res.data.auth_token,
		authTokenExpiresAt: Date.now() + 60_000 * 4, // assume 4 mins.
		refreshToken: res.data.refresh_token,
		user: {
			user_id: res.data.user_id,
			username: res.data.username,
			tenant: res.data.tenant,
			description: res.data.description,
			locale: res.data.locale,
			dateFormat: res.data.dateFormat,
			isParentUser: res.data.isParentUser,
		},
	};

	storeAuth(auth);

	return res;
}
