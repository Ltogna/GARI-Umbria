# application-forms-ui

## Getting started

To make it easy for you to get started with GitLab, here's a list of recommended next steps.

Already a pro? Just edit this README.md and make it your own. Want to make it
easy? [Use the template at the bottom](#editing-this-readme)!

## Add your files

- [ ] [Create](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file)
      or [upload](https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line)
      or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.fe.abacogroup.eu/new-agri/application-forms-ui.git
git branch -M master
git push -uf origin master
```

## Integrate with your tools

- [ ] [Set up project integrations](https://gitlab.fe.abacogroup.eu/new-agri/application-forms-ui/-/settings/integrations)

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Automatically merge when pipeline succeeds](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

## Test and Deploy

Use the built-in continuous integration in GitLab.

- [ ] [Get started with GitLab CI/CD](https://docs.gitlab.com/ee/ci/quick_start/index.html)
- [ ] [Analyze your code for known vulnerabilities with Static Application Security Testing(SAST)](https://docs.gitlab.com/ee/user/application_security/sast/)
- [ ] [Deploy to Kubernetes, Amazon EC2, or Amazon ECS using Auto Deploy](https://docs.gitlab.com/ee/topics/autodevops/requirements.html)
- [ ] [Use pull-based deployments for improved Kubernetes management](https://docs.gitlab.com/ee/user/clusters/agent/)
- [ ] [Set up protected environments](https://docs.gitlab.com/ee/ci/environments/protected_environments.html)

---

# Editing this README

When you're ready to make this README your own, just edit this file and use the handy template below (or feel free to
structure it however you want - this is just a starting point!). Thank you
to [makeareadme.com](https://www.makeareadme.com/) for this template.

## Suggestions for a good README

Every project is different, so consider which of these sections apply to yours. The sections used in the template are
suggestions for most open source projects. Also keep in mind that while a README can be too long and detailed, too long
is better than too short. If you think your README is too long, consider utilizing another form of documentation rather
than cutting out information.

## Name

Choose a self-explaining name for your project.

## Description

Let people know what your project can do specifically. Provide context and add a link to any reference visitors might be
unfamiliar with. A list of Features or a Background subsection can also be added here. If there are alternatives to your
project, this is a good place to list differentiating factors.

## Badges

On some READMEs, you may see small images that convey metadata, such as whether or not all the tests are passing for the
project. You can use Shields to add some to your README. Many services also have instructions for adding a badge.

## Visuals

Depending on what you are making, it can be a good idea to include screenshots or even a video (you'll frequently see
GIFs rather than actual videos). Tools like ttygif can help, but check out Asciinema for a more sophisticated method.

## Installation

Within a particular ecosystem, there may be a common way of installing things, such as using Yarn, NuGet, or Homebrew.
However, consider the possibility that whoever is reading your README is a novice and would like more guidance. Listing
specific steps helps remove ambiguity and gets people to using your project as quickly as possible. If it only runs in a
specific context like a particular programming language version or operating system or has dependencies that have to be
installed manually, also add a Requirements subsection.

## Usage

Use examples liberally, and show the expected output if you can. It's helpful to have inline the smallest example of
usage that you can demonstrate, while providing links to more sophisticated examples if they are too long to reasonably
include in the README.

## Support

Tell people where they can go to for help. It can be any combination of an issue tracker, a chat room, an email address,
etc.

## Roadmap

If you have ideas for releases in the future, it is a good idea to list them in the README.

## Contributing

State if you are open to contributions and what your requirements are for accepting them.

For people who want to make changes to your project, it's helpful to have some documentation on how to get started.
Perhaps there is a script that they should run or some environment variables that they need to set. Make these steps
explicit. These instructions could also be useful to your future self.

You can also document commands to lint the code or run tests. These steps help to ensure high code quality and reduce
the likelihood that the changes inadvertently break something. Having instructions for running tests is especially
helpful if it requires external setup, such as starting a Selenium server for testing in a browser.

## Authors and acknowledgment

Show your appreciation to those who have contributed to the project.

## License

For open source projects, say how it is licensed.

## Project status

If you have run out of energy or time for your project, put a note at the top of the README saying that development has
slowed down or stopped completely. Someone may choose to fork your project or volunteer to step in as a maintainer or
owner, allowing your project to keep going. You can also make an explicit request for maintainers.

## fasi del deploy con pipeline

## 1 pua-app-forms-ui deploy

1. mettini nel branch develop.
2. apri un terminale e usa `npm version patch` (crea un nuovo commit con la versione aggiornata aggiunta nella descrizione del commit).
3. effettua il pusha sul branch.
4. push su master (nel nostro caso, il merge di develop su master) fa partire la pipeline.
5. **stellina verde sul progetto da interfaccia gitlab** accanto all'id del commit (pua-app-forms-ui), evita di lanciarlo se non vedi la stellina verde che indica che le pipeline sono terminate con successo
6. crea un nuovo tag di pua-app-forms-ui il valore del tag deve essere allineato al commit della versione che cambia del package.json
7. creando il tag di pua parte la pipeline.

## 2 umbria-gari > deployment deploy

1. vai su umbria-gari > deployment e apri il file chart.yaml.
2. aggiorna le versioni con quelle dei tag dei progetti che hai aggiornato effettual il commit e push dei cambiamenti su master.
3. attendi che la pipeline dei progetti dipendenti sia terminata con successo.
4. crea un nuovo tag e aspetta che la pipeline termini.

## fasi k9s in locale da rancher

1. avvia powershell con i permessi di amministrazione e lancia il comando: Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
2. choco install k9s
3. log in rancher and downlaod file, (la terza icona in alto a destra partendo dall'icona di upload file )
4. crea una cartella .kube sottoil path: C:users/salva(il tuo tuo username)
5. crea una cartella .kube
6. C:\Users\salva\.kube
   6.1) metti qui dentro il file scaricato da rancher e rinominanlo config.
   6.2) cancella il campo e il valore della chiave certificate-authority-data
7. connect vpn

8. apri una nuova finistra su powershell e lancia il coamdno k9s, al caricamento premi shift + . ;
9. ns (shortcut for namespace) e poi enter:
10. partiranno tutti i container e k9s sara pronto
11. apri il cmd di windows e lancia il comando: curl -X POST -d "logger=com.abacogroup&level=DEBUG" localhost:8081/tasks/log-level,

# lanciare i log di application in locale

1. apri il cmd di windows e lancia il comando: curl -X POST -d "logger=com.abacogroup&level=DEBUG" localhost:8081/tasks/log-level,
2. apri k9s in locale > premi shift + : > ns,
   2.2) scegli name : umbria-dev (l'ultimo), scegli il terzo( vai in application) > shift+f > cambia la porta locale se gia in uso.
   2.3) prendi i log da kubernatis dentro application > invio > seleziona il portForward e premi invio.

# lanciare i log di application in locale

3. vai su rancher
4. premi dev sulla sinistra
5. premi worklaods > deployments, filtro per appli > nameSpace: umbrai-dev > application
6. vai su pod > i tre puntini sul container > view logs > cerca DEBUG, i log sono filtrabili( filtro sulla destra).

# deploy workflow( esempio pua workflow):

1. pull di develop
2. apri git e crea un nuovo branch
3. mvn clean isntall -DskipTests (di project), i test potrebbero durare tanto quindi saltarli è meglio
4. su target si è creato pua-owrkflow-10-9.jar , copia il jar su git , dentro la cartella workflow,
   al solito dentro bundle gari applications, si prende l'ultimo si fa la cartella incrementata di 1, fai un controllo rispetto all'ultimo che la versione sia incrementata
5. incrementare la versione del pom
6. poi la merge request del branch creato


# installazione del progetto pua-app-forms-ui con il parent 
1. il parent del progetto è application-ui, per entrambi i progetti devi usare la versioni di node 20.11.1.
2. dopo aver settato la versione dovrai autenticarti su nexus.
3. effettua il npm i su entrambi i progetti.
4. aggiungi nel progetto figlio(pua-app-forms-ui) sotto la cartella public un file chiamato index.js.json che contiene:  
   ``` {   "path": "/ui/pua-app-forms/src/main.ts"   }``` . 
5. esegui il parent sulla porta 3000 e il progetto figlio sulla porta 3001, e apri una pagina del progetto figlio.
6.  i 2 comandi da poter aggiugnere per lanciare il progetto dal parent, mettili nel file package.json dentro l'oggetto script:  
   ```  "1MicroFrontEndManager": "vite --mode standalone --port 3000 ",```  
   ```  "2MicroFrontEndPua": "cd .. && cd pua-app-forms-ui && npx vite --port 3001",  ``` 

# verificare manualmente il file openapi.json di un servizio back-end

1. pull di develop prendi nel borwser il tuo ambiente (https://umbria-dev.fe.abacogroup.eu)
2. aggiungi la risorsa back (servizio-back-end/openapi.json),
3. esempio:
   https://umbria-dev.fe.abacogroup.eu/pua-application-forms/openapi.json (pua back-end)
   https://umbria-dev.fe.abacogroup.eu/crop-plan-api/openapi.json (cropPlanApi back-end)
4. prendi il json e mettilo dentro swuagger editor
5. verifica le api
