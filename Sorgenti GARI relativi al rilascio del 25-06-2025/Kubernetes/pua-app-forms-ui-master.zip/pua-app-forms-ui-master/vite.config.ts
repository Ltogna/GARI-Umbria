import { fileURLToPath, URL } from "url";

import vue from "@vitejs/plugin-vue";
import { defineConfig } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";
import vueDevTools from "vite-plugin-vue-devtools";
import { BASE } from "./src/constants";

// https://vitejs.dev/config/
export default defineConfig({
	base: BASE,
	plugins: [
		vue(),
		viteStaticCopy({
			targets: [
				{
					src: "node_modules/bootstrap-italia/dist/**/*",
					dest: "bootstrap-italia/dist",
				},
			],
		}),
		vueDevTools(),
	],
	css: {
		preprocessorOptions: {
			scss: {
				additionalData: `
				  @import "@/assets/scss/global.scss";
				`,
			},
		},
	},
	resolve: {
		alias: {
			"@": fileURLToPath(new URL("./src", import.meta.url)),
		},
	},
	build: {
		rollupOptions: {
			output: {
				entryFileNames: "[name].[hash].js",
				assetFileNames: "assets/[name].[hash].[ext]",
			},
		},
	},
	server: {
		port: 3000,
		proxy: {
			"/pua-application-forms": {
				target: "https://umbria-dev.fe.abacogroup.eu",
				// target: "http://localhost:8080",
				secure: false,
				changeOrigin: true,
			},
			"/crop-plan-api": {
				target: "https://umbria-dev.fe.abacogroup.eu/",
				secure: false,
				changeOrigin: true,
			},

			"/applications": {
				// target: "https://iacs-dev.fe.abacogroup.eu",
				target: "http://localhost:8080",
				secure: false,
				changeOrigin: true,
			},
			"/sso2": {
				target: "https://umbria-dev.fe.abacogroup.eu",
				// target: "https://iacs-dev.fe.abacogroup.eu",
				secure: false,
				changeOrigin: true,
			},
			"/lpis-server-api": {
				// target: "http://localhost:8080/",
				target: "https://umbria-dev.fe.abacogroup.eu/",
				// target: "https://iacs-dev.fe.abacogroup.eu/",
				// target: "https://farm-coll.avepa.it/",
				// target: "https://iacs-test.abacogroup.cloud/",
				changeOrigin: true,
				secure: false,
			},
			"/geoproxy": {
				target: "https://iacs-dev.fe.abacogroup.eu/",
				// target: "https://farm-coll.avepa.it/",
				// target: "https://iacs-test.abacogroup.cloud/",
				secure: false,
				changeOrigin: true,
			},
		},
	},
});
