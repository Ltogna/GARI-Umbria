## fasi del deploy con pipeline

## 1 pua-app-forms-ui deploy

1. use develop branch.
2. open terminal and use `npm version patch` (create new commit with new version in commit description).
3. performe push.
4. push in master (in our project, merge of develop in master) will trigger pipeline.
5. **green start in gitlab interface** near commit id (pua-app-forms-ui), avoid create tag if start is missing, it means pipeline job done successfully
6. create new tag in pua-app-forms-ui tag value must be align to commit version, and commit version must be align to package.json
7. create new tag will trigger pipeline.

## 2 umbria-gari > deployment deploy

1. go in umbria-gari > deployment and open file chart.yaml.
2. update your tag version in chart.yaml and commit and push changes in master.
3. wait pipeline of depency project will end..
4. create a new tag, will trigger a pipeline wait until pipeline end.
