package com.abacogroup.filestore.service.impl.fs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Duration;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.FileNotInStoreException;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.impl.fs.FSLayout.Type;

public class TemporaryFilesCleanerTest {
	private static final BucketId BUCKET_ID = new BucketId("_", "b");

	@Test
	public void whenInvoked_thenDeleteAlsoAliases(@TempDir File dir) throws IOException, InterruptedException, FileNotInStoreException {
		FSLayout fsLayout = new FSLayout(dir);
		FileSystemStore store = new FileSystemStore(fsLayout) {
			@Override
			protected Duration getTemporaryFilesCleanupInterval() {
				return Duration.ofSeconds(1);
			}
		};

		String alias = "theAlias";
		String aliasZero = "zero";
		StoredFile zero = loadFile(store, Duration.ofMillis(1), aliasZero);
		StoredFile one = loadFile(store, Duration.ofMillis(1));
		StoredFile two = loadFile(store, Duration.ofDays(1), alias);
		StoredFile three = loadFile(store, Duration.ofDays(1), alias);

		Thread.sleep(2_000);

		assertThrows(FileNotInStoreException.class, () -> store.getFile(BUCKET_ID, zero.getId()));
		assertThrows(FileNotInStoreException.class, () -> store.getFile(BUCKET_ID, aliasZero));
		assertThrows(FileNotInStoreException.class, () -> store.getFile(BUCKET_ID, one.getId()));

		StoredFile file = store.getFile(BUCKET_ID, two.getId());
		var bytes = readFileContent(store, file);
		assertThat(bytes.length).isEqualTo(UUID.randomUUID().toString().length());

		file = store.getFile(BUCKET_ID, three.getId());
		var bytesA = readFileContent(store, file);

		store.getFile(BUCKET_ID, alias);
		var bytesB = readFileContent(store, file);

		assertThat(bytesA.length).isEqualTo(UUID.randomUUID().toString().length());
		assertArrayEquals(bytesA, bytesB);
	}

	@Test
	public void whenInvoked_thenDeleteTempFiles(@TempDir File dir) throws IOException, InterruptedException {
		FSLayout fsLayout = new FSLayout(dir);
		FileSystemStore store = new FileSystemStore(fsLayout) {
			@Override
			protected Duration getTemporaryFilesCleanupInterval() {
				return Duration.ofSeconds(1);
			}
		};

		loadFile(store, Duration.ofMillis(1));
		StoredFile toPreserve = loadFile(store, Duration.ofHours(1));

		Thread.sleep(1_200);

		File tmpDir = fsLayout.getTenantBucket(BUCKET_ID, Type.TEMP_FILES_REGISTRY);
		assertNotNull(tmpDir);

		AtomicInteger cnt = new AtomicInteger(0);
		AtomicReference<String> fileName = new AtomicReference<>();

		walk(tmpDir, cnt, fileName);
		assertEquals(1, cnt.get());
		assertEquals(toPreserve.getId(), fileName.get());

		File filesDir = fsLayout.getTenantBucket(BUCKET_ID, Type.FILES);
		assertNotNull(filesDir);

		cnt.set(0);
		fileName.set(null);
		walk(filesDir, cnt, fileName);
		assertEquals(1, cnt.get());
		assertEquals(toPreserve.getId(), fileName.get());

		File contentDir = fsLayout.getTenantBucket(BUCKET_ID, Type.CONTENT);
		assertNotNull(contentDir);

		cnt.set(0);
		fileName.set(null);
		walk(contentDir, cnt, fileName);
		assertEquals(1, cnt.get());
		assertEquals(toPreserve.getContentId(), fileName.get());
	}

	private void walk(File tmpDir, AtomicInteger cnt, AtomicReference<String> fileName) throws IOException {
		Files.walkFileTree(tmpDir.toPath(), new SimpleFileVisitor<Path>() {
			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
				cnt.incrementAndGet();
				fileName.set(file.toFile().getName());
				return super.visitFile(file, attrs);
			}
		});
	}

	private byte[] readFileContent(FileSystemStore store, StoredFile file) throws IOException, FileNotInStoreException {
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			store.getFileContent(BUCKET_ID, file, out);
			return out.toByteArray();
		}
	}

	private StoredFile loadFile(FileSystemStore store, Duration deleteAfter, String alias) throws IOException {
		var uuid = UUID.randomUUID().toString();
		var meta = new FileMetadata(uuid, null, deleteAfter, alias);

		return store.addFile(BUCKET_ID, meta, new ByteArrayInputStream(uuid.getBytes()));
	}

	private StoredFile loadFile(FileSystemStore store, Duration deleteAfter) throws IOException {
		return loadFile(store, deleteAfter, null);
	}

}
