package com.abacogroup.filestore.service.impl.fs;

import java.io.IOException;
import java.io.InputStream;

public class OddInputStream extends InputStream {
	private final InputStream in;
	private int size = 7 * 1024;

	public OddInputStream(InputStream in) {
		this.in = in;
	}

	@Override
	public int read() throws IOException {
		return in.read();
	}

	@Override
	public int read(byte[] b) throws IOException {
		return read(b, 0, Math.min(b.length, size));
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		return super.read(b, off, Math.min(b.length, size));
	}

	@Override
	public void close() throws IOException {
		in.close();
	}

}
