package com.abacogroup.filestore.resource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.zip.GZIPInputStream;

import org.apache.commons.io.input.BoundedInputStream;
import org.apache.commons.io.output.NullOutputStream;
import org.glassfish.jersey.media.multipart.BodyPart;
import org.glassfish.jersey.media.multipart.ContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.MultiPart;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.test.grizzly.GrizzlyWebTestContainerFactory;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.api.AddFileResponse;
import com.abacogroup.filestore.api.FileMetadataResponse;
import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.impl.fs.FSLayout;
import com.abacogroup.filestore.service.impl.fs.FileSystemStore;
import com.abacogroup.filestore.service.impl.fs.IOUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.auth.AuthFilter;
import io.dropwizard.auth.AuthValueFactoryProvider;
import io.dropwizard.testing.junit5.DropwizardExtensionsSupport;
import io.dropwizard.testing.junit5.ResourceExtension;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@ExtendWith(DropwizardExtensionsSupport.class)
public class FileResourcesTest {
	private static final BucketId BUCKET = new BucketId("_", "test-rest");
	private static final String FILE_NAME = "test.csv";
	private static final String MIME_TYPE = "text/csv";

	private static final File dir = new File(System.getProperty("java.io.tmpdir"), UUID.randomUUID().toString());
	static {
		dir.mkdirs();
	}

	private static final ObjectMapper MAPPER = new ObjectMapper();
	static {
		MAPPER.findAndRegisterModules();
	}

	private static final FileSystemStore STORE = new FileSystemStore(new FSLayout(dir));
	private static final ResourceExtension EXT = ResourceExtension.builder()
			.setTestContainerFactory(new GrizzlyWebTestContainerFactory())
			// .setClientConfigurator(config -> {
			// config.register(GZipEncoder.class);
			// config.property(ClientProperties.USE_ENCODING, "gzip");
			// })
			.addProvider(MultiPartFeature.class)
			.addProvider(new MultitenantFilter("tenantId"))
			.addProvider(new AuthFilter<String, User>() {
				{
					authenticator = x -> Optional.of(new User("testUser", "_"));
				}

				@Override
				public void filter(ContainerRequestContext requestContext) throws IOException {
					authenticate(requestContext, "X", SecurityContext.BASIC_AUTH);
				}
			})
			.addProvider(new AuthValueFactoryProvider.Binder<>(User.class))
			.addResource(new FileResources(new FileUploader(STORE), STORE, MAPPER))
			.build();

	@AfterAll
	public static void cleanup() throws IOException {
		deleteDirectory(dir);
	}

	private static boolean deleteDirectory(File dir) {
		File[] allContents = dir.listFiles();
		if (allContents != null) {
			for (File file : allContents) {
				deleteDirectory(file);
			}
		}
		return dir.delete();
	}

	@Test
	public void whenDownloadingCompressedStoredFile_thenGetOriginalBytes() throws IOException, ParseException {
		StoredFile storedFile;
		long uncompressedFileSize;
		try (var in = BoundedInputStream.builder().setInputStream(getClass().getResourceAsStream("/test.csv.gz")).get()) {
			FileMetadata meta = new FileMetadata(FILE_NAME, MIME_TYPE);
			storedFile = STORE.addFile(BUCKET, meta, in);
			uncompressedFileSize = in.getCount();
		}

		Response response = EXT.target(BUCKET.getTenant())
				.path("/public/v1/files")
				.path(BUCKET.getName())
				.path(storedFile.getId())
				.request()
				.header(HttpHeaders.ACCEPT_ENCODING, "gzip")
				.get();

		assertEquals(200, response.getStatus());
		assertTrue(response.getHeaderString(HttpHeaders.CONTENT_ENCODING).indexOf("gzip") > -1);
		assertEquals(MIME_TYPE, response.getMediaType().toString());

		var cd = new ContentDisposition(response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION), true);
		assertEquals(FILE_NAME, cd.getFileName());

		try (var in = response.readEntity(InputStream.class); var out = new ByteArrayOutputStream()) {
			long written = IOUtils.stream2stream(in, out);
			assertTrue(uncompressedFileSize > out.size());

			written = IOUtils.stream2stream(new GZIPInputStream(new ByteArrayInputStream(out.toByteArray())), NullOutputStream.INSTANCE);
			assertEquals(uncompressedFileSize, written);
		}
	}

	@Test
	public void whenUploadingFileWithNonAsciiChars_thenSucceed() throws IOException {
		String fileName = "ტესტი ფაილის სახელი";
		try (var in = new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz"))) {
			var body = new BodyPart(MediaType.valueOf(MIME_TYPE))
					.contentDisposition(FormDataContentDisposition.name("file").fileName(fileName).build())
					.entity(in);

			try (var multipart = new MultiPart()) {
				multipart.bodyPart(body);

				Response response = EXT.target(BUCKET.getTenant())
						.path("/public/v1/files")
						.path(BUCKET.getName())
						.register(MultiPartFeature.class)
						.request()
						.post(Entity.entity(multipart, MediaType.MULTIPART_FORM_DATA));

				assertEquals(200, response.getStatus());

				var addedFile = response.readEntity(AddFileResponse.class);

				response = EXT.target(BUCKET.getTenant())
						.path("/public/v1/files")
						.path(BUCKET.getName())
						.path(addedFile.getId())
						.request()
						.header(HttpHeaders.ACCEPT_ENCODING, "gzip")
						.head();

				assertEquals(200, response.getStatus());
				String cd = response.getHeaders().get("Content-Disposition").get(0).toString();
				assertTrue(cd.contains("UTF-8''" + URLEncoder.encode(fileName, StandardCharsets.UTF_8)));
			}
		}
	}

	@Test
	public void whenUploadingFile_thenSucceed() throws IOException {
		try (var in = new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz"))) {
			var body = new BodyPart(MediaType.valueOf(MIME_TYPE))
					.contentDisposition(FormDataContentDisposition.name("file").fileName(FILE_NAME).build())
					.entity(in);

			try (var multipart = new MultiPart()) {
				multipart.bodyPart(body);

				Response response = EXT.target(BUCKET.getTenant())
						.path("/public/v1/files")
						.path(BUCKET.getName())
						.register(MultiPartFeature.class)
						.request()
						.post(Entity.entity(multipart, MediaType.MULTIPART_FORM_DATA));

				assertEquals(200, response.getStatus());

				var addedFile = response.readEntity(AddFileResponse.class);
				assertNotNull(addedFile.getId());
			}
		}
	}

	@Test
	public void whenUploadingTemporaryFile_thenSucceed() throws IOException {
		try (var in = new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz"))) {
			var body = new BodyPart(MediaType.valueOf(MIME_TYPE))
					.contentDisposition(FormDataContentDisposition.name("file").fileName(FILE_NAME).build())
					.entity(in);

			try (var multipart = new MultiPart()) {
				multipart.bodyPart(body);

				Response response = EXT.target(BUCKET.getTenant())
						.register(MultiPartFeature.class)
						.path("/public/v1/files")
						.path(BUCKET.getName())
						.queryParam("deleteAfterMins", 1)
						.request()
						.post(Entity.entity(multipart, MediaType.MULTIPART_FORM_DATA));

				assertEquals(200, response.getStatus());

				var addedFile = response.readEntity(AddFileResponse.class);
				assertNotNull(addedFile.getId());
			}
		}
	}

	@Test
	public void whenDownloadingFile_thenSucceed() throws IOException {
		var fileName = FILE_NAME + ".gz";
		var mimeType = "application/gzip";

		StoredFile storedFile;
		long size;
		try (var in = BoundedInputStream.builder().setInputStream(getClass().getResourceAsStream("/test.csv.gz")).get()) {
			FileMetadata meta = new FileMetadata(fileName, mimeType);
			storedFile = STORE.addFile(BUCKET, meta, in);
			size = in.getCount();
		}

		Response response = EXT.target(BUCKET.getTenant())
				.register(MultiPartFeature.class)
				.path("/public/v1/files")
				.path(BUCKET.getName())
				.path(storedFile.getId())
				.request()
				.get();

		assertEquals(200, response.getStatus());

		var disposition = response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION);
		assertEquals("attachment; filename=\"" + fileName + "\"; filename*=UTF-8''" + fileName, disposition);

		var contentType = response.getHeaderString(HttpHeaders.CONTENT_TYPE);
		assertEquals(mimeType, contentType);

		try (var in = response.readEntity(InputStream.class)) {
			var bytes = in.readAllBytes();
			assertEquals(size, bytes.length);
		}
	}

	@Test
	public void whenStreamFile_thenSucceed() throws IOException {
		var fileName = "hello.txt";
		var mimeType = "text/plain";

		ByteArrayInputStream in = new ByteArrayInputStream("Hello".getBytes());

		List<StoredFile> files = new LinkedList<>();
		FileMetadata meta = new FileMetadata(fileName, mimeType);
		for (int i = 0; i < 15; i++) {
			files.add(STORE.addFile(BUCKET, meta, in));
		}

		Response response = EXT.target(BUCKET.getTenant())
				.path("/public/v1/files")
				.path(BUCKET.getName())
				.request()
				.accept("application/jsonl")
				.get();

		assertEquals(200, response.getStatus());

		try (var reader = new BufferedReader(new InputStreamReader((response.readEntity(InputStream.class))))) {
			String line;
			while ((line = reader.readLine()) != null) {
				var fileMetadata = MAPPER.readValue(line, FileMetadataResponse.class);
				files.removeIf(file -> file.getId().equals(fileMetadata.getId()));
			}
		}

		assertEquals(0, files.size());
	}

	@Test
	public void whenStreamFileWithLimit_thenSucceed() throws IOException {
		var fileName = "hello.txt";
		var mimeType = "text/plain";

		ByteArrayInputStream in = new ByteArrayInputStream("Hello".getBytes());

		List<StoredFile> files = new LinkedList<>();
		FileMetadata meta = new FileMetadata(fileName, mimeType);
		for (int i = 0; i < 5; i++) {
			files.add(STORE.addFile(BUCKET, meta, in));
		}

		Response response = EXT.target(BUCKET.getTenant())
				.path("/public/v1/files")
				.path(BUCKET.getName())
				.queryParam("limit", "2")
				.request()
				.accept("application/jsonl")
				.get();

		assertEquals(200, response.getStatus());

		int cnt = 0;
		try (var reader = new BufferedReader(new InputStreamReader((response.readEntity(InputStream.class))))) {
			while (reader.readLine() != null) {
				cnt++;
			}
		}

		assertEquals(2, cnt);
	}

	@Test
	public void whenStreamFileWithNegativeLimit_thenSucceed() throws IOException {
		var fileName = "hello.txt";
		var mimeType = "text/plain";

		ByteArrayInputStream in = new ByteArrayInputStream("Hello".getBytes());

		List<StoredFile> files = new LinkedList<>();
		FileMetadata meta = new FileMetadata(fileName, mimeType);
		for (int i = 0; i < 5; i++) {
			files.add(STORE.addFile(BUCKET, meta, in));
		}

		Response response = EXT.target(BUCKET.getTenant())
				.path("/public/v1/files")
				.path(BUCKET.getName())
				.queryParam("limit", "-1")
				.request()
				.accept("application/jsonl")
				.get();

		assertEquals(200, response.getStatus());

		try (var reader = new BufferedReader(new InputStreamReader((response.readEntity(InputStream.class))))) {
			String line;
			while ((line = reader.readLine()) != null) {
				var fileMetadata = MAPPER.readValue(line, FileMetadataResponse.class);
				files.removeIf(file -> file.getId().equals(fileMetadata.getId()));
			}
		}

		assertEquals(0, files.size());
	}

}
