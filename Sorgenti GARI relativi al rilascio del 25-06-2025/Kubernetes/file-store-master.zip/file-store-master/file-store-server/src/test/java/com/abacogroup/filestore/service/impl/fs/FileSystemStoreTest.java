package com.abacogroup.filestore.service.impl.fs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.GZIPInputStream;

import org.apache.commons.io.input.BoundedInputStream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.Compression;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.FileNotInStoreException;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.TemporaryFileException;

public class FileSystemStoreTest {

	@TempDir
	File dir;

	private FileSystemStore store;

	@BeforeEach
	public void before() {
		store = new FileSystemStore(new FSLayout(dir));
	}

	@Test
	public void whenBucketSyntaxIsWrong_thenThrow() {
		InputStream in = new ByteArrayInputStream(new byte[0]);
		FileMetadata meta = new FileMetadata("x");
		assertThrows(IllegalArgumentException.class, () -> store.addFile(new BucketId("_", "../testBucket"), meta, in));
		assertThrows(IllegalArgumentException.class, () -> store.addFile(new BucketId("_", "/testBucket"), meta, in));
		assertThrows(IllegalArgumentException.class, () -> store.addFile(new BucketId("_", "testBucket/"), meta, in));
		assertThrows(IllegalArgumentException.class, () -> store.addFile(new BucketId("_", "test/Bucket"), meta, in));
		assertThrows(IllegalArgumentException.class,
				() -> store.addFile(new BucketId("_", "test/../../Bucket"), meta, in));

		assertThrows(IllegalArgumentException.class,
				() -> store.addFile(new BucketId("/", "test/../../Bucket"), meta, in));
		assertThrows(IllegalArgumentException.class,
				() -> store.addFile(new BucketId("../", "test/../../Bucket"), meta, in));
		assertThrows(IllegalArgumentException.class,
				() -> store.addFile(new BucketId("/../", "test/../../Bucket"), meta, in));
	}

	@Test
	public void whenCorrectBlobAdded_thenSucceed() throws IOException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile storedFile = store.addFile(bid(bucket), meta, in);
		assertNotNull(storedFile);
		assertNotNull(storedFile.getId());
		assertNull(storedFile.getBucketName());
		assertNotEquals("", storedFile.getId());
		assertEquals(name, storedFile.getName());
		assertEquals(mimeType, storedFile.getMimeType());
		assertEquals(bytes.length, storedFile.getSize());
		assertNotNull(storedFile.getContentId());
	}

	@Test
	public void whenFileWithAliasIsAdded_thenSucceed() throws IOException, FileNotInStoreException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		InputStream in = new ByteArrayInputStream(bytes);
		String alias = UUID.randomUUID().toString();
		FileMetadata meta = new FileMetadata(name, mimeType, null, alias);

		StoredFile storedFile = store.addFile(bid(bucket), meta, in);

		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			store.getFileContent(bid(bucket), storedFile, out);
			assertArrayEquals(bytes, out.toByteArray());
		}

		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			storedFile = store.getFile(bid(bucket), alias);
			assertNotNull(storedFile);
			assertNotNull(storedFile.getId());
			assertEquals(mimeType, storedFile.getMimeType());
			assertEquals(bytes.length, storedFile.getSize());
			assertNotNull(storedFile.getContentId());

			store.getFileContent(bid(bucket), storedFile, out);
			assertArrayEquals(bytes, out.toByteArray());
		}
	}

	@Test
	public void whenAliasIsDuplicated_thenSecondWins() throws IOException, FileNotInStoreException {
		var bucket = "Test-Bucket-0";
		var bytes1 = "Hello".getBytes();
		var bytes2 = "Good luck".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		String alias = UUID.randomUUID().toString();

		StoredFile storedFile1;
		try (InputStream in = new ByteArrayInputStream(bytes1)) {
			FileMetadata meta1 = new FileMetadata(name, mimeType, null, alias);
			storedFile1 = store.addFile(bid(bucket), meta1, in);
		}

		StoredFile storedFile2;
		try (InputStream in = new ByteArrayInputStream(bytes2)) {
			FileMetadata meta2 = new FileMetadata(name, mimeType, null, alias);
			storedFile2 = store.addFile(bid(bucket), meta2, in);
		}

		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			store.getFileContent(bid(bucket), storedFile1, out);
			assertArrayEquals(bytes1, out.toByteArray());
		}
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			store.getFileContent(bid(bucket), storedFile2, out);
			assertArrayEquals(bytes2, out.toByteArray());
		}

		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			StoredFile storedFile = store.getFile(bid(bucket), alias);
			assertNotNull(storedFile);
			assertNotNull(storedFile.getId());
			assertEquals(mimeType, storedFile.getMimeType());
			assertEquals(bytes2.length, storedFile.getSize());
			assertNotNull(storedFile.getContentId());

			store.getFileContent(bid(bucket), storedFile, out);
			assertArrayEquals(bytes2, out.toByteArray());
		}
	}

	@Test
	public void whenFileWithAliasNamedAsAnotherFileIsAdded_thenError() throws IOException, FileNotInStoreException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType, null, null);
		StoredFile storedFile = store.addFile(bid(bucket), meta, in);

		FileMetadata meta2 = new FileMetadata(name, mimeType, null, storedFile.getId());
		assertThrows(IOException.class, () -> store.addFile(bid(bucket), meta2, in));
	}

	@Test
	public void whenLinkToExistingFile_thenSucceed() throws IOException, FileNotInStoreException, TemporaryFileException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";
		var destinationBucket = "destination";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile original = store.addFile(bid(bucket), meta, in);

		StoredFile linked = store.linkFile(bid(bucket), original.getId(), destinationBucket, null);
		original.setBucketName(bucket);

		assertEquals(original, linked);
	}

	@Test
	public void whenLinkToExistingFileSettingDifferentName_thenSucceed() throws IOException, FileNotInStoreException, TemporaryFileException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var newFileName = "test2.txt";
		var mimeType = "text/plain";
		var destinationBucket = "destination";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile original = store.addFile(bid(bucket), meta, in);

		StoredFile linked = store.linkFile(bid(bucket), original.getId(), destinationBucket, newFileName);
		assertEquals(newFileName, linked.getName());

		assertNotEquals(original.getId(), linked.getId());

		try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
			store.getFileContent(bid(bucket), linked, baos);
			assertArrayEquals(bytes, baos.toByteArray());
		}
	}

	@Test
	public void whenLinkToALink_thenSucceed() throws IOException, FileNotInStoreException, TemporaryFileException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";
		var destinationBucket = "destination";
		var destinationBucket2 = "destination2";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile original = store.addFile(bid(bucket), meta, in);

		StoredFile linked = store.linkFile(bid(bucket), original.getId(), destinationBucket, null);
		StoredFile linked2 = store.linkFile(bid(destinationBucket), linked.getId(), destinationBucket2, null);

		// both links must point to the same file, because
		// when a link is created it resolves the linked file and, if it's itself a link
		// we just link to the real source file
		original.setBucketName(bucket);
		assertEquals(original, linked);
		assertEquals(original, linked2);
	}

	@Test
	public void whenGettingLinkedFile_thenGetContent() throws IOException, FileNotInStoreException, TemporaryFileException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";
		var destinationBucket = "destination";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile original = store.addFile(bid(bucket), meta, in);
		StoredFile linked = store.linkFile(bid(bucket), original.getId(), destinationBucket, null);

		try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
			store.getFileContent(bid(destinationBucket), linked, baos);
			assertThat(bytes).containsExactly(baos.toByteArray());
		}
	}

	@Test
	public void canReadStoredFile() throws IOException, FileNotInStoreException {
		var bucket = "test-bucket";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		FileMetadata meta = new FileMetadata(name, mimeType);
		StoredFile storedFile = store.addFile(bid(bucket), meta, new ByteArrayInputStream(bytes));

		StoredFile read = store.getFile(bid(bucket), storedFile.getId());
		assertEquals(storedFile, read);

		try (var baos = new ByteArrayOutputStream()) {
			store.getFileContent(bid(bucket), read, baos);
			assertArrayEquals(bytes, baos.toByteArray());
		}
	}

	@Test
	public void whenFileWorthCompressing_thenCompressContent() throws IOException, FileNotInStoreException {
		try (var in = new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz"))) {
			var bucket = "test-bucket";
			var name = " test.csv";
			var mimeType = "text/csv";

			FileMetadata meta = new FileMetadata(name, mimeType);
			StoredFile storedFile = store.addFile(bid(bucket), meta, in);
			assertEquals(Compression.GZIP_OK, storedFile.getCompression());

			try (var baos = new ByteArrayOutputStream()) {
				store.getFileContent(bid(bucket), storedFile, baos);
				assertFalse(baos.size() < 500 * 1024);

				baos.reset();
				store.getFileContentAsStored(bid(bucket), storedFile, baos);
				assertTrue(baos.size() < 500 * 1024);
			}
		}
	}

	@Test
	public void whenFileWorthCompressingIsTwoPhases_thenCompressContentAndUncompressCorrectly() throws IOException, FileNotInStoreException {
		byte[] content = new byte[CompressionEuristicsOutputStream.THRESHOLD + 2];
		try (ByteArrayInputStream in = new ByteArrayInputStream(content)) {
			var bucket = "test-bucket";
			var name = " zero.bin";
			var mimeType = "application/octet-stream";

			FileMetadata meta = new FileMetadata(name, mimeType);
			StoredFile storedFile = store.addFile(bid(bucket), meta, in);
			assertEquals(Compression.GZIP_OK, storedFile.getCompression());

			try (var baos = new ByteArrayOutputStream()) {
				store.getFileContent(bid(bucket), storedFile, baos);
				assertArrayEquals(content, baos.toByteArray());

				baos.reset();
				store.getFileContentAsStored(bid(bucket), storedFile, baos);
				assertThat(baos.toByteArray().length).isLessThan(content.length);
			}
		}
	}

	@Test
	public void whenFileDoesntWorthCompressing_thenStoreOriginal() throws IOException, FileNotInStoreException {
		try (var in = BoundedInputStream.builder().setInputStream(getClass().getResourceAsStream("/ultra-compressed.7z")).get()) {
			var bucket = "test-bucket";
			var name = " test.7z";
			var mimeType = "application/x-7z-compressed";

			FileMetadata meta = new FileMetadata(name, mimeType);
			StoredFile storedFile = store.addFile(bid(bucket), meta, in);
			assertEquals(Compression.NONE, storedFile.getCompression());

			try (var baos = new ByteArrayOutputStream()) {
				store.getFileContent(bid(bucket), storedFile, baos);
				assertEquals(in.getCount(), baos.size());
			}
		}
	}

	@Test
	public void whenReadBlobThatDoesNotExists_thenThrow() throws IOException, FileNotInStoreException {
		assertThrows(FileNotInStoreException.class, () -> store.getFile(bid("no-bucket"), "xxxx"));

	}

	@Test
	public void whenBytesArrivesInDifferentChunkSizes_thenHashToSameValue() throws IOException, FileNotInStoreException {
		var bucket = "test-dedupe";
		var name = " test.csv";
		var mimeType = "text/csv";
		FileMetadata meta = new FileMetadata(name, mimeType);
		StoredFile storedFile;

		try (var in = new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz"))) {
			storedFile = store.addFile(bid(bucket), meta, in);
			assertEquals(-1, storedFile.getContentId().indexOf('@'));
		}

		try (var in = new OddInputStream(new GZIPInputStream(getClass().getResourceAsStream("/test.csv.gz")))) {
			StoredFile storedFile2 = store.addFile(bid(bucket), meta, in);
			assertEquals(storedFile.getContentId(), storedFile2.getContentId());
		}
	}

	@Test
	public void whenHashConflict_thenCreateDifferentFiles() throws IOException, FileNotInStoreException {
		FileSystemStore nodedupeStore = new FileSystemStore(new FSLayout(dir), ConstantMessageDigest::new);

		var bucket = "test-dedupe";
		var name = " test.txt";
		var mimeType = "text/plain";
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile storedFile;
		try (var in = new ByteArrayInputStream("first".getBytes())) {
			storedFile = nodedupeStore.addFile(bid(bucket), meta, in);
			assertEquals(-1, storedFile.getContentId().indexOf('@'));
		}

		try (var in = new ByteArrayInputStream("second".getBytes())) {
			StoredFile storedFile2 = nodedupeStore.addFile(bid(bucket), meta, in);
			assertEquals("1@" + storedFile.getContentId(), storedFile2.getContentId());
		}
	}

	@Test
	public void whenTemporaryFileIsMadePeristent_thenDontDeleteIt()
			throws IOException, FileNotInStoreException, InterruptedException {
		var bucket = "test-temp";
		var name = " test.txt";
		var mimeType = "text/plain";
		FileMetadata meta = new FileMetadata(name, mimeType, Duration.ofSeconds(1), null);

		StoredFile storedFile1, storedFile2;
		try (var in = new ByteArrayInputStream("test".getBytes())) {
			storedFile1 = store.addFile(bid(bucket), meta, in);
			storedFile2 = store.addFile(bid(bucket), meta, in);
		}

		store.makeFilePeristent(bid(bucket), storedFile2.getId());

		Thread.sleep(1_200);

		TemporaryFilesCleaner cleaner = new TemporaryFilesCleaner(new FSLayout(dir), store.getOjectMapper());
		cleaner.run();

		assertThrows(FileNotInStoreException.class, () -> store.getFile(bid(bucket), storedFile1.getId()));

		StoredFile readFile = store.getFile(bid(bucket), storedFile2.getId());
		assertEquals(storedFile2, readFile);
	}

	@Test
	public void whenTemporaryFileIsMadePeristentOnWrongBucket_thenError()
			throws IOException, FileNotInStoreException, InterruptedException {
		var bucket = "test-temp";
		var name = " test.txt";
		var mimeType = "text/plain";
		FileMetadata meta = new FileMetadata(name, mimeType, Duration.ofSeconds(1), null);

		StoredFile storedFile;
		try (var in = new ByteArrayInputStream("test".getBytes())) {
			storedFile = store.addFile(bid(bucket), meta, in);
		}

		assertThrows(FileNotInStoreException.class, () -> store.makeFilePeristent(bid("another-bucket"), storedFile.getId()));
	}

	@Test
	public void whenIsTemporaryOnTemporaryFile_thenReturnTrue() throws IOException, FileNotInStoreException {
		var bucket = "test-temp";
		var name = " test.txt";
		var mimeType = "text/plain";
		FileMetadata meta = new FileMetadata(name, mimeType, Duration.ofSeconds(1), null);

		StoredFile storedFile;
		try (var in = new ByteArrayInputStream("test".getBytes())) {
			storedFile = store.addFile(bid(bucket), meta, in);
		}

		assertTrue(store.isTemporary(bid(bucket), storedFile.getId()));
	}

	@Test
	public void whenIsTemporaryOnPersistentFile_thenReturnFalse() throws IOException, FileNotInStoreException {
		var bucket = "test-temp";
		var name = " test.txt";
		var mimeType = "text/plain";
		FileMetadata meta = new FileMetadata(name, mimeType);

		StoredFile storedFile;
		try (var in = new ByteArrayInputStream("test".getBytes())) {
			storedFile = store.addFile(bid(bucket), meta, in);
		}

		assertFalse(store.isTemporary(bid(bucket), storedFile.getId()));
	}

	@Test
	public void whenIsTemporaryOnMissingFile_thenThrow() throws IOException {
		assertThrows(FileNotInStoreException.class, () -> store.isTemporary(bid("xxxxx"), "yyyy"));
	}

	@Test
	public void whenStreamFileIDsRequested_thenReturnAll() throws IOException {
		var bucket = "Test-Bucket-0";
		var bytes = "Hello".getBytes();
		var name = " test.txt";
		var mimeType = "text/plain";

		InputStream in = new ByteArrayInputStream(bytes);
		FileMetadata meta = new FileMetadata(name, mimeType);

		List<StoredFile> addedFiles = new ArrayList<>();
		for (int i = 0; i < 15; i++) {
			addedFiles.add(store.addFile(bid(bucket), meta, in));
		}

		store.streamFiles(bid(bucket))
				.forEach(storedFile -> addedFiles.removeIf(f -> f.getId().equals(storedFile.getId())));

		assertEquals(0, addedFiles.size());
	}

	private BucketId bid(String bucket) {
		return new BucketId("_", bucket);
	}

}
