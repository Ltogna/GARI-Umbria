package com.abacogroup.filestore;

public class Run {
    public static void main(String[] args) {
        FileStoreApp.main(new String[] { "server", "config.yml" });
    }
}
