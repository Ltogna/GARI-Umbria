package com.abacogroup.filestore.service.impl.fs;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.FileMetadata;

public class FSLayoutTest {

	@Test
	public void whenStreamingBuckets_thenReturnAllOfThem(@TempDir File dir) throws IOException {
		var fsLayout = new FSLayout(dir);
		FileSystemStore store = new FileSystemStore(fsLayout);

		int t = 4;
		int b = 4;

		Set<BucketId> buckets = new HashSet<>();
		FileMetadata meta;
		int i = 0;
		for (int tenant = 0; tenant < t; tenant++) {
			for (int bucket = 0; bucket < b; bucket++) {
				meta = new FileMetadata("file" + i);

				var id = new BucketId("t" + tenant, "bucket" + bucket);
				buckets.add(id);

				var bytes = ("Content" + i).getBytes();
				store.addFile(id, meta, new ByteArrayInputStream(bytes));
				i++;
			}
		}

		assertEquals(t * b, fsLayout.streamBuckets().count());

		fsLayout.streamBuckets().forEach(buckets::remove);
		assertEquals(0, buckets.size());
	}

}
