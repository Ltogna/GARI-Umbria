package com.abacogroup.filestore.service.impl.fs;

import java.security.MessageDigest;

public class ConstantMessageDigest extends MessageDigest {

	private byte[] result;

	protected ConstantMessageDigest() {
		this(new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 0 });
	}

	protected ConstantMessageDigest(byte[] result) {
		super("CONSTANT");
		this.result = result;
	}

	@Override
	protected void engineUpdate(byte input) {
	}

	@Override
	protected void engineUpdate(byte[] input, int offset, int len) {
	}

	@Override
	protected byte[] engineDigest() {
		return result;
	}

	@Override
	protected void engineReset() {
	}

}
