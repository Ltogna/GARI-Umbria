#!/bin/sh

umask 0002 && \
java -XX:MaxRAMPercentage=70 -XshowSettings:vm -Djava.security.egd=file:/dev/./urandom -cp "/app/*" com.abacogroup.filestore.FileStoreApp server config.yml
