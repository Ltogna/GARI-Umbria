package com.abacogroup.filestore.resource.stream;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicBoolean;

import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.Compression;
import com.abacogroup.filestore.service.FileNotInStoreException;
import com.abacogroup.filestore.service.Store;
import com.abacogroup.filestore.service.StoredFile;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.ws.rs.InternalServerErrorException;
import jakarta.ws.rs.NotFoundException;
import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.HttpHeaders;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;
import jakarta.ws.rs.core.StreamingOutput;

public class FileContentStreamer {

	private final Store store;
	private final BucketId bucket;
	private final StoredFile storedFile;

	public FileContentStreamer(Store store, BucketId bucket, StoredFile storedFile) {
		this.store = store;
		this.bucket = bucket;
		this.storedFile = storedFile;
	}

	public Response createResponse(HttpServletRequest request) {
		AtomicBoolean raw = new AtomicBoolean();
		var streaming = new StreamingOutput() {
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					if (raw.get()) {
						store.getFileContentAsStored(bucket, storedFile, output);
					} else {
						store.getFileContent(bucket, storedFile, output);
					}
				} catch (FileNotInStoreException e) {
					throw new NotFoundException(e);
				}
			}
		};

		ResponseBuilder builder = Response.ok(streaming);

		boolean sendRaw = setupCompression(request, builder);
		raw.set(sendRaw);

		setupHeadersFromStoredFile(builder, !sendRaw);

		return builder.build();
	}

	public void setupHeadersFromStoredFile(ResponseBuilder builder, boolean sendSize) {
		boolean temporary;
		try {
			temporary = store.isTemporary(bucket, storedFile.getId());
		} catch (FileNotInStoreException e) {
			throw new NotFoundException(e);
		} catch (IOException e) {
			throw new InternalServerErrorException(e);
		}

		builder
				.header(HttpHeaders.CONTENT_DISPOSITION,
						"attachment; filename=\"" + storedFile.getName() + "\"; filename*=UTF-8''"
								+ URLEncoder.encode(storedFile.getName(), StandardCharsets.UTF_8))
				.header(HttpHeaders.CONTENT_TYPE, storedFile.getMimeType())
				.header(HttpHeaders.ETAG, storedFile.getId())
				.header(HttpHeaders.LAST_MODIFIED, DateTimeFormatter.RFC_1123_DATE_TIME.format(storedFile.getDate().atZone(ZoneId.systemDefault())))
				.header("X-Temporary-File", temporary);

		if (sendSize) {
			builder.header(HttpHeaders.CONTENT_LENGTH, storedFile.getSize());
		}
	}

	private boolean setupCompression(HttpServletRequest request, ResponseBuilder builder) {
		Compression compression = storedFile.getCompression();
		if (compression == Compression.NONE) {
			return false;
		}

		boolean raw = false;

		var acceptedEncodings = request.getHeaders("Accept-Encoding");
		String enc;
		while (acceptedEncodings.hasMoreElements()) {
			enc = acceptedEncodings.nextElement();
			if (enc.startsWith(compression.getHttpContentEncoding()) || "*".equals(enc)) {
				builder.header(HttpHeaders.CONTENT_ENCODING, compression.getHttpContentEncoding());
				raw = true;
				break;
			}
		}

		return raw;
	}

}
