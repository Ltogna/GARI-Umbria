package com.abacogroup.filestore.api;

import java.time.Instant;

import com.abacogroup.filestore.service.StoredFile;

public class FileMetadataResponse {
	private String id;
	private String name;
	private String mimeType;
	private long size;
	private Instant date;

	public FileMetadataResponse(StoredFile stored) {
		this.id = stored.getId();
		this.name = stored.getName();
		this.mimeType = stored.getMimeType();
		this.size = stored.getSize();
		this.date = stored.getDate();
	}

	public FileMetadataResponse() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public Instant getDate() {
		return date;
	}

	public void setDate(Instant date) {
		this.date = date;
	}

}
