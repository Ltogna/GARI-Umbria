package com.abacogroup.filestore.service.impl.fs;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.impl.fs.FSLayout.Type;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TemporaryFilesCleaner implements Runnable {
	private static final Logger log = LoggerFactory.getLogger(TemporaryFilesCleaner.class);

	private final FSLayout fsLayout;
	private ObjectMapper mapper;

	public TemporaryFilesCleaner(FSLayout fsLayout, ObjectMapper mapper) {
		this.fsLayout = fsLayout;
		this.mapper = mapper;
	}

	@Override
	public void run() {
		log.info("Collecting garbage...");
		try {
			fsLayout.streamBuckets().forEach(this::collectGarbage);
		} catch (Exception e) {
			log.error("Error collecting garbage", e);
		}
	}

	private void collectGarbage(BucketId bucketId) {
		File dir = fsLayout.getTenantBucket(bucketId, Type.TEMP_FILES_REGISTRY);
		if (!dir.exists()) {
			return;
		}

		try (var walker = Files.walk(dir.toPath(), 1)) {
			walker
					.filter(path -> path.toFile().isFile())
					.forEach(path -> maybeDelete(bucketId, path));
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	private void maybeDelete(BucketId bucket, Path path) {
		// It is possible that someone makes the file persistent
		// just after we read it and before we delete it
		// or that another instance is trying to delete the same file

		TempFileMetadata meta;
		try {
			meta = mapper.readValue(Files.readAllBytes(path), TempFileMetadata.class);
			if (Instant.now().isBefore(meta.getDeleteAt())) {
				return;
			}
		} catch (IOException e) {
			log.debug("Error deleting " + path, e);
			return;
		}

		// rename the file to be sure we are the only ones using it
		{
			String uuid = UUID.randomUUID().toString();
			File file = path.toFile();
			File dest = new File(file.getParent(), uuid);
			path = dest.toPath();
			if (!file.renameTo(dest)) {
				log.info("Cannot rename {} to {}", path, uuid);
				return;
			}
		}

		try {
			// It is better to leak the other files than to have the registry to point to missing files
			// so we delete the registry file first.
			if (!deleteFile(path)) {
				log.info("Cannot delete {}", path);
				return;
			}

			File filesDir = fsLayout.getTenantBucket(bucket, Type.FILES);
			var filePath = fsLayout.idToFile(filesDir, meta.getId()).toPath();
			StoredFile storedFile = mapper.readValue(Files.readAllBytes(filePath), StoredFile.class);

			// Delete the stored file first
			// we can tolerate the content to survive the StoredFile but not vice-versa
			// Otherwise the StoredFile would point to a missing contentId
			if (!deleteFile(filePath)) {
				log.info("Cannot delete {}", filePath);
				return;
			}

			deleteAliasFile(storedFile, filesDir);

			File contentDir = fsLayout.getTenantBucket(bucket, Type.CONTENT);
			deleteFile(fsLayout.idToFile(contentDir, storedFile.getContentId()).toPath());
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	private void deleteAliasFile(StoredFile storedFile, File filesDir) throws IOException {
		if (storedFile.getAlias() == null) {
			return;
		}

		var file = fsLayout.idToFile(filesDir, storedFile.getAlias());
		if (!file.exists()) {
			// The alias was changed to point to another file and it was already deleted
			return;
		}

		var filePath = file.toPath();
		StoredFile aliasFile = mapper.readValue(Files.readAllBytes(filePath), StoredFile.class);
		if (aliasFile.getContentId().equals(storedFile.getContentId())) {
			// Delete the file only if the alias is still poing to the same content
			deleteFile(filePath);
		}
	}

	private boolean deleteFile(Path filePath) throws IOException {
		boolean deleted = Files.deleteIfExists(filePath);
		if (!deleted) {
			log.warn("Cannot delete file {}", filePath);
		}
		return deleted;
	}

}
