package com.abacogroup.filestore.resource;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.api.AddFileResponse;
import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.Store;
import com.abacogroup.filestore.service.StoredFile;

public class FileUploader {

    private final Store store;

    public FileUploader(Store store) {
        this.store = store;
    }

    public AddFileResponse addFile(User user, String tenantId, String bucketName, InputStream inputStream, FormDataBodyPart bodyPart, Integer deleteAfterMins,
            String alias) throws IOException {
        FormDataContentDisposition cd = bodyPart.getFormDataContentDisposition();
        String unescapedName = cd.getFileName(false);
        String name = cd.getFileName(true);
        if (unescapedName != null && unescapedName.equals(name)) {
            name = new String(name.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
        }

        String contentType = bodyPart.getMediaType().toString();

        Duration deleteAfter = null;
        if (deleteAfterMins != null && deleteAfterMins > 0) {
            deleteAfter = Duration.ofMinutes(deleteAfterMins);
        }

        FileMetadata meta = new FileMetadata(name, contentType, deleteAfter, alias);

        StoredFile addedFile = store.addFile(new BucketId(tenantId, bucketName), meta, inputStream);
        return new AddFileResponse(addedFile.getId());
    }
}
