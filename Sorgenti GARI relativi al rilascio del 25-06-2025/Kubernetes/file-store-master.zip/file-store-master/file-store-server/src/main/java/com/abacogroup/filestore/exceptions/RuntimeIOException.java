package com.abacogroup.filestore.exceptions;

import java.io.IOException;

public class RuntimeIOException extends RuntimeException {
	private static final long serialVersionUID = -7295795126451003037L;

	public RuntimeIOException(IOException e) {
		super(e.getMessage(), e);
	}
}
