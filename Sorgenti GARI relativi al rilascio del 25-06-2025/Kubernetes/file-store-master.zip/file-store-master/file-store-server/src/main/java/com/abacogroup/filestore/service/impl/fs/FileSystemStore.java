package com.abacogroup.filestore.service.impl.fs;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.DigestOutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.Base64.Encoder;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.abacogroup.filestore.exceptions.RuntimeIOException;
import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.Compression;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.FileNotInStoreException;
import com.abacogroup.filestore.service.Store;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.TemporaryFileException;
import com.abacogroup.filestore.service.impl.fs.FSLayout.Type;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;

public class FileSystemStore implements Store {
	private static final Pattern TENANT_ALLOWED_CHARS = Pattern.compile("[a-zA-Z0-9\\_\\-]+");
	private static final Pattern ID_ALLOWED_CHARS = Pattern
			.compile("[a-zA-Z0-9\\_\\-][@a-zA-Z0-9\\_\\-][@a-zA-Z0-9\\_\\-][@a-zA-Z0-9\\_\\-]+(?:\\.v2)?(?:\\.gz)?");

	private ScheduledExecutorService scheduledExecutorService;

	private FSLayout fsLayout;
	private Supplier<MessageDigest> messageDigestSupplier;

	private Encoder encoder;
	private ObjectMapper mapper;

	public FileSystemStore(FSLayout fsLayout) {
		this(fsLayout, () -> {
			try {
				return MessageDigest.getInstance("SHA-512");
			} catch (NoSuchAlgorithmException e) {
				throw new IllegalStateException(e.getMessage(), e);
			}
		});
	}

	public FileSystemStore(FSLayout fsLayout, Supplier<MessageDigest> messageDigestSupplier) {
		this.fsLayout = fsLayout;
		this.messageDigestSupplier = messageDigestSupplier;

		this.encoder = Base64.getUrlEncoder().withoutPadding();
		this.mapper = JsonMapper.builder(/* new MessagePackFactory() */)
				.findAndAddModules()
				.build()
				.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
				.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		var millis = getTemporaryFilesCleanupInterval().toMillis();
		scheduledExecutorService = Executors.newScheduledThreadPool(1);
		scheduledExecutorService.scheduleWithFixedDelay(new TemporaryFilesCleaner(fsLayout, mapper), millis, millis,
				TimeUnit.MILLISECONDS);
	}

	// Visible for testing
	ObjectMapper getOjectMapper() {
		return mapper;
	}

	@Override
	public StoredFile addFile(BucketId bucketId, FileMetadata metadata, InputStream in) throws IOException {
		checkBucketIdSyntax(bucketId);
		if (metadata.getAlias() != null) {
			checkIdSyntax(metadata.getAlias());
		}

		StoredFile newStoredFile = null;

		MessageDigest digest = messageDigestSupplier.get();

		File contentFile = createTempFile("file-content", ".tmp");
		try {
			String contentId = null;
			long size = -1;
			String hash = null;

			CompressionEuristicsOutputStream cos = new CompressionEuristicsOutputStream(
					new BufferedOutputStream(new FileOutputStream(contentFile)));
			try (DigestOutputStream contentOut = new DigestOutputStream(cos, digest)) {
				size = IOUtils.stream2stream(in, contentOut);
				hash = bytesToString(digest.digest(), ".v2");
				contentId = hash;
				contentId += cos.getCompression().suffix();
			}

			// Temporary files are never deduplicated so we can safely delete
			// them when needed
			boolean dedupe = metadata.getDeleteAfter().isEmpty();

			File contentDir = fsLayout.getOrCreateTenantBucket(bucketId, Type.CONTENT);
			contentId = moveContentToBucket(contentFile, contentDir, contentId, dedupe);

			File filesBucket = fsLayout.getOrCreateTenantBucket(bucketId, Type.FILES);
			newStoredFile = new StoredFile(createUniqueFileId(filesBucket), metadata, size, Instant.now(),
					contentId, cos.getCompression(), metadata.getAlias());

			persistStoredFile(newStoredFile, filesBucket);

			String id = newStoredFile.getId();
			metadata.getDeleteAfter()
					.ifPresent(deleteAfter -> markToBeDeleted(bucketId, id, deleteAfter));

			if (metadata.getAlias() != null) {
				createAlias(filesBucket, newStoredFile, metadata.getAlias());
			}
		} finally {
			Files.deleteIfExists(contentFile.toPath());
		}

		return newStoredFile;
	}

	private void createAlias(File filesBucket, StoredFile original, String alias) throws IOException {
		FileMetadata metadata = new FileMetadata(original.getName(), original.getMimeType(), null, original.getId());
		var storedFile = StoredFile.createAlias(alias, metadata, original.getSize(), original.getDate(),
				original.getContentId(), original.getCompression(), original.getId());
		File file = fsLayout.idToFile(filesBucket, alias);
		if (file.exists()) {
			deleteFileIfAliasOrThrow(file.toPath());
		}
		persistStoredFile(storedFile, filesBucket);
	}

	private void deleteFileIfAliasOrThrow(Path file) throws IOException {
		byte[] bytes = Files.readAllBytes(file);
		StoredFile storedFile = mapper.readValue(bytes, StoredFile.class);
		if (!Boolean.TRUE.equals(storedFile.getIsAlias())) {
			throw new IOException("Cannot delete a non alias file");
		}
		Files.deleteIfExists(file);
	}

	private void persistStoredFile(StoredFile newStoredFile, File filesBucket) throws IOException {
		File jsonFile = createTempFile("file", ".tmp");
		try {
			try (OutputStream jsonOut = new BufferedOutputStream(new FileOutputStream(jsonFile))) {
				mapper.writeValue(jsonOut, newStoredFile);
			}

			moveFileToBucket(jsonFile, filesBucket, newStoredFile.getId());
		} finally {
			Files.deleteIfExists(jsonFile.toPath());
		}

	}

	@Override
	public boolean exists(BucketId bucketId, String fileId) throws IOException {
		checkBucketIdSyntax(bucketId);
		checkIdSyntax(fileId);

		File bucket = fsLayout.getTenantBucket(bucketId, Type.FILES);
		File ret = fsLayout.idToFile(bucket, fileId);
		return ret.exists();
	}

	@Override
	public StoredFile linkFile(BucketId sourceBucketId, String fileId, String destinationBucketName, String newFileName)
			throws IOException, FileNotInStoreException, TemporaryFileException {
		if (!exists(sourceBucketId, fileId)) {
			throw new FileNotInStoreException(String.format("File %s not found in bucket %s", fileId, sourceBucketId));
		}

		if (isTemporary(sourceBucketId, fileId)) {
			throw new TemporaryFileException(
					String.format("File %s in bucket %s is temporary", fileId, sourceBucketId));
		}

		BucketId destBucketId = new BucketId(sourceBucketId.getTenant(), destinationBucketName);
		if (exists(destBucketId, fileId)) {
			throw new IllegalStateException(
					String.format("File %s already present in destination bucket %s", fileId, sourceBucketId));
		}

		File filesBucket = fsLayout.getOrCreateTenantBucket(destBucketId, Type.FILES);

		StoredFile storedFile = getFile(sourceBucketId, fileId);
		if (storedFile.getBucketName() == null) {
			storedFile.setBucketName(sourceBucketId.getName());
		}

		if (newFileName != null) {
			String newId = createUniqueFileId(filesBucket);
			storedFile.setId(newId);
			storedFile.setName(newFileName);
		}

		persistStoredFile(storedFile, filesBucket);

		return storedFile;
	}

	private File createTempFile(String prefix, String suffix) throws IOException {
		return File.createTempFile(prefix, suffix, fsLayout.getTempFolder());
	}

	@Override
	public boolean isTemporary(BucketId bucketId, String fileId) throws IOException, FileNotInStoreException {
		checkBucketIdSyntax(bucketId);
		checkIdSyntax(fileId);

		File file = getRealFile(bucketId, fileId); // Check if the file exists
		if (!file.exists()) {
			throw new FileNotFoundException("File not found");
		}

		File dir = fsLayout.getTenantBucket(bucketId, Type.TEMP_FILES_REGISTRY);
		file = new File(dir, fileId);
		return file.exists();
	}

	@Override
	public boolean makeFilePeristent(BucketId bucketId, String fileId) throws IOException, FileNotInStoreException {
		getFile(bucketId, fileId); // We check that the file exists in this bucket
		File dir = fsLayout.getOrCreateTenantBucket(bucketId, Type.TEMP_FILES_REGISTRY);
		File file = new File(dir, fileId);
		return Files.deleteIfExists(file.toPath());
	}

	private void markToBeDeleted(BucketId bucketId, String id, Duration deleteAfter) {
		File dir = fsLayout.getOrCreateTenantBucket(bucketId, Type.TEMP_FILES_REGISTRY);
		Path path = new File(dir, id).toPath();
		try {
			Instant deleteAt = Instant.now().plus(deleteAfter);
			Files.writeString(path, mapper.writeValueAsString(new TempFileMetadata(bucketId, id, deleteAt)),
					StandardOpenOption.CREATE);
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	@Override
	public void getFileContent(BucketId bucketId, StoredFile storedFile, OutputStream out)
			throws IOException, FileNotInStoreException {
		getFileContent(bucketId, storedFile, out, storedFile.getCompression());
	}

	@Override
	public void getFileContentAsStored(BucketId bucketId, StoredFile storedFile, OutputStream out)
			throws IOException, FileNotInStoreException {
		getFileContent(bucketId, storedFile, out, Compression.NONE);
	}

	@Override
	public void zip(BucketId bucketId, List<String> fileIds, OutputStream out)
			throws IOException, FileNotInStoreException {
		try (ZipOutputStream zipOut = new ZipOutputStream(out)) {
			checkBucketIdSyntax(bucketId);
			fileIds.forEach(this::checkIdSyntax);

			File bucket;
			StoredFile storedFile;
			for (var id : fileIds) {
				File file = getRealFile(bucketId, id);
				storedFile = mapper.readValue(file, StoredFile.class);

				bucket = fsLayout.getTenantBucket(getTargetBucketId(storedFile, bucketId), Type.CONTENT);

				ZipEntry entry = new ZipEntry(storedFile.getName());
				entry.setTime(storedFile.getDate().toEpochMilli());

				zipOut.putNextEntry(entry);

				file = getFileToRead(bucket, storedFile.getContentId());
				try (var in = storedFile.getCompression()
						.decompressor(new BufferedInputStream(new FileInputStream(file)))) {
					IOUtils.stream2stream(in, zipOut);
				}
			}
		}
	}

	private void getFileContent(BucketId bucketId, StoredFile storedFile, OutputStream out, Compression compression)
			throws IOException, FileNotInStoreException {
		checkBucketIdSyntax(bucketId);
		checkIdSyntax(storedFile.getContentId());

		BucketId targetBucketId = getTargetBucketId(storedFile, bucketId);

		File bucket = fsLayout.getTenantBucket(targetBucketId, Type.CONTENT);
		File file = getFileToRead(bucket, storedFile.getContentId());
		try (var in = compression.decompressor(new BufferedInputStream(new FileInputStream(file)))) {
			IOUtils.stream2stream(in, out);
		}
	}

	private BucketId getTargetBucketId(StoredFile storedFile, BucketId defaultBucketId) {
		String bucketName = storedFile.getBucketName();
		if (bucketName == null || bucketName.equals(defaultBucketId.getName())) {
			return defaultBucketId;
		}

		return new BucketId(defaultBucketId.getTenant(), bucketName);
	}

	@Override
	public StoredFile getFile(BucketId bucketId, String id) throws IOException, FileNotInStoreException {
		checkBucketIdSyntax(bucketId);
		checkIdSyntax(id);

		File file = getRealFile(bucketId, id);
		return mapper.readValue(file, StoredFile.class);
	}

	@Override
	public Stream<StoredFile> streamFiles(BucketId bucketId) throws IOException {
		checkBucketIdSyntax(bucketId);

		File bucket = fsLayout.getTenantBucket(bucketId, Type.FILES);

		return Files.walk(bucket.toPath())
				.map(Path::toFile)
				.filter(File::isFile)
				.map(this::uncheckedReadStoredFile);
	}

	private StoredFile uncheckedReadStoredFile(File file) {
		try {
			return mapper.readValue(file, StoredFile.class);
		} catch (IOException e) {
			throw new RuntimeIOException(e);
		}
	}

	private File getRealFile(BucketId bucketId, String id) throws IOException, FileNotInStoreException {
		File bucket = fsLayout.getTenantBucket(bucketId, Type.FILES);
		return getFileToRead(bucket, id);
	}

	// protected for testing
	protected Duration getTemporaryFilesCleanupInterval() {
		return Duration.ofMinutes(15);
	}

	private File getFileToRead(File bucket, String id) throws FileNotInStoreException {
		File ret = fsLayout.idToFile(bucket, id);

		if (!ret.exists() || !ret.canRead()) {
			throw new FileNotInStoreException(String.format("File %s not found", id));
		}

		return ret;
	}

	private String moveContentToBucket(File from, File bucket, String id, boolean dedupe) throws IOException {
		File to = fsLayout.idToFile(bucket, id);
		if (to.exists()) {
			var fromLen = dedupe ? from.length() : -1;
			if (fromLen != to.length()) {
				to = computeFreeFile(bucket, id, fromLen);
			} else {
				Files.delete(from.toPath());
				return to.getName();
			}
		} else if (!dedupe) {
			to = computeFreeFile(bucket, id, -1);
		}

		to.getParentFile().mkdirs();
		boolean moved = from.renameTo(to);

		// It is possible that another thread was moving to the same file in
		// parallel
		// so we re-check for file presence
		if (!moved && !to.exists()) {
			throw new IOException(
					String.format("Cannot move %s file to %s", from.getAbsolutePath(), to.getAbsolutePath()));
		}

		return to.getName();
	}

	private void moveFileToBucket(File from, File bucket, String id) throws IOException {
		File to = fsLayout.idToFile(bucket, id);
		if (to.exists()) {
			throw new IOException(String.format("%s already exists", to.getAbsolutePath()));
		}

		to.getParentFile().mkdirs();
		boolean moved = from.renameTo(to);

		if (!moved) {
			throw new IOException(
					String.format("Cannot move %s file to %s", from.getAbsolutePath(), to.getAbsolutePath()));
		}
	}

	private File computeFreeFile(File bucket, String id, long fromLen) {
		int cnt = 0;
		String originalId = id;

		File to;
		long toLen;

		do {
			cnt++;
			id = cnt + "@" + originalId;
			to = fsLayout.idToFile(bucket, id);
			toLen = to.length();
		} while (to.exists() && toLen != fromLen);

		return to;
	}

	private void checkBucketIdSyntax(BucketId bucketId) {
		checkRegEx(bucketId.getTenant(), TENANT_ALLOWED_CHARS);
		checkRegEx(bucketId.getName(), TENANT_ALLOWED_CHARS);
	}

	private void checkIdSyntax(String id) {
		checkRegEx(id, ID_ALLOWED_CHARS);
	}

	private void checkRegEx(String id, Pattern pattern) {
		if (id == null || !pattern.matcher(id).matches()) {
			throw new IllegalArgumentException(
					String.format("%s is not a valid id; it must match regex: %s", id, pattern.pattern()));
		}
	}

	private String createUniqueFileId(File bucket) {
		ThreadLocalRandom random = ThreadLocalRandom.current();
		byte[] uuid = new byte[24];

		String id;
		do {
			random.nextBytes(uuid);
			id = bytesToString(uuid, "");
		} while (fsLayout.idToFile(bucket, id).exists());

		return id;
	}

	// TOM: This encoding scheme allows to have less directories than a full base64
	// encoding
	// we will have 256 first level directories (00 to ff)
	// each of these will potentially include 4096 sub-directories (64 * 64)
	// for a maximum of 1_048_576 directories
	// (instead of 64 * 64 * 64 * 64 = 16_777_216)
	// this saving is because each empty directory use 4k of disk space, and
	// directories with sub-directories
	// takes even more space
	private String bytesToString(byte[] bytes, String suffix) {
		if (bytes == null || bytes.length == 0) {
			return null;
		}

		ByteBuffer buf = ByteBuffer.wrap(bytes);

		StringBuilder ret = new StringBuilder(bytes.length * 2);

		int firstByte = buf.get() & 0xff;
		if (firstByte < 0x10) {
			ret.append('0');
		}
		ret.append(Integer.toHexString(firstByte));
		ret.append(new String(encoder.encode(buf).array(), StandardCharsets.US_ASCII));
		ret.append(suffix);

		return ret.toString();
	}

}
