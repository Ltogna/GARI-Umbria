package com.abacogroup.filestore.service.impl.fs;

import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import com.abacogroup.filestore.service.BucketId;

public class FSLayout {
	public enum Type {
		CONTENT("content"), FILES("files"), TEMP_FILES_REGISTRY("temp-files-registry");

		private String value;

		Type(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	private static final String TEMP_FOLDER_NAME = "@tmp";

	private final File root;
	private final File tempFolder;

	public FSLayout(File root) {
		this.root = root;
		this.tempFolder = new File(root, TEMP_FOLDER_NAME);
		getOrCreateTempFolder();
	}

	public File idToFile(File bucket, String contentId) {
		if (contentId.length() < 4) {
			throw new IllegalArgumentException("contentId must be at least 4 characters long");
		}

		var subDir = new File(bucket, contentId.substring(0, 2));
		subDir = new File(subDir, contentId.substring(2, 4));
		return new File(subDir, contentId);
	}

	public final File getTenantBucket(BucketId bucketId, Type type) {
		File ret;
		ret = new File(root, bucketId.getTenant());
		ret = new File(ret, bucketId.getName());
		ret = new File(ret, type.getValue());
		return ret;
	}

	public final File getOrCreateTenantBucket(BucketId bucketId, Type type) {
		File ret = getTenantBucket(bucketId, type);
		ret.mkdirs();
		return ret;
	}

	public final File getTempFolder() {
		return tempFolder;
	}

	private File getOrCreateTempFolder() {
		File ret = getTempFolder();
		ret.mkdirs();
		return ret;
	}

	public Stream<BucketId> streamBuckets() {
		return StreamSupport.stream(new BucketsSpliterator(), false);
	}

	private class BucketsSpliterator implements Spliterator<BucketId> {
		private LinkedList<File> tenantDirs;
		private File currentTenant;

		private LinkedList<File> bucketDirs;

		private BucketsSpliterator() {
			this.tenantDirs = new LinkedList<>();
			this.bucketDirs = new LinkedList<>();

			File[] dirs = listSubdirs(root);
			tenantDirs.addAll(Arrays.asList(dirs));
		}

		private boolean nextTenant() {
			currentTenant = null;
			bucketDirs.clear();
			if (tenantDirs.isEmpty()) {
				return false;
			}

			currentTenant = tenantDirs.pop();
			File[] dirs = listSubdirs(currentTenant);
			bucketDirs.addAll(Arrays.asList(dirs));

			return true;
		}

		private File nextBucket() {
			if (bucketDirs.isEmpty()) {
				return null;
			}

			return bucketDirs.pop();
		}

		@Override
		public boolean tryAdvance(Consumer<? super BucketId> action) {
			if (currentTenant == null) {
				nextTenant();
			}

			while (true) {
				if (currentTenant == null) {
					return false;
				}

				var bucketDir = nextBucket();
				if (bucketDir != null) {
					action.accept(new BucketId(currentTenant.getName(), bucketDir.getName()));
					return true;
				}

				nextTenant();
			}
		}

		@Override
		public Spliterator<BucketId> trySplit() {
			return null;
		}

		@Override
		public long estimateSize() {
			return Long.MAX_VALUE;
		}

		@Override
		public int characteristics() {
			return Spliterator.DISTINCT
					| Spliterator.NONNULL
					| Spliterator.IMMUTABLE;
		}

		private File[] listSubdirs(File dir) {
			File[] dirs = dir.listFiles(File::isDirectory);
			if (dirs == null) {
				throw new IllegalStateException(root.getAbsolutePath() + " list files returned null");
			}
			return dirs;
		}

	}

}
