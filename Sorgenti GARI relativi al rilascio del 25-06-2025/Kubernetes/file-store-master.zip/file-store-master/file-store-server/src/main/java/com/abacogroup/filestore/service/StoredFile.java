package com.abacogroup.filestore.service;

import java.time.Instant;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class StoredFile {
	private String id;
	private String name;
	private String mimeType;
	private long size;
	private Instant date;
	private String bucketName;
	private String contentId;
	private Compression compression;
	private String alias;
	private Boolean isAlias;

	public StoredFile() {
	}

	public StoredFile(String id, FileMetadata metadata, long size, Instant date, String contentId, Compression compression, String alias) {
		this(id, metadata, size, date, null, contentId, compression, alias);
	}

	private StoredFile(String id, FileMetadata metadata, long size, Instant date, String bucketName, String contentId, Compression compression, String alias) {
		this.id = id;
		this.name = metadata.getName();
		this.mimeType = metadata.getMimeType();
		this.size = size;
		this.date = date;
		this.bucketName = bucketName;
		this.contentId = contentId;
		this.compression = compression;
		this.alias = alias;
	}

	public static StoredFile createAlias(String id, FileMetadata metadata, long size, Instant date, String contentId, Compression compression, String aliasOf) {
		StoredFile ret = new StoredFile(id, metadata, size, date, contentId, compression, aliasOf);
		ret.setIsAlias(true);
		return ret;
	}

	public String getId() {
		return id;
	}

	public String getAlias() {
		return alias;
	}

	public Boolean getIsAlias() {
		return isAlias;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public void setIsAlias(Boolean isAlias) {
		this.isAlias = isAlias;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public Instant getDate() {
		return date;
	}

	public void setDate(Instant date) {
		this.date = date;
	}

	public String getBucketName() {
		return bucketName;
	}

	public void setBucketName(String bucketName) {
		this.bucketName = bucketName;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public Compression getCompression() {
		return compression;
	}

	public void setCompression(Compression compression) {
		this.compression = compression;
	}

	@Override
	public int hashCode() {
		return Objects.hash(bucketName, compression, contentId, date, id, mimeType, name, size);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		StoredFile other = (StoredFile) obj;
		return Objects.equals(bucketName, other.bucketName) && compression == other.compression && Objects.equals(contentId, other.contentId)
				&& Objects.equals(date, other.date) && Objects.equals(id, other.id) && Objects.equals(mimeType, other.mimeType)
				&& Objects.equals(name, other.name) && size == other.size;
	}

	@Override
	public String toString() {
		return "StoredFile [id=" + id + ", name=" + name + ", mimeType=" + mimeType + ", size=" + size + ", date=" + date + ", bucketName=" + bucketName
				+ ", contentId=" + contentId + ", compression=" + compression + "]";
	}

}
