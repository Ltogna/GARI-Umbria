package com.abacogroup.filestore.resource;

import static com.abacogroup.filestore.resource.Constants.ALIAS_ALLOWED_CHARS;
import static com.abacogroup.filestore.resource.Constants.ALIAS_HEADER_NAME;

import java.io.IOException;
import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.api.AddFileResponse;
import com.codahale.metrics.annotation.Timed;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DefaultValue;
import jakarta.ws.rs.HeaderParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Timed
@Path("/{tenantId}/public/v1/temp-files")
@Tag(name = "Temp-files", description = "Temporary files related APIs, exposed to the outside world")
public class TempFileResources {
	private final FileUploader fileUploader;

	public TempFileResources(FileUploader fileUploader) {
		this.fileUploader = fileUploader;
	}

	@POST
	@Path("/{bucketName}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(description = "Add a file to a bucket")
	@ApiResponse(description = "The added file identifier")
	public AddFileResponse addFile(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(hidden = true) @NotNull @FormDataParam("file") InputStream inputStream,
			@Parameter(description = "The file content") @NotNull @FormDataParam("file") FormDataBodyPart bodyPart,
			@Parameter(description = "The file will be deleted after the specified number of minutes") @HeaderParam("X-FS-DeleteAfterMins") @NotNull @Min(1) @Max(60) @DefaultValue("60") Integer deleteAfterMins,
			@Parameter(description = "An optional alias for the ID. Warning: the alias will be valid for this new file, even if previously set for another one") @HeaderParam(ALIAS_HEADER_NAME) @Pattern(regexp = ALIAS_ALLOWED_CHARS) String alias)
			throws IOException {
		return fileUploader.addFile(user, tenantId, bucketName, inputStream, bodyPart, deleteAfterMins, alias);
	}

}
