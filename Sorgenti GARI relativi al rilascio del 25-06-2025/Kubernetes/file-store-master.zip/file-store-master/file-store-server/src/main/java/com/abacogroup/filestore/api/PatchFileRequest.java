package com.abacogroup.filestore.api;

public class PatchFileRequest {
	private Boolean temporary;

	public Boolean getTemporary() {
		return temporary;
	}

	public void setTemporary(Boolean temporary) {
		this.temporary = temporary;
	}

}
