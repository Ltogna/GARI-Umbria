package com.abacogroup.filestore.service.impl.fs;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.io.output.ProxyOutputStream;

import com.abacogroup.filestore.service.Compression;

public class CompressionEuristicsOutputStream extends ProxyOutputStream {
	private static final double MAX_RATIO = 0.95;

	// Visible for testing
	static final int THRESHOLD = 256 * 1024;

	private ByteArrayOutputStream baos;

	private OutputStream originalOS;
	private Compression compression;

	public CompressionEuristicsOutputStream(OutputStream originalOS) {
		super(new ByteArrayOutputStream(THRESHOLD));
		this.baos = (ByteArrayOutputStream) this.out;

		this.originalOS = originalOS;
		this.compression = Compression.NONE;
	}

	public Compression getCompression() {
		return compression;
	}

	@Override
	protected void afterWrite(int n) throws IOException {
		if (baos == null || baos.size() < THRESHOLD) {
			return;
		}

		baos.flush();
		var uncompressedBytes = baos.toByteArray();
		baos.reset();

		var numBytesToWrite = Math.min(THRESHOLD, uncompressedBytes.length);
		try (GZIPOutputStream gzip = new GZIPOutputStream(baos)) {
			gzip.write(uncompressedBytes, 0, numBytesToWrite);
		}

		double ratio = baos.size() / (double) numBytesToWrite;
		if (ratio >= MAX_RATIO) {
			this.out = originalOS;
		} else {
			this.out = new GZIPOutputStream(originalOS);
			compression = Compression.GZIP_OK;
		}

		baos.close();
		baos = null;

		this.out.write(uncompressedBytes);
	}

	@Override
	public void close() throws IOException {
		super.close();

		// If threshold was not reached we just copy the accumulated bytes to the original OutputStream
		if (baos != null) {
			baos.flush();
			baos.writeTo(originalOS);
			originalOS.close();
			baos.close();
		}
	}

}
