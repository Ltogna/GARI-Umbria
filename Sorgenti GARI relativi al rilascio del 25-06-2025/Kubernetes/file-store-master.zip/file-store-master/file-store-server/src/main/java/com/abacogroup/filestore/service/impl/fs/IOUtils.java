package com.abacogroup.filestore.service.impl.fs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class IOUtils {
	private static final int BUF_SIZE_BYTES = 4096;

	private IOUtils() {
	}

	public static void file2file(File from, File to) throws IOException {
		try (var in = new FileInputStream(from); var out = new FileOutputStream(to)) {
			stream2stream(in, out);
		}
	}

	public static void file2stream(File file, OutputStream out) throws IOException {
		try (var in = new FileInputStream(file)) {
			stream2stream(in, out);
		}
	}

	public static void stream2file(InputStream in, File file) throws IOException {
		try (var out = new FileOutputStream(file)) {
			stream2stream(in, out);
		}
	}

	/**
	 * @param in
	 *            the InputStream to read from
	 * @param out
	 *            the OutputStream to write to
	 * @return The number of written bytes
	 * @throws IOException
	 */
	public static long stream2stream(InputStream in, OutputStream out) throws IOException {
		long totalWritten = 0;
		byte[] buf = new byte[BUF_SIZE_BYTES];
		int len;
		while ((len = in.read(buf)) != -1) {
			out.write(buf, 0, len);
			totalWritten += len;
		}
		return totalWritten;
	}

}
