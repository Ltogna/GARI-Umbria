package com.abacogroup.filestore.resource;

public abstract class Constants {

    public static final String ALIAS_ALLOWED_CHARS = "[a-zA-Z0-9\\_\\-][a-zA-Z0-9\\_\\-][a-zA-Z0-9\\_\\-][a-zA-Z0-9\\_\\-]+";
    public static final String ALIAS_HEADER_NAME = "X-FS-Alias";

    private Constants() {
    }
}
