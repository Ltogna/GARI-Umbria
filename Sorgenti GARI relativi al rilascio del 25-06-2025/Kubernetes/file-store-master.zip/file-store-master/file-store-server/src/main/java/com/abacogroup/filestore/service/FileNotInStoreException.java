package com.abacogroup.filestore.service;

public class FileNotInStoreException extends Exception {
	private static final long serialVersionUID = 700012482650673247L;

	public FileNotInStoreException(String message, Throwable cause) {
		super(message, cause);
	}

	public FileNotInStoreException(String message) {
		super(message);
	}

	public FileNotInStoreException(Throwable cause) {
		super(cause);
	}

}
