package com.abacogroup.filestore.service;

public class TemporaryFileException extends Exception {
	private static final long serialVersionUID = 2894760917660505692L;

	public TemporaryFileException(String message, Throwable cause) {
		super(message, cause);
	}

	public TemporaryFileException(String message) {
		super(message);
	}

	public TemporaryFileException(Throwable cause) {
		super(cause);
	}

}
