package com.abacogroup.filestore.health;

import java.nio.file.FileStore;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.codahale.metrics.health.HealthCheck;

public class FileSystemSpaceHealthCheck extends HealthCheck {
	private static final Logger log = LoggerFactory.getLogger(FileSystemSpaceHealthCheck.class);

	private static final long MIN_USABLE_SPACE_BYTES = 10L * 1024 * 1024; // 10MB

	private final Path path;

	public FileSystemSpaceHealthCheck(Path path) {
		this.path = path;
	}

	@Override
	protected Result check() throws Exception {
		FileStore store = Files.getFileStore(path);
		long usable = store.getUsableSpace();

		if (usable < MIN_USABLE_SPACE_BYTES) {
			log.warn("LOW USABLE SPACE ON DISK: {} bytes", usable);
			return Result.unhealthy("LOW USABLE SPACE ON DISK: %s bytes", usable);
		}

		return Result.healthy("Free space: %s bytes", usable);
	}

}
