package com.abacogroup.filestore.service;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public enum Compression {
	NONE("", "", in -> in, out -> out),

	// TOM: The original euristics implementation was creating GZIP files
	// consisting of 2 headers, this is accepted by the gzip specification
	// but it looks like browsers do not like it...
	// To be backwards compatible we now expend these on the server side and let jaxrs re-compress them
	@Deprecated GZIP(".gz", "gzip-multiheader", GZIPInputStream::new, GZIPOutputStream::new),
	GZIP_OK(".gz", "gzip", GZIPInputStream::new, GZIPOutputStream::new);

	private String suffix;
	private String httpContentEncoding;
	private ThrowingFunction<InputStream, InputStream> decompressor;
	private ThrowingFunction<OutputStream, OutputStream> compressor;

	Compression(String suffix, String httpContentEncoding, ThrowingFunction<InputStream, InputStream> decompressor,
			ThrowingFunction<OutputStream, OutputStream> compressor) {
		this.suffix = suffix;
		this.httpContentEncoding = httpContentEncoding;
		this.decompressor = decompressor;
		this.compressor = compressor;
	}

	public OutputStream compressor(OutputStream out) {
		try {
			return compressor.apply(out);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public InputStream decompressor(InputStream in) {
		try {
			return decompressor.apply(in);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}

	public String suffix() {
		return suffix;
	}

	public String getHttpContentEncoding() {
		return httpContentEncoding;
	}
}
