package com.abacogroup.filestore;

import java.io.File;
import java.io.IOException;
import java.util.EnumSet;
import java.util.TimeZone;

import org.eclipse.jetty.servlets.CrossOriginFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.dropwizard.auth.multitenant.MultitenantFilter;
import com.abacogroup.dropwizard.auth.sso2.AuthUtils;
import com.abacogroup.dropwizard.auth.sso2.Sso2Client;
import com.abacogroup.filestore.health.FileSystemSpaceHealthCheck;
import com.abacogroup.filestore.resource.FileResources;
import com.abacogroup.filestore.resource.FileUploader;
import com.abacogroup.filestore.resource.TempFileResources;
import com.abacogroup.filestore.service.impl.fs.FSLayout;
import com.abacogroup.filestore.service.impl.fs.FileSystemStore;
import com.abacogroup.tracing.dropwizard.AbacoApplication;
import com.abacogroup.tracing.jaxrs.client.AddRequestId;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import io.dropwizard.client.JerseyClientBuilder;
import io.dropwizard.configuration.EnvironmentVariableSubstitutor;
import io.dropwizard.configuration.SubstitutingSourceProvider;
import io.dropwizard.core.setup.Bootstrap;
import io.dropwizard.core.setup.Environment;
import io.dropwizard.forms.MultiPartBundle;
import io.dropwizard.jersey.setup.JerseyEnvironment;
import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;
import io.swagger.v3.oas.integration.ClasspathOpenApiConfigurationLoader;
import io.swagger.v3.oas.integration.api.OpenAPIConfiguration;
import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.ws.rs.client.Client;

public class FileStoreApp extends AbacoApplication<FileStoreConfig> {
	private static final Logger log = LoggerFactory.getLogger(FileStoreApp.class);

	@Override
	public String getName() {
		return "FileStore";
	}

	@Override
	public void initialize(Bootstrap<FileStoreConfig> bootstrap) {
		SubstitutingSourceProvider provider = new SubstitutingSourceProvider(bootstrap.getConfigurationSourceProvider(),
				new EnvironmentVariableSubstitutor(false));
		bootstrap.setConfigurationSourceProvider(provider);
		bootstrap.addBundle(new MultiPartBundle());
	}

	@Override
	public void doRun(FileStoreConfig configuration, Environment environment) throws Exception {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				environment.getApplicationContext().getServer().stop();
			} catch (Exception e) {
				log.warn(e.getMessage(), e);
				System.exit(1);
			}
		}));

		ObjectMapper objectMapper = environment.getObjectMapper();
		configure(objectMapper);

		File root = getRoot(configuration);
		environment.healthChecks().register("filesystem", new FileSystemSpaceHealthCheck(root.toPath()));

		var jersey = environment.jersey();

		FileSystemStore store = new FileSystemStore(new FSLayout(root));
		FileUploader fileUploader = new FileUploader(store);
		jersey.register(new FileResources(fileUploader, store, objectMapper));
		jersey.register(new TempFileResources(fileUploader));

		Client client = createJerseyClient(configuration, environment);
		Sso2Client sso2Client = new Sso2Client(client.target(configuration.getSso2ServerUrl()));
		AuthUtils.installAuthFilter(environment, sso2Client);
		initMultitenantCapabilities(jersey);

		initOpenApi(jersey);
		setupCORS(environment);
	}

	private Client createJerseyClient(FileStoreConfig config, Environment environment) {
		var jerseyClient = config.getJerseyClient();
		Client client = new JerseyClientBuilder(environment).using(jerseyClient).build("file-store");
		client.register(new AddRequestId());
		return client;
	}

	private void initMultitenantCapabilities(JerseyEnvironment jersey) {
		jersey.register(new MultitenantFilter("tenantId"));
	}

	private File getRoot(FileStoreConfig configuration) {
		String root = configuration.getRoot();

		File dir = new File(root);
		if (!dir.exists()) {
			dir.mkdirs();
		}

		if (!dir.isDirectory()) {
			throw new IllegalArgumentException(String.format("%s is not a directory", root));
		}
		if (!dir.canRead()) {
			throw new IllegalArgumentException(String.format("%s is not readable", root));
		}
		if (!dir.canWrite()) {
			throw new IllegalArgumentException(String.format("%s is not writeable", root));
		}

		return dir;
	}

	private void initOpenApi(JerseyEnvironment jersey) throws IOException {
		OpenAPIConfiguration oasConfig = new ClasspathOpenApiConfigurationLoader()
				.load("openapi-configuration.yaml");

		jersey.register(new OpenApiResource()
				.openApiConfiguration(oasConfig));
	}

	private void setupCORS(Environment environment) {
		Dynamic cors = environment.servlets().addFilter("CORS", CrossOriginFilter.class);
		cors.setInitParameter(CrossOriginFilter.ALLOWED_ORIGINS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_HEADERS_PARAM, "*");
		cors.setInitParameter(CrossOriginFilter.ALLOWED_METHODS_PARAM, "GET,PUT,POST,DELETE");
		cors.addMappingForUrlPatterns(EnumSet.allOf(DispatcherType.class), false, "*");
	}

	private void configure(ObjectMapper objectMapper) {
		objectMapper
				.setTimeZone(TimeZone.getDefault())
				.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
	}

	public static void main(String[] args) {
		try {
			new FileStoreApp().run(args);
		} catch (Exception e) {
			log.error("Error in main", e);
			System.exit(1);
		}
	}

}
