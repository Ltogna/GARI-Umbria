package com.abacogroup.filestore;

import io.dropwizard.client.JerseyClientConfiguration;
import io.dropwizard.core.Configuration;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class FileStoreConfig extends Configuration {

	@NotEmpty
	private String root;

	@NotEmpty
	private String sso2ServerUrl;

	@NotNull
	@Valid
	private JerseyClientConfiguration jerseyClient;

	public String getRoot() {
		return root;
	}

	public void setRoot(String root) {
		this.root = root;
	}

	public JerseyClientConfiguration getJerseyClient() {
		return jerseyClient;
	}

	public void setJerseyClient(JerseyClientConfiguration jerseyClient) {
		this.jerseyClient = jerseyClient;
	}

	public String getSso2ServerUrl() {
		return sso2ServerUrl;
	}

	public void setSso2ServerUrl(String sso2ServerUrl) {
		this.sso2ServerUrl = sso2ServerUrl;
	}

}
