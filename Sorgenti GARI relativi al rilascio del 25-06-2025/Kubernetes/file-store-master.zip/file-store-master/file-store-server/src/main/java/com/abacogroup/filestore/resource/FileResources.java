package com.abacogroup.filestore.resource;

import static com.abacogroup.filestore.resource.Constants.ALIAS_ALLOWED_CHARS;
import static com.abacogroup.filestore.resource.Constants.ALIAS_HEADER_NAME;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.util.List;
import java.util.Objects;

import org.glassfish.jersey.media.multipart.FormDataBodyPart;
import org.glassfish.jersey.media.multipart.FormDataParam;

import com.abacogroup.dropwizard.auth.sso2.User;
import com.abacogroup.filestore.api.AddFileResponse;
import com.abacogroup.filestore.api.FileMetadataResponse;
import com.abacogroup.filestore.api.PatchFileRequest;
import com.abacogroup.filestore.exceptions.RuntimeIOException;
import com.abacogroup.filestore.resource.stream.FileContentStreamer;
import com.abacogroup.filestore.service.BucketId;
import com.abacogroup.filestore.service.FileMetadata;
import com.abacogroup.filestore.service.FileNotInStoreException;
import com.abacogroup.filestore.service.Store;
import com.abacogroup.filestore.service.StoredFile;
import com.abacogroup.filestore.service.TemporaryFileException;
import com.codahale.metrics.annotation.Timed;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.dropwizard.auth.Auth;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.StreamingOutput;

@Timed
@Path("/{tenantId}/public/v1/files")
@Tag(name = "Files", description = "File related APIs (these are not exposed on the internet)")
public class FileResources {
	private final FileUploader fileUploader;
	private Store store;
	private ObjectMapper mapper;

	public FileResources(FileUploader fileUploader, Store store, ObjectMapper mapper) {
		this.fileUploader = fileUploader;
		this.store = store;
		this.mapper = mapper;
	}

	@POST
	@Path("/{bucketName}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(description = "Add a file to a bucket")
	@ApiResponse(description = "The added file identifier")
	public AddFileResponse addFile(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(hidden = true) @NotNull @FormDataParam("file") InputStream inputStream,
			@Parameter(description = "The file content") @NotNull @FormDataParam("file") FormDataBodyPart bodyPart,
			@Parameter(description = "If set, and greater then 0, the file is considered to be temporary and deleted after the specified minutes") @HeaderParam("X-FS-DeleteAfterMins") Integer deleteAfterMins,
			@Parameter(description = "An optional alias for the ID. Warning: the alias will be valid for this new file, even if previously set for another one") @HeaderParam(ALIAS_HEADER_NAME) @Pattern(regexp = ALIAS_ALLOWED_CHARS) String alias)
			throws IOException {
		return fileUploader.addFile(user, tenantId, bucketName, inputStream, bodyPart, deleteAfterMins, alias);
	}

	@GET
	@Path("/{bucketName}/{id}")
	@Operation(description = "Get a file from the store")
	@ApiResponse(description = "The file bytes")
	public Response getFile(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "The file id") @PathParam("id") String id,
			@Parameter(hidden = true) @Context HttpServletRequest request) throws IOException {
		try {
			BucketId bucketId = new BucketId(tenantId, bucketName);
			var storedFile = store.getFile(bucketId, id);
			FileContentStreamer streamer = new FileContentStreamer(store, bucketId, storedFile);
			return streamer.createResponse(request);
		} catch (FileNotInStoreException e) {
			throw new NotFoundException(e);
		}
	}

	@POST
	@Path("/{bucketName}/{id}/link-to/{destinationBucketName}")
	@Produces(MediaType.APPLICATION_JSON)
	@Operation(description = "Link an existing non temporary file from one bucket to another")
	@ApiResponses({
			@ApiResponse(responseCode = "204", description = "Link created"),
			@ApiResponse(responseCode = "404", description = "Source file not in store"),
			@ApiResponse(responseCode = "412", description = "Source file is temporary")
	})
	public AddFileResponse linkFile(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The source bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "The file id") @PathParam("id") String id,
			@Parameter(description = "The destination bucket name") @PathParam("destinationBucketName") String destinationBucketName,
			@Parameter(description = "An optional new name to assign to the file") @HeaderParam("X-FS-FileName") String fileName) throws IOException {
		try {
			BucketId sourceBucketId = new BucketId(tenantId, bucketName);
			StoredFile addedFile = store.linkFile(sourceBucketId, id, destinationBucketName, fileName);
			return new AddFileResponse(addedFile.getId());
		} catch (FileNotInStoreException e) {
			throw new NotFoundException(e);
		} catch (TemporaryFileException e) {
			throw new WebApplicationException(e.getMessage(), Response.Status.PRECONDITION_FAILED);
		}
	}

	@GET
	@Path("/{bucketName}")
	@Produces("application/jsonl") // see https://jsonlines.org/
	@Operation(description = "Streams the file metadata in a bucket using Transfer-Encoding: chunked")
	@ApiResponse(description = "The files metadata as json lines separated by \\n", content = {
			@Content(mediaType = "application/jsonl", schema = @Schema(implementation = FileMetadataResponse.class)) })
	public Response streamFiles(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "Limit the number of files returned") @QueryParam("limit") Long limitParam)
			throws IOException {
		BucketId bucketId = new BucketId(tenantId, bucketName);
		long limit = limitParam == null || limitParam <= 0 ? Long.MAX_VALUE : limitParam;
		var streaming = new StreamingOutput() {
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				store.streamFiles(bucketId)
						.limit(limit)
						.map(FileMetadataResponse::new)
						.forEach(fileMetadata -> {
							try {
								output.write(mapper.writeValueAsBytes(fileMetadata));
								output.write('\n');
							} catch (IOException e) {
								throw new RuntimeIOException(e);
							}
						});
			}
		};

		return Response.ok(streaming).build();
	}

	@HEAD
	@Path("/{bucketName}/{id}")
	@Operation(description = "Get a file metadata from the store")
	public Response getFileMetadata(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "The file id") @PathParam("id") String id) throws IOException {
		try {
			BucketId bucketId = new BucketId(tenantId, bucketName);
			var storedFile = store.getFile(bucketId, id);
			FileContentStreamer streamer = new FileContentStreamer(store, bucketId, storedFile);

			var builder = Response.ok();
			streamer.setupHeadersFromStoredFile(builder, true);
			return builder.build();
		} catch (FileNotInStoreException e) {
			throw new NotFoundException(e);
		}
	}

	@PATCH
	@Path("/{bucketName}/{id}")
	@Operation(description = "Patch an already loaded file")
	public void patchFileMetadata(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "The file id") @PathParam("id") String id,
			@Valid @NotNull PatchFileRequest request) throws IOException {
		if (request.getTemporary() == null) {
			return;
		}
		if (Boolean.TRUE.equals(request.getTemporary())) {
			throw new BadRequestException("temporary must be false or null");
		}

		BucketId bucketId = new BucketId(tenantId, bucketName);
		try {
			store.makeFilePeristent(bucketId, id);
		} catch (FileNotInStoreException e) {
			throw new NotFoundException(e);
		}
	}

	@POST
	@Path("/{bucketName}/compressed/zip")
	@Operation(description = "Download a zip package composed by the supplied files")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "OK"),
			@ApiResponse(responseCode = "404", description = "One or more requested files are not in store")
	})
	public Response downloadZip(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@NotNull @Size(min = 1) List<@NotEmpty String> fileIds) throws IOException {
		BucketId bucketId = new BucketId(tenantId, bucketName);

		for (var id : fileIds) {
			if (!store.exists(bucketId, id)) {
				throw new NotFoundException(id + " not found");
			}
		}

		var streaming = new StreamingOutput() {
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try {
					store.zip(bucketId, fileIds, output);
				} catch (FileNotInStoreException e) {
					// This should never happen because we check for the files upfront
					throw new InternalServerErrorException(e.getMessage(), e);
				}
			}
		};
		return Response.ok(streaming).build();
	}

	@POST
	@Path("/{bucketName}/compressed/zip/{destinationBucketName}")
	@Operation(description = "Create a zip package composed by the supplied files and store it in the destination bucket")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "OK"),
			@ApiResponse(responseCode = "404", description = "One or more requested files are not in store")
	})
	public AddFileResponse produceZipAndStoreToBucket(
			@Parameter(hidden = true) @Auth User user,
			@Parameter(description = "The tenant") @PathParam("tenantId") String tenantId,
			@Parameter(description = "The bucket name") @PathParam("bucketName") String bucketName,
			@Parameter(description = "The destination bucket name") @PathParam("destinationBucketName") String destinationBucketName,
			@Parameter(description = "An optional new name to assign to the file") @HeaderParam("X-FS-FileName") String fileName,
			@NotNull @Size(min = 1) List<@NotEmpty String> fileIds) throws IOException, FileNotInStoreException {
		BucketId bucketId = new BucketId(tenantId, bucketName);
		BucketId destinationBucketId = new BucketId(tenantId, destinationBucketName);

		for (var id : fileIds) {
			if (!store.exists(bucketId, id)) {
				throw new NotFoundException(id + " not found");
			}
		}

		File tmp = File.createTempFile("produceZipAndStoreToBucket", ".zip");
		try {
			try (FileOutputStream output = new FileOutputStream(tmp)) {
				store.zip(bucketId, fileIds, output);
			}

			try (InputStream input = new FileInputStream(tmp)) {
				FileMetadata meta = new FileMetadata(Objects.requireNonNullElse(fileName, "file.zip"), "application/zip", null, null);
				StoredFile addedFile = store.addFile(destinationBucketId, meta, input);
				return new AddFileResponse(addedFile.getId());
			}
		} finally {
			Files.delete(tmp.toPath());
		}
	}

}
