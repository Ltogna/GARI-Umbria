package com.abacogroup.filestore.service.impl.fs;

import java.time.Instant;

import com.abacogroup.filestore.service.BucketId;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class TempFileMetadata {
	private final BucketId bucketId;
	private final String id;
	private final Instant deleteAt;

	@JsonCreator
	public TempFileMetadata(
			@JsonProperty("bucketId") BucketId bucketId,
			@JsonProperty("id") String id,
			@JsonProperty("deleteAt") Instant deleteAt) {
		this.bucketId = bucketId;
		this.id = id;
		this.deleteAt = deleteAt;
	}

	public BucketId getBucketId() {
		return bucketId;
	}

	public String getId() {
		return id;
	}

	public Instant getDeleteAt() {
		return deleteAt;
	}

}
