package com.abacogroup.filestore.api;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;

public class AddFileResponse {
	private final String id;

	@JsonCreator
	public AddFileResponse(@JsonProperty("id") String id) {
		this.id = id;
	}

	@Schema(description = "The file identifier")
	public String getId() {
		return id;
	}

}
