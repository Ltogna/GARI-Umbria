package com.abacogroup.filestore.service;

import java.time.Duration;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Supplier;

public class FileMetadata {
	private final String name;
	private final String mimeType;
	private final Duration deleteAfter;
	private final String alias;

	public FileMetadata(String name) {
		this(name, null, null, null);
	}

	public FileMetadata(String name, String mimeType) {
		this(name, mimeType, null, null);
	}

	public FileMetadata(String name, String mimeType, Duration deleteAfter, String alias) {
		this.name = lastPart(def(name, () -> UUID.randomUUID().toString()));
		this.mimeType = mimeType;
		this.deleteAfter = deleteAfter;
		this.alias = alias;
	}

	public String getName() {
		return name;
	}

	public String getMimeType() {
		return mimeType;
	}

	public Optional<Duration> getDeleteAfter() {
		return Optional.ofNullable(deleteAfter);
	}

	public String getAlias() {
		return alias;
	}

	private <T> T def(T value, Supplier<T> ifNull) {
		return value != null ? value : ifNull.get();
	}

	private String lastPart(String fileName) {
		if (fileName == null)
			return null;

		int pos = fileName.lastIndexOf('\\');
		if (pos == -1)
			pos = fileName.lastIndexOf('/');
		if (pos == -1)
			return fileName;

		return fileName.substring(pos + 1);
	}

}
