package com.abacogroup.filestore.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.stream.Stream;

public interface Store {

	/**
	 * Adds a file to the store
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param metadata
	 *            the file metadata
	 * @param in
	 *            the InputStream to read from
	 * @return the StoreFile pbject
	 * @throws IOException
	 */
	StoredFile addFile(BucketId bucketId, FileMetadata metadata, InputStream in) throws IOException;

	/**
	 * Link a file to another bucket; note that the file cannot be a temporary one.
	 *
	 * @param sourceBucketId
	 *            the bucket containing the file
	 * @param sourceFileId
	 *            the source fileId
	 * @param destinationBucketName
	 *            the destination bucket name (you cannot have cross-tenant links)
	 * @param newFileName
	 *            the new name to give to the file (only to the link itself); can be <code>null<code>
	 * @return the StoredFile in the destination bucket
	 * @throws IOException
	 * @throws FileNotInStoreException
	 *             if the source file does not exist or is a temporary one
	 * @throws TemporaryFileException
	 *             if the source file is a temporary one
	 */
	StoredFile linkFile(BucketId sourceBucketId, String sourceFileId, String destinationBucketName, String newFileName)
			throws IOException, FileNotInStoreException, TemporaryFileException;

	/**
	 * Check if a file exists into the store
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param fileId
	 *            the file ID
	 * @return true if the file exists, false otherwise
	 * @throws IOException
	 */
	boolean exists(BucketId bucketId, String fileId) throws IOException;

	/**
	 * Remove the deleteAfter attribute from a file; if the file is not in store or was added without the deleteAfter attribute, this method does nothing.
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param metadata
	 *            the file metadata
	 * @return true if the file was made persistent
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	boolean makeFilePeristent(BucketId bucketId, String fileId) throws IOException, FileNotInStoreException;

	/**
	 * Get a file from the store
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param fileId
	 *            the file ID
	 * @return the StoredFile
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	StoredFile getFile(BucketId bucketId, String fileId) throws IOException, FileNotInStoreException;

	/**
	 * Stream the files in a bucket.
	 *
	 * @param bucketId
	 *            the bucket id
	 * @return the stored file
	 * @throws IOException
	 */
	Stream<StoredFile> streamFiles(BucketId bucketId) throws IOException;

	/**
	 * Test if the {@link StoredFile} identified by {@link BucketId} and <code>fileId</code> will be deleted in the future.
	 *
	 * @param bucketId
	 *            the bucket
	 * @param fileId
	 *            the fileId
	 * @return true if the stored file will be deleted
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	boolean isTemporary(BucketId bucketId, String fileId) throws IOException, FileNotInStoreException;

	/**
	 * Get a file content from the store
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param storedFile
	 *            the file to read
	 * @param out
	 *            the OutputStream to write to
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	void getFileContent(BucketId bucketId, StoredFile storedFile, OutputStream out)
			throws IOException, FileNotInStoreException;

	/**
	 * Get the file content as stored internally and not as originally added. If the file was compresesd then this will write the compressed bytes and not the
	 * original ones.
	 *
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param storedFile
	 *            the file to read
	 * @param out
	 *            the OutputStream to write to
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	void getFileContentAsStored(BucketId bucketId, StoredFile storedFile, OutputStream out)
			throws IOException, FileNotInStoreException;

	/**
	 * Writes a zip compressed archive containing the requested files from the bucket
	 * 
	 * @param bucketId
	 *            the bucket to add the file to
	 * @param fileIds
	 *            the files to read
	 * @param out
	 *            the OutputStream to write to
	 * @throws IOException
	 * @throws FileNotInStoreException
	 */
	void zip(BucketId bucketId, List<String> fileIds, OutputStream out) throws IOException, FileNotInStoreException;
}
