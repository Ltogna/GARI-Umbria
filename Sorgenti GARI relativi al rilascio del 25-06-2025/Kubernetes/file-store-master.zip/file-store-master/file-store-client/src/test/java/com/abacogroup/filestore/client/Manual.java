package com.abacogroup.filestore.client;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URI;

import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;

import com.abacogroup.filestore.client.auth.Authenticator;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Manual {
	private static final String AUTH_TOKEN = "TEST";

	public static void main(String[] args) throws Exception {
		var auth = new Authenticator() {
			@Override
			public void accept(HttpUriRequestBase request) {
				request.setHeader("Authorization", "JWT " + AUTH_TOKEN);
			}
		};

		var bucket = "tom";

		ObjectMapper mapper = new ObjectMapper();
		try (FileStoreClient fsClient = new FileStoreClient(new URI("http://localhost:8080"), mapper)) {

			var result = fsClient.addFile(auth, "_", bucket, new File("c:\\temp\\test.csv"));

			var out = new FileOutputStream("c:\\temp\\test-download.csv");
			fsClient.getFileContent(auth, "_", bucket, result.getId(), out);
		}
	}
}
