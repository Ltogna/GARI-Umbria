package com.abacogroup.filestore.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Optional;

import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpHeaders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.abacogroup.filestore.client.auth.Authenticator;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.Response;


class JaxRsSupportTest {

    private static final String FILE_EXT = ".txt";
    private static final String DEFAULT_FILENAME_WITHOUT_EXT = "test$$$file";
    private static final String DEFAULT_FILENAME = DEFAULT_FILENAME_WITHOUT_EXT+FILE_EXT;
    private static final String EXPECTED_FILE_NAME_NO_EXT = "different $$$ Filename";
    private static final URI BASE_URI = URI.create("http://localhost/api/");
    private static final String TENANT_ID = "tenant";
    private static final String BUCKET = "bucket";
    private static final String FILE_ID = "fileId";
    private static final String DEFAULT_CONTENT_DISPOSITION = getContentDispoString(DEFAULT_FILENAME);
    private static final String DEFAULT_CONTENT_DISPOSITION_WITHOUT_EXT = getContentDispoString(DEFAULT_FILENAME_WITHOUT_EXT);
    private static final String EXPECTED_CONTENT_DISPOSITION_WHEN_CHANGED = getContentDispoString(EXPECTED_FILE_NAME_NO_EXT+FILE_EXT);
    private static final String EXPECTED_CONTENT_DISPOSITION_WHEN_CHANGED_WITH_NO_EXT = getContentDispoString(EXPECTED_FILE_NAME_NO_EXT);

    private CloseableHttpClient httpClient;
    private JaxRsSupportDataProvider provider;
    private Authenticator authenticator;
    private CloseableHttpResponse httpResponse;
    private HttpEntity httpEntity;
    private JaxRsSupport jaxRsSupport;

    private static String getContentDispoString(String fileName) {
        return "attachment; filename=\"" + fileName + "\"; filename*=UTF-8''" + URLEncoder.encode(fileName, StandardCharsets.UTF_8);
    }

    @BeforeEach
    void setUp() {
        httpClient = mock(CloseableHttpClient.class);
        provider = mock(JaxRsSupportDataProvider.class);
        authenticator = mock(Authenticator.class);
        httpResponse = mock(CloseableHttpResponse.class);
        httpEntity = mock(HttpEntity.class);

        jaxRsSupport = new JaxRsSupport(BASE_URI, httpClient, provider);
    }

    private void doProxyFileResponse_withExpectedFileNameNoExt(String contentDispositionValue, String expectedContentDisposition, String expectedFileNameNoExt) throws Exception {
        when(httpClient.execute(any(HttpGet.class))).thenReturn(httpResponse);
        when(httpResponse.getCode()).thenReturn(200);
        when(httpResponse.getEntity()).thenReturn(httpEntity);
        when(httpEntity.getContent()).thenReturn(new ByteArrayInputStream("content".getBytes()));

        Header contentType = mock(Header.class);
        when(contentType.getName()).thenReturn(HttpHeaders.CONTENT_TYPE);
        when(contentType.getValue()).thenReturn("application/octet-stream");
        when(httpResponse.getHeader(HttpHeaders.CONTENT_TYPE)).thenReturn(contentType);

        if (contentDispositionValue != null) {
            Header contentDisposition = mock(Header.class);
            when(contentDisposition.getName()).thenReturn(HttpHeaders.CONTENT_DISPOSITION);
            when(contentDisposition.getValue()).thenReturn(contentDispositionValue);
            when(httpResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION)).thenReturn(contentDisposition);
        } else {
            when(httpResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION)).thenReturn(null);
        }

        when(httpResponse.getHeader(HttpHeaders.CONTENT_ENCODING)).thenReturn(null);
        when(httpResponse.getHeader(HttpHeaders.LAST_MODIFIED)).thenReturn(null);

        Response response = jaxRsSupport.proxyFileResponse(authenticator, TENANT_ID, BUCKET, FILE_ID, expectedFileNameNoExt);

        assertNotNull(response);
        assertEquals(200, response.getStatus());
        assertNotNull(response.getEntity());
        assertEquals(expectedContentDisposition, response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION));
        assertEquals("application/octet-stream", response.getHeaderString(HttpHeaders.CONTENT_TYPE));
        assertEquals(TENANT_ID + "/" + BUCKET + "/" + FILE_ID, response.getHeaderString(HttpHeaders.ETAG));
    }

    @Test
    void proxyFileResponse_withExpectedFileNameNoExt_returnsStreamingResponse() throws Exception {
        doProxyFileResponse_withExpectedFileNameNoExt(DEFAULT_CONTENT_DISPOSITION, EXPECTED_CONTENT_DISPOSITION_WHEN_CHANGED, EXPECTED_FILE_NAME_NO_EXT);
    }

    @Test
    void proxyFileResponse_withExpectedFileNameNoExt_returnsStreamingResponse_whenContentDispositionIsNull() throws Exception {
        doProxyFileResponse_withExpectedFileNameNoExt(null, EXPECTED_CONTENT_DISPOSITION_WHEN_CHANGED_WITH_NO_EXT, EXPECTED_FILE_NAME_NO_EXT);
    }

    @Test
    void proxyFileResponse_withExpectedFileNameNoExt_returnsStreamingResponse_whenContentDispositionIsDefaultWithoutExt() throws Exception {
        doProxyFileResponse_withExpectedFileNameNoExt(DEFAULT_CONTENT_DISPOSITION_WITHOUT_EXT, EXPECTED_CONTENT_DISPOSITION_WHEN_CHANGED_WITH_NO_EXT, EXPECTED_FILE_NAME_NO_EXT);
    }

    @Test
    void proxyFileResponse_withNullExpectedFileNameNoExt_returnsStreamingResponse() throws Exception {
        doProxyFileResponse_withExpectedFileNameNoExt(DEFAULT_CONTENT_DISPOSITION, DEFAULT_CONTENT_DISPOSITION, null);
    }

    @Test
    @SuppressWarnings("deprecation")
    void proxyFileResponse_whenNon200Response_throwsWebApplicationException() throws Exception {
        when(httpClient.execute(any(HttpGet.class))).thenReturn(httpResponse);
        when(httpResponse.getCode()).thenReturn(404);
        when(httpResponse.getEntity()).thenReturn(httpEntity);
        when(httpResponse.getReasonPhrase()).thenReturn("Not Found");
        when(httpEntity.getContent()).thenReturn(new ByteArrayInputStream("not found".getBytes()));

        assertThrows(WebApplicationException.class, () ->
            jaxRsSupport.proxyFileResponse(authenticator, TENANT_ID, BUCKET, FILE_ID, EXPECTED_FILE_NAME_NO_EXT)
        );
    }

    @Test
    @SuppressWarnings("deprecation")
    void proxyFileResponse_withDefaultOverload_returnsStreamingResponse() throws Exception {
        when(httpClient.execute(any(HttpGet.class))).thenReturn(httpResponse);
        when(httpResponse.getCode()).thenReturn(200);
        when(httpResponse.getEntity()).thenReturn(httpEntity);
        when(httpEntity.getContent()).thenReturn(new ByteArrayInputStream("abc".getBytes()));

        Header contentType = mock(Header.class);
        when(contentType.getName()).thenReturn(HttpHeaders.CONTENT_TYPE);
        when(contentType.getValue()).thenReturn("application/pdf");
        when(httpResponse.getHeader(HttpHeaders.CONTENT_TYPE)).thenReturn(contentType);

        when(httpResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION)).thenReturn(null);
        when(httpResponse.getHeader(HttpHeaders.CONTENT_ENCODING)).thenReturn(null);
        when(httpResponse.getHeader(HttpHeaders.LAST_MODIFIED)).thenReturn(null);

        Response response = jaxRsSupport.proxyFileResponse(authenticator, TENANT_ID, BUCKET, FILE_ID);

        assertNotNull(response);
        assertEquals(200, response.getStatus());
        assertNotNull(response.getEntity());
    }

    @Test
    void proxyHeaderResponse_returnsMetadataHeaders() throws Exception {
        
        com.abacogroup.filestore.client.response.FileMetadata metadata =
            new com.abacogroup.filestore.client.response.FileMetadata()
                .withName(Optional.of("file.txt"))
                .withSize(Optional.of(123L))
                .withMimeType(Optional.of("text/plain"))
                .withDate(Optional.of(java.time.Instant.ofEpochMilli(456L)));

        when(provider.getFileMetadata(authenticator, TENANT_ID, BUCKET, FILE_ID)).thenReturn(metadata);

        Response response = jaxRsSupport.proxyHeaderResponse(authenticator, TENANT_ID, BUCKET, FILE_ID);

        assertNotNull(response);
        assertEquals(200, response.getStatus());
        assertNotNull(response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION));
        assertTrue(response.getHeaderString(HttpHeaders.CONTENT_DISPOSITION).contains("file.txt"));
        assertEquals("123", response.getHeaderString(HttpHeaders.CONTENT_LENGTH));
        assertEquals("text/plain", response.getHeaderString(HttpHeaders.CONTENT_TYPE));
        assertEquals(TENANT_ID + "/" + BUCKET + "/" + FILE_ID, response.getHeaderString(HttpHeaders.ETAG));
    }

    @Test
    void proxyHeaderResponse_whenFileNotFound_returns404() throws Exception {
        when(provider.getFileMetadata(authenticator, TENANT_ID, BUCKET, FILE_ID)).thenThrow(new java.io.FileNotFoundException());

        Response response = jaxRsSupport.proxyHeaderResponse(authenticator, TENANT_ID, BUCKET, FILE_ID);

        assertNotNull(response);
        assertEquals(404, response.getStatus());
    }

    @Test
    @SuppressWarnings("deprecation")
    void proxyFileResponse_withHeaderMapper_removesContentTypeHeader() throws Exception {
        when(httpClient.execute(any(HttpGet.class))).thenReturn(httpResponse);
        when(httpResponse.getCode()).thenReturn(200);
        when(httpResponse.getEntity()).thenReturn(httpEntity);
        when(httpEntity.getContent()).thenReturn(new ByteArrayInputStream("xyz".getBytes()));

        Header contentType = mock(Header.class);
        when(contentType.getName()).thenReturn(HttpHeaders.CONTENT_TYPE);
        when(contentType.getValue()).thenReturn("application/json");
        when(httpResponse.getHeader(HttpHeaders.CONTENT_TYPE)).thenReturn(contentType);

        when(httpResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION)).thenReturn(null);
        when(httpResponse.getHeader(HttpHeaders.CONTENT_ENCODING)).thenReturn(null);
        when(httpResponse.getHeader(HttpHeaders.LAST_MODIFIED)).thenReturn(null);

        Response response = jaxRsSupport.proxyFileResponse(
            authenticator,
            TENANT_ID,
            BUCKET,
            FILE_ID,
            (name, value) -> HttpHeaders.CONTENT_TYPE.equals(name) ? null : value
        );

        assertNotNull(response);
        assertEquals(200, response.getStatus());
        assertNull(response.getHeaderString(HttpHeaders.CONTENT_TYPE));
    }
}
