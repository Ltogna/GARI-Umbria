package com.abacogroup.filestore.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.hc.core5.net.URIBuilder;

final class Utils {
	public static final String PUBLIC_V1_FILES = "/public/v1/files";

	private static final int BUF_SIZE_BYTES = 4096;

	private Utils() {
	}

	static URI buildAndWrapException(URIBuilder builder) {
		try {
			return builder.build();
		} catch (URISyntaxException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	/**
	 * @param in
	 *            the InputStream to read from
	 * @param out
	 *            the OutputStream to write to
	 * @return The number of written bytes
	 * @throws IOException
	 */
	static long stream2stream(InputStream in, OutputStream out) throws IOException {
		byte[] buf = new byte[BUF_SIZE_BYTES];
		long totalWritten = 0;
		int len;
		while ((len = in.read(buf)) != -1) {
			out.write(buf, 0, len);
			totalWritten += len;
		}
		return totalWritten;
	}

}
