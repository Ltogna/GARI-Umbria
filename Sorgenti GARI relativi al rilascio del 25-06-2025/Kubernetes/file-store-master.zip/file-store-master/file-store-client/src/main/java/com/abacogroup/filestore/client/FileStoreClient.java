package com.abacogroup.filestore.client;

import static com.abacogroup.filestore.client.Utils.PUBLIC_V1_FILES;
import static com.abacogroup.filestore.client.Utils.buildAndWrapException;
import static com.abacogroup.filestore.client.Utils.stream2stream;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.file.Files;
import java.time.Instant;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpHead;
import org.apache.hc.client5.http.classic.methods.HttpPatch;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.config.ConnectionConfig;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.entity.mime.InputStreamBody;
import org.apache.hc.client5.http.entity.mime.MultipartEntityBuilder;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.ContentType;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.HttpHeaders;
import org.apache.hc.core5.http.ProtocolException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.http.io.entity.HttpEntities;
import org.apache.hc.core5.net.URIBuilder;
import org.apache.hc.core5.pool.PoolConcurrencyPolicy;
import org.apache.hc.core5.pool.PoolReusePolicy;
import org.apache.hc.core5.util.Timeout;

import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.request.FileToAddMetadata;
import com.abacogroup.filestore.client.response.AddFileResponse;
import com.abacogroup.filestore.client.response.FileMetadata;
import com.abacogroup.tracing.httpclient5.AddRequestId;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileStoreClient implements AutoCloseable, JaxRsSupportDataProvider {

	private URI baseURL;
	private ObjectMapper mapper;

	private PoolingHttpClientConnectionManager connectionManager;
	private CloseableHttpClient client;
	private CloseableHttpClient noCompressionClient;

	private ThreadPoolExecutor executor;

	/**
	 * Creates a FileStoreClient
	 *
	 * @param baseURL
	 *            the file store base url (i.e.: http://file-store:8080/file-store
	 * @param mapper
	 *            the object mapper to handle json data
	 */
	public FileStoreClient(URI baseURL, ObjectMapper mapper) {
		Objects.requireNonNull(baseURL, "Invalid baseURL");

		this.baseURL = baseURL;
		this.mapper = mapper;

		init();
	}

	private void init() {
		connectionManager = PoolingHttpClientConnectionManagerBuilder.create()
				.setMaxConnPerRoute(100)
				.setMaxConnTotal(200)
				.setPoolConcurrencyPolicy(PoolConcurrencyPolicy.STRICT)
				.setConnPoolPolicy(PoolReusePolicy.LIFO)
				.setDefaultConnectionConfig(ConnectionConfig.custom()
						.setConnectTimeout(5, TimeUnit.SECONDS)
						.setTimeToLive(5, TimeUnit.MINUTES)
						.setValidateAfterInactivity(1, TimeUnit.MINUTES)
						.build())
				.build();

		var requestConfig = RequestConfig.custom()
				.setConnectionRequestTimeout(Timeout.ofSeconds(2))
				.setResponseTimeout(Timeout.ofSeconds(30))
				.setProtocolUpgradeEnabled(false)
				.build();

		client = HttpClientBuilder.create()
				.setConnectionManager(connectionManager)
				.setDefaultRequestConfig(requestConfig)
				.addRequestInterceptorFirst(new AddRequestId())
				.setRetryStrategy(new RequestRetryStrategy())
				.build();

		noCompressionClient = HttpClientBuilder.create()
				.setConnectionManager(connectionManager)
				.setDefaultRequestConfig(requestConfig)
				.addRequestInterceptorFirst(new AddRequestId())
				.setRetryStrategy(new RequestRetryStrategy())
				.disableContentCompression()
				.build();

		executor = new ThreadPoolExecutor(0, 25,
				60L, TimeUnit.SECONDS,
				new SynchronousQueue<Runnable>());
	}

	@Override
	public void close() throws IOException {
		executor.shutdown();

		close(client);
		close(noCompressionClient);
		close(connectionManager);
	}

	private void close(Closeable c) throws IOException {
		if (c != null) {
			c.close();
		}
	}

	/**
	 * Access to JAX-RS specific utilities
	 *
	 * @return jaxrs supporting utilities
	 */
	public JaxRsSupport jaxrs() {
		return new JaxRsSupport(baseURL, noCompressionClient, this);
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param file
	 *            the file to write
	 * @return the added file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public AddFileResponse addFile(Authenticator authenticator, String tenantId, String bucket, File file) throws IOException {
		if (!file.exists()) {
			throw new IOException(String.format("file %s does not exist", file.getAbsolutePath()));
		}
		if (!file.canRead()) {
			throw new IOException(String.format("file %s is not readable", file.getAbsolutePath()));
		}

		String mimeType = Files.probeContentType(file.toPath());
		if (mimeType == null) {
			mimeType = "application/octet-stream";
		}

		return addFile(authenticator, tenantId, bucket, new FileToAddMetadata(file.getName(), mimeType), new FileInputStream(file));
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param file
	 *            the file to write
	 * @return the added file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public Future<AddFileResponse> addFileAsync(Authenticator authenticator, String tenantId, String bucket, File file) {
		return executor.submit(() -> addFile(authenticator, tenantId, bucket, file));
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param file
	 *            the file to write
	 * @param alias
	 *            the file alias; this can be used instead of the automatically generated ID; it is your responsibility to avoid duplicates at bucket level
	 * @return the added file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public AddFileResponse addFile(Authenticator authenticator, String tenantId, String bucket, File file, String alias) throws IOException {
		if (!file.exists()) {
			throw new IOException(String.format("file %s does not exist", file.getAbsolutePath()));
		}
		if (!file.canRead()) {
			throw new IOException(String.format("file %s is not readable", file.getAbsolutePath()));
		}

		String mimeType = Files.probeContentType(file.toPath());
		if (mimeType == null) {
			mimeType = "application/octet-stream";
		}

		return addFile(authenticator, tenantId, bucket, new FileToAddMetadata(file.getName(), mimeType, null, alias), new FileInputStream(file));
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param file
	 *            the file to write
	 * @param alias
	 *            the file alias; this can be used instead of the automatically generated ID; it is your responsibility to avoid duplicates at bucket level
	 * @return the added file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public Future<AddFileResponse> addFileAsync(Authenticator authenticator, String tenantId, String bucket, File file, String alias) {
		return executor.submit(() -> addFile(authenticator, tenantId, bucket, file));
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param metadata
	 *            the file metadata to write to the store
	 * @param in
	 *            the input stream to read from; the input stream will be closed by this method, before return
	 * @return the added file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public AddFileResponse addFile(Authenticator authenticator, String tenantId, String bucket, FileToAddMetadata metadata, InputStream in)
			throws IOException {
		try (in) {
			HttpPost post = new HttpPost(buildAndWrapException(new URIBuilder(baseURL)
					.appendPath(tenantId)
					.appendPath(PUBLIC_V1_FILES)
					.appendPath(bucket)));

			if (metadata.getDeleteAfterMins() != null && metadata.getDeleteAfterMins() > 0) {
				post.addHeader("X-FS-DeleteAfterMins", metadata.getDeleteAfterMins());
			}

			if (metadata.getAlias() != null && !metadata.getAlias().isBlank()) {
				post.addHeader("X-FS-Alias", metadata.getAlias());
			}

			authenticator.accept(post);

			InputStreamBody bin = new InputStreamBody(in, ContentType.create(metadata.getMimeType()), metadata.getName());
			MultipartEntityBuilder builder = MultipartEntityBuilder.create()
					.addPart("file", bin);

			post.setEntity(builder.build());

			return client.execute(post, response -> {
				check2xx(response);

				HttpEntity resEntity = response.getEntity();
				var json = EntityUtils.toString(resEntity);

				return mapper.readValue(json, AddFileResponse.class);
			});
		}
	}

	/**
	 * Adds a file to the store
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to write to
	 * @param metadata
	 *            the file metadata to write to the store
	 * @param in
	 *            the input stream to read from; the input stream will be closed by this method, before the async operation ends
	 * @return the added file id
	 */
	public Future<AddFileResponse> addFileAsync(Authenticator authenticator, String tenantId, String bucket, FileToAddMetadata metadata, InputStream in) {
		return executor.submit(() -> addFile(authenticator, tenantId, bucket, metadata, in));
	}

	public AddFileResponse linkFile(Authenticator authenticator, String tenantId, String sourceBucket, String fileId,
			String destinationBucket, String newFileName) throws IOException {

		if (newFileName != null && newFileName.isBlank()) {
			throw new IllegalArgumentException("New file name must not be blank");
		}

		HttpPost post = new HttpPost(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(sourceBucket)
				.appendPath(fileId)
				.appendPath("link-to")
				.appendPath(destinationBucket)));

		if (newFileName != null) {
			post.setHeader("X-FS-FileName", newFileName);
		}

		authenticator.accept(post);

		return client.execute(post, response -> {
			if (response.getCode() == 404) {
				throw new FileNotFoundException(tenantId + '/' + sourceBucket + '/' + fileId);
			}
			if (response.getCode() == 412) {
				throw new FileNotFoundException(tenantId + '/' + sourceBucket + '/' + fileId + " is temporary");
			}

			check2xx(response);

			String json;
			try (HttpEntity resEntity = response.getEntity()) {
				json = EntityUtils.toString(resEntity);
			}

			return mapper.readValue(json, AddFileResponse.class);
		});

	}

	public AddFileResponse linkFile(Authenticator authenticator, String tenantId, String sourceBucket, String fileId, String destinationBucket)
			throws IOException {
		return linkFile(authenticator, tenantId, sourceBucket, fileId, destinationBucket, null);
	}

	@Override
	public FileMetadata getFileMetadata(Authenticator authenticator, String tenantId, String bucket, String id) throws IOException, FileNotFoundException {
		HttpHead head = new HttpHead(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(bucket)
				.appendPath(id)));

		authenticator.accept(head);

		return client.execute(head, response -> {
			if (response.getCode() == 404) {
				throw new FileNotFoundException(tenantId + '/' + bucket + '/' + id);
			}
			check2xx(response);
			return createFileMetadata(id, response);
		});
	}

	/**
	 * Get a file metadata
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to read from
	 * @param id
	 *            the file id
	 * @return the file metadata
	 */
	public Future<FileMetadata> getFileMetadataAsync(Authenticator authenticator, String tenantId, String bucket, String id) {
		return executor.submit(() -> getFileMetadata(authenticator, tenantId, bucket, id));
	}

	/**
	 * Streams all files metadata in a bucket. <b>The stream must be closed by the caller once done</b>
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket
	 * @param limit
	 *            the maximum number of elements to return
	 * @return a {@link Stream} of files metadata
	 * @throws IOException
	 */
	public Stream<FileMetadata> streamFileMetadata(Authenticator authenticator, String tenantId, String bucket, long limit) throws IOException {
		HttpGet get = new HttpGet(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(bucket)
				.addParameter("limit", String.valueOf(limit))));
		get.setHeader(HttpHeaders.ACCEPT, "application/jsonl");

		authenticator.accept(get);

		@SuppressWarnings("deprecation")
		CloseableHttpResponse response = client.execute(get);
		if (response.getCode() < 200 || response.getCode() > 299) {
			response.close();
			throw new IllegalStateException("Expected status code of 2xx but got " + response.getCode());
		}

		FileMetadataSpliterator spliterator = new FileMetadataSpliterator(response, mapper);
		Stream<FileMetadata> ret = StreamSupport.stream(spliterator, false);
		ret.onClose(spliterator::close);

		return ret;
	}

	/**
	 * Streams all files metadata in a bucket. <b>The stream must be closed by the caller once done</b>
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket
	 * @return a {@link Stream} of files metadata
	 * @throws IOException
	 */
	public Stream<FileMetadata> streamFileMetadata(Authenticator authenticator, String tenantId, String bucket) throws IOException {
		return streamFileMetadata(authenticator, tenantId, bucket, -1);
	}

	private FileMetadata createFileMetadata(String id, ClassicHttpResponse response) throws ProtocolException {
		var fileName = getFilenameFromResponse(response);
		var mimeType = getHeaderValue(response, HttpHeaders.CONTENT_TYPE);
		var len = getHeaderValue(response, HttpHeaders.CONTENT_LENGTH).map(Long::parseLong);
		var isTemp = getHeaderValue(response, "X-Temporary-File").map(Boolean::parseBoolean);
		var lastModified = getHeaderValue(response, HttpHeaders.LAST_MODIFIED)
				.map(str -> DateTimeFormatter.RFC_1123_DATE_TIME.parse(str))
				.map(Instant::from);

		return new FileMetadata()
				.withDate(lastModified)
				.withId(id)
				.withIsTemporary(isTemp)
				.withMimeType(mimeType)
				.withName(fileName)
				.withSize(len);
	}

	/**
	 * Get a file content
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket id to read from
	 * @param id
	 *            the file id
	 * @param out
	 *            the OutputStream to write the content to; this will be closed before return
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public void getFileContent(Authenticator authenticator, String tenantId, String bucket, String id, OutputStream out) throws IOException {
		try (out) {
			HttpGet get = new HttpGet(buildAndWrapException(new URIBuilder(baseURL)
					.appendPath(tenantId)
					.appendPath(PUBLIC_V1_FILES)
					.appendPath(bucket)
					.appendPath(id)));

			authenticator.accept(get);

			client.execute(get, response -> {
				if (response.getCode() == 404) {
					throw new FileNotFoundException(tenantId + '/' + bucket + '/' + id);
				}
				check2xx(response);

				HttpEntity entity = response.getEntity();
				try (var in = entity.getContent()) {
					if (in == null) {
						return null;
					}
					stream2stream(in, out);
				}

				return null;
			});
		}
	}

	/**
	 * Get a zip package of the requested files
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket id to read from
	 * @param fileIds
	 *            the file ids
	 * @param out
	 *            the OutputStream to write the content to; this will be closed before return
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public void getZip(Authenticator authenticator, String tenantId, String bucket, List<String> fileIds, OutputStream out) throws IOException {
		try (out) {
			HttpPost post = new HttpPost(buildAndWrapException(new URIBuilder(baseURL)
					.appendPath(tenantId)
					.appendPath(PUBLIC_V1_FILES)
					.appendPath(bucket)
					.appendPath("compressed/zip")));

			authenticator.accept(post);

			var body = HttpEntities.create(mapper.writeValueAsString(fileIds), ContentType.APPLICATION_JSON);
			post.setEntity(body);

			client.execute(post, response -> {
				if (response.getCode() == 404) {
					throw new FileNotFoundException("At least one of the reqested files was not found");
				}
				check2xx(response);

				HttpEntity entity = response.getEntity();
				try (var in = entity.getContent()) {
					if (in == null) {
						return null;
					}
					stream2stream(in, out);
				}

				return null;
			});
		}
	}

	public AddFileResponse produceAndAddZipFile(Authenticator authenticator, String tenantId, String sourceBucket, String destinationBucket,
			List<String> fileIds, OutputStream out)
			throws IOException {
		HttpPost post = new HttpPost(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(sourceBucket)
				.appendPath("compressed/zip")
				.appendPath(destinationBucket)));

		authenticator.accept(post);

		var body = HttpEntities.create(mapper.writeValueAsString(fileIds), ContentType.APPLICATION_JSON);
		post.setEntity(body);

		return client.execute(post, response -> {
			if (response.getCode() == 404) {
				throw new FileNotFoundException("At least one of the reqested files was not found");
			}
			check2xx(response);

			HttpEntity resEntity = response.getEntity();
			String json = EntityUtils.toString(resEntity);

			return mapper.readValue(json, AddFileResponse.class);
		});
	}

	/**
	 * Get a file content
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket id to read from
	 * @param id
	 *            the file id
	 * @param out
	 *            the OutputStream to write the content to; this will be closed before the async operation ends
	 */
	public Future<Void> getFileContentAsync(Authenticator authenticator, String tenantId, String bucket, String id, OutputStream out) {
		return executor.submit(() -> {
			getFileContent(authenticator, tenantId, bucket, id, out);
			return null;
		});
	}

	/**
	 * Makes a temporary file permanent
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket id to write to
	 * @param id
	 *            the file id
	 * @throws IOException
	 *             if anything goes wrong
	 */
	public void makePermanent(Authenticator authenticator, String tenantId, String bucket, String id) throws IOException {
		HttpPatch patch = new HttpPatch(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(bucket)
				.appendPath(id)));

		authenticator.accept(patch);

		var entity = HttpEntities.create("{\"temporary\":false}", ContentType.APPLICATION_JSON);
		patch.setEntity(entity);

		client.execute(patch, response -> {
			if (response.getCode() == 404) {
				throw new FileNotFoundException(tenantId + '/' + bucket + '/' + id);
			}
			check2xx(response);
			return null;
		});
	}

	/**
	 * Makes a temporary file permanent
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket id to write to
	 * @param id
	 *            the file id
	 */
	public Future<Void> makePermanentAsync(Authenticator authenticator, String tenantId, String bucket, String id) {
		return executor.submit(() -> {
			makePermanent(authenticator, tenantId, bucket, id);
			return null;
		});
	}

	private Optional<String> getFilenameFromResponse(ClassicHttpResponse response) throws ProtocolException {
		var disposition = response.getHeader(HttpHeaders.CONTENT_DISPOSITION);
		if (disposition == null || disposition.getValue().isEmpty()) {
			return Optional.empty();
		}

		String ret = null;
		String[] tokens = disposition.getValue().split(";");
		for (var token : tokens) {
			token = token.trim();
			if (!token.startsWith("filename")) {
				continue;
			}

			int pos = token.indexOf('=');
			if (pos == -1) {
				continue;
			}

			ret = removeQuotes(token.substring(pos + 1));

			// rfc5987
			pos = token.indexOf("filename*=");
			if (pos > -1) {
				int ampPos = ret.indexOf("''");
				String enc = ret.substring(0, ampPos).trim();
				try {
					ret = URLDecoder.decode(ret.substring(ampPos + 2), enc);
					break; // filename*=.... wins over filename=.... regardles which one comes first
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException(e);
				}
			}

		}

		return Optional.ofNullable(ret);
	}

	private Optional<String> getHeaderValue(ClassicHttpResponse response, String headerName) throws ProtocolException {
		var disposition = response.getHeader(headerName);
		if (disposition == null || disposition.getValue().isEmpty()) {
			return Optional.empty();
		}

		return Optional.of(disposition.getValue());
	}

	private String removeQuotes(String str) {
		if (str == null || str.isEmpty()) {
			return str;
		}

		if (str.startsWith("\"") && str.endsWith("\"")) {
			str = str.substring(1, str.length() - 1);
		}

		return str;
	}

	private void check2xx(ClassicHttpResponse response) throws HttpException {
		if (response.getCode() < 200 || response.getCode() > 299) {
			throw new HttpException("Expected status code of 2xx but got " + response.getCode());
		}
	}
}
