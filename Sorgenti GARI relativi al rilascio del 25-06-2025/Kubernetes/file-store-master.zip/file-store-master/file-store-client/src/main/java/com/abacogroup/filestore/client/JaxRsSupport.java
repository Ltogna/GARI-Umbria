package com.abacogroup.filestore.client;

import static com.abacogroup.filestore.client.Utils.PUBLIC_V1_FILES;
import static com.abacogroup.filestore.client.Utils.buildAndWrapException;
import static com.abacogroup.filestore.client.Utils.stream2stream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.function.BiFunction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.core5.http.Header;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.HttpHeaders;
import org.apache.hc.core5.http.ProtocolException;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.net.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.response.FileMetadata;

import jakarta.ws.rs.WebApplicationException;
import jakarta.ws.rs.core.CacheControl;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.ResponseBuilder;
import jakarta.ws.rs.core.StreamingOutput;

public final class JaxRsSupport {
	private static final Logger log = LoggerFactory.getLogger(JaxRsSupport.class);
	Pattern extensionPattern = Pattern.compile("attachment; filename=\\\".*(\\.[^\"]+)\\\";");

	private URI baseURL;
	private CloseableHttpClient noCompressionClient;
	private JaxRsSupportDataProvider provider;

	JaxRsSupport(URI baseURL, CloseableHttpClient noCompressionClient, JaxRsSupportDataProvider provider) {
		this.baseURL = baseURL;
		this.noCompressionClient = noCompressionClient;
		this.provider = provider;
	}

	/**
	 * Proxies file content from the remote repository to the JAX-RS response
	 *
	 * @param authenticator
	 *            the authenticator.
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket name
	 * @param id
	 *            the file id
	 * @return a JAX-RS response that streams file content to the caller
	 * @throws IOException
	 */
	public Response proxyFileResponse(Authenticator authenticator, String tenantId, String bucket, String id) throws IOException {
		try {
			return doProxyFileResponse(authenticator, tenantId, bucket, id, (name, value) -> value);
		} catch (ProtocolException | IOException e) {
			throw new IOException(e.getMessage(), e);
		}
	}

	/**
	 * Proxies file content from the remote repository to the JAX-RS response
	 *
	 * @param authenticator
	 *            the authenticator.
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket name
	 * @param id
	 *            the file id
	 * @param expectedFileNameNoExt
	 * 		  the expected file name without extension, used to set the Content-Disposition header
	 * @return a JAX-RS response that streams file content to the caller
	 * @throws IOException
	 */
	public Response proxyFileResponse(Authenticator authenticator, String tenantId, String bucket, String id, String expectedFileNameNoExt) throws IOException {
		if (StringUtils.isBlank(expectedFileNameNoExt)) {
			log.warn("ExpectedFileNameNoExt is blank, using default file name");
			return proxyFileResponse(authenticator, tenantId, bucket, id);
		}
		try {
			Response r = doProxyFileResponse(authenticator, tenantId, bucket, id, (name, value) -> value);
			String contentDisposition = r.getHeaderString(HttpHeaders.CONTENT_DISPOSITION);
			String filenameToStore = expectedFileNameNoExt;
			if (contentDisposition != null) {
				r.getHeaders().remove(HttpHeaders.CONTENT_DISPOSITION);
				Matcher matcher = extensionPattern.matcher(contentDisposition);				
				if (matcher.find()) {
					String ext = matcher.group(1);
					if (!StringUtils.isBlank(ext)){
						filenameToStore = expectedFileNameNoExt + ext;
					}
				}
			} 
			r.getHeaders().add(HttpHeaders.CONTENT_DISPOSITION, fileNameToContentDisposition(filenameToStore));
			return r;
		} catch (ProtocolException | IOException e) {
			throw new IOException(e.getMessage(), e);
		}
	}	

	/**
	 * Proxies file content from the remote repository to the JAX-RS response
	 *
	 * @param authenticator
	 *            the authenticator.
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket name
	 * @param id
	 *            the file id
	 * @param headerMapper
	 *            a Function that can change the default headers; inputs are: headerName, headerValue and the result is the mapped headerValue. Returning null
	 *            will remove the header.
	 * @return a JAX-RS response that streams file content to the caller
	 * @throws IOException
	 */
	public Response proxyFileResponse(Authenticator authenticator, String tenantId, String bucket, String id, BiFunction<String, String, String> headerMapper)
			throws IOException {
		try {
			return doProxyFileResponse(authenticator, tenantId, bucket, id, headerMapper);
		} catch (ProtocolException | IOException e) {
			throw new IOException(e.getMessage(), e);
		}
	}

    /**
	 * Given a filename, generates a content disposition header value while handling UTF-8 filenames
	 * 
	 * @implNote this method duplicates the work of the file-store-server because we don't want to modify the {@link JaxRsSupportDataProvider} interface
	 * 
	 * @param fileName the filename in UTF-8
	 * @return the content disposition header value
	 * 
	 */
	private String fileNameToContentDisposition(String fileName) {
		return "attachment; filename=\"" + fileName + "\"; filename*=UTF-8''"
								+ URLEncoder.encode(fileName, StandardCharsets.UTF_8);
	}

	/**
	 * Proxies file heades from the remote repository to the JAX-RS response
	 *
	 * @param authenticator
	 *            the authenticator.
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket name
	 * @param id
	 *            the file id
	 * @return a JAX-RS response that sets the file response heades
	 * @throws IOException
	 */
	public Response proxyHeaderResponse(Authenticator authenticator, String tenantId, String bucket, String id) throws IOException {
		try {
			FileMetadata metadata = provider.getFileMetadata(authenticator, tenantId, bucket, id);
			return Response.ok()
					.cacheControl(new CacheControl())
					
					.header(HttpHeaders.CONTENT_DISPOSITION, fileNameToContentDisposition(metadata.getName()))
					.header(HttpHeaders.CONTENT_LENGTH, metadata.getSize())
					.header(HttpHeaders.CONTENT_TYPE, metadata.getMimeType())
					.header(HttpHeaders.ETAG, tenantId + '/' + bucket + '/' + id)
					.header(HttpHeaders.LAST_MODIFIED, metadata.getDate())
					.build();
		} catch (FileNotFoundException e) {
			return Response.status(404).build();
		}
	}

	private Response doProxyFileResponse(Authenticator authenticator, String tenantId, String bucket, String id,
			BiFunction<String, String, String> headerMapper) throws IOException, ProtocolException {
		HttpGet get = new HttpGet(buildAndWrapException(new URIBuilder(baseURL)
				.appendPath(tenantId)
				.appendPath(PUBLIC_V1_FILES)
				.appendPath(bucket)
				.appendPath(id)));
		get.addHeader("Accept-Encoding", "gzip");

		authenticator.accept(get);

		@SuppressWarnings("deprecation")
		CloseableHttpResponse response = noCompressionClient.execute(get);
		HttpEntity entity = response.getEntity();
		if (response.getCode() != 200) {
			if (log.isWarnEnabled()) {
				log.warn("Error downloading content for {}/{}/{}: status = {} {}, body = {}",
						tenantId, bucket, id,
						response.getCode(), response.getReasonPhrase(),
						EntityUtils.toString(entity));
			}

			EntityUtils.consume(entity);
			response.close();
			throw new WebApplicationException(response.getReasonPhrase(), response.getCode());
		}

		var streaming = new StreamingOutput() {
			@Override
			public void write(OutputStream output) throws IOException, WebApplicationException {
				try (var in = entity.getContent()) {
					if (in != null) {
						stream2stream(in, output);
					}
				} finally {
					response.close();
				}
			}
		};

		var builder = Response.ok(streaming);

		setHeader(builder, response.getHeader(HttpHeaders.CONTENT_TYPE), headerMapper);
		setHeader(builder, response.getHeader(HttpHeaders.CONTENT_DISPOSITION), headerMapper);
		setHeader(builder, response.getHeader(HttpHeaders.CONTENT_ENCODING), headerMapper);
		setHeader(builder, response.getHeader(HttpHeaders.LAST_MODIFIED), headerMapper);

		return builder
				.header(HttpHeaders.ETAG, tenantId + '/' + bucket + '/' + id)
				.cacheControl(new CacheControl())
				.build();
	}

	private void setHeader(ResponseBuilder builder, Header header, BiFunction<String, String, String> headerMapper) {
		if (header == null) {
			return;
		}

		String value = headerMapper.apply(header.getName(), header.getValue());
		if (value != null) {
			builder.header(header.getName(), value);
		}
	}

}
