package com.abacogroup.filestore.client;

import java.io.FileNotFoundException;
import java.io.IOException;

import com.abacogroup.filestore.client.auth.Authenticator;
import com.abacogroup.filestore.client.response.FileMetadata;

public interface JaxRsSupportDataProvider {

	/**
	 * Get a file metadata
	 *
	 * @param authenticator
	 *            the authenticator used to authorize users
	 * @param tenantId
	 *            the tenant id
	 * @param bucket
	 *            the bucket to read from
	 * @param id
	 *            the file id
	 * @return the file metadata
	 * @throws IOException
	 *             if anything goes wrong
	 * @throws FileNotFoundException
	 *             if the file is not present in the bucket
	 */
	public FileMetadata getFileMetadata(Authenticator authenticator, String tenantId, String bucket, String id) throws IOException, FileNotFoundException;
}
