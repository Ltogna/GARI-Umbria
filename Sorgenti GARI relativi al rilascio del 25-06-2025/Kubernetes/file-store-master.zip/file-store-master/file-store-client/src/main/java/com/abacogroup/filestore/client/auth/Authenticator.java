package com.abacogroup.filestore.client.auth;

import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;

public interface Authenticator {

	void accept(HttpUriRequestBase request);

}
