package com.abacogroup.filestore.client.response;

public class AddFileResponse {
	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
