package com.abacogroup.filestore.client.request;

public class FileToAddMetadata {
	private String name;
	private String mimeType;
	private Integer deleteAfterMins;
	private String alias;

	public FileToAddMetadata(String name, String mimeType, Integer deleteAfterMins, String alias) {
		this.name = name;
		this.mimeType = mimeType;
		this.deleteAfterMins = deleteAfterMins;
		this.alias = alias;
	}

	public FileToAddMetadata(String name, String mimeType, Integer deleteAfterMins) {
		this(name, mimeType, deleteAfterMins, null);
	}

	public FileToAddMetadata(String name, String mimeType) {
		this(name, mimeType, null);
	}

	public String getName() {
		return name;
	}

	public String getAlias() {
		return alias;
	}

	public String getMimeType() {
		return mimeType;
	}

	public Integer getDeleteAfterMins() {
		return deleteAfterMins;
	}

}
