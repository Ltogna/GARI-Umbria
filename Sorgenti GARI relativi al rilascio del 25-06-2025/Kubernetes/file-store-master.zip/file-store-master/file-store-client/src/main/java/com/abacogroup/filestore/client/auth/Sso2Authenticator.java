package com.abacogroup.filestore.client.auth;

import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;

import com.abacogroup.dropwizard.auth.sso2.User;

public class Sso2Authenticator implements Authenticator {

	private final User user;

	public Sso2Authenticator(User user) {
		this.user = user;
	}

	@Override
	public void accept(HttpUriRequestBase request) {
		request.addHeader("Authorization", "JWT " + user.getAuthToken());
	}

}
