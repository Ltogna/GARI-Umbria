package com.abacogroup.filestore.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;
import java.util.Spliterator;
import java.util.function.Consumer;

import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.HttpEntity;
import org.apache.hc.core5.http.io.entity.EntityUtils;

import com.abacogroup.filestore.client.response.FileMetadata;
import com.fasterxml.jackson.databind.ObjectMapper;

public final class FileMetadataSpliterator implements AutoCloseable, Spliterator<FileMetadata> {
	private ClassicHttpResponse response;
	private HttpEntity entity;
	private ObjectMapper mapper;
	private BufferedReader reader;

	@SuppressWarnings("resource")
	FileMetadataSpliterator(ClassicHttpResponse response, ObjectMapper mapper) throws IOException {
		this.response = Objects.requireNonNull(response);
		this.entity = response.getEntity();
		this.mapper = mapper;
		this.reader = new BufferedReader(new InputStreamReader(entity.getContent()));
	}

	@Override
	public boolean tryAdvance(Consumer<? super FileMetadata> action) {
		try {
			String line = reader.readLine();
			if (line == null) {
				return false;
			}

			var fileMetadata = mapper.readValue(line, FileMetadata.class);
			action.accept(fileMetadata);

			return true;
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	@Override
	public void close() {
		try {
			if (reader != null) {
				reader.close();
			}

			if (entity != null) {
				EntityUtils.consume(entity);
				entity.close();
			}
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}

		try {
			response.close();
		} catch (IOException e) {
			throw new IllegalStateException(e.getMessage(), e);
		}
	}

	@Override
	public Spliterator<FileMetadata> trySplit() {
		return null;
	}

	@Override
	public long estimateSize() {
		return Long.MAX_VALUE;
	}

	@Override
	public int characteristics() {
		return Spliterator.DISTINCT
				| Spliterator.NONNULL
				| Spliterator.IMMUTABLE;
	}

}
