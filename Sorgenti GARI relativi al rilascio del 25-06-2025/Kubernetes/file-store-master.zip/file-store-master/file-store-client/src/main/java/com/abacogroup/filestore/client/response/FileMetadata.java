package com.abacogroup.filestore.client.response;

import java.time.Instant;
import java.util.Optional;

public class FileMetadata {
	private String id;
	private String name;
	private String mimeType;
	private Long size;
	private Instant date;
	private Optional<Boolean> temporary;

	public FileMetadata withId(String id) {
		this.id = id;
		return this;
	}

	public FileMetadata withName(Optional<String> opt) {
		this.name = opt.orElse(null);
		return this;
	}

	public FileMetadata withMimeType(Optional<String> opt) {
		this.mimeType = opt.orElse(null);
		return this;
	}

	public FileMetadata withSize(Optional<Long> opt) {
		this.size = opt.orElse(null);
		return this;
	}

	public FileMetadata withDate(Optional<Instant> opt) {
		this.date = opt.orElse(null);
		return this;
	}

	public FileMetadata withIsTemporary(Optional<Boolean> temporary) {
		this.temporary = temporary;
		return this;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public Instant getDate() {
		return date;
	}

	public void setDate(Instant date) {
		this.date = date;
	}

	public Optional<Boolean> getTemporary() {
		return temporary;
	}

	public void setTemporary(Optional<Boolean> temporary) {
		this.temporary = temporary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((mimeType == null) ? 0 : mimeType.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		result = prime * result + ((temporary == null) ? 0 : temporary.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FileMetadata other = (FileMetadata) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (mimeType == null) {
			if (other.mimeType != null)
				return false;
		} else if (!mimeType.equals(other.mimeType))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (size == null) {
			if (other.size != null)
				return false;
		} else if (!size.equals(other.size))
			return false;
		if (temporary == null) {
			if (other.temporary != null)
				return false;
		} else if (!temporary.equals(other.temporary))
			return false;
		return true;
	}

}
