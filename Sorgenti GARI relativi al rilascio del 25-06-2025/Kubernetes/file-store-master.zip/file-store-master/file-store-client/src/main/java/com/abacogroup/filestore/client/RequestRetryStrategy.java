package com.abacogroup.filestore.client;

import java.io.IOException;
import java.net.ConnectException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.hc.client5.http.HttpRequestRetryStrategy;
import org.apache.hc.core5.http.ConnectionClosedException;
import org.apache.hc.core5.http.HttpRequest;
import org.apache.hc.core5.http.HttpResponse;
import org.apache.hc.core5.http.NoHttpResponseException;
import org.apache.hc.core5.http.protocol.HttpContext;
import org.apache.hc.core5.util.TimeValue;

public class RequestRetryStrategy implements HttpRequestRetryStrategy {

	private static final TimeValue RETRY_INTERVAL = TimeValue.of(500, TimeUnit.MILLISECONDS);
	private static List<Class<? extends IOException>> RETRY_ERRORS = List.of(NoHttpResponseException.class,
			ConnectException.class,
			ConnectionClosedException.class);

	@Override
	public boolean retryRequest(HttpRequest request, IOException exception, int execCount, HttpContext context) {
		if (execCount >= 2) {
			return false;
		}

		for (var c : RETRY_ERRORS) {
			if (c.isAssignableFrom(exception.getClass())) {
				return true;
			}
		}

		return false;
	}

	@Override
	public boolean retryRequest(HttpResponse response, int execCount, HttpContext context) {
		return false;
	}

	@Override
	public TimeValue getRetryInterval(HttpResponse response, int execCount, HttpContext context) {
		return RETRY_INTERVAL;
	}

}
