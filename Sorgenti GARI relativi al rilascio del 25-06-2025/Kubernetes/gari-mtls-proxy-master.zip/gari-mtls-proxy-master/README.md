# mTLS Proxy

## Convert a .p12 to .crt + .key

```sh
# Extract the key
openssl pkcs12 -in filename.pfx -nocerts -out filename.key

# Extract the certificate
openssl pkcs12 -in filename.pfx -clcerts -nokeys -out filename.crt 

# Remove password from key
openssl.exe rsa -in filenme.key -out filename.np.key
```

## Run envoy

Run envoy using:

```sh
docker run --rm -p 10000:10000 -p 9901:9901 -v %cd%\config.yaml:/etc/envoy/envoy.yaml -v %cd%\certs:/certs -it envoyproxy/envoy:v1.32-latest
```

Or, in debug mode:
```sh
docker run --rm -p 10000:10000 -p 9901:9901 -v %cd%\config.yaml:/etc/envoy/envoy.yaml -v %cd%\certs:/certs -it envoyproxy/envoy:v1.32-latest -l debug -c /etc/envoy/envoy.yaml
```