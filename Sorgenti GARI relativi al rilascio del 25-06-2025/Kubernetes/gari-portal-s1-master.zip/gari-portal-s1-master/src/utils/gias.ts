import { ErrorType, HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { z } from "zod";

const userData = getUserData()!;

export const GiasTokenResponseResponseSchema = z.nullable(
	z.object({
		message: z.string(),
		token: z.string(),
		baseURL: z.string(),
	})
);

export type GiasTokenResponse = z.infer<typeof GiasTokenResponseResponseSchema>;

export async function getGiasToken(
	http: HTTPClient,
	customizationPath: string
): Promise<GiasTokenResponse | null> {
	const customizationPathFn = customizationPath.replaceAll(
		"{tenant}",
		userData.tenant
	);
	const res = await http.getJson(
		GiasTokenResponseResponseSchema,
		customizationPathFn
	);
	if (res.errorType !== ErrorType.NONE) {
		const resany: any = res;
		if (resany.err && resany.err instanceof z.ZodError) {
			console.log(resany.err.issues);
		} else console.error(res);
		return null;
	}
	return res.data;
}

export const getGiasUsernameModelSchema = z.object({
	username: z.string(),
});

export const getGiasUsernameResponseSchema = z.nullable(
	getGiasUsernameModelSchema
);
export type getGiasUsernameResponse = z.infer<
	typeof getGiasUsernameResponseSchema
>;

// da caprie http da dove deve uscire
export async function getGiasUsername(
	http: HTTPClient,
	customizationPath: string
): Promise<getGiasUsernameResponse | null> {
	const customizationPathFn = customizationPath.replaceAll(
		"{tenant}",
		userData.tenant
	);
	const res = await http.getJson(
		getGiasUsernameResponseSchema,
		customizationPathFn
	);
	if (res.errorType !== ErrorType.NONE) {
		const resany: any = res;
		if (resany.err && resany.err instanceof z.ZodError) {
			console.log(resany.err.issues);
		} else console.error(res);
		return null;
	}
	return res.data;
}
