import { ErrorType, HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { userHasPermission, type User } from "@abaco/safe-rest/src/sso2";
import { z } from "zod";
import { i18nFromMap } from "../i18n";

const BaseMenuItemSchema = z
	.object({
		title: z.optional(z.string()).default(""),
		titleI18n: z.optional(z.record(z.string().min(1), z.string())),
		ssoFunctions: z.optional(z.array(z.string())),
		visibility: z.optional(z.boolean()),
		tenantFilter: z.optional(z.array(z.string())),
	})
	.strict();

const ModuleLinkMenuItemSchema = BaseMenuItemSchema.extend({
	startRoute: z.string(),
	isHome: z.optional(z.boolean()),
	id: z.string(),
	script: z.string(),
}).strict();

const BuiltinLinkMenuItemSchema = BaseMenuItemSchema.extend({
	internalUrl: z.string(),
	isHome: z.optional(z.boolean()),
}).strict();

const ExternalLinkMenuItemSchema = BaseMenuItemSchema.extend({
	externalUrl: z.string(),
	externalUrlTarget: z.optional(z.string()),
}).strict();

const SubMenuItemSchema = BaseMenuItemSchema.extend({
	submenu: z
		.union([
			ModuleLinkMenuItemSchema,
			BuiltinLinkMenuItemSchema,
			ExternalLinkMenuItemSchema,
		])
		.array(), //z.optional(BaseMenuItemSchema.array())
}).strict();

const MenuSchema = z.object({
	portalName: z.string(),
	menu: z
		.union([
			SubMenuItemSchema,
			ModuleLinkMenuItemSchema,
			BuiltinLinkMenuItemSchema,
			ExternalLinkMenuItemSchema,
		])
		.array(),
});

export type MenuRoot = z.infer<typeof MenuSchema>;
export type ModuleLinkMenuItem = Omit<
	z.infer<typeof ModuleLinkMenuItemSchema>,
	"titleI18n"
>;
export type BuiltinLinkMenuItem = Omit<
	z.infer<typeof BuiltinLinkMenuItemSchema>,
	"titleI18n"
>;
export type ExternalLinkMenuItem = Omit<
	z.infer<typeof ExternalLinkMenuItemSchema>,
	"titleI18n"
>;

export type SubMenuItem = Omit<z.infer<typeof SubMenuItemSchema>, "titleI18n">;
export type MenuItem =
	| SubMenuItem
	| ModuleLinkMenuItem
	| BuiltinLinkMenuItem
	| ExternalLinkMenuItem;

type BaseMenuItem = z.infer<typeof BaseMenuItemSchema>;

export function isModuleLinkMenuItem(
	menuItem: MenuItem
): menuItem is ModuleLinkMenuItem {
	return (menuItem as ModuleLinkMenuItem).startRoute !== undefined;
}

export function isBuiltinLinkMenuItem(
	menuItem: MenuItem
): menuItem is BuiltinLinkMenuItem {
	return (menuItem as BuiltinLinkMenuItem).internalUrl !== undefined;
}

export function isExternalLinkMenuItem(
	menuItem: MenuItem
): menuItem is ExternalLinkMenuItem {
	return (menuItem as ExternalLinkMenuItem).externalUrl !== undefined;
}

export function isSubMenuItem(menuItem: MenuItem): menuItem is SubMenuItem {
	return (menuItem as SubMenuItem).submenu !== undefined;
}

export function getMenuUrl(
	menuItem: ModuleLinkMenuItem | BuiltinLinkMenuItem | ExternalLinkMenuItem
): string {
	if (isModuleLinkMenuItem(menuItem)) return menuItem.startRoute;
	if (isBuiltinLinkMenuItem(menuItem)) return menuItem.internalUrl;
	if (isExternalLinkMenuItem(menuItem)) return menuItem.externalUrl;
	return ""; //never!!
}

export async function loadMenu(
	userData: User,
	http: HTTPClient,
	customizationPath: string
): Promise<MenuRoot | null> {
	const res = await http.getJson(MenuSchema, customizationPath + "menu.json");
	if (res.errorType !== ErrorType.NONE) {
		const resany: any = res;
		if (resany.err && resany.err instanceof z.ZodError) {
			console.log(resany.err.issues);
		} else console.error(res);
		return null;
	}
	purgeMenu(userData, res.data.menu);
	return res.data;
}

export function getHomeUrl(menuItems: MenuItem[]): string | null {
	const m = getHomeMenuItem(menuItems);
	if (m && isModuleLinkMenuItem(m)) return m.startRoute;
	else if (m && isBuiltinLinkMenuItem(m)) return m.internalUrl;
	else return null;
}

export function getHomeMenuItem(
	menuItems: MenuItem[]
): BuiltinLinkMenuItem | ModuleLinkMenuItem | null {
	for (const menuel of menuItems) {
		if (isSubMenuItem(menuel)) {
			const ret = getHomeMenuItem(menuel.submenu);
			if (ret) return ret;
		} else if (
			(isBuiltinLinkMenuItem(menuel) || isModuleLinkMenuItem(menuel)) &&
			menuel.isHome &&
			menuel.visibility
		)
			return menuel;
	}

	return null;
}

function purgeMenu(userData: User, items: MenuItem[]): void {
	items.forEach(menuItem => {
		const basemenuitem = menuItem as BaseMenuItem;

		menuItem.title = i18nFromMap(basemenuitem.titleI18n, basemenuitem.title);

		menuItem.visibility = menuItem.visibility ?? true;

		if (menuItem.tenantFilter && menuItem.tenantFilter.length > 0) {
			if (
				userData &&
				userData.tenant &&
				!menuItem.tenantFilter.includes(userData.tenant)
			)
				menuItem.visibility = false;
		}

		if (menuItem.ssoFunctions) {
			let haveAtLeastOneSSOFunction = false;
			menuItem.ssoFunctions.forEach(ssoFunction => {
				const contextFunction = ssoFunction.split("|");
				if (userHasPermission(contextFunction[0], contextFunction[1]))
					haveAtLeastOneSSOFunction = true;
			});
			if (!haveAtLeastOneSSOFunction) menuItem.visibility = false;
		}

		if (isSubMenuItem(menuItem)) {
			purgeMenu(userData, menuItem.submenu);
			if (menuItem.visibility)
				menuItem.visibility =
					menuItem.submenu.find(
						submenuItem => submenuItem.visibility === true
					) !== undefined;
		}
	});
}
