import { onMounted, onBeforeUnmount, type Ref } from "vue";

export function useHeightObserver(
	cssCustomProp: string,
	element: Ref<HTMLElement | null>
) {
	const r = document.querySelector(":root") as HTMLDivElement;
	const resizeObserver = new ResizeObserver(() => {
		if (element.value) {
			r.style.setProperty(cssCustomProp, `${element.value.clientHeight}px`);
		}
	});

	onMounted(() => {
		r.style.setProperty(cssCustomProp, `0px`);
		element.value && resizeObserver.observe(element.value);
	});

	onBeforeUnmount(() => {
		element.value && resizeObserver.unobserve(element.value);
		r.style.setProperty(cssCustomProp, `0px`);
	});
}
