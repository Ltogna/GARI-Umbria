import type { DynamicModulesState } from "@abaco/micro-frontend/src/model";
import { dynamicModuleRouteBuilder } from "@abaco/micro-frontend/src/resources/microRouterHelpers";
import { createAbcRouter } from "@abaco/micro-frontend/src/Utility";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { h } from "vue";
import { useI18n } from "vue-i18n";
import type { Router, RouteRecordRaw } from "vue-router";
import OpenUma from "../components/openUma/openUma.vue";
import { BASE, MODULE_ID } from "../constants";
import {
	getHomeUrl,
	isModuleLinkMenuItem,
	isSubMenuItem,
	type MenuItem,
	type MenuRoot,
} from "../utils/menu";
import ChildUserSelectorViewVue from "../views/ChildUserSelectorView.vue";
import HomeDemo from "../views/HomeDemo.vue";
import HomeFragment from "../views/HomeFragment.vue";
import Home from "../views/HomeView.vue";

//export interface DefaultRouteOption {
//  internalRoutes?: RouteRecordRaw[];
//}

const internalRoutes: RouteRecordRaw[] = [
	{
		name: "Home",
		path: BASE + "home",
		component: Home,
	},
	{
		name: "HomeD",
		path: BASE + "home_d",
		component: HomeDemo,
	},
	{
		name: "HomeF",
		path: BASE + "home_f",
		component: HomeFragment,
	},
	{
		name: "RootRedir",
		redirect: BASE + "home",
		path: BASE,
	},
];

const externalRoutes: RouteRecordRaw[] = [
	{
		name: "ChildUserSelector",
		path: BASE + "login/child-user-selector",
		component: ChildUserSelectorViewVue,
		meta: {
			unauthenticated: true,
		},
		props: route => {
			return { redirectTo: route.query.redirectTo };
		},
	},
	{
		name: "OpenUma",
		path: BASE + "open-uma",
		component: OpenUma, // TODO(salvo): creare il componente che stacca i ltoken e fa redirect
	},
	{
		name: "Root",
		path: BASE,
		component: () => import("../views/LoggedView.vue"),
		children: [...internalRoutes],
		meta: { isMain: true },
	},
	{
		name: "NotFoundPage",
		path: BASE + ":catchAll(.*)",
		meta: {
			unauthenticated: true,
		},
		component: {
			render() {
				const { t } = useI18n({});
				return h("h3", {}, t(`${MODULE_ID}.page_not_found`));
			},
		},
	},
];

export async function createRouter(menu: MenuRoot | null): Promise<Router> {
	const routes = externalRoutes;

	let homeUrl = null;
	if (menu) homeUrl = getHomeUrl(menu?.menu);

	if (homeUrl) replaceRootRedir(homeUrl, routes);

	const router = createAbcRouter(routes);

	if (menu) applyMenu(router, menu);

	// eslint-disable-next-line @typescript-eslint/no-unused-vars
	router.beforeEach(async (to, _from) => {
		const userData = getUserData();
		if (userData === null) {
			return {
				name: "ErrorOnLogin",
				query: { errorMessage: "No valid user found" },
			};
		}

		if (userData.isParentUser && to.name != "ChildUserSelector") {
			return {
				name: "ChildUserSelector",
				query: { redirectTo: to.fullPath },
			};
		}
	});

	return router;
}

function replaceRootRedir(homeUrl: string, routes: RouteRecordRaw[]) {
	for (const route of routes) {
		if (route.name === "RootRedir") route.redirect = homeUrl;
		if (route.children) replaceRootRedir(homeUrl, route.children);
	}
}

function applyMenu(router: Router, menu: MenuRoot) {
	const modulesState: DynamicModulesState = { modules: {} };
	collectModuleScripts(menu.menu, modulesState);
	addRoutes(menu.menu, modulesState, "Root", router);
}

function collectModuleScripts(
	menuItems: MenuItem[],
	modulesState: DynamicModulesState
): void {
	menuItems.forEach(item => {
		if (isModuleLinkMenuItem(item)) {
			modulesState.modules[item.id] = {
				url: item.script,
			};
		}
		if (isSubMenuItem(item)) collectModuleScripts(item.submenu, modulesState);
	});
}

function addRoutes(
	menuItems: MenuItem[],
	modulesState: DynamicModulesState,
	mainRouteName: string,
	router: Router
) {
	menuItems.forEach(item => {
		if (isModuleLinkMenuItem(item)) {
			const basePath = (BASE === "/" ? "/portal/" : BASE) + item.id;
			item.startRoute = item.startRoute.endsWith("/")
				? item.startRoute.substring(0, item.startRoute.length - 1)
				: item.startRoute;
			item.startRoute = basePath + item.startRoute;
			const route = dynamicModuleRouteBuilder(item.id, basePath, modulesState);
			if (!router.getRoutes().find(r => r.name === route.name)) {
				router.addRoute(mainRouteName, route);
			}
		}
		if (isSubMenuItem(item))
			addRoutes(item.submenu, modulesState, mainRouteName, router);
	});
}
