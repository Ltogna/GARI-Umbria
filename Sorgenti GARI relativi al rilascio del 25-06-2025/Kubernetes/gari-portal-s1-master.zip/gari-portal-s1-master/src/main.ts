import { createApp } from "vue";
import App from "./App.vue";
import { createRouter } from "./router";

//import "./assets/main.css";
import { getUserData, login, whoAmI } from "@abaco/safe-rest/src/sso2";
import { loadMenu } from "./utils/menu";
import { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";

import "@fortawesome/fontawesome-pro/css/all.css";
import i18n, { loadLocaleMessages } from "./i18n";
import { BASE } from "./constants";

window.bootstrap.loadFonts(
	`${import.meta.env.BASE_URL}bootstrap-italia/dist/fonts`
);
const isDev = import.meta.env.DEV;
if (isDev) console.log("isDev:" + isDev);

async function startApp() {
	let userData = getUserData();

	const url = new URL(window.location.href);
	const customization =
		BASE +
		(url.searchParams.has("customization")
			? url.searchParams.get("customization")
			: "");
	if (isDev) console.log("customizationUrl:", customization);
	if (userData === null) {
		if (isDev)
			await login(
				{ password: "welcome", tenant: "master", username: "admin" },
				"/sso2"
			);
		else await whoAmI("/sso2");
		userData = getUserData();
	}

	if (userData == null) {
		console.error("ErrorOnLogin");
	} else {
		//if (isDev) userData.isParentUser = true;
		await loadLocaleMessages(userData.locale);

		const menu = await loadMenu(userData, new HTTPClient(), customization);

		if (menu) document.title = menu.portalName;

		const router = await createRouter(menu);

		const app = createApp(App);

		app.use(router);
		app.use(i18n);

		app.provide("menu", menu);
		app.provide("customization", customization);

		app.mount("#app");
	}
}

startApp();
