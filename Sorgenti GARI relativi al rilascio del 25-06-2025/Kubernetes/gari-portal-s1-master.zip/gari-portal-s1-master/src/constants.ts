export const BASE: string = import.meta.env.BASE_URL;
export const MODULE_ID: string = "abaco_portal_s1";
