<script lang="ts" setup>
import { getUserData, logout } from "@abaco/safe-rest/src/sso2";
import { inject, ref } from "vue";
import { useI18n } from "vue-i18n";
import MenuCmp from "../components/MenuCmp.vue";
import { useHeightObserver } from "../composables/useHeightObserver";
import { MODULE_ID } from "../constants";
import type { MenuItem, MenuRoot } from "../utils/menu";

const { t } = useI18n({});

//const localMenuItems = ref([] as MenuItemType);
//const route = useRoute();

const userData = getUserData()!;
//const userDescription = getUserData()!.description;

const headerEl = ref<HTMLElement | null>(null);
const cssCustomProp = "--abaco-portal-parent-header-height";
useHeightObserver(cssCustomProp, headerEl);

const menu: MenuRoot = inject("menu")!;
const customization: string = inject("customization")!;
const localMenuItems: MenuItem[] = menu.menu;

//watch(route, initRouteSegments, { deep: true, flush: "post" });

//function initRouteSegments(currentRoute: RouteLocationNormalizedLoaded) {
//    const segments = getItemSegments(localMenuItems.value, currentRoute);
//    routeStore.setRouteSegments(segments);
//}

function getLogoSrc(): string {
	return customization + "gari-logo-tiny.png";
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
async function doLogout() {
	const tenant = userData.tenant;
	await logout(userData.tenant, "/sso2");
	window.location.href = "/?tenant=" + tenant;
}

async function clearSessionStorageAndGoInLogout() {
	window.sessionStorage.removeItem("sso2data");
	window.location.href = "/logout";
}
</script>

<template>
	<header ref="headerEl" class="it-header-wrapper">
		<div
			class="it-header-center-wrapper it-small-header custom-color-header h-100">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="it-header-center-content-wrapper">
							<div class="it-brand-wrapper">
								<a href="/">
									<img class="logo-image" :src="getLogoSrc()" alt="Logo" />
								</a>
							</div>

							<div class="menu-wrapper">
								<ul class="navbar-nav">
									<li :class="{ 'nav-item': true, dropdown: true }">
										<div class="dropdown">
											<a
												class="nav-link dropdown-toggle"
												href="#"
												role="button"
												data-bs-toggle="dropdown"
												aria-expanded="false"
												style="text-decoration: none">
												<div class="user-link-container">
													<i class="fa-solid fa-user mx-2"></i>
													<span>{{ userData.description }}</span>

													<i class="fa-solid fa-angle-down ms-2"></i>
												</div>
											</a>

											<div class="dropdown-menu">
												<div class="link-list-wrapper">
													<ul class="link-list">
														<li>
															<a
																role="button"
																class="nav-link dropdown-item dropdown-submenu-item"
																@click="clearSessionStorageAndGoInLogout()"
																active-class="active">
																<span>{{ t(`${MODULE_ID}.logout`) }}</span>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<MenuCmp :menu-items="localMenuItems" :user-data="userData" />
	</header>
</template>

<style>
.it-header-center-wrapper.custom-color-header {
	background-color: var(--bs-body-bg);
}
.it-header-wrapper {
	width: 100%;
	min-width: fit-content;
}
.logo-image {
	padding-bottom: 10px;
	height: 100px;
}
</style>
