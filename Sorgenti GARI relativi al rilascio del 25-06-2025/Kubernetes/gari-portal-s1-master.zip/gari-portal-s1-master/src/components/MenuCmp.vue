<template>
	<div class="it-header-navbar-wrapper">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<!--start nav-->
					<nav
						class="navbar navbar-expand-lg theme-dark-mobile"
						:aria-label="t(`${MODULE_ID}.main_navigation`)">
						<button
							class="custom-navbar-toggler"
							type="button"
							aria-controls="nav1"
							aria-expanded="false"
							:aria-label="t(`${MODULE_ID}.hide_show_navigation`)"
							data-bs-toggle="navbarcollapsible"
							data-bs-target="#nav1">
							<i class="fa-solid fa-bars fa-lg"></i>
						</button>
						<div class="navbar-collapsable" id="nav1" style="display: none">
							<div class="overlay" style="display: none"></div>
							<div class="close-div">
								<button class="btn close-menu" type="button">
									<span class="visually-hidden">
										{{ t(`${MODULE_ID}.hide_navigation`) }}
									</span>
									<i class="fa-solid fa-xmark fa-2x"></i>
								</button>
							</div>

							<div class="menu-wrapper" v-if="menuReady">
								<ul class="navbar-nav">
									<li
										:class="{ 'nav-item': true, dropdown: isSubMenuItem(item) }"
										v-for="(item, i) in menuItems"
										:key="i">
										<a
											v-if="isExternalLinkMenuItem(item) && item.visibility"
											class="nav-link dropdown-toggle"
											@click="
												openExternalUrl(
													userData,
													item.externalUrl,
													item.externalUrlTarget
												)
											"
											role="button"
											aria-expanded="false"
											style="text-decoration: none">
											{{ item.title }}
										</a>
										<RouterLink
											v-else-if="
												item.visibility &&
												(isBuiltinLinkMenuItem(item) ||
													isModuleLinkMenuItem(item))
											"
											:to="getMenuUrl(item)"
											class="nav-link"
											active-class="active">
											<span>{{ item.title }}</span>
										</RouterLink>
										<div
											v-else-if="item.visibility && isSubMenuItem(item)"
											class="dropdown">
											<a
												class="nav-link dropdown-toggle"
												href="#"
												role="button"
												data-bs-toggle="dropdown"
												aria-expanded="false"
												style="text-decoration: none">
												{{ item.title }}&nbsp;
												<i class="fa-solid fa-angle-down"></i>
											</a>

											<div class="dropdown-menu">
												<div class="link-list-wrapper">
													<ul class="link-list">
														<li
															v-for="(submenuItem, i) in item.submenu"
															:key="i">
															<RouterLink
																v-if="
																	submenuItem.visibility &&
																	(isBuiltinLinkMenuItem(submenuItem) ||
																		isModuleLinkMenuItem(submenuItem))
																"
																:to="getMenuUrl(submenuItem)"
																class="nav-link dropdown-item dropdown-submenu-item"
																active-class="active"
																style="">
																<span>{{ submenuItem.title }}</span>
															</RouterLink>
															<a
																v-if="
																	isExternalLinkMenuItem(submenuItem) &&
																	submenuItem.visibility
																"
																class="nav-link dropdown-item dropdown-submenu-item"
																@click="
																	openExternalUrl(
																		userData,
																		submenuItem.externalUrl,
																		submenuItem.externalUrlTarget
																	)
																"
																role="button"
																aria-expanded="false"
																style="text-decoration: none"
																active-class="active">
																<span>{{ submenuItem.title }}</span>
															</a>
														</li>
													</ul>
												</div>
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</div>
</template>

<script setup lang="ts">
import { getJWTToken, type User } from "@abaco/safe-rest/src/sso2";
import { onMounted, type PropType, ref, toRefs } from "vue";
import { useI18n } from "vue-i18n";
import { http } from "../api/http";
import { MODULE_ID } from "../constants";
import {
	getMenuUrl,
	isBuiltinLinkMenuItem,
	isExternalLinkMenuItem,
	isModuleLinkMenuItem,
	isSubMenuItem,
	type MenuItem,
} from "../utils/menu";

const { t } = useI18n({});

const props = defineProps({
	menuItems: { type: Object as PropType<MenuItem[]>, required: true },
	userData: { type: Object as PropType<User>, required: true },
});

const { menuItems } = toRefs(props);

const menuReady = ref(false);

onMounted(async () => {
	menuReady.value = true;
});

async function openExternalUrl(
	userData: User,
	externalUrl: string | undefined,
	externalUrlTarget: string | undefined
) {
	if (externalUrl) {
		const ssoToken = await getJWTTokenFromState();
		const href = externalUrl
			.replaceAll("{tenant}", userData.tenant)
			.replaceAll("{SSOToken}", ssoToken);
		window.open(href, externalUrlTarget ?? "_blank");
	}
}
async function getJWTTokenFromState() {
	return (await getJWTToken(http)) || "";
}
</script>
