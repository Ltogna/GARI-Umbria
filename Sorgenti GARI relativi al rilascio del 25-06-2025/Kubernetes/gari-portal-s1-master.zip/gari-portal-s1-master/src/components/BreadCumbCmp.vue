<template>
	<header ref="breadEl">
		<div class="container" v-if="routeSegments.length > 0">
			<div class="row">
				<div class="col-md-12">
					<nav
						class="breadcrumb-container"
						aria-label="Percorso di navigazione">
						<ol class="breadcrumb">
							<li v-if="homeMenuItem" class="breadcrumb-item">
								<RouterLink
									:to="
										isModuleLinkMenuItem(homeMenuItem)
											? homeMenuItem.startRoute
											: homeMenuItem.internalUrl
									">
									{{ homeMenuItem.title }}
								</RouterLink>
							</li>
							<li
								v-for="(segment, i) in routeSegments"
								:key="i"
								class="breadcrumb-item active">
								<span class="separator">/</span>
								<a href="#">{{ segment }}</a>
							</li>
						</ol>
					</nav>
				</div>
			</div>
		</div>
	</header>
</template>

<style scoped>
.breadcrumb-container a {
	text-decoration: none;
}
.breadcrumb-container {
	padding-left: 11px;
}
</style>

<script setup lang="ts">
import { onMounted, ref, toRefs, watch, type PropType } from "vue";
import { useRoute, type RouteLocationNormalizedLoaded } from "vue-router";
import {
	isModuleLinkMenuItem,
	isSubMenuItem,
	type BuiltinLinkMenuItem,
	type MenuItem,
	type ModuleLinkMenuItem,
} from "../utils/menu";
import { useHeightObserver } from "../composables/useHeightObserver";

const props = defineProps({
	homeMenuItem: {
		type: Object as PropType<BuiltinLinkMenuItem | ModuleLinkMenuItem | null>,
		required: true,
	},
	menuItems: { type: Object as PropType<MenuItem[]>, required: true },
});

const { menuItems } = toRefs(props);

const breadEl = ref<HTMLElement | null>(null);
const cssCustomProp = "--abaco-portal-breadcumb-height";
useHeightObserver(cssCustomProp, breadEl);

const routeSegments = ref([] as string[]);

const route = useRoute();

watch(route, initRouteSegments, { deep: true, flush: "post" });

function initRouteSegments(currentRoute: RouteLocationNormalizedLoaded) {
	const segments = getItemSegments(menuItems.value, currentRoute);
	routeSegments.value = segments;
}

function getItemSegments(
	localMenuItems: MenuItem[],
	currentRoute: RouteLocationNormalizedLoaded
) {
	const segments: string[] = [];
	const routeName = currentRoute.name;

	if (!routeName) {
		return [];
	}

	const currentMenu = findMenu(localMenuItems, currentRoute);

	if (currentMenu) {
		for (let entry of currentMenu) segments.push(entry.title);
	}

	return segments;
}

function findMenu(
	menuItems: MenuItem[],
	currentRoute: RouteLocationNormalizedLoaded
): MenuItem[] {
	var path: MenuItem[] = [];
	let currentMenu = menuItems.find(
		m =>
			isModuleLinkMenuItem(m) &&
			m.id === currentRoute.name &&
			currentRoute.path.includes(m.startRoute)
	);

	if (currentMenu) {
		path.push(currentMenu);
		return path;
	}

	let i = 0;
	while (i < menuItems.length) {
		const m = menuItems[i];
		if (isSubMenuItem(m)) {
			var foundPath = findMenu(m.submenu, currentRoute);
			if (foundPath.length > 0) {
				path.push(m);
				path = path.concat(foundPath);
				return path;
			}
		}
		i++;
	}

	return path;
}

onMounted(async () => {
	initRouteSegments(route);
});
</script>
