<script setup lang="ts">
// Vue
import { onMounted, ref } from "vue";
import { useI18n } from "vue-i18n";

//Boootstrap Italia components
import { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { MODULE_ID } from "../../constants";
import {
	getGiasToken,
	getGiasUsername,
	type getGiasUsernameResponse,
	type GiasTokenResponse,
} from "../../utils/gias";

// Boootstrap Italia components
// Store

const { t } = useI18n({});

const giasRedirectLink = ref<string>("");
const giasRedirectLinkErrorInBuild = ref<boolean>(false);

const giasUsername = ref<getGiasUsernameResponse>(
	{} as getGiasUsernameResponse
);
const giasToken = ref<GiasTokenResponse>({} as GiasTokenResponse);
const loading = ref<boolean>(true);

onMounted(async () => {
	await openGiasUrl();
	loading.value = false;
});

async function buildAndOpenGiasRedirectLink() {
	if (giasToken.value != null) {
		giasRedirectLinkErrorInBuild.value = false;
		giasRedirectLink.value = giasToken.value.baseURL;
		giasRedirectLink.value += `/Agenda/index.aspx?token=${giasToken.value.token}&username=${giasUsername.value?.username}`;
		window.open(giasRedirectLink.value, "GIAS");
	} else {
		giasRedirectLinkErrorInBuild.value = true;
		alert(t(`${MODULE_ID}.openUma.errors.GIAS_TOKEN_NULL`));
	}
}

async function openGiasUrl() {
	const giasUsernameFn = await getGiasUsername(
		new HTTPClient(),
		`/data-importer/{tenant}/public/v1/gias/user`
	);
	if (giasUsernameFn != null) {
		giasUsername.value = giasUsernameFn;
	}

	giasToken.value = await getGiasToken(new HTTPClient(), `/get-gias-token`);
	await buildAndOpenGiasRedirectLink();
}
</script>

<template>
	<div></div>
</template>
<style scoped></style>
