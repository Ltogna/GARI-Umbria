<script setup lang="ts">
import { inject, onMounted, ref } from "vue";

const htmlContent = ref("");
onMounted(async () => {
	const customization: string = inject("customization")!;

	fetch(customization + "footer_fragment.html")
		.then(response => response.text())
		.then(data => {
			htmlContent.value = data;
		});
});
</script>

<template>
	<footer class="it-footer">
		<div v-html="htmlContent"></div>
	</footer>
</template>
