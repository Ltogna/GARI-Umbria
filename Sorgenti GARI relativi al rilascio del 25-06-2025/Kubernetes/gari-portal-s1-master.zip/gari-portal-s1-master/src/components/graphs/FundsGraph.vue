<template>
	<div style="border: 1px solid gray; padding: 5px">
		<span>Fondi erogati</span>
		<v-chart class="chart" :option="option" :autoresize="true" />
	</div>
</template>

<script lang="ts">
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { PieChart } from "echarts/charts";
import "echarts/lib/component/grid";
import "echarts/lib/component/toolbox";
import { BarChart } from "echarts/charts";
import * as echarts from "echarts";
import {
	TitleComponent,
	TooltipComponent,
	LegendComponent,
} from "echarts/components";
import VChart from "vue-echarts";
import { ref, defineComponent } from "vue";

use([
	CanvasRenderer,
	PieChart,
	TitleComponent,
	TooltipComponent,
	LegendComponent,
]);

export default defineComponent({
	name: "FundsGraph",
	components: {
		VChart,
	},
	setup() {
		(echarts as any).use([BarChart]);
		const option = ref({
			tooltip: {
				trigger: "item",
			},
			legend: {
				top: "5%",
				left: "center",
			},
			series: [
				{
					type: "pie",
					radius: ["40%", "70%"],
					avoidLabelOverlap: false,
					label: {
						show: false,
						position: "center",
					},
					emphasis: {
						label: {
							show: true,
							fontSize: "40",
							fontWeight: "bold",
						},
					},
					labelLine: {
						show: false,
					},
					data: [
						{
							value: 1048,
							name: "Belluno",
							itemStyle: { normal: { color: "#0E426C" } },
						},
						{
							value: 735,
							name: "Padova",
							itemStyle: { normal: { color: "#FFC652" } },
						},
						{
							value: 580,
							name: "Treviso",
							itemStyle: { normal: { color: "#83AE84" } },
						},
						{
							value: 484,
							name: "Venezia",
							itemStyle: { normal: { color: "#ba1045" } },
						},
						{
							value: 300,
							name: "Verona",
							itemStyle: { normal: { color: "#339900" } },
						},
						{
							value: 300,
							name: "Vicenza",
							itemStyle: { normal: { color: "#0099cc" } },
						},
					],

					// markPoint: {
					//     tooltip: { show: false },
					//     label: {
					//         show: true,
					//         formatter: "{b}",
					//         color: "black",
					//         fontSize: 20,
					//     },
					//     data: [
					//         {
					//             name: "320.972.264.84",
					//             value: "-",
					//             symbol: "circle",
					//             itemStyle: { color: "transparent" },
					//             x: "50%",
					//             y: "50%",
					//         },
					//     ],
					// },
				},
			],
		});

		return { option };
	},
});
</script>

<style scoped>
.chart {
	height: 50vh;
}
</style>
