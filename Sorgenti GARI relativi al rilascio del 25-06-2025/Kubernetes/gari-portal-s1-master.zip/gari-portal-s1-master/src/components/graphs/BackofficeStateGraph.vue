<template>
	<div style="border: 1px solid gray; padding: 5px">
		<span>Stato lavorazioni back office</span>
		<v-chart class="chart" :option="option" :autoresize="true" />
	</div>
</template>

<script lang="ts">
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { PieChart } from "echarts/charts";
import "echarts/lib/component/grid";
import "echarts/lib/component/toolbox";
import { BarChart } from "echarts/charts";
import * as echarts from "echarts";
import {
	TitleComponent,
	TooltipComponent,
	LegendComponent,
} from "echarts/components";
import VChart from "vue-echarts";
import { ref, defineComponent } from "vue";

use([
	CanvasRenderer,
	PieChart,
	TitleComponent,
	TooltipComponent,
	LegendComponent,
]);

export default defineComponent({
	name: "BackofficeStateGraph",
	components: {
		VChart,
	},
	setup() {
		(echarts as any).use([BarChart]);
		const option = ref({
			tooltip: {
				trigger: "axis",
				axisPointer: {
					type: "shadow",
				},
			},
			legend: {},
			grid: {
				left: "3%",
				right: "4%",
				bottom: "3%",
				containLabel: true,
			},
			toolbox: {
				show: true,
				orient: "vertical",
				left: "right",
				top: "top",
				feature: {
					mark: { show: false },
					dataView: {
						optionToContent: function (opt: any) {
							const axisData = opt.xAxis[0].data;
							const series = opt.series;
							let table = `<table style="width:100%;text-align:center">
                                    <tbody>
                                        <tr>
                                            <td>Provincia</td>
                                            <td>${series[0].name}</td>
                                            <td>${series[1].name}</td>
                                        </tr>`;
							for (let i = 0, l = axisData.length; i < l; i++) {
								table += `
                                    <tr>
                                        <td>${axisData[i]}</td>
                                        <td>${series[0].data[i]}</td>
                                        <td>${series[1].data[i]}</td>
                                    </tr>
                                `;
							}
							table += "</tbody></table>";
							return table;
						},
					},
					magicType: { show: false, type: ["line", "bar", "stack"] },
					restore: { show: false },
					saveAsImage: { show: true },
				},
			},
			xAxis: [
				{
					type: "category",
					data: [
						"Belluno",
						"Treviso",
						"Padova",
						"Rovigo",
						"Verona",
						"Vicenza",
						"Venezia",
					],
				},
			],
			yAxis: [
				{
					type: "value",
					name: "Parcelle",
				},
			],
			series: [
				{
					name: "Da lavorare",
					type: "bar",
					stack: "Ad",
					label: { show: true },
					labelLayout: {
						hideOverlap: true,
					},
					emphasis: {
						focus: "series",
					},
					itemStyle: { normal: { color: "#ffd966" } },
					data: [100, 200, 120, 400, 300, 150, 70],
				},
				{
					name: "Completate",
					type: "bar",
					stack: "Ad",
					label: { show: true },
					labelLayout: {
						hideOverlap: true,
					},
					emphasis: {
						focus: "series",
					},
					itemStyle: { normal: { color: "#a9d18e" } },
					data: [20, 70, 60, 20, 222, 40, 30],
				},
			],
		});

		return { option };
	},
});
</script>

<style scoped>
.chart {
	height: 50vh;
}
</style>
