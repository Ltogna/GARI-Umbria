<template>
	<div style="border: 1px solid gray; padding: 5px">
		<span>Tot Domande</span>
		<v-chart class="chart" :option="option" :autoresize="true" />
	</div>
</template>

<script lang="ts">
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { PieChart } from "echarts/charts";
import "echarts/lib/component/grid";
import "echarts/lib/component/toolbox";
import { BarChart } from "echarts/charts";
import * as echarts from "echarts";
import {
	TitleComponent,
	TooltipComponent,
	LegendComponent,
} from "echarts/components";
import VChart from "vue-echarts";
import { defineComponent } from "vue";

use([
	CanvasRenderer,
	PieChart,
	TitleComponent,
	TooltipComponent,
	LegendComponent,
]);

export default defineComponent({
	name: "TotalApplicationsGraph",
	components: {
		VChart,
	},
	setup() {
		(echarts as any).use([BarChart]);

		const app: any = {};

		let option = {};

		const posList = [
			"left",
			"right",
			"top",
			"bottom",
			"inside",
			"insideTop",
			"insideLeft",
			"insideRight",
			"insideBottom",
			"insideTopLeft",
			"insideTopRight",
			"insideBottomLeft",
			"insideBottomRight",
		];
		app.configParameters = {
			rotate: {
				min: -90,
				max: 90,
			},
			align: {
				options: {
					left: "left",
					center: "center",
					right: "right",
				},
			},
			verticalAlign: {
				options: {
					top: "top",
					middle: "middle",
					bottom: "bottom",
				},
			},
			position: {
				options: posList.reduce(function (map: any, pos: any) {
					map[pos] = pos;
					return map;
				}, {}),
			},
			distance: {
				min: 0,
				max: 100,
			},
		};
		app.config = {
			rotate: 90,
			align: "left",
			verticalAlign: "middle",
			position: "insideBottom",
			distance: 15,
			onChange: function () {
				const labelOption = {
					rotate: app.config.rotate,
					align: app.config.align,
					verticalAlign: app.config.verticalAlign,
					position: app.config.position,
					distance: app.config.distance,
				};
				this.chartOption = {
					series: [
						{
							label: labelOption,
						},
						{
							label: labelOption,
						},
						{
							label: labelOption,
						},
						{
							label: labelOption,
						},
					],
				};
			},
		};
		const labelOption = {
			show: true,
			position: app.config.position,
			distance: app.config.distance,
			align: app.config.align,
			verticalAlign: app.config.verticalAlign,
			rotate: app.config.rotate,
			formatter: "{c} ",
			fontSize: 16,
			rich: {
				name: {},
			},
		};
		option = {
			tooltip: {
				trigger: "axis",
				axisPointer: {
					type: "shadow",
				},
			},
			legend: {
				data: ["Totali", "Approvate", "Pagate", "Respinte"],
			},
			toolbox: {
				show: true,
				orient: "vertical",
				left: "right",
				top: "top",
				feature: {
					mark: { show: false },
					dataView: { show: true, readOnly: false },
					magicType: { show: false, type: ["line", "bar", "stack"] },
					restore: { show: false },
					saveAsImage: { show: true },
				},
			},
			xAxis: [
				{
					type: "category",
					axisTick: { show: false },
					data: ["2018", "2019", "2020", "2021", "2022"],
				},
			],
			yAxis: [
				{
					type: "value",
				},
			],
			series: [
				{
					name: "Totali",
					type: "bar",
					barGap: 0,
					label: labelOption,
					itemStyle: { normal: { color: "#0E426C" } },
					emphasis: {
						focus: "series",
					},
					data: [3810, 3320, 3010, 3340, 3900],
				},
				{
					name: "Approvate",
					type: "bar",
					label: labelOption,
					itemStyle: { normal: { color: "#83AE84" } },
					emphasis: {
						focus: "series",
					},
					data: [2210, 1820, 1910, 2340, 2900],
				},
				{
					name: "Pagate",
					type: "bar",
					label: labelOption,
					itemStyle: { normal: { color: "#FFC652" } },
					emphasis: {
						focus: "series",
					},
					data: [2210, 1820, 1910, 2340, 2780],
				},
				{
					name: "Respinte",
					type: "bar",
					label: labelOption,
					itemStyle: { normal: { color: "#ba1045" } },
					emphasis: {
						focus: "series",
					},
					data: [1600, 1500, 1100, 1000, 1000],
				},
			],
		};

		return { option };
	},
});
</script>

<style scoped>
.chart {
	height: 50vh;
}
</style>
