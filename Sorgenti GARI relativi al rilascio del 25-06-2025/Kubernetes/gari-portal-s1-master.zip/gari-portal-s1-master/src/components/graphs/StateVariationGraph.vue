<template>
	<div style="border: 1px solid gray; padding: 5px">
		<span>Variazioni di stato</span>
		<v-chart class="chart" :option="option" :autoresize="true" />
	</div>
</template>

<script lang="ts">
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { PieChart } from "echarts/charts";
import "echarts/lib/component/grid";
import "echarts/lib/component/toolbox";
import { LineChart } from "echarts/charts";
import * as echarts from "echarts";
import {
	TitleComponent,
	TooltipComponent,
	LegendComponent,
} from "echarts/components";
import VChart from "vue-echarts";
import { ref, defineComponent } from "vue";

use([
	CanvasRenderer,
	PieChart,
	TitleComponent,
	TooltipComponent,
	LegendComponent,
]);

export default defineComponent({
	name: "StateVariationGraph",
	components: {
		VChart,
	},
	setup() {
		(echarts as any).use([LineChart]);
		const option = ref({
			tooltip: {
				trigger: "axis",
				/* axisPointer: {
                    type: "shadow",
                }, */
			},
			legend: {},
			grid: {
				left: "3%",
				right: "4%",
				bottom: "3%",
				containLabel: true,
			},
			toolbox: {
				show: true,
				orient: "vertical",
				left: "right",
				top: "top",
				feature: {
					mark: { show: false },
					dataView: {
						optionToContent: function (opt: any) {
							const axisData = opt.xAxis[0].data;
							const series = opt.series;
							let table = `<table style="width:100%;text-align:center">
                                    <tbody>
                                        <tr>
                                            <td>Provincia</td>
                                            <td>${series[0].name}</td>
                                            <td>${series[1].name}</td>
                                            <td>${series[2].name}</td>
                                            <td>${series[3].name}</td>
                                            <td>${series[4].name}</td>
                                            <td>${series[5].name}</td>
                                        </tr>`;
							for (let i = 0, l = axisData.length; i < l; i++) {
								table += `
                                    <tr>
                                        <td>${axisData[i]}</td>
                                        <td>${series[0].data[i]}</td>
                                        <td>${series[1].data[i]}</td>
                                        <td>${series[2].data[i]}</td>
                                        <td>${series[3].data[i]}</td>
                                        <td>${series[4].data[i]}</td>
                                        <td>${series[5].data[i]}</td>
                                    </tr>
                                `;
							}
							table += "</tbody></table>";
							return table;
						},
					},
					magicType: { show: false, type: ["line", "bar", "stack"] },
					restore: { show: false },
					saveAsImage: { show: true },
				},
			},
			xAxis: [
				{
					type: "category",
					axisTick: {
						alignWithLabel: true,
					},
					axisLabel: {
						rotate: 30,
					},
					data: [
						"1/1/2023",
						"1/15/2023",
						"2/1/2023",
						"2/15/2023",
						"3/1/2023",
						"3/15/2023",
						"4/1/2023",
					],
				},
			],
			yAxis: [
				{
					type: "value",
					name: "Aziende",
				},
			],
			series: [
				{
					name: "Da iniziare",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#d9d9d9" } },
					areaStyle: {
						color: "#d9d9d9",
						opacity: 1,
					},
					data: [1000, 900, 800, 600, 400, 200, 100],
				},
				{
					name: "In corso",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#ffd966" } },
					areaStyle: {
						color: "#ffd966",
						opacity: 1,
					},
					data: [200, 300, 400, 450, 400, 200, 100],
				},
				{
					name: "Validazione grafica in corso",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#f4b183" } },
					areaStyle: {
						color: "#f4b183",
						opacity: 1,
					},
					data: [10, 20, 5, 30, 50, 60, 80],
				},
				{
					name: "Validazione grafica completata",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#ffc000" } },
					areaStyle: {
						color: "#ffc000",
						opacity: 1,
					},
					data: [20, 40, 10, 60, 100, 120, 160],
				},
				{
					name: "Correttiva anomalie",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#c5e0b4" } },
					areaStyle: {
						color: "#c5e0b4",
						opacity: 1,
					},
					data: [100, 200, 400, 200, 600, 300, 400],
				},
				{
					name: "Completato",
					type: "line",
					stack: "x",
					label: { show: true, position: "insideTop" },
					labelLayout: {
						hideOverlap: true,
					},
					itemStyle: { normal: { color: "#a9d18e" } },
					areaStyle: {
						color: "#a9d18e",
						opacity: 1,
					},
					data: [500, 370, 215, 490, 280, 950, 990],
				},
			],
		});

		return { option };
	},
});
</script>

<style scoped>
.chart {
	height: 50vh;
}
</style>
