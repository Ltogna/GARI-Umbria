<template>
	<div style="border: 1px solid gray; padding: 5px">
		<span>N° Domande</span>
		<v-chart class="chart" :option="option" :autoresize="true" />
	</div>
</template>

<script lang="ts">
import { use } from "echarts/core";
import { CanvasRenderer } from "echarts/renderers";
import { PieChart } from "echarts/charts";
import "echarts/lib/component/grid";
import "echarts/lib/component/toolbox";
import { BarChart } from "echarts/charts";
import * as echarts from "echarts";
import {
	TitleComponent,
	TooltipComponent,
	LegendComponent,
} from "echarts/components";
import VChart from "vue-echarts";
import { ref, defineComponent } from "vue";

use([
	CanvasRenderer,
	PieChart,
	TitleComponent,
	TooltipComponent,
	LegendComponent,
]);

export default defineComponent({
	name: "ApplicationsGraph",
	components: {
		VChart,
	},
	setup() {
		(echarts as any).use([BarChart]);
		const option = ref({
			toolbox: {
				show: true,
				orient: "vertical",
				left: "right",
				top: "top",
				feature: {
					mark: { show: true },
					dataView: { show: true, readOnly: false },
					saveAsImage: { show: true },
				},
			},
			tooltip: {
				trigger: "item",
			},
			legend: {
				orient: "vertical",
				left: "5%",
				top: "5%",
			},
			series: [
				{
					top: "50%",
					type: "pie",
					radius: "99%",
					data: [
						{
							value: 87,
							name: "DICHIARAZIONE DI PRODUZIONE",
							itemStyle: { normal: { color: "#FFC652" } },
						},
						{ value: 5, name: "DICHIARAZIONE PREVENTIVA" },
						{ value: 7155, name: "GESTIONE TITOLI" },
						{
							value: 64217,
							name: "PAGAMENTI DIRETTI - SDS",
							itemStyle: { normal: { color: "#0E426C" } },
						},
						{
							value: 64876,
							name: "PAGAMENTI DIRETTI E PROGRAMMA DI SVILUPPO RURALE (2014-2020)",
						},
						{
							value: 13150,
							name: "PSR ISTRUTTORIA (2014-2020)",
							itemStyle: { normal: { color: "#ba1045" } },
						},
						{
							value: 1491,
							name: "RISTRUTTURAZIONE E RICONVERSIONE DEI VIGNETI",
						},
						{ value: 48538, name: "UMA" },
					],
					emphasis: {
						itemStyle: {
							shadowBlur: 10,
							shadowOffsetX: 0,
							shadowColor: "rgba(0, 0, 0, 0.5)",
						},
					},
					label: {
						show: false,
						position: "center",
					},
				},
			],
		});

		return { option };
	},
});
</script>

<style scoped>
.chart {
	height: 50vh;
}
</style>
