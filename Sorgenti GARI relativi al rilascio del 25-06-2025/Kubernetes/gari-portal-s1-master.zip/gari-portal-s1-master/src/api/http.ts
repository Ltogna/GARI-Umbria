import { HTTPClient } from "@abaco/safe-rest/src/HTTPClient";
import { installSso2RequestConfigProvider } from "@abaco/safe-rest/src/sso2";

const SSO2_BASE_URL = "/sso2";
const unauthenticatedHttp = new HTTPClient();

const http = new HTTPClient();
installSso2RequestConfigProvider(http, SSO2_BASE_URL);

export { http, unauthenticatedHttp, SSO2_BASE_URL };
