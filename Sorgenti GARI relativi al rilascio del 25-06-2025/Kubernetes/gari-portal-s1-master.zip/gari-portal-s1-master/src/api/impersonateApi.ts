import type { HttpJsonResult } from "@abaco/safe-rest/src/HTTPClient";
import {
	getNextPagedResultsSchema,
	type NextPagedResults,
} from "@abaco/safe-rest/src/pagination";
import { impersonate } from "@abaco/safe-rest/src/sso2";
import { z } from "zod";
import { http } from "./http";

// const ImpersonationRequestSchema = z.object({
//     userid: z.string()
// });

const ChildUserSchema = z.object({
	descr: z.string(),
	tenant: z.string(),
	userid: z.string(),
	username: z.string(),
});

export type ChildUser = z.infer<typeof ChildUserSchema>;

export async function getChildrenForUser(
	tenantId: string,
	nextKey?: string,
	filter?: string
): Promise<HttpJsonResult<NextPagedResults<ChildUser>>> {
	const params: any = {};
	if (nextKey) {
		params.nextKey = nextKey;
	}
	if (filter) {
		params.filter = filter;
	}
	const res = await http.getJson(
		getNextPagedResultsSchema(ChildUserSchema),
		`/sso2/${tenantId}/public/v1/impersonation`,
		{ params }
	);
	return res;
}

export async function doImpersonate(tenantId: string, userid: string) {
	return await impersonate(tenantId, "/sso2", { userid });
}
