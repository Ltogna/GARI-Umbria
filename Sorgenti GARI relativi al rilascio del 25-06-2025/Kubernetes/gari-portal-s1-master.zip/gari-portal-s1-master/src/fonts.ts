import { BASE } from "./constants";

(window as any).__PUBLIC_PATH__ = BASE + "bootstrap-italia/dist/fonts";
