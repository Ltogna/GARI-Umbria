<template>
	<div v-html="htmlContent"></div>
</template>

<script setup lang="ts">
import { inject, onMounted, ref } from "vue";

const htmlContent = ref("");
onMounted(async () => {
	const customization: string = inject("customization")!;
	fetch(customization + "home_fragment.html")
		.then(response => response.text())
		.then(data => {
			htmlContent.value = data;
		});
});
</script>
