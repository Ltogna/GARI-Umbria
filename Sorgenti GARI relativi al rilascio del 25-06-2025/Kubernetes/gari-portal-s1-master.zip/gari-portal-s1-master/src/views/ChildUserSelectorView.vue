<script setup lang="ts">
import { ErrorType } from "@abaco/safe-rest/src/HTTPClient";
import { getUserData } from "@abaco/safe-rest/src/sso2";
import { onMounted, ref } from "vue";
import {
	type ChildUser,
	getChildrenForUser,
	doImpersonate,
} from "../api/impersonateApi";
import { useI18n } from "vue-i18n";
import { MODULE_ID } from "../constants";

const { t } = useI18n({});

const children = ref<ChildUser[]>([]);
const selectedChild = ref<ChildUser | null>(null);
const loading = ref(false);

const props = defineProps(["redirectTo"]);

const isDev = import.meta.env.DEV;

onMounted(() => {
	getChildren();
});

async function getChildren() {
	loading.value = true;
	if (!isDev) {
		const res = await getChildrenForUser(getUserData()!.tenant);

		if (res.errorType == ErrorType.NONE) {
			children.value = res.data.records;
		} else {
			console.error(res);
		}
	} else {
		const userData = getUserData()!;
		children.value = [
			{
				descr: "11111111",
				tenant: userData.tenant,
				userid: userData.user_id + "1",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr: "222222222",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
			{
				descr:
					"222222222 askdòhf òasdlkhf òlaskdf hàasidhf alisdf iwqàfoiwqhfcskdah fàlaksd psdihf asdf hbaslkdfhasoid fasipodhf alksdbfalksdhf saodfd",
				tenant: userData.tenant,
				userid: userData.user_id + "2",
				username: userData.username,
			},
		];
	}
	loading.value = false;
}

const selectChild = (child: ChildUser) => {
	selectedChild.value = child;
};

const callImpersonate = async () => {
	loading.value = true;
	let userData;
	if (selectedChild.value) {
		const response = await doImpersonate(
			getUserData()!.tenant,
			selectedChild.value.userid
		);
		if (response.errorType != ErrorType.NONE) {
			console.error(response);
			return {
				name: "_Login",
				query: { externalError: "Invalid token provided" },
			};
		}
		userData = getUserData();
	}
	loading.value = false;
	if (userData != null && props.redirectTo) {
		//router.push({ name: props.redirectTo });
		//not router.push... the app must reload!
		window.location.href = props.redirectTo;
	}
};
</script>

<template>
	<main class="w-50 min-vh-100 mx-auto d-flex align-items-center">
		<div class="container my-5">
			<div class="card-wrapper card-space">
				<div class="card card-bg rounded">
					<div class="card-body">
						<h1 class="h3 mb-3 fw-normal">
							{{ t(`${MODULE_ID}.select_child_user`) }}
						</h1>
						<div class="it-list-wrapper">
							<ul class="it-list">
								<li v-for="(child, itemObjKey) in children" :key="itemObjKey">
									<div class="form-check">
										<input
											name="gruppo1"
											type="radio"
											:id="'radio' + itemObjKey"
											@click="selectChild(child)" />
										<label :for="'radio' + itemObjKey">{{ child.descr }}</label>
									</div>
								</li>
							</ul>
						</div>

						<button
							class="w-100 btn btn-lg btn-primary mt-4"
							:disabled="loading"
							@click="callImpersonate()">
							{{ t(`${MODULE_ID}.confirm_profile`) }}
						</button>
					</div>
				</div>
			</div>
		</div>
	</main>
</template>
