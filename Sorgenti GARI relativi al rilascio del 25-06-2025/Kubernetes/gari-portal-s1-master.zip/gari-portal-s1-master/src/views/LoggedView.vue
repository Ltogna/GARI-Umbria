<script setup lang="ts">
import ParentHeader from "../components/ParentHeader.vue";
import ParentFooter from "../components/ParentFooter.vue";
import BreadCumbCmp from "../components/BreadCumbCmp.vue";
import type { MenuRoot } from "../utils/menu";
import { getHomeMenuItem } from "../utils/menu";
import { inject } from "vue";

const menu: MenuRoot = inject("menu")!;
</script>

<template>
	<div>
		<ParentHeader />
		<div class="flex-wrapper">
			<div class="container">
				<BreadCumbCmp
					:home-menu-item="getHomeMenuItem(menu.menu)"
					:menu-items="menu.menu" />
				<router-view class="container" />
			</div>
			<ParentFooter />
		</div>

		<a
			href="#"
			aria-hidden="true"
			tabindex="-1"
			data-bs-toggle="backtotop"
			class="back-to-top return-to-top-page-link">
			<i class="return-to-top-page-link__icon fa-solid fa-arrow-up fa-lg"></i>
		</a>
	</div>
</template>

<style scoped>
.return-to-top-page-link {
	color: var(--bs-white);
}
.return-to-top-page-link:link {
	color: var(--bs-white);
}
.return-to-top-page-link__icon {
	position: absolute;
	left: 50%;
	top: 50%;
	translate: -50% -50%;
}

.flex-wrapper {
	display: flex;
	min-height: calc(100vh - 161px);
	flex-direction: column;
	justify-content: space-between;
}
</style>
