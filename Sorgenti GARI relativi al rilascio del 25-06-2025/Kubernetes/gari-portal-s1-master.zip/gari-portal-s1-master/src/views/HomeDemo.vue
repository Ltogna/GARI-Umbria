<template>
	&nbsp;
	<section>
		<div class="container">
			<div class="row g-4 mb-4">
				<div class="col-md-6">
					<article class="scheda scheda-round">
						<ProvinceAlignmentGraph />
					</article>
				</div>
				<div class="col-md-6">
					<article class="scheda scheda-round">
						<StateVariationGraph />
					</article>
				</div>
				<div class="col-md-6">
					<article class="scheda scheda-round">
						<BackofficeStateGraph />
					</article>
				</div>
				<div class="col-md-6">
					<article class="scheda scheda-round">
						<!--  -->
					</article>
				</div>
			</div>
		</div>
	</section>
</template>

<script lang="ts">
import ProvinceAlignmentGraph from "../components/graphs/ProvinceAlignmentGraph.vue";
import StateVariationGraph from "../components/graphs/StateVariationGraph.vue";
import BackofficeStateGraph from "../components/graphs/BackofficeStateGraph.vue";

export default {
	components: {
		ProvinceAlignmentGraph,
		StateVariationGraph,
		BackofficeStateGraph,
	},
};
</script>
