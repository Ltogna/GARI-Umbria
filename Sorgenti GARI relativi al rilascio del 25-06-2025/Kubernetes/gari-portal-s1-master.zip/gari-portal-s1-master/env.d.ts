/// <reference types="vite/client" />
import type * as BootstrapItalia from "bootstrap-italia";

declare global {
    interface Window {
        bootstrap: typeof BootstrapItalia;
    }
}
