import { fileURLToPath, URL } from "node:url";

import vue from "@vitejs/plugin-vue";
import { defineConfig } from "vite";
import { viteStaticCopy } from "vite-plugin-static-copy";

export default defineConfig({
    base: "/",
    plugins: [
        viteStaticCopy({
            targets: [
                {
                    src: "node_modules/bootstrap-italia/dist/**/*",
                    dest: "bootstrap-italia/dist"
                }
            ]
        }),
        vue()
    ],
    build: {
        rollupOptions: {
            external: ["/bootstrap-italia/dist/js/bootstrap-italia.bundle.min.js", "/css/main.css"]
        }
    },
    resolve: {
        alias: {
            "@": fileURLToPath(new URL("./src", import.meta.url))
        }
    },

    server: {
        proxy: {
            "/sso2": {
                target: "https://iacs-dev.fe.abacogroup.eu",
                secure: false,
                changeOrigin: true
            },
            "/ui": {
                target: "https://iacs-dev.fe.abacogroup.eu",
                changeOrigin: true
            },
            "/sso2-login": {
                target: "https://iacs-dev.fe.abacogroup.eu",
                changeOrigin: true
            },
            "/lpis-server-api": {
                target: "https://iacs-dev.fe.abacogroup.eu",
                changeOrigin: true
            },
			"/data-importer": {
				target: "https://umbria-dev.fe.abacogroup.eu/",
				// target: "http://localhost:8080",
				secure: false,
				changeOrigin: true,
			},
        }
    }
});
